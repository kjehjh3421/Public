//
// Tizen C++ SDK
// Copyright (c) 2012-2013 Samsung Electronics Co., Ltd.
//
// Licensed under the Flora License, Version 1.1 (the License);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://floralicense.org/license/
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an AS IS BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#ifndef _PANEL2_H_
#define _PANEL2_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>

class Panel2
	: public Tizen::Ui::Controls::Panel
	, public Tizen::Ui::IActionEventListener
	, public Tizen::Base::Runtime::ITimerEventListener
	, public Tizen::Ui::Controls::IIconListViewItemProvider
{
public:
	Panel2(void);
	virtual ~Panel2(void);

	result Construct(Tizen::Graphics::Rectangle rect);

	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);
	virtual void OnTimerExpired(Tizen::Base::Runtime::Timer& timer);

	//IIconListViewItemProvider
	virtual Tizen::Ui::Controls::IconListViewItem* CreateItem(int index);
	virtual bool DeleteItem(int index, Tizen::Ui::Controls::IconListViewItem* pItem);
	virtual int GetItemCount(void);

	virtual void OnBackGround(void);
	virtual void OnForeGround(void);

private:
	typedef enum
	{
		TIMER_INIT,
		TIMER_START,
		TIMER_STOP
	} TimerStatus;

	TimerStatus __timerStatus;

	static const int ID_BUTTON_START = 101;
	static const int ID_BUTTON_STOP = 102;
	static const int INTERVAL = 500/8;
	static const int ITEM_COUNT = 3;
	static const int PROGRESS_COUNT = 30;
	static const int ICONLIST_ITEM_COUNT = 20;

	int __progress;
	int __timerFlag;

	Tizen::Ui::Controls::IconListView* __pIconList;
	Tizen::Base::Runtime::Timer* __pTimer;
	Tizen::Graphics::Bitmap* __pItemBitmap[ITEM_COUNT];
	Tizen::Graphics::Bitmap* __pProgressBitmap[PROGRESS_COUNT];

	Tizen::Ui::Controls::Button* __pStartButton;
	Tizen::Ui::Controls::Button* __pStopButton;
};

#endif // _PANEL2_H_
