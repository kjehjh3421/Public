//
// Tizen C++ SDK
// Copyright (c) 2012-2013 Samsung Electronics Co., Ltd.
//
// Licensed under the Flora License, Version 1.1 (the License);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://floralicense.org/license/
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an AS IS BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#ifndef _PANEL3_H_
#define _PANEL3_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>

class Panel3
	: public Tizen::Ui::Controls::Panel
	, public Tizen::Ui::IActionEventListener
	, public Tizen::Base::Runtime::ITimerEventListener
	, public Tizen::Ui::Controls::IListViewItemProvider
{
public:
	Panel3(void);
	virtual ~Panel3(void);

	result Construct(Tizen::Graphics::Rectangle rect);

	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);
	virtual void OnTimerExpired(Tizen::Base::Runtime::Timer& timer);

	//IListViewItemProvider
	virtual Tizen::Ui::Controls::ListItemBase* CreateItem(int index, int itemWidth);
	virtual bool DeleteItem(int index, Tizen::Ui::Controls::ListItemBase* pItem, int itemWidth);
	virtual int GetItemCount(void);

	virtual void OnBackGround(void);
	virtual void OnForeGround(void);

private:
	typedef enum
	{
		TIMER_INIT,
		TIMER_START,
		TIMER_STOP
	} TimerStatus;

	TimerStatus __timerStatus;

	static const int ID_OPTIONKEY = 100;
	static const int ID_FORM1 = 200;
	static const int ID_FORM2 = 201;
	static const int ID_FORM3 = 202;
	static const int ID_BUTTON_START = 301;
	static const int ID_BUTTON_STOP = 302;
	static const int ID_FORMAT_STRING = 500;
	static const int ID_FORMAT_BITMAP = 501;
	static const int ID_CUSTOMLIST_ITEM1 = 504;
	static const int ID_CUSTOMLIST_ITEM2 = 505;
	static const int ID_CUSTOMLIST_ITEM3 = 506;
	static const int ID_CUSTOMLIST_ITEM4 = 507;
	static const int ID_CUSTOMLIST_ITEM5 = 508;
	static const int ID_CUSTOMLIST_ITEM6 = 509;
	static const int INTERVAL = 500/8;
	static const int PROGRESS_COUNT = 30;
	static const int LIST_ITEM_COUNT = 10;
	static const int LIST_STYLE_COUNT = 3;

	int __progress;
	int __timerFlag;

	Tizen::Ui::Controls::ListView* __pListView;
	Tizen::Base::Runtime::Timer* __pTimer;
	Tizen::Graphics::Bitmap* __pHome;
	Tizen::Graphics::Bitmap* __pMsg;
	Tizen::Graphics::Bitmap* __pAlarm;
	Tizen::Graphics::Bitmap* __pHome_focused;
	Tizen::Graphics::Bitmap* __pMsg_focused;
	Tizen::Graphics::Bitmap* __pAlarm_focused;
	Tizen::Graphics::Bitmap* __pProgressBitmap[PROGRESS_COUNT];

	Tizen::Ui::Controls::Button* __pStartButton;
	Tizen::Ui::Controls::Button* __pStopButton;
};

#endif // _PANEL3_H_
