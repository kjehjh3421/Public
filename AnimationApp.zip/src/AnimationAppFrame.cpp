#include "AnimationAppFrame.h"
#include "MainForm.h"

using namespace Tizen::Base;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;

AnimationAppFrame::AnimationAppFrame(void)
{
}

AnimationAppFrame::~AnimationAppFrame(void)
{
}

result
AnimationAppFrame::OnInitializing(void)
{
	result r = E_SUCCESS;

	// Create a form
	MainForm* pMainForm = new MainForm();
	pMainForm->Initialize();

	// Add the form to the frame
	AddControl(pMainForm);

	// Set the current form
	SetCurrentForm(pMainForm);

	// Draw the form
	pMainForm->Invalidate(true);

	// TODO: Add your initialization code here

	return r;
}

result
AnimationAppFrame::OnTerminating(void)
{
	result r = E_SUCCESS;

	// TODO: Add your termination code here

	return r;
}


