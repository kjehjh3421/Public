//
// Tizen C++ SDK
// Copyright (c) 2012-2013 Samsung Electronics Co., Ltd.
//
// Licensed under the Flora License, Version 1.1 (the License);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://floralicense.org/license/
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an AS IS BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#include "MainForm.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;

MainForm::MainForm(void)
{
}

MainForm::~MainForm(void)
{
}

bool
MainForm::Initialize(void)
{
	Form::Construct(FORM_STYLE_NORMAL | FORM_STYLE_PORTRAIT_INDICATOR | FORM_STYLE_HEADER);

	return true;
}

result
MainForm::OnInitializing(void)
{
	result r = E_SUCCESS;

	Header * pHeader = GetHeader();
	if (pHeader != null)
	{
		HeaderItem  headerItem1;
		headerItem1.Construct(ID_HEADER_ITEM1);
		headerItem1.SetText("Panel 1");

		HeaderItem  headerItem2;
		headerItem2.Construct(ID_HEADER_ITEM2);
		headerItem2.SetText("Panel 2");

		HeaderItem  headerItem3;
		headerItem3.Construct(ID_HEADER_ITEM3);
		headerItem3.SetText("Panel 3");

		pHeader->SetStyle(HEADER_STYLE_TAB);
		pHeader->AddItem(headerItem1);
		pHeader->AddItem(headerItem2);
		pHeader->AddItem(headerItem3);
		pHeader->AddActionEventListener(*this);
	}

	SetFormBackEventListener(this);

	Rectangle clientRect= GetClientAreaBounds();
	Rectangle rect(0,0,clientRect.width,clientRect.height);

	__pPanel1 = new (std::nothrow) Panel1();
	__pPanel1->Construct(rect);
	AddControl(__pPanel1);

	__pPanel2 = new (std::nothrow) Panel2();
	__pPanel2->Construct(rect);
	__pPanel2->SetShowState(false);
	AddControl(__pPanel2);

	__pPanel3 = new (std::nothrow) Panel3();
	__pPanel3->Construct(rect);
	__pPanel3->SetShowState(false);
	AddControl(__pPanel3);

	return r;
}

result
MainForm::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
MainForm::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	switch(actionId)
	{
	case ID_HEADER_ITEM1:
		__pPanel1->SetShowState(true);
		__pPanel2->SetShowState(false);
		__pPanel3->SetShowState(false);
		break;
	case ID_HEADER_ITEM2:
		__pPanel1->SetShowState(false);
		__pPanel2->SetShowState(true);
		__pPanel3->SetShowState(false);
		break;
	case ID_HEADER_ITEM3:
		__pPanel1->SetShowState(false);
		__pPanel2->SetShowState(false);
		__pPanel3->SetShowState(true);
		break;
	default:
		break;
	}

	Draw();
}

void
MainForm::OnFormBackRequested(Form& source)
{
	UiApp* pApp = UiApp::GetInstance();
	AppAssert(pApp);
	pApp->Terminate();
}

void
MainForm::OnForeGround(void)
{
	__pPanel1->OnForeGround();
	__pPanel2->OnForeGround();
	__pPanel3->OnForeGround();
}

void
MainForm::OnBackGround(void)
{
	__pPanel1->OnBackGround();
	__pPanel2->OnBackGround();
	__pPanel3->OnBackGround();
}
