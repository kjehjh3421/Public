//
// Tizen C++ SDK
// Copyright (c) 2012-2013 Samsung Electronics Co., Ltd.
//
// Licensed under the Flora License, Version 1.1 (the License);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://floralicense.org/license/
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an AS IS BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#include "Panel2.h"
#include <FApp.h>

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Base::Runtime;

Panel2::Panel2(void)
	: __timerStatus(TIMER_INIT)
	, __progress(0)
	, __timerFlag(0)
	, __pIconList(null)
	, __pTimer(null)
	, __pStartButton(null)
	, __pStopButton(null)
{

}
Panel2::~Panel2(void)
{
	delete __pTimer;

	for (int i = 0; i < ITEM_COUNT; i++)
	{
		delete __pItemBitmap[i];
	}

	for (int i = 0; i < PROGRESS_COUNT; i++)
	{
		delete __pProgressBitmap[i];
	}
}

result
Panel2::Construct(Tizen::Graphics::Rectangle rect)
{
	result r = E_SUCCESS;
	Panel::Construct(rect);

	// Create a Start Button
	__pStartButton = new (std::nothrow) Button();
	__pStartButton->Construct(Rectangle(20, rect.height-64, 210, 50));
	__pStartButton->SetText(L"Start");
	__pStartButton->SetActionId(ID_BUTTON_START);
	__pStartButton->AddActionEventListener(*this);
	AddControl(__pStartButton);

	// Create a Stop Button
	__pStopButton = new (std::nothrow) Button();
	__pStopButton->Construct(Rectangle(250, rect.height-64, 210, 50));
	__pStopButton->SetText(L"Stop");
	__pStopButton->SetActionId(ID_BUTTON_STOP);
	__pStopButton->AddActionEventListener(*this);
	__pStopButton->SetEnabled(false);
	AddControl(__pStopButton);

	AppResource *pAppResource = Application::GetInstance()->GetAppResource();
	// Create Bitmap

	if (pAppResource != null)
	{
		__pItemBitmap[0] = pAppResource->GetBitmapN(L"home_type4.png");
		__pItemBitmap[1] = pAppResource->GetBitmapN(L"message_type4.png");
		__pItemBitmap[2] = pAppResource->GetBitmapN(L"alarm_type4.png");

		__pProgressBitmap[0] = pAppResource->GetBitmapN("00_list_process_01.png");
		__pProgressBitmap[1] = pAppResource->GetBitmapN("00_list_process_02.png");
		__pProgressBitmap[2] = pAppResource->GetBitmapN("00_list_process_03.png");
		__pProgressBitmap[3] = pAppResource->GetBitmapN("00_list_process_04.png");
		__pProgressBitmap[4] = pAppResource->GetBitmapN("00_list_process_05.png");
		__pProgressBitmap[5] = pAppResource->GetBitmapN("00_list_process_06.png");
		__pProgressBitmap[6] = pAppResource->GetBitmapN("00_list_process_07.png");
		__pProgressBitmap[7] = pAppResource->GetBitmapN("00_list_process_08.png");
		__pProgressBitmap[8] = pAppResource->GetBitmapN("00_list_process_09.png");
		__pProgressBitmap[9] = pAppResource->GetBitmapN("00_list_process_10.png");
		__pProgressBitmap[10] = pAppResource->GetBitmapN("00_list_process_11.png");
		__pProgressBitmap[11] = pAppResource->GetBitmapN("00_list_process_12.png");
		__pProgressBitmap[12] = pAppResource->GetBitmapN("00_list_process_13.png");
		__pProgressBitmap[13] = pAppResource->GetBitmapN("00_list_process_14.png");
		__pProgressBitmap[14] = pAppResource->GetBitmapN("00_list_process_15.png");
		__pProgressBitmap[15] = pAppResource->GetBitmapN("00_list_process_16.png");
		__pProgressBitmap[16] = pAppResource->GetBitmapN("00_list_process_17.png");
		__pProgressBitmap[17] = pAppResource->GetBitmapN("00_list_process_18.png");
		__pProgressBitmap[18] = pAppResource->GetBitmapN("00_list_process_19.png");
		__pProgressBitmap[19] = pAppResource->GetBitmapN("00_list_process_20.png");
		__pProgressBitmap[20] = pAppResource->GetBitmapN("00_list_process_21.png");
		__pProgressBitmap[21] = pAppResource->GetBitmapN("00_list_process_22.png");
		__pProgressBitmap[22] = pAppResource->GetBitmapN("00_list_process_23.png");
		__pProgressBitmap[23] = pAppResource->GetBitmapN("00_list_process_24.png");
		__pProgressBitmap[24] = pAppResource->GetBitmapN("00_list_process_25.png");
		__pProgressBitmap[25] = pAppResource->GetBitmapN("00_list_process_26.png");
		__pProgressBitmap[26] = pAppResource->GetBitmapN("00_list_process_27.png");
		__pProgressBitmap[27] = pAppResource->GetBitmapN("00_list_process_28.png");
		__pProgressBitmap[28] = pAppResource->GetBitmapN("00_list_process_29.png");
		__pProgressBitmap[29] = pAppResource->GetBitmapN("00_list_process_30.png");
	}

	// Create Timer
	__pTimer = new (std::nothrow) Timer();
	__pTimer->Construct(*this);

	// Create a IconList
	__pIconList = new (std::nothrow) IconListView;
	__pIconList->Construct(Rectangle(0, 0, rect.width, rect.height-100), Dimension(96, 96), ICON_LIST_VIEW_STYLE_NORMAL , ICON_LIST_VIEW_SCROLL_DIRECTION_VERTICAL);
	__pIconList->SetItemBorderStyle( ICON_LIST_VIEW_ITEM_BORDER_STYLE_OUTLINE );

	__pIconList->SetItemProvider(*this);
	AddControl(__pIconList);

	return r;
}

void
Panel2::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	switch(actionId)
	{
	case ID_BUTTON_START:
		if (TIMER_START != __timerStatus)
		{
			__pStartButton->SetEnabled(false);
			__pStopButton->SetEnabled(true);

			__timerStatus = TIMER_START;
			__pTimer->Start(INTERVAL);
		}
		break;
	case ID_BUTTON_STOP:
		__pStartButton->SetEnabled(true);
		__pStopButton->SetEnabled(false);

		__timerStatus = TIMER_STOP;
		break;
	}
	Draw();
}

void
Panel2::OnTimerExpired(Timer &  timer)
{
	if(__timerStatus == TIMER_STOP)
	{
		__progress = 0;
		__pStartButton->SetEnabled(true);
		__pStopButton->SetEnabled(false);

		Draw();

		return;
	}

	result r = __pTimer->Start(INTERVAL);
	TryReturnVoid(!IsFailed(r), "Timer Start Fail.");

	__pIconList->RefreshList(0, LIST_REFRESH_TYPE_ITEM_MODIFY);

	__pStartButton->SetEnabled(false);
	__pStopButton->SetEnabled(true);

	Draw();
}

Tizen::Ui::Controls::IconListViewItem*
Panel2::CreateItem(int index)
{
	String itemText;
	IconListViewItem* pIconListview = new (std::nothrow) IconListViewItem();

	if (index == 0 && __timerStatus == TIMER_START)
	{
		itemText = "Animating";
		int index = __progress % PROGRESS_COUNT;
		pIconListview->Construct(*__pProgressBitmap[index], &itemText);
		__progress++;

		return pIconListview;
	}
	else
	{
		itemText = "Icon";
		switch (index % ITEM_COUNT)
		{
		case 0:
			pIconListview->Construct(*__pItemBitmap[0], &itemText);
			break;
		case 1:
			pIconListview->Construct(*__pItemBitmap[1], &itemText);
			break;
		case 2:
			pIconListview->Construct(*__pItemBitmap[2], &itemText);
			break;
		}

		return pIconListview;
	}
}

bool
Panel2::DeleteItem(int index, Tizen::Ui::Controls::IconListViewItem* pItem)
{
	delete pItem;
	return true;
}

int
Panel2::GetItemCount(void)
{
	return ICONLIST_ITEM_COUNT;
}

void
Panel2::OnForeGround(void)
{
	if (__timerStatus == TIMER_STOP && __timerFlag ==1)
	{
		__timerStatus = TIMER_START;
		__pTimer->Start(INTERVAL);
		__timerFlag = 0;
	}
}

void
Panel2::OnBackGround(void)
{
	if (__timerStatus == TIMER_START)
	{
		__timerStatus = TIMER_STOP;
		__timerFlag = 1;
	}
}
