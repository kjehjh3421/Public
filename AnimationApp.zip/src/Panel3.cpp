//
// Tizen C++ SDK
// Copyright (c) 2012-2013 Samsung Electronics Co., Ltd.
//
// Licensed under the Flora License, Version 1.1 (the License);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://floralicense.org/license/
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an AS IS BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#include "Panel3.h"
#include <FApp.h>

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Base::Runtime;

static const Rectangle BITMAP_RECT(10, 7, 60, 60);
static const Rectangle STRING_RECT(80, 12, 200, 50);

Panel3::Panel3(void)
	: __timerStatus(TIMER_INIT)
	, __progress(0)
	, __timerFlag(0)
	, __pListView(null)
	, __pTimer(null)
	, __pStartButton(null)
	, __pStopButton(null)
{

}
Panel3::~Panel3(void)
{
	delete __pTimer;
	delete __pHome;
	delete __pMsg;
	delete __pAlarm;

	for (int i = 0; i < PROGRESS_COUNT; i++)
	{
		delete __pProgressBitmap[i];
	}
}

result
Panel3::Construct(Tizen::Graphics::Rectangle rect)
{
	Panel::Construct(rect);

	// Create a Start Button
	__pStartButton = new (std::nothrow) Button();
	__pStartButton->Construct(Rectangle(20, rect.height-64, 210, 50));
	__pStartButton->SetText(L"Start");
	__pStartButton->SetActionId(ID_BUTTON_START);
	__pStartButton->AddActionEventListener(*this);
	AddControl(__pStartButton);

	// Create a Stop Button
	__pStopButton = new (std::nothrow) Button();
	__pStopButton->Construct(Rectangle(250, rect.height-64, 210, 50));
	__pStopButton->SetText(L"Stop");
	__pStopButton->SetActionId(ID_BUTTON_STOP);
	__pStopButton->AddActionEventListener(*this);
	__pStopButton->SetEnabled(false);
	AddControl(__pStopButton);

	AppResource *pAppResource = Application::GetInstance()->GetAppResource();
	// Create Bitmap
	if (pAppResource != null)
	{
		__pHome = pAppResource->GetBitmapN(L"home_type3.png");
		__pMsg = pAppResource->GetBitmapN(L"message_type3.png");
		__pAlarm = pAppResource->GetBitmapN(L"alarm_type3.png");

		__pProgressBitmap[0] = pAppResource->GetBitmapN("00_list_process_01.png");
		__pProgressBitmap[1] = pAppResource->GetBitmapN("00_list_process_02.png");
		__pProgressBitmap[2] = pAppResource->GetBitmapN("00_list_process_03.png");
		__pProgressBitmap[3] = pAppResource->GetBitmapN("00_list_process_04.png");
		__pProgressBitmap[4] = pAppResource->GetBitmapN("00_list_process_05.png");
		__pProgressBitmap[5] = pAppResource->GetBitmapN("00_list_process_06.png");
		__pProgressBitmap[6] = pAppResource->GetBitmapN("00_list_process_07.png");
		__pProgressBitmap[7] = pAppResource->GetBitmapN("00_list_process_08.png");
		__pProgressBitmap[8] = pAppResource->GetBitmapN("00_list_process_09.png");
		__pProgressBitmap[9] = pAppResource->GetBitmapN("00_list_process_10.png");
		__pProgressBitmap[10] = pAppResource->GetBitmapN("00_list_process_11.png");
		__pProgressBitmap[11] = pAppResource->GetBitmapN("00_list_process_12.png");
		__pProgressBitmap[12] = pAppResource->GetBitmapN("00_list_process_13.png");
		__pProgressBitmap[13] = pAppResource->GetBitmapN("00_list_process_14.png");
		__pProgressBitmap[14] = pAppResource->GetBitmapN("00_list_process_15.png");
		__pProgressBitmap[15] = pAppResource->GetBitmapN("00_list_process_16.png");
		__pProgressBitmap[16] = pAppResource->GetBitmapN("00_list_process_17.png");
		__pProgressBitmap[17] = pAppResource->GetBitmapN("00_list_process_18.png");
		__pProgressBitmap[18] = pAppResource->GetBitmapN("00_list_process_19.png");
		__pProgressBitmap[19] = pAppResource->GetBitmapN("00_list_process_20.png");
		__pProgressBitmap[20] = pAppResource->GetBitmapN("00_list_process_21.png");
		__pProgressBitmap[21] = pAppResource->GetBitmapN("00_list_process_22.png");
		__pProgressBitmap[22] = pAppResource->GetBitmapN("00_list_process_23.png");
		__pProgressBitmap[23] = pAppResource->GetBitmapN("00_list_process_24.png");
		__pProgressBitmap[24] = pAppResource->GetBitmapN("00_list_process_25.png");
		__pProgressBitmap[25] = pAppResource->GetBitmapN("00_list_process_26.png");
		__pProgressBitmap[26] = pAppResource->GetBitmapN("00_list_process_27.png");
		__pProgressBitmap[27] = pAppResource->GetBitmapN("00_list_process_28.png");
		__pProgressBitmap[28] = pAppResource->GetBitmapN("00_list_process_29.png");
		__pProgressBitmap[29] = pAppResource->GetBitmapN("00_list_process_30.png");
	}
	// Create Timer
	__pTimer = new (std::nothrow) Timer();
	__pTimer->Construct(*this);

	// Create a CustomList
	__pListView = new (std::nothrow) ListView();
	__pListView->Construct(Rectangle(0, 0, rect.width, rect.height-74), true, false);
	__pListView->SetItemProvider(*this);
	AddControl(__pListView);

	return E_SUCCESS;
}

void
Panel3::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	switch(actionId)
	{
	case ID_BUTTON_START:
		if (TIMER_START != __timerStatus)
		{
			__pStartButton->SetEnabled(false);
			__pStopButton->SetEnabled(true);

			__timerStatus = TIMER_START;
			__pTimer->Start(INTERVAL);
		}
		break;
	case ID_BUTTON_STOP:
		__pStartButton->SetEnabled(true);
		__pStopButton->SetEnabled(false);

		__timerStatus = TIMER_STOP;
		break;
	}

	Draw();
}

void
Panel3::OnTimerExpired(Tizen::Base::Runtime::Timer &  timer)
{
	if(__timerStatus == TIMER_STOP)
	{
		__progress = 0;

		__pStartButton->SetEnabled(true);
		__pStopButton->SetEnabled(false);

		Draw();

		return;
	}

	result r = __pTimer->Start(INTERVAL);
	TryReturnVoid(!IsFailed(r), "Timer Start Fail.");

	__pStartButton->SetEnabled(false);
	__pStopButton->SetEnabled(true);

	Invalidate(true);

	__pListView->RefreshList(0, LIST_REFRESH_TYPE_ITEM_MODIFY);
}

Tizen::Ui::Controls::ListItemBase*
Panel3::CreateItem(int index, int itemWidth)
{
	ListAnnexStyle style = LIST_ANNEX_STYLE_NORMAL;
	CustomItem* pItem = new (std::nothrow) CustomItem();

	//ListView Setting
	if (index == 0 && __timerStatus == TIMER_START)
	{
		int index = __progress % PROGRESS_COUNT;
		pItem->Construct(Tizen::Graphics::Dimension(itemWidth,74), style);
		pItem->AddElement(BITMAP_RECT, ID_FORMAT_BITMAP, *__pProgressBitmap[index], null, null);
		pItem->AddElement(STRING_RECT, ID_FORMAT_STRING, L"Animating", true);
		__progress++;
		return pItem;
	}
	else
	{
		switch (index % LIST_STYLE_COUNT)
		{
		case 0:
			style = LIST_ANNEX_STYLE_NORMAL;
			pItem->Construct(Tizen::Graphics::Dimension(itemWidth,74), style);
			pItem->AddElement(BITMAP_RECT, ID_FORMAT_BITMAP, *__pHome, null, null);
			pItem->AddElement(STRING_RECT, ID_FORMAT_STRING, L"Home", true);
			break;
		case 1:
			style = LIST_ANNEX_STYLE_MARK;
			pItem->Construct(Tizen::Graphics::Dimension(itemWidth,74), style);
			pItem->AddElement(BITMAP_RECT, ID_FORMAT_BITMAP, *__pMsg, null, null);
			pItem->AddElement(STRING_RECT, ID_FORMAT_STRING, L"Message", true);
			break;
		case 2:
			style = LIST_ANNEX_STYLE_ONOFF_SLIDING;
			pItem->Construct(Tizen::Graphics::Dimension(itemWidth,74), style);
			pItem->AddElement(BITMAP_RECT, ID_FORMAT_BITMAP, *__pAlarm, null, null);
			pItem->AddElement(STRING_RECT, ID_FORMAT_STRING, L"Alarm", true);
			break;

		default:
			break;
		}
		return pItem;
	}
}

bool
Panel3::DeleteItem(int index, Tizen::Ui::Controls::ListItemBase* pItem, int itemWidth)
{
	delete pItem;
	pItem = null;
	return true;
}

int
Panel3::GetItemCount(void)
{
	return LIST_ITEM_COUNT;
}

void
Panel3::OnForeGround(void)
{
	if (__timerStatus == TIMER_STOP && __timerFlag == 1)
	{
		__timerStatus = TIMER_START;
		__pTimer->Start(INTERVAL);
		__timerFlag = 0;
	}
}

void
Panel3::OnBackGround(void)
{
	if (__timerStatus == TIMER_START)
	{
		__timerStatus = TIMER_STOP;
		__timerFlag = 1;
	}
}
