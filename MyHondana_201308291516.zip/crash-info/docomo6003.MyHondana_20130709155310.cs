S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG2
Build-Date: 2013.07.04 20:54:23

Crash Information
Process Name: MyHondana
PID: 6186
Date: 2013-07-09 15:53:10(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=6186 tid=6186
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 6186, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0x00000001
r2   = 0x00000001, r3   = 0x00000000
r4   = 0xb4220598, r5   = 0x00000001
r6   = 0x000c2ec4, r7   = 0x00000000
r8   = 0x000c2ec4, r9   = 0x00000000
r10  = 0xb41d1f44, fp   = 0xb41d1ee4
ip   = 0xb42226cc, sp   = 0xbed19130
lr   = 0xb3c1003f, pc   = 0xb3c0ffd6
cpsr = 0x40000030

Memory Information
MemTotal:  2063912 KB
MemFree:   1389968 KB
Buffers:     34832 KB
Cached:     334848 KB
VmPeak:     101456 KB
VmSize:     101452 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       17724 KB
VmRSS:       17724 KB
VmData:       7284 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       64376 KB
VmPTE:          88 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00070000 rw-p [heap]
00070000 000fb000 rw-p [heap]
b1327000 b1373000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b137c000 b1381000 r-xp /usr/lib/libjson.so.0.0.1
b1389000 b138d000 r-xp /usr/lib/liblocation-pos-log.so
b1395000 b13a0000 r-xp /usr/lib/libmdm-common.so.1.0.37
b13a8000 b13ba000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b13c2000 b13c4000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b13cc000 b13d1000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b13d9000 b13e4000 r-xp /usr/lib/libdrm-trusted.so.0.0.52
b13ec000 b13ee000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b13f6000 b1403000 r-xp /usr/lib/libdrm-client.so.0.0.90
b140c000 b1414000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b1436000 b146d000 r-xp /usr/lib/libpulse.so.0.16.2
b1475000 b14d9000 r-xp /usr/lib/libasound.so.2.0.0
b14e3000 b14e6000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b14ef000 b14f3000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b14fc000 b1519000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b1521000 b1526000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b152e000 b155b000 r-xp /usr/lib/libSLP-location.so.0.0.0
b1564000 b15a1000 r-xp /usr/lib/libmdm.so.1.0.63
b15a9000 b15ad000 r-xp /usr/lib/libss-client.so.1.0.0
b15b6000 b15bf000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b15c7000 b15cb000 r-xp /usr/lib/libmmffile.so.0.0.0
b15d3000 b15da000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b15e3000 b15fd000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b1605000 b1620000 r-xp /usr/lib/libmedia-service.so.1.0.0
b1628000 b163d000 r-xp /usr/lib/libnetwork.so.0.0.0
b1645000 b1653000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b165c000 b1663000 r-xp /usr/lib/libenchant.so.1.6.1
b166b000 b166e000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.8
b1677000 b1680000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b1689000 b168d000 r-xp /usr/lib/libmmfsession.so.0.0.0
b1696000 b16a5000 r-xp /usr/lib/libmmfsound.so.0.1.0
b16ad000 b16b2000 r-xp /usr/lib/libmemenv.so.1.1.0
b16ba000 b16f8000 r-xp /usr/lib/libleveldb.so.1.1.0
b1701000 b172b000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b1734000 b1736000 r-xp /usr/lib/libsecfw.so
b173e000 b1747000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b1752000 b1761000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b1769000 b1781000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b1783000 b1790000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b1799000 b17a2000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b17aa000 b17ec000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b17f5000 b1891000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b189d000 b18c2000 r-xp /usr/lib/libxslt.so.1.1.16
b18cb000 b18cd000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b18d5000 b18dd000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b18e5000 b18f0000 r-xp /usr/lib/libcapi-location-manager.so.0.1.12
b18f8000 b190f000 r-xp /usr/lib/libwifi-direct.so.0.0
b1917000 b191f000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.7
b1927000 b1930000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b1938000 b193b000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b1943000 b196a000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.70
b1972000 b1988000 r-xp /usr/lib/osp/libosp-locations.so.1.2.1.0
b1991000 b199b000 r-xp /usr/lib/libcapi-network-connection.so.0.1.10
b19a3000 b19ac000 r-xp /usr/lib/libcapi-web-favorites.so
b19b4000 b2c0c000 r-xp /usr/lib/libewebkit2.so.0.10.144.6
b2cff000 b2db4000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2dc1000 b2ddf000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2de8000 b2e02000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2e0b000 b2e5e000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2e67000 b2ecb000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2ef0000 b2f17000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2f21000 b2f69000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2f71000 b3001000 r-xp /usr/lib/libCOREGL.so.3.0
b300b000 b300e000 r-xp /usr/lib/libmm_ta.so.0.0.0
b3016000 b301d000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b3026000 b3035000 r-xp /usr/lib/libICE.so.6.3.0
b303f000 b3044000 r-xp /usr/lib/libSM.so.6.0.1
b304c000 b304d000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3055000 b3057000 r-xp /usr/lib/libledplayer.so.0.1
b305f000 b3065000 r-xp /usr/lib/libxcb-render.so.0.0.0
b306d000 b306e000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b3077000 b307e000 r-xp /usr/lib/libGLESv2.so.2.0
b3086000 b30cd000 r-xp /usr/lib/libtiff.so.5.1.0
b30d8000 b3101000 r-xp /usr/lib/libturbojpeg.so
b311a000 b311e000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3127000 b312d000 r-xp /usr/lib/libgif.so.4.1.6
b3135000 b3157000 r-xp /usr/lib/libavutil.so.51.73.101
b3166000 b3194000 r-xp /usr/lib/libswscale.so.2.1.101
b319d000 b3494000 r-xp /usr/lib/libavcodec.so.54.59.100
b37bb000 b37d4000 r-xp /usr/lib/libpng12.so.0.50.0
b37dd000 b37e4000 r-xp /usr/lib/libfeedback.so.0.1.4
b37ed000 b3800000 r-xp /usr/lib/libtts.so
b3809000 b380b000 r-xp /usr/lib/libEGL.so.1.4
b3813000 b38ca000 r-xp /usr/lib/libcairo.so.2.11200.12
b38d4000 b38ed000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b38f7000 b38fc000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b3904000 b3906000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b390e000 b41ba000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b422b000 b4234000 r-xp /usr/lib/libslp_devman_plugin.so
b423d000 b423f000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4247000 b424a000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4252000 b4255000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b425d000 b426a000 r-xp /usr/lib/libmodem.so.0.0.0
b4272000 b4275000 r-xp /usr/lib/libdevice-node.so.0.1
b427d000 b428d000 r-xp /usr/lib/libaccounts-svc.so.0.2.68
b4295000 b4298000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b42a0000 b42a6000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b42ae000 b42b3000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b42bb000 b42bc000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b42c5000 b42c8000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b42d0000 b42d5000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b42dd000 b42e0000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b42e8000 b42e9000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b42f1000 b42ff000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4308000 b430e000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4316000 b433b000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4343000 b4346000 r-xp /usr/lib/libuuid.so.1.3.0
b434f000 b4363000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b436b000 b4373000 r-xp /usr/lib/libminizip.so.1.0.0
b437b000 b4387000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4390000 b43ae000 r-xp /usr/lib/libpcre.so.0.0.1
b43b6000 b43ba000 r-xp /usr/lib/libheynoti.so.0.0.2
b43c2000 b43d0000 r-xp /usr/lib/libdeviced.so.0.1.0
b43d9000 b43e4000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b43f1000 b43fa000 r-xp /usr/lib/libdevman.so.0.1
b4402000 b4406000 r-xp /usr/lib/libchromium.so.1.0
b440e000 b441f000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4428000 b4734000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b475c000 b4766000 r-xp /lib/libnss_files-2.13.so
b476f000 b4770000 r-xp /usr/lib/libpmapi.so.1.2
b4778000 b477f000 r-xp /usr/lib/libalarm.so.0.0.0
b4787000 b479a000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b47a3000 b47bf000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b47c8000 b47cb000 r-xp /usr/lib/libiniparser.so.0
b47d4000 b4824000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b482e000 b483f000 r-xp /usr/lib/libcom-core.so.0.0.1
b4847000 b484d000 r-xp /usr/lib/libappsvc.so.0.1.0
b4855000 b4857000 r-xp /usr/lib/libdri2.so.0.0.0
b485f000 b4867000 r-xp /usr/lib/libdrm.so.2.4.0
b486f000 b4873000 r-xp /usr/lib/libtbm.so.1.0.0
b487b000 b487e000 r-xp /usr/lib/libXv.so.1.0.0
b4886000 b4890000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4899000 b4965000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b497b000 b498a000 r-xp /usr/lib/libnotification.so.0.1.0
b4992000 b49b6000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b49bf000 b49cf000 r-xp /lib/libresolv-2.13.so
b49d3000 b49d5000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b49dd000 b4ab5000 r-xp /usr/lib/libxml2.so.2.7.8
b4ac2000 b4b9f000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4baa000 b4baf000 r-xp /usr/lib/libcheck.so.0.0.0
b4bb7000 b4bc1000 r-xp /usr/lib/libspdy.so.0.0.0
b4bca000 b4d1d000 r-xp /usr/lib/libcrypto.so.1.0.0
b4d3b000 b4d87000 r-xp /usr/lib/libssl.so.1.0.0
b4d93000 b4dc1000 r-xp /usr/lib/libidn.so.11.5.44
b4dca000 b4dd4000 r-xp /usr/lib/libcares.so.2.1.0
b4ddc000 b4df3000 r-xp /lib/libexpat.so.1.5.2
b4dfd000 b4e21000 r-xp /usr/lib/libicule.so.48.1
b4e2a000 b4e38000 r-xp /usr/lib/libsf_common.so
b4e41000 b4edc000 r-xp /usr/lib/libstdc++.so.6.0.14
b4eef000 b4f07000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4f08000 b4f0b000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4f13000 b4f17000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4f20000 b4f25000 r-xp /usr/lib/libffi.so.5.0.10
b4f2d000 b4f2e000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4f36000 b4f40000 r-xp /usr/lib/libXext.so.6.4.0
b4f49000 b4f4c000 r-xp /usr/lib/libXtst.so.6.1.0
b4f54000 b4f5a000 r-xp /usr/lib/libXrender.so.1.3.0
b4f62000 b4f68000 r-xp /usr/lib/libXrandr.so.2.2.0
b4f70000 b4f71000 r-xp /usr/lib/libXinerama.so.1.0.0
b4f7a000 b4f83000 r-xp /usr/lib/libXi.so.6.1.0
b4f8b000 b4f8e000 r-xp /usr/lib/libXfixes.so.3.1.0
b4f96000 b4f98000 r-xp /usr/lib/libXgesture.so.7.0.0
b4fa0000 b4fa1000 r-xp /usr/lib/libXdamage.so.1.1.0
b4faa000 b4fb1000 r-xp /usr/lib/libXcursor.so.1.0.2
b4fb9000 b4fdc000 r-xp /usr/lib/libexif.so.12.3.3
b4ff0000 b4ffa000 r-xp /usr/lib/libethumb.so.1.7.99
b5002000 b5046000 r-xp /usr/lib/libsndfile.so.1.0.25
b5054000 b5056000 r-xp /usr/lib/libctxdata.so.0.0.0
b505e000 b506c000 r-xp /usr/lib/libremix.so.0.0.0
b5074000 b5075000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b507d000 b5096000 r-xp /usr/lib/liblua-5.1.so
b509f000 b50a6000 r-xp /usr/lib/libembryo.so.1.7.99
b50af000 b50ef000 r-xp /usr/lib/libcurl.so.4.3.0
b50f8000 b5162000 r-xp /usr/lib/libpixman-1.so.0.28.2
b516f000 b5193000 r-xp /usr/lib/libfontconfig.so.1.5.0
b519c000 b51f8000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b520a000 b521e000 r-xp /usr/lib/libfribidi.so.0.3.1
b5226000 b527e000 r-xp /usr/lib/libfreetype.so.6.8.1
b5289000 b52ad000 r-xp /usr/lib/libjpeg.so.8.0.2
b52c5000 b52dc000 r-xp /lib/libz.so.1.2.5
b52e4000 b52ec000 r-xp /usr/lib/libemotion.so.1.7.99
b52f4000 b52f9000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5302000 b5310000 r-xp /usr/lib/libsensor.so.1.1.0
b531c000 b5322000 r-xp /usr/lib/libappcore-common.so.1.1
b532a000 b532c000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.79
b5334000 b533f000 r-xp /usr/lib/libresourced.so.0.2.79
b5347000 b534a000 r-xp /usr/lib/libproc-stat.so.0.2.79
b6347000 b642f000 r-xp /usr/lib/libicuuc.so.48.1
b643c000 b655c000 r-xp /usr/lib/libicui18n.so.48.1
b656a000 b656d000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6575000 b657d000 r-xp /usr/lib/libvconf.so.0.2.45
b6585000 b658b000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6593000 b659f000 r-xp /usr/lib/libail.so.0.1.0
b65a7000 b65b2000 r-xp /usr/lib/libaul.so.0.1.0
b65bb000 b65d2000 r-xp /usr/lib/libecore_input.so.1.7.99
b65ed000 b660a000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6613000 b6615000 r-xp /usr/lib/libXcomposite.so.1.0.0
b661d000 b6651000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b665a000 b6689000 r-xp /usr/lib/libecore_x.so.1.7.99
b6693000 b66d2000 r-xp /usr/lib/libeina.so.1.7.99
b66db000 b66f0000 r-xp /usr/lib/libecore.so.1.7.99
b6707000 b6722000 r-xp /usr/lib/libecore_con.so.1.7.99
b672b000 b6730000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6738000 b6740000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6748000 b6751000 r-xp /usr/lib/libedbus.so.1.7.99
b6759000 b675b000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6763000 b6767000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6770000 b6786000 r-xp /usr/lib/libefreet.so.1.7.99
b6790000 b67ec000 r-xp /usr/lib/libedje.so.1.7.99
b67f6000 b68a6000 r-xp /usr/lib/libevas.so.1.7.99
b68c8000 b68db000 r-xp /usr/lib/libeet.so.1.7.99
b68e4000 b694e000 r-xp /lib/libm-2.13.so
b6957000 b695f000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b6960000 b6967000 r-xp /usr/lib/libutilX.so.1.1.0
b696f000 b6a91000 r-xp /usr/lib/libelementary.so.1.7.99
b6aa6000 b6aa9000 r-xp /lib/libattr.so.1.1.0
b6ab1000 b6ab3000 r-xp /usr/lib/libXau.so.6.0.0
b6abb000 b6ac1000 r-xp /lib/librt-2.13.so
b6aca000 b6ad2000 r-xp /lib/libcrypt-2.13.so
b6b02000 b6b05000 r-xp /lib/libcap.so.2.21
b6b0d000 b6b0f000 r-xp /usr/lib/libiri.so
b6b17000 b6b2c000 r-xp /usr/lib/libxcb.so.1.1.0
b6b34000 b6b3f000 r-xp /lib/libunwind.so.8.0.1
b6b6d000 b6c8a000 r-xp /lib/libc-2.13.so
b6c98000 b6ca1000 r-xp /lib/libgcc_s-4.5.3.so.1
b6ca9000 b6cd5000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6cde000 b6ce1000 r-xp /usr/lib/libbundle.so.0.1.22
b6ce9000 b6ceb000 r-xp /lib/libdl-2.13.so
b6cf4000 b6cf7000 r-xp /usr/lib/libsmack.so.1.0.0
b6cff000 b6dd9000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6de2000 b6df6000 r-xp /lib/libpthread-2.13.so
b6e02000 b6e07000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e0f000 b6e17000 r-xp /usr/lib/libappcore-efl.so.1.1
b6e19000 b6e1a000 r-xp /usr/lib/libdlog.so.0.0.0
b6e23000 b6e90000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6e9a000 b6ea3000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6eab000 b6f91000 r-xp /usr/lib/libX11.so.6.3.0
b6f9c000 b6f9d000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6fa5000 b6fa9000 r-xp /usr/lib/libsys-assert.so
b6fb1000 b6fce000 r-xp /lib/ld-2.13.so
becfa000 bed1b000 rwxp [stack]
End of Maps Information

Callstack Information (PID:6186)
Call Stack Count: 17
 0: Tizen::Ui::_UiEventManager::GetEventListeners(Tizen::Ui::_UiEventType, bool) const + 0x11 (0xb3c0ffd6) [/usr/lib/osp/libosp-uifw.so] + 0x301fd6
 1: Tizen::Ui::_UiEventManager::IsListenerRegistered(Tizen::Ui::_UiEventType, bool, Tizen::Ui::_IUiEventListener const&) + 0xa (0xb3c1003f) [/usr/lib/osp/libosp-uifw.so] + 0x30203f
 2: Tizen::Ui::_UiEventManager::AddEventListener(Tizen::Ui::_UiEventType, bool, Tizen::Ui::_IUiEventListener const&) + 0x12 (0xb3c1016f) [/usr/lib/osp/libosp-uifw.so] + 0x30216f
 3: Tizen::Ui::_UiEventManager::AddPostKeyEventListener(Tizen::Ui::_IKeyEventListener const&) + 0x16 (0xb3c101e7) [/usr/lib/osp/libosp-uifw.so] + 0x3021e7
 4: (0xb3bfca33) [/usr/lib/osp/libosp-uifw.so] + 0x2eea33
 5: (0xb3bfcabf) [/usr/lib/osp/libosp-uifw.so] + 0x2eeabf
 6: pthread_once + 0xc8 (0xb6deeab0) [/lib/libpthread.so.0] + 0xcab0
 7: (0xb3bfcfef) [/usr/lib/osp/libosp-uifw.so] + 0x2eefef
 8: (0xb3bcd547) [/usr/lib/osp/libosp-uifw.so] + 0x2bf547
 9: InitializeUiFramework + 0x6 (0xb3bcd56f) [/usr/lib/osp/libosp-uifw.so] + 0x2bf56f
10: Tizen::App::_UiAppImpl::OnAppInitializing() + 0xc (0xb3f763d9) [/usr/lib/osp/libosp-uifw.so] + 0x6683d9
11: Tizen::App::_AppImpl::OnCreate(void*) + 0x80 (0xb451ac85) [/usr/lib/osp/libosp-appfw.so] + 0xf2c85
12: (0xb42fad7f) [/usr/lib/libcapi-appfw-application.so.0] + 0x9d7f
13: (0xb6e1396c) [/usr/lib/libappcore-efl.so.1] + 0x496c
14: appcore_efl_main + 0xe8 (0xb6e1523c) [/usr/lib/libappcore-efl.so.1] + 0x623c
15: app_efl_main + 0xc6 (0xb42faed3) [/usr/lib/libcapi-appfw-application.so.0] + 0x9ed3
16: (0xb43065e8) [/usr/lib/libcapi-appfw-application.so.0] + 0xb43065e8
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
