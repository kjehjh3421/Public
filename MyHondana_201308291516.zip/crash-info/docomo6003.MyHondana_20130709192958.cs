S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG2
Build-Date: 2013.07.04 20:54:23

Crash Information
Process Name: MyHondana
PID: 6335
Date: 2013-07-09 19:29:58(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=6335 tid=6335
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 6335, uid 5000)

Register Information
r0   = 0x001b6720, r1   = 0x001b69c0
r2   = 0x7fffffff, r3   = 0x00000001
r4   = 0xbede4a94, r5   = 0x001b69c0
r6   = 0x00000000, r7   = 0x001bd860
r8   = 0xb46f4158, r9   = 0xb41c2598
r10  = 0x00000001, fp   = 0xbede4fb0
ip   = 0xb46f712c, sp   = 0xbede4740
lr   = 0xb45055cb, pc   = 0xb45055f0
cpsr = 0x280f0030

Memory Information
MemTotal:  2063912 KB
MemFree:   1135708 KB
Buffers:     34380 KB
Cached:     551292 KB
VmPeak:     143620 KB
VmSize:     124332 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       50548 KB
VmRSS:       50548 KB
VmData:      23608 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       66084 KB
VmPTE:         126 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00070000 rw-p [heap]
00070000 00894000 rw-p [heap]
b05bc000 b05c0000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b05c9000 b0dc8000 rwxp [stack:6337]
b0dc8000 b0f16000 r-xp /usr/lib/r3p2/libMali.so
b0f22000 b0f4a000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0f4e000 b0f6c000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b0f7e000 b0f84000 r-xp /usr/lib/libUMP.so
b12c6000 b1312000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b131b000 b1320000 r-xp /usr/lib/libjson.so.0.0.1
b1328000 b132c000 r-xp /usr/lib/liblocation-pos-log.so
b1334000 b133f000 r-xp /usr/lib/libmdm-common.so.1.0.37
b1347000 b1359000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b1361000 b1363000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b136b000 b1370000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b1378000 b1383000 r-xp /usr/lib/libdrm-trusted.so.0.0.52
b138b000 b138d000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b1395000 b13a2000 r-xp /usr/lib/libdrm-client.so.0.0.90
b13ab000 b13b3000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b13d5000 b140c000 r-xp /usr/lib/libpulse.so.0.16.2
b1414000 b1478000 r-xp /usr/lib/libasound.so.2.0.0
b1482000 b1485000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b148e000 b1492000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b149b000 b14b8000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b14c0000 b14c5000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b14cd000 b14fa000 r-xp /usr/lib/libSLP-location.so.0.0.0
b1503000 b1540000 r-xp /usr/lib/libmdm.so.1.0.63
b1548000 b154c000 r-xp /usr/lib/libss-client.so.1.0.0
b1555000 b155e000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b1566000 b156a000 r-xp /usr/lib/libmmffile.so.0.0.0
b1572000 b1579000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b1582000 b159c000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b15a4000 b15bf000 r-xp /usr/lib/libmedia-service.so.1.0.0
b15c7000 b15dc000 r-xp /usr/lib/libnetwork.so.0.0.0
b15e4000 b15f2000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b15fb000 b1602000 r-xp /usr/lib/libenchant.so.1.6.1
b160a000 b160d000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.8
b1616000 b161f000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b1628000 b162c000 r-xp /usr/lib/libmmfsession.so.0.0.0
b1635000 b1644000 r-xp /usr/lib/libmmfsound.so.0.1.0
b164c000 b1651000 r-xp /usr/lib/libmemenv.so.1.1.0
b1659000 b1697000 r-xp /usr/lib/libleveldb.so.1.1.0
b16a0000 b16ca000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b16d3000 b16d5000 r-xp /usr/lib/libsecfw.so
b16dd000 b16e6000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b16f1000 b1700000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b1708000 b1720000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b1722000 b172f000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b1738000 b1741000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b1749000 b178b000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b1794000 b1830000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b183c000 b1861000 r-xp /usr/lib/libxslt.so.1.1.16
b186a000 b186c000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b1874000 b187c000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b1884000 b188f000 r-xp /usr/lib/libcapi-location-manager.so.0.1.12
b1897000 b18ae000 r-xp /usr/lib/libwifi-direct.so.0.0
b18b6000 b18be000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.7
b18c6000 b18cf000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b18d7000 b18da000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b18e2000 b1909000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.70
b1911000 b1927000 r-xp /usr/lib/osp/libosp-locations.so.1.2.1.0
b1930000 b193a000 r-xp /usr/lib/libcapi-network-connection.so.0.1.10
b1942000 b194b000 r-xp /usr/lib/libcapi-web-favorites.so
b1953000 b2bab000 r-xp /usr/lib/libewebkit2.so.0.10.144.6
b2c9e000 b2d53000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2d60000 b2d7e000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2d87000 b2dda000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2de3000 b2e47000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2e54000 b2e6e000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2e7d000 b2e87000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b2e8f000 b2eb9000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2ec3000 b2f0b000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2f13000 b2fa3000 r-xp /usr/lib/libCOREGL.so.3.0
b2fad000 b2fb0000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2fb8000 b2fbf000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2fc8000 b2fd7000 r-xp /usr/lib/libICE.so.6.3.0
b2fe1000 b2fe6000 r-xp /usr/lib/libSM.so.6.0.1
b2fee000 b2fef000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2ff7000 b2ff9000 r-xp /usr/lib/libledplayer.so.0.1
b3001000 b3007000 r-xp /usr/lib/libxcb-render.so.0.0.0
b300f000 b3010000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b3019000 b3020000 r-xp /usr/lib/libGLESv2.so.2.0
b3028000 b306f000 r-xp /usr/lib/libtiff.so.5.1.0
b307a000 b30a3000 r-xp /usr/lib/libturbojpeg.so
b30bc000 b30c0000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b30c9000 b30cf000 r-xp /usr/lib/libgif.so.4.1.6
b30d7000 b30f9000 r-xp /usr/lib/libavutil.so.51.73.101
b3108000 b3136000 r-xp /usr/lib/libswscale.so.2.1.101
b313f000 b3436000 r-xp /usr/lib/libavcodec.so.54.59.100
b375d000 b3776000 r-xp /usr/lib/libpng12.so.0.50.0
b377f000 b3786000 r-xp /usr/lib/libfeedback.so.0.1.4
b378f000 b37a2000 r-xp /usr/lib/libtts.so
b37ab000 b37ad000 r-xp /usr/lib/libEGL.so.1.4
b37b5000 b386c000 r-xp /usr/lib/libcairo.so.2.11200.12
b3876000 b388f000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3899000 b389e000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b38a6000 b38a8000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b38b0000 b415c000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41cd000 b41d6000 r-xp /usr/lib/libslp_devman_plugin.so
b41df000 b41e1000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41e9000 b41ec000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41f4000 b41f7000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b41ff000 b420c000 r-xp /usr/lib/libmodem.so.0.0.0
b4214000 b4217000 r-xp /usr/lib/libdevice-node.so.0.1
b421f000 b422f000 r-xp /usr/lib/libaccounts-svc.so.0.2.68
b4237000 b423a000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b4242000 b4248000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4250000 b4255000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b425d000 b425e000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b4267000 b426a000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4272000 b4277000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b427f000 b4282000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b428a000 b428b000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4293000 b42a1000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b42aa000 b42b0000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b42b8000 b42dd000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b42e5000 b42e8000 r-xp /usr/lib/libuuid.so.1.3.0
b42f1000 b4305000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b430d000 b4315000 r-xp /usr/lib/libminizip.so.1.0.0
b431d000 b4329000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4332000 b4350000 r-xp /usr/lib/libpcre.so.0.0.1
b4358000 b435c000 r-xp /usr/lib/libheynoti.so.0.0.2
b4364000 b4372000 r-xp /usr/lib/libdeviced.so.0.1.0
b437b000 b4386000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4393000 b439c000 r-xp /usr/lib/libdevman.so.0.1
b43a4000 b43a8000 r-xp /usr/lib/libchromium.so.1.0
b43b0000 b43c1000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b43ca000 b46d6000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b46fe000 b4708000 r-xp /lib/libnss_files-2.13.so
b4711000 b4712000 r-xp /usr/lib/libpmapi.so.1.2
b471a000 b4721000 r-xp /usr/lib/libalarm.so.0.0.0
b4729000 b473c000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4745000 b4761000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b476a000 b476d000 r-xp /usr/lib/libiniparser.so.0
b4776000 b47c6000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b47d0000 b47e1000 r-xp /usr/lib/libcom-core.so.0.0.1
b47e9000 b47ef000 r-xp /usr/lib/libappsvc.so.0.1.0
b47f7000 b47f9000 r-xp /usr/lib/libdri2.so.0.0.0
b4801000 b4809000 r-xp /usr/lib/libdrm.so.2.4.0
b4811000 b4815000 r-xp /usr/lib/libtbm.so.1.0.0
b481d000 b4820000 r-xp /usr/lib/libXv.so.1.0.0
b4828000 b4832000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b483b000 b4907000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b491d000 b492c000 r-xp /usr/lib/libnotification.so.0.1.0
b4934000 b4958000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4961000 b4971000 r-xp /lib/libresolv-2.13.so
b4975000 b4977000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b497f000 b4a57000 r-xp /usr/lib/libxml2.so.2.7.8
b4a64000 b4b41000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4b4c000 b4b51000 r-xp /usr/lib/libcheck.so.0.0.0
b4b59000 b4b63000 r-xp /usr/lib/libspdy.so.0.0.0
b4b6c000 b4cbf000 r-xp /usr/lib/libcrypto.so.1.0.0
b4cdd000 b4d29000 r-xp /usr/lib/libssl.so.1.0.0
b4d35000 b4d63000 r-xp /usr/lib/libidn.so.11.5.44
b4d6c000 b4d76000 r-xp /usr/lib/libcares.so.2.1.0
b4d7e000 b4d95000 r-xp /lib/libexpat.so.1.5.2
b4d9f000 b4dc3000 r-xp /usr/lib/libicule.so.48.1
b4dcc000 b4dda000 r-xp /usr/lib/libsf_common.so
b4de3000 b4e7e000 r-xp /usr/lib/libstdc++.so.6.0.14
b4e91000 b4ea9000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4eaa000 b4ead000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4eb5000 b4eb9000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4ec2000 b4ec7000 r-xp /usr/lib/libffi.so.5.0.10
b4ecf000 b4ed0000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4ed8000 b4ee2000 r-xp /usr/lib/libXext.so.6.4.0
b4eeb000 b4eee000 r-xp /usr/lib/libXtst.so.6.1.0
b4ef6000 b4efc000 r-xp /usr/lib/libXrender.so.1.3.0
b4f04000 b4f0a000 r-xp /usr/lib/libXrandr.so.2.2.0
b4f12000 b4f13000 r-xp /usr/lib/libXinerama.so.1.0.0
b4f1c000 b4f25000 r-xp /usr/lib/libXi.so.6.1.0
b4f2d000 b4f30000 r-xp /usr/lib/libXfixes.so.3.1.0
b4f38000 b4f3a000 r-xp /usr/lib/libXgesture.so.7.0.0
b4f42000 b4f43000 r-xp /usr/lib/libXdamage.so.1.1.0
b4f4c000 b4f53000 r-xp /usr/lib/libXcursor.so.1.0.2
b4f5b000 b4f7e000 r-xp /usr/lib/libexif.so.12.3.3
b4f92000 b4f9c000 r-xp /usr/lib/libethumb.so.1.7.99
b4fa4000 b4fe8000 r-xp /usr/lib/libsndfile.so.1.0.25
b4ff6000 b4ff8000 r-xp /usr/lib/libctxdata.so.0.0.0
b5000000 b500e000 r-xp /usr/lib/libremix.so.0.0.0
b5016000 b5017000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b501f000 b5038000 r-xp /usr/lib/liblua-5.1.so
b5041000 b5048000 r-xp /usr/lib/libembryo.so.1.7.99
b5051000 b5091000 r-xp /usr/lib/libcurl.so.4.3.0
b509a000 b5104000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5111000 b5135000 r-xp /usr/lib/libfontconfig.so.1.5.0
b513e000 b519a000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b51ac000 b51c0000 r-xp /usr/lib/libfribidi.so.0.3.1
b51c8000 b5220000 r-xp /usr/lib/libfreetype.so.6.8.1
b522b000 b524f000 r-xp /usr/lib/libjpeg.so.8.0.2
b5267000 b527e000 r-xp /lib/libz.so.1.2.5
b5286000 b528e000 r-xp /usr/lib/libemotion.so.1.7.99
b5296000 b529b000 r-xp /usr/lib/libecore_fb.so.1.7.99
b52a4000 b52b2000 r-xp /usr/lib/libsensor.so.1.1.0
b52be000 b52c4000 r-xp /usr/lib/libappcore-common.so.1.1
b52cc000 b52ce000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.79
b52d6000 b52e1000 r-xp /usr/lib/libresourced.so.0.2.79
b52e9000 b52ec000 r-xp /usr/lib/libproc-stat.so.0.2.79
b62e9000 b63d1000 r-xp /usr/lib/libicuuc.so.48.1
b63de000 b64fe000 r-xp /usr/lib/libicui18n.so.48.1
b650c000 b650f000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6517000 b651f000 r-xp /usr/lib/libvconf.so.0.2.45
b6527000 b652d000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6535000 b6541000 r-xp /usr/lib/libail.so.0.1.0
b6549000 b6554000 r-xp /usr/lib/libaul.so.0.1.0
b655d000 b6574000 r-xp /usr/lib/libecore_input.so.1.7.99
b658f000 b65ac000 r-xp /usr/lib/libecore_evas.so.1.7.99
b65b5000 b65b7000 r-xp /usr/lib/libXcomposite.so.1.0.0
b65bf000 b65f3000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b65fc000 b662b000 r-xp /usr/lib/libecore_x.so.1.7.99
b6635000 b6674000 r-xp /usr/lib/libeina.so.1.7.99
b667d000 b6692000 r-xp /usr/lib/libecore.so.1.7.99
b66a9000 b66c4000 r-xp /usr/lib/libecore_con.so.1.7.99
b66cd000 b66d2000 r-xp /usr/lib/libecore_imf.so.1.7.99
b66da000 b66e2000 r-xp /usr/lib/libethumb_client.so.1.7.99
b66ea000 b66f3000 r-xp /usr/lib/libedbus.so.1.7.99
b66fb000 b66fd000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6705000 b6709000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6712000 b6728000 r-xp /usr/lib/libefreet.so.1.7.99
b6732000 b678e000 r-xp /usr/lib/libedje.so.1.7.99
b6798000 b6848000 r-xp /usr/lib/libevas.so.1.7.99
b686a000 b687d000 r-xp /usr/lib/libeet.so.1.7.99
b6886000 b68f0000 r-xp /lib/libm-2.13.so
b68f9000 b6901000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b6902000 b6909000 r-xp /usr/lib/libutilX.so.1.1.0
b6911000 b6a33000 r-xp /usr/lib/libelementary.so.1.7.99
b6a48000 b6a4b000 r-xp /lib/libattr.so.1.1.0
b6a53000 b6a55000 r-xp /usr/lib/libXau.so.6.0.0
b6a5d000 b6a63000 r-xp /lib/librt-2.13.so
b6a6c000 b6a74000 r-xp /lib/libcrypt-2.13.so
b6aa4000 b6aa7000 r-xp /lib/libcap.so.2.21
b6aaf000 b6ab1000 r-xp /usr/lib/libiri.so
b6ab9000 b6ace000 r-xp /usr/lib/libxcb.so.1.1.0
b6ad6000 b6ae1000 r-xp /lib/libunwind.so.8.0.1
b6b0f000 b6c2c000 r-xp /lib/libc-2.13.so
b6c3a000 b6c43000 r-xp /lib/libgcc_s-4.5.3.so.1
b6c4b000 b6c77000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6c80000 b6c83000 r-xp /usr/lib/libbundle.so.0.1.22
b6c8b000 b6c8d000 r-xp /lib/libdl-2.13.so
b6c96000 b6c99000 r-xp /usr/lib/libsmack.so.1.0.0
b6ca1000 b6d7b000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6d84000 b6d98000 r-xp /lib/libpthread-2.13.so
b6da4000 b6da9000 r-xp /usr/lib/libecore_file.so.1.7.99
b6db1000 b6db9000 r-xp /usr/lib/libappcore-efl.so.1.1
b6dbb000 b6dbc000 r-xp /usr/lib/libdlog.so.0.0.0
b6dc5000 b6e32000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6e3c000 b6e45000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e4d000 b6f33000 r-xp /usr/lib/libX11.so.6.3.0
b6f3e000 b6f3f000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6f47000 b6f4b000 r-xp /usr/lib/libsys-assert.so
b6f53000 b6f70000 r-xp /lib/ld-2.13.so
bedc6000 bede7000 rwxp [stack]
bedc6000 bede7000 rwxp [stack]
End of Maps Information

Callstack Information (PID:6335)
Call Stack Count: 27
 0: Tizen::Base::String::String(Tizen::Base::String const&) + 0x37 (0xb45055f0) [/usr/lib/osp/libosp-appfw.so] + 0x13b5f0
 1: (0xb2ead978) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x1e978
 2: (0xb2eaedf0) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x1fdf0
 3: (0xb3c8ad37) [/usr/lib/osp/libosp-uifw.so] + 0x3dad37
 4: (0xb3da6019) [/usr/lib/osp/libosp-uifw.so] + 0x4f6019
 5: (0xb3c9013f) [/usr/lib/osp/libosp-uifw.so] + 0x3e013f
 6: (0xb3c90769) [/usr/lib/osp/libosp-uifw.so] + 0x3e0769
 7: Tizen::Ui::Controls::_IconListView::OnDraw() + 0xa (0xb3c94e23) [/usr/lib/osp/libosp-uifw.so] + 0x3e4e23
 8: Tizen::Ui::_ControlImpl::OnDraw() + 0x10 (0xb3b5a289) [/usr/lib/osp/libosp-uifw.so] + 0x2aa289
 9: Tizen::Ui::_Control::ControlVisualElementContentProvider::PrepareDraw(Tizen::Ui::Animations::VisualElement&) + 0xb6 (0xb3b56d87) [/usr/lib/osp/libosp-uifw.so] + 0x2a6d87
10: Tizen::Ui::Animations::_VisualElementImpl::InvokePrepareDraw() + 0x16 (0xb3ae4e27) [/usr/lib/osp/libosp-uifw.so] + 0x234e27
11: Tizen::Ui::Animations::_VisualElementImpl::DrawRectangle(Tizen::Graphics::FloatRectangle const&) + 0x2d4 (0xb3ae5139) [/usr/lib/osp/libosp-uifw.so] + 0x235139
12: Tizen::Ui::Animations::_VisualElementImpl::DrawRectangleIfNeeded(Tizen::Graphics::FloatRectangle const&) + 0x70 (0xb3ae5291) [/usr/lib/osp/libosp-uifw.so] + 0x235291
13: Tizen::Ui::Animations::_VisualElementImpl::DrawRectangleIfNeeded(Tizen::Graphics::FloatRectangle const&) + 0x112 (0xb3ae5333) [/usr/lib/osp/libosp-uifw.so] + 0x235333
14: Tizen::Ui::Animations::_VisualElementImpl::DrawRectangleIfNeeded(Tizen::Graphics::FloatRectangle const&) + 0x112 (0xb3ae5333) [/usr/lib/osp/libosp-uifw.so] + 0x235333
15: Tizen::Ui::Animations::_VisualElementImpl::DrawRectangleIfNeeded(Tizen::Graphics::FloatRectangle const&) + 0x112 (0xb3ae5333) [/usr/lib/osp/libosp-uifw.so] + 0x235333
16: Tizen::Ui::Animations::_VisualElementImpl::DrawRectangleIfNeeded(Tizen::Graphics::FloatRectangle const&) + 0x112 (0xb3ae5333) [/usr/lib/osp/libosp-uifw.so] + 0x235333
17: Tizen::Ui::Animations::_VisualElementImpl::Draw() + 0x9e (0xb3ae5457) [/usr/lib/osp/libosp-uifw.so] + 0x235457
18: Tizen::Ui::Animations::_DisplayManager::Render(Tizen::Ui::Animations::_RootVisualElement&) + 0x30 (0xb3acf8f9) [/usr/lib/osp/libosp-uifw.so] + 0x21f8f9
19: Tizen::Ui::Animations::_DisplayManager::RenderAll() + 0x36 (0xb3acf9a7) [/usr/lib/osp/libosp-uifw.so] + 0x21f9a7
20: (0xb3af1729) [/usr/lib/osp/libosp-uifw.so] + 0x241729
21: (0xb6686b2d) [/usr/lib/libecore.so.1] + 0x9b2d
22: (0xb6687fff) [/usr/lib/libecore.so.1] + 0xafff
23: ecore_main_loop_begin + 0x30 (0xb6688575) [/usr/lib/libecore.so.1] + 0xb575
24: elm_run + 0x6 (0xb69bac73) [/usr/lib/libelementary.so.1] + 0xa9c73
25: appcore_efl_main + 0x114 (0xb6db7268) [/usr/lib/libappcore-efl.so.1] + 0x6268
26: app_efl_main + 0xc6 (0xb429ced3) [/usr/lib/libcapi-appfw-application.so.0] + 0x9ed3
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
