S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 2695
Date: 2013-07-12 22:04:55(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=2695 tid=2695
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2695, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x00000000, esi = 0xbfafb5fc
ebp = 0xbfafb138, esp = 0xbfafb0f0
eax = 0xb47bb960, ebx = 0xb47caa10
ecx = 0xb47caa10, edx = 0xb47bb848
eip = 0xb448e265

Memory Information
MemTotal:   509368 KB
MemFree:      5560 KB
Buffers:     28288 KB
Cached:     288564 KB
VmPeak:     182856 KB
VmSize:     182792 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       65948 KB
VmRSS:       65948 KB
VmData:      46780 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100456 KB
VmPTE:         168 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
afb41000 afbb4000 r-xp /usr/lib/host-gl/libGL.so.1.2
afbd7000 afbe5000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afbe6000 afc1d000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afc21000 afc23000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afc24000 afc2b000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc2c000 afc39000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc3a000 afc48000 r-xp /usr/lib/libudev.so.0.13.1
afc49000 afc8b000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc8c000 afd18000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afd1e000 afd28000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afd29000 afd41000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd42000 afd48000 r-xp /usr/lib/libmmffile.so.0.0.0
afd49000 afd51000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd52000 afd54000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd55000 afd76000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd77000 afd79000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd7a000 afd98000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd99000 afd9f000 r-xp /usr/lib/libmemenv.so.1.1.0
afda0000 afde9000 r-xp /usr/lib/libleveldb.so.1.1.0
afdeb000 afdf6000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afdf7000 afe33000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe35000 afe4a000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe4b000 afe6b000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe6d000 afea3000 r-xp /usr/lib/libxslt.so.1.1.16
afea4000 afeac000 r-xp /usr/lib/libeeze.so.1.7.99
afead000 afeb2000 r-xp /usr/lib/libeukit.so.1.7.99
afeb3000 afebd000 r-xp /usr/lib/libenchant.so.1.6.1
afebe000 afec8000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afec9000 afed5000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afed6000 aff05000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
aff0b000 aff0f000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
aff10000 aff1c000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
aff1e000 aff25000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
aff26000 aff35000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff36000 aff39000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff3a000 aff4b000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff4c000 aff7b000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff7c000 aff82000 r-xp /usr/lib/libogg.so.0.7.1
aff83000 affae000 r-xp /usr/lib/libvorbis.so.0.4.3
affaf000 affb4000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
affb5000 affb9000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
affba000 affbf000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
affc0000 affe5000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affe6000 b0000000 r-xp /usr/lib/libnetwork.so.0.0.0
b0002000 b002e000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b002f000 b201a000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2114000 b227f000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b228b000 b230f000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2311000 b232d000 r-xp /usr/lib/libwifi-direct.so.0.0
b232e000 b2339000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b233a000 b2345000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2346000 b2354000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b2355000 b23f7000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b23fd000 b250f000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2515000 b253a000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b253c000 b2569000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2571000 b2572000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b257b000 b25d1000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b25d4000 b2604000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2605000 b2658000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2659000 b265f000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2660000 b2665000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2666000 b26ae000 r-xp /usr/lib/libpulse.so.0.12.4
b26af000 b26b3000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26b4000 b27a6000 r-xp /usr/lib/libasound.so.2.0.0
b27aa000 b27cf000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b27d0000 b27e4000 r-xp /usr/lib/libmmfsound.so.0.1.0
b27e5000 b28c5000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b28ca000 b2929000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b292a000 b2936000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2937000 b294a000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b294b000 b294e000 r-xp /usr/lib/libmm_ta.so.0.0.0
b294f000 b2966000 r-xp /usr/lib/libICE.so.6.3.0
b2969000 b2970000 r-xp /usr/lib/libSM.so.6.0.1
b2971000 b2972000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2973000 b297e000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b297f000 b2984000 r-xp /usr/lib/libsysman.so.0.2.0
b2985000 b2990000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2994000 b2998000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2999000 b29f6000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b29f8000 b2a00000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2a01000 b2a03000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2a04000 b2a67000 r-xp /usr/lib/libtiff.so.5.1.0
b2a6a000 b2abc000 r-xp /usr/lib/libturbojpeg.so
b2acd000 b2ad4000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ad5000 b2ade000 r-xp /usr/lib/libgif.so.4.1.6
b2adf000 b2b05000 r-xp /usr/lib/libavutil.so.51.73.101
b2b0c000 b2b51000 r-xp /usr/lib/libswscale.so.2.1.101
b2b52000 b2eb7000 r-xp /usr/lib/libavcodec.so.54.59.100
b31d8000 b31ff000 r-xp /usr/lib/libpng12.so.0.50.0
b3200000 b3207000 r-xp /usr/lib/libfeedback.so.0.1.4
b3208000 b3217000 r-xp /usr/lib/libtts.so
b3218000 b322e000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b322f000 b3349000 r-xp /usr/lib/libcairo.so.2.11200.12
b334c000 b3370000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3371000 b4157000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41c7000 b41cd000 r-xp /usr/lib/libslp_devman_plugin.so
b41ce000 b41d0000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41d1000 b41d4000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41d5000 b41d9000 r-xp /usr/lib/libdevice-node.so.0.1
b41da000 b41e8000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b41e9000 b41f2000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b41f3000 b41f9000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41fa000 b41fc000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b41fd000 b4201000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4202000 b4209000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b420a000 b420d000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b420e000 b420f000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4210000 b4223000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4225000 b422d000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b422e000 b425e000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b425f000 b4263000 r-xp /usr/lib/libuuid.so.1.3.0
b4264000 b4275000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4276000 b4277000 r-xp /usr/lib/libpmapi.so.1.2
b4278000 b4284000 r-xp /usr/lib/libminizip.so.1.0.0
b4285000 b4296000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4297000 b42bf000 r-xp /usr/lib/libpcre.so.0.0.1
b42c0000 b42c4000 r-xp /usr/lib/libheynoti.so.0.0.2
b42c5000 b42ca000 r-xp /usr/lib/libhaptic.so.0.1
b42cb000 b42cc000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42cd000 b42d4000 r-xp /usr/lib/libdevman.so.0.1
b42d5000 b42db000 r-xp /usr/lib/libchromium.so.1.0
b42dc000 b42e4000 r-xp /usr/lib/libalarm.so.0.0.0
b42e5000 b42ee000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b42ef000 b4307000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4308000 b47b2000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b47d4000 b47de000 r-xp /lib/libnss_files-2.13.so
b47e0000 b47e9000 r-xp /lib/libnss_nis-2.13.so
b47eb000 b47fe000 r-xp /lib/libnsl-2.13.so
b4802000 b4808000 r-xp /lib/libnss_compat-2.13.so
b4a0a000 b4a24000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a25000 b4b6e000 r-xp /usr/lib/libxml2.so.2.7.8
b4b74000 b4b9a000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b9b000 b4b9e000 r-xp /usr/lib/libiniparser.so.0
b4ba0000 b4c09000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c0b000 b4c27000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c28000 b4c2f000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c30000 b4c33000 r-xp /usr/lib/libdri2.so.0.0.0
b4c34000 b4c3f000 r-xp /usr/lib/libdrm.so.2.4.0
b4c40000 b4c45000 r-xp /usr/lib/libtbm.so.1.0.0
b4c46000 b4c4a000 r-xp /usr/lib/libXv.so.1.0.0
b4c4b000 b4d69000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d78000 b4d8d000 r-xp /usr/lib/libnotification.so.0.1.0
b4d8e000 b4d97000 r-xp /usr/lib/libutilX.so.1.1.0
b4d98000 b4dcb000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4dcd000 b4dde000 r-xp /lib/libresolv-2.13.so
b4de2000 b4de5000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4de6000 b4f4b000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f4f000 b50bf000 r-xp /usr/lib/libcrypto.so.1.0.0
b50d7000 b512d000 r-xp /usr/lib/libssl.so.1.0.0
b5132000 b5161000 r-xp /usr/lib/libidn.so.11.5.44
b5162000 b5171000 r-xp /usr/lib/libcares.so.2.0.0
b5172000 b5199000 r-xp /lib/libexpat.so.1.5.2
b519b000 b51ce000 r-xp /usr/lib/libicule.so.48.1
b51cf000 b51da000 r-xp /usr/lib/libsf_common.so
b51db000 b52b7000 r-xp /usr/lib/libstdc++.so.6.0.14
b52c3000 b52c6000 r-xp /usr/lib/libapp-checker.so.0.1.0
b52c7000 b52ec000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b52ed000 b52f2000 r-xp /usr/lib/libffi.so.5.0.10
b52f3000 b52f4000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b52f5000 b5326000 r-xp /usr/lib/libexif.so.12.3.3
b5333000 b533f000 r-xp /usr/lib/libethumb.so.1.7.99
b5340000 b53a4000 r-xp /usr/lib/libsndfile.so.1.0.25
b53aa000 b53ad000 r-xp /usr/lib/libctxdata.so.0.0.0
b53ae000 b53c5000 r-xp /usr/lib/libremix.so.0.0.0
b53c6000 b53c8000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b53c9000 b53f6000 r-xp /usr/lib/liblua-5.1.so
b53f7000 b5401000 r-xp /usr/lib/libembryo.so.1.7.99
b5402000 b5405000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5406000 b5467000 r-xp /usr/lib/libcurl.so.4.3.0
b5469000 b546f000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5470000 b5481000 r-xp /usr/lib/libXext.so.6.4.0
b5482000 b5487000 r-xp /usr/lib/libXtst.so.6.1.0
b5488000 b5490000 r-xp /usr/lib/libXrender.so.1.3.0
b5491000 b549a000 r-xp /usr/lib/libXrandr.so.2.2.0
b549b000 b549d000 r-xp /usr/lib/libXinerama.so.1.0.0
b549e000 b54ac000 r-xp /usr/lib/libXi.so.6.1.0
b54ad000 b54b1000 r-xp /usr/lib/libXfixes.so.3.1.0
b54b2000 b54b4000 r-xp /usr/lib/libXgesture.so.7.0.0
b54b5000 b54b7000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54b8000 b54ba000 r-xp /usr/lib/libXdamage.so.1.1.0
b54bb000 b54c5000 r-xp /usr/lib/libXcursor.so.1.0.2
b54c6000 b555d000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5562000 b5597000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5599000 b561e000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5628000 b563e000 r-xp /usr/lib/libfribidi.so.0.3.1
b563f000 b56c4000 r-xp /usr/lib/libfreetype.so.6.8.1
b56c8000 b570f000 r-xp /usr/lib/libjpeg.so.8.0.2
b5720000 b573f000 r-xp /lib/libz.so.1.2.5
b5740000 b574c000 r-xp /usr/lib/libemotion.so.1.7.99
b574d000 b5753000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5755000 b5765000 r-xp /usr/lib/libsensor.so.1.1.0
b5768000 b576e000 r-xp /usr/lib/libappcore-common.so.1.1
b6877000 b69d2000 r-xp /usr/lib/libicuuc.so.48.1
b69e0000 b6bbf000 r-xp /usr/lib/libicui18n.so.48.1
b6bc6000 b6bc9000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6bca000 b6bd6000 r-xp /usr/lib/libvconf.so.0.2.45
b6bd7000 b6be0000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6be1000 b6bf2000 r-xp /usr/lib/libail.so.0.1.0
b6bf3000 b6c03000 r-xp /usr/lib/libaul.so.0.1.0
b6c04000 b6c54000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c55000 b6c98000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c9a000 b6cf5000 r-xp /usr/lib/libeina.so.1.7.99
b6cf7000 b6d16000 r-xp /usr/lib/libecore.so.1.7.99
b6d25000 b6d50000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d52000 b6d5d000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d5e000 b6d6a000 r-xp /usr/lib/libedbus.so.1.7.99
b6d6b000 b6d6e000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d6f000 b6d75000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d76000 b6d98000 r-xp /usr/lib/libefreet.so.1.7.99
b6d9a000 b6e31000 r-xp /usr/lib/libedje.so.1.7.99
b6e33000 b6e4a000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e5e000 b6e65000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e66000 b6e93000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e95000 b6f9f000 r-xp /usr/lib/libevas.so.1.7.99
b6fba000 b6fd7000 r-xp /usr/lib/libeet.so.1.7.99
b6fd8000 b6ffc000 r-xp /lib/libm-2.13.so
b6ffe000 b71ce000 r-xp /usr/lib/libelementary.so.1.7.99
b71db000 b71e6000 r-xp /usr/lib/libcapi-web-favorites.so
b71e7000 b71e9000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b71ec000 b71f0000 r-xp /lib/libattr.so.1.1.0
b71f1000 b71f3000 r-xp /usr/lib/libXau.so.6.0.0
b71f5000 b71fc000 r-xp /lib/librt-2.13.so
b71fe000 b7206000 r-xp /lib/libcrypt-2.13.so
b722f000 b7232000 r-xp /lib/libcap.so.2.21
b7233000 b7235000 r-xp /usr/lib/libiri.so
b7236000 b7250000 r-xp /lib/libgcc_s-4.5.3.so.1
b7251000 b7271000 r-xp /usr/lib/libxcb.so.1.1.0
b7273000 b727c000 r-xp /lib/libunwind.so.8.0.1
b7286000 b73dc000 r-xp /lib/libc-2.13.so
b73e2000 b73e7000 r-xp /usr/lib/libsmack.so.1.0.0
b73e8000 b7434000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7435000 b743a000 r-xp /usr/lib/libbundle.so.0.1.22
b743b000 b743d000 r-xp /lib/libdl-2.13.so
b7440000 b7569000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b756a000 b757f000 r-xp /lib/libpthread-2.13.so
b7584000 b7585000 r-xp /usr/lib/libdlog.so.0.0.0
b7586000 b7630000 r-xp /usr/lib/libsqlite3.so.0.8.6
b7633000 b763f000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b7640000 b7775000 r-xp /usr/lib/libX11.so.6.3.0
b777a000 b7782000 r-xp /usr/lib/libecore_imf.so.1.7.99
b7783000 b7788000 r-xp /usr/lib/libappcore-efl.so.1.1
b778a000 b778e000 r-xp /usr/lib/libsys-assert.so
b7792000 b7793000 r-xp [vdso]
b7793000 b77af000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:2695)
Call Stack Count: 33
 0: non-virtual thunk to MyHondanaMainForm::CreateItem(int) + 0x45 (0xb25b5de5) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3ade5
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
