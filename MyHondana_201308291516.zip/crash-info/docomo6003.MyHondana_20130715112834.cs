S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG2
Build-Date: 2013.07.04 20:54:23

Crash Information
Process Name: MyHondana
PID: 8782
Date: 2013-07-15 11:28:34(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=8782 tid=8782
Signal: 6
      (SIGABRT)
      si_code: -6
      signal sent by tkill (sent by pid 8782, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0x0000224e
r2   = 0x00000006, r3   = 0x0000224e
r4   = 0x00000006, r5   = 0xb6c93be4
r6   = 0xb6c93000, r7   = 0x0000010c
r8   = 0x00000be4, r9   = 0x000d8fc0
r10  = 0xb6fcd000, fp   = 0xbefb9e20
ip   = 0xb6fcd4c0, sp   = 0xbefb9748
lr   = 0xb6b9a55c, pc   = 0xb6b96760
cpsr = 0x20070010

Memory Information
MemTotal:  2063912 KB
MemFree:   1345416 KB
Buffers:     34812 KB
Cached:     359084 KB
VmPeak:     116936 KB
VmSize:     112816 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       25712 KB
VmRSS:       25712 KB
VmData:      16520 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       66260 KB
VmPTE:          96 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00070000 rw-p [heap]
00070000 001e1000 rw-p [heap]
b05f3000 b05f7000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b0600000 b0dff000 rwxp [stack:8784]
b0dff000 b0f4d000 r-xp /usr/lib/r3p2/libMali.so
b0f59000 b0f81000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0f85000 b0fa3000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b0fb2000 b0fbc000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b12f6000 b1342000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b134b000 b1350000 r-xp /usr/lib/libjson.so.0.0.1
b1358000 b135c000 r-xp /usr/lib/liblocation-pos-log.so
b1364000 b1376000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b137e000 b1380000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b1388000 b138d000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b1395000 b13a0000 r-xp /usr/lib/libdrm-trusted.so.0.0.52
b13a8000 b13aa000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b13b2000 b13bf000 r-xp /usr/lib/libdrm-client.so.0.0.90
b13c8000 b13d0000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b13f2000 b1429000 r-xp /usr/lib/libpulse.so.0.16.2
b1431000 b1495000 r-xp /usr/lib/libasound.so.2.0.0
b149f000 b14a2000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b14ab000 b14af000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b14b8000 b14d5000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b14dd000 b14e2000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b14ea000 b1517000 r-xp /usr/lib/libSLP-location.so.0.0.0
b1520000 b1529000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b1531000 b1535000 r-xp /usr/lib/libmmffile.so.0.0.0
b153d000 b1544000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b154d000 b1567000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b156f000 b158a000 r-xp /usr/lib/libmedia-service.so.1.0.0
b1592000 b159d000 r-xp /usr/lib/libmdm-common.so.1.0.37
b15a5000 b15b3000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b15bc000 b15c3000 r-xp /usr/lib/libenchant.so.1.6.1
b15cb000 b15ce000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.8
b15d7000 b15e0000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b15e9000 b15ed000 r-xp /usr/lib/libmmfsession.so.0.0.0
b15f6000 b1605000 r-xp /usr/lib/libmmfsound.so.0.1.0
b160d000 b1612000 r-xp /usr/lib/libmemenv.so.1.1.0
b161a000 b1658000 r-xp /usr/lib/libleveldb.so.1.1.0
b1661000 b168b000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b1694000 b1696000 r-xp /usr/lib/libsecfw.so
b169e000 b16a7000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b16b2000 b16c1000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b16c9000 b16e1000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b16e3000 b16f0000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b16f9000 b1702000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b170a000 b174c000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b1755000 b17f1000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b17fd000 b1822000 r-xp /usr/lib/libxslt.so.1.1.16
b182b000 b182d000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b1835000 b183d000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b1845000 b1850000 r-xp /usr/lib/libcapi-location-manager.so.0.1.12
b1858000 b185b000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b1863000 b1868000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b1870000 b1897000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.70
b189f000 b18b5000 r-xp /usr/lib/osp/libosp-locations.so.1.2.1.0
b18be000 b18fb000 r-xp /usr/lib/libmdm.so.1.0.63
b1903000 b1918000 r-xp /usr/lib/libnetwork.so.0.0.0
b1920000 b1929000 r-xp /usr/lib/libcapi-web-favorites.so
b1931000 b2b89000 r-xp /usr/lib/libewebkit2.so.0.10.144.6
b2c7c000 b2ccf000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2cd8000 b2cef000 r-xp /usr/lib/libwifi-direct.so.0.0
b2cf7000 b2cff000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.7
b2d07000 b2d10000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2d18000 b2d22000 r-xp /usr/lib/libcapi-network-connection.so.0.1.10
b2d2a000 b2d8e000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2d9b000 b2e50000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2e5d000 b2e77000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2e80000 b2e9e000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2eaa000 b2eb0000 r-xp /usr/lib/libUMP.so
b2ebf000 b2f15000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2f20000 b2f68000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2f70000 b3000000 r-xp /usr/lib/libCOREGL.so.3.0
b300a000 b300d000 r-xp /usr/lib/libmm_ta.so.0.0.0
b3015000 b301c000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b3025000 b3034000 r-xp /usr/lib/libICE.so.6.3.0
b303e000 b3043000 r-xp /usr/lib/libSM.so.6.0.1
b304b000 b304c000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3054000 b3056000 r-xp /usr/lib/libledplayer.so.0.1
b305e000 b3064000 r-xp /usr/lib/libxcb-render.so.0.0.0
b306c000 b306d000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b3076000 b307d000 r-xp /usr/lib/libGLESv2.so.2.0
b3085000 b30cc000 r-xp /usr/lib/libtiff.so.5.1.0
b30d7000 b3100000 r-xp /usr/lib/libturbojpeg.so
b3119000 b311d000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3126000 b312c000 r-xp /usr/lib/libgif.so.4.1.6
b3134000 b3156000 r-xp /usr/lib/libavutil.so.51.73.101
b3165000 b3193000 r-xp /usr/lib/libswscale.so.2.1.101
b319c000 b3493000 r-xp /usr/lib/libavcodec.so.54.59.100
b37ba000 b37d3000 r-xp /usr/lib/libpng12.so.0.50.0
b37dc000 b37e3000 r-xp /usr/lib/libfeedback.so.0.1.4
b37ec000 b37ff000 r-xp /usr/lib/libtts.so
b3808000 b380a000 r-xp /usr/lib/libEGL.so.1.4
b3812000 b38c9000 r-xp /usr/lib/libcairo.so.2.11200.12
b38d3000 b38ec000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b38f6000 b38fa000 r-xp /usr/lib/libss-client.so.1.0.0
b3903000 b3905000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b390d000 b41b9000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b422a000 b4233000 r-xp /usr/lib/libslp_devman_plugin.so
b423c000 b423e000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4246000 b4249000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4251000 b4254000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b425c000 b4269000 r-xp /usr/lib/libmodem.so.0.0.0
b4271000 b4274000 r-xp /usr/lib/libdevice-node.so.0.1
b427c000 b428c000 r-xp /usr/lib/libaccounts-svc.so.0.2.68
b4294000 b4297000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b429f000 b42a5000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b42ad000 b42b2000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b42ba000 b42bb000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b42c4000 b42c7000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b42cf000 b42d4000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b42dc000 b42df000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b42e7000 b42e8000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b42f0000 b42fe000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4307000 b430d000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4315000 b433a000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4342000 b4345000 r-xp /usr/lib/libuuid.so.1.3.0
b434e000 b4362000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b436a000 b4372000 r-xp /usr/lib/libminizip.so.1.0.0
b437a000 b4386000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b438f000 b43ad000 r-xp /usr/lib/libpcre.so.0.0.1
b43b5000 b43b9000 r-xp /usr/lib/libheynoti.so.0.0.2
b43c1000 b43cf000 r-xp /usr/lib/libdeviced.so.0.1.0
b43d8000 b43e3000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b43f0000 b43f9000 r-xp /usr/lib/libdevman.so.0.1
b4401000 b4405000 r-xp /usr/lib/libchromium.so.1.0
b440d000 b441e000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4427000 b4733000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b475b000 b4765000 r-xp /lib/libnss_files-2.13.so
b476e000 b476f000 r-xp /usr/lib/libpmapi.so.1.2
b4777000 b477e000 r-xp /usr/lib/libalarm.so.0.0.0
b4786000 b4799000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b47a2000 b47be000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b47c7000 b47ca000 r-xp /usr/lib/libiniparser.so.0
b47d3000 b4823000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b482d000 b483e000 r-xp /usr/lib/libcom-core.so.0.0.1
b4846000 b484c000 r-xp /usr/lib/libappsvc.so.0.1.0
b4854000 b4856000 r-xp /usr/lib/libdri2.so.0.0.0
b485e000 b4866000 r-xp /usr/lib/libdrm.so.2.4.0
b486e000 b4872000 r-xp /usr/lib/libtbm.so.1.0.0
b487a000 b487d000 r-xp /usr/lib/libXv.so.1.0.0
b4885000 b488f000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4898000 b4964000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b497a000 b4989000 r-xp /usr/lib/libnotification.so.0.1.0
b4991000 b49b5000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b49be000 b49ce000 r-xp /lib/libresolv-2.13.so
b49d2000 b49d4000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b49dc000 b4ab4000 r-xp /usr/lib/libxml2.so.2.7.8
b4ac1000 b4b9e000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4ba9000 b4bae000 r-xp /usr/lib/libcheck.so.0.0.0
b4bb6000 b4bc0000 r-xp /usr/lib/libspdy.so.0.0.0
b4bc9000 b4d1c000 r-xp /usr/lib/libcrypto.so.1.0.0
b4d3a000 b4d86000 r-xp /usr/lib/libssl.so.1.0.0
b4d92000 b4dc0000 r-xp /usr/lib/libidn.so.11.5.44
b4dc9000 b4dd3000 r-xp /usr/lib/libcares.so.2.1.0
b4ddb000 b4df2000 r-xp /lib/libexpat.so.1.5.2
b4dfc000 b4e20000 r-xp /usr/lib/libicule.so.48.1
b4e29000 b4e37000 r-xp /usr/lib/libsf_common.so
b4e40000 b4edb000 r-xp /usr/lib/libstdc++.so.6.0.14
b4eee000 b4f06000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4f07000 b4f0a000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4f12000 b4f16000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4f1f000 b4f24000 r-xp /usr/lib/libffi.so.5.0.10
b4f2c000 b4f2d000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4f35000 b4f3f000 r-xp /usr/lib/libXext.so.6.4.0
b4f48000 b4f4b000 r-xp /usr/lib/libXtst.so.6.1.0
b4f53000 b4f59000 r-xp /usr/lib/libXrender.so.1.3.0
b4f61000 b4f67000 r-xp /usr/lib/libXrandr.so.2.2.0
b4f6f000 b4f70000 r-xp /usr/lib/libXinerama.so.1.0.0
b4f79000 b4f82000 r-xp /usr/lib/libXi.so.6.1.0
b4f8a000 b4f8d000 r-xp /usr/lib/libXfixes.so.3.1.0
b4f95000 b4f97000 r-xp /usr/lib/libXgesture.so.7.0.0
b4f9f000 b4fa0000 r-xp /usr/lib/libXdamage.so.1.1.0
b4fa9000 b4fb0000 r-xp /usr/lib/libXcursor.so.1.0.2
b4fb8000 b4fdb000 r-xp /usr/lib/libexif.so.12.3.3
b4fef000 b4ff9000 r-xp /usr/lib/libethumb.so.1.7.99
b5001000 b5045000 r-xp /usr/lib/libsndfile.so.1.0.25
b5053000 b5055000 r-xp /usr/lib/libctxdata.so.0.0.0
b505d000 b506b000 r-xp /usr/lib/libremix.so.0.0.0
b5073000 b5074000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b507c000 b5095000 r-xp /usr/lib/liblua-5.1.so
b509e000 b50a5000 r-xp /usr/lib/libembryo.so.1.7.99
b50ae000 b50ee000 r-xp /usr/lib/libcurl.so.4.3.0
b50f7000 b5161000 r-xp /usr/lib/libpixman-1.so.0.28.2
b516e000 b5192000 r-xp /usr/lib/libfontconfig.so.1.5.0
b519b000 b51f7000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5209000 b521d000 r-xp /usr/lib/libfribidi.so.0.3.1
b5225000 b527d000 r-xp /usr/lib/libfreetype.so.6.8.1
b5288000 b52ac000 r-xp /usr/lib/libjpeg.so.8.0.2
b52c4000 b52db000 r-xp /lib/libz.so.1.2.5
b52e3000 b52eb000 r-xp /usr/lib/libemotion.so.1.7.99
b52f3000 b52f8000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5301000 b530f000 r-xp /usr/lib/libsensor.so.1.1.0
b531b000 b5321000 r-xp /usr/lib/libappcore-common.so.1.1
b5329000 b532b000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.79
b5333000 b533e000 r-xp /usr/lib/libresourced.so.0.2.79
b5346000 b5349000 r-xp /usr/lib/libproc-stat.so.0.2.79
b6346000 b642e000 r-xp /usr/lib/libicuuc.so.48.1
b643b000 b655b000 r-xp /usr/lib/libicui18n.so.48.1
b6569000 b656c000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6574000 b657c000 r-xp /usr/lib/libvconf.so.0.2.45
b6584000 b658a000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6592000 b659e000 r-xp /usr/lib/libail.so.0.1.0
b65a6000 b65b1000 r-xp /usr/lib/libaul.so.0.1.0
b65ba000 b65d1000 r-xp /usr/lib/libecore_input.so.1.7.99
b65ec000 b6609000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6612000 b6614000 r-xp /usr/lib/libXcomposite.so.1.0.0
b661c000 b6650000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6659000 b6688000 r-xp /usr/lib/libecore_x.so.1.7.99
b6692000 b66d1000 r-xp /usr/lib/libeina.so.1.7.99
b66da000 b66ef000 r-xp /usr/lib/libecore.so.1.7.99
b6706000 b6721000 r-xp /usr/lib/libecore_con.so.1.7.99
b672a000 b672f000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6737000 b673f000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6747000 b6750000 r-xp /usr/lib/libedbus.so.1.7.99
b6758000 b675a000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6762000 b6766000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b676f000 b6785000 r-xp /usr/lib/libefreet.so.1.7.99
b678f000 b67eb000 r-xp /usr/lib/libedje.so.1.7.99
b67f5000 b68a5000 r-xp /usr/lib/libevas.so.1.7.99
b68c7000 b68da000 r-xp /usr/lib/libeet.so.1.7.99
b68e3000 b694d000 r-xp /lib/libm-2.13.so
b6956000 b695e000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b695f000 b6966000 r-xp /usr/lib/libutilX.so.1.1.0
b696e000 b6a90000 r-xp /usr/lib/libelementary.so.1.7.99
b6aa5000 b6aa8000 r-xp /lib/libattr.so.1.1.0
b6ab0000 b6ab2000 r-xp /usr/lib/libXau.so.6.0.0
b6aba000 b6ac0000 r-xp /lib/librt-2.13.so
b6ac9000 b6ad1000 r-xp /lib/libcrypt-2.13.so
b6b01000 b6b04000 r-xp /lib/libcap.so.2.21
b6b0c000 b6b0e000 r-xp /usr/lib/libiri.so
b6b16000 b6b2b000 r-xp /usr/lib/libxcb.so.1.1.0
b6b33000 b6b3e000 r-xp /lib/libunwind.so.8.0.1
b6b6c000 b6c89000 r-xp /lib/libc-2.13.so
b6c97000 b6ca0000 r-xp /lib/libgcc_s-4.5.3.so.1
b6ca8000 b6cd4000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6cdd000 b6ce0000 r-xp /usr/lib/libbundle.so.0.1.22
b6ce8000 b6cea000 r-xp /lib/libdl-2.13.so
b6cf3000 b6cf6000 r-xp /usr/lib/libsmack.so.1.0.0
b6cfe000 b6dd8000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6de1000 b6df5000 r-xp /lib/libpthread-2.13.so
b6e01000 b6e06000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e0e000 b6e16000 r-xp /usr/lib/libappcore-efl.so.1.1
b6e18000 b6e19000 r-xp /usr/lib/libdlog.so.0.0.0
b6e22000 b6e8f000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6e99000 b6ea2000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6eaa000 b6f90000 r-xp /usr/lib/libX11.so.6.3.0
b6f9b000 b6f9c000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6fa4000 b6fa8000 r-xp /usr/lib/libsys-assert.so
b6fb0000 b6fcd000 r-xp /lib/ld-2.13.so
bef9b000 befbc000 rwxp [stack]
End of Maps Information

Callstack Information (PID:8782)
Call Stack Count: 25
 0: gsignal + 0x3c (0xb6b96760) [/lib/libc.so.6] + 0x2a760
 1: abort + 0x1ac (0xb6b9a55c) [/lib/libc.so.6] + 0x2e55c
 2: __assert_fail + 0x10c (0xb6b8f63c) [/lib/libc.so.6] + 0x2363c
 3: SysAssertfInternal + 0x9e (0xb4564657) [/usr/lib/osp/libosp-appfw.so] + 0x13d657
 4: Tizen::Io::File::Read(void*, int) + 0x54 (0xb45adda5) [/usr/lib/osp/libosp-appfw.so] + 0x186da5
 5: MyHondanaFrame::CheckLogin() + 0x230 (0xb2ee61f8) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x271f8
 6: MyHondanaFrame::OnInitializing() + 0x18 (0xb2ee5cf4) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x26cf4
 7: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x22 (0xb3bb8fb7) [/usr/lib/osp/libosp-uifw.so] + 0x2abfb7
 8: Tizen::Ui::Controls::_FrameImpl::OnAttachedToMainTree() + 0xa (0xb3d7790b) [/usr/lib/osp/libosp-uifw.so] + 0x46a90b
 9: Tizen::Ui::_ControlManager::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0x76 (0xb3bc831f) [/usr/lib/osp/libosp-uifw.so] + 0x2bb31f
10: Tizen::Ui::_ControlManager::ActivateWindow(Tizen::Ui::_Window&, bool) + 0xcc (0xb3bc8d4d) [/usr/lib/osp/libosp-uifw.so] + 0x2bbd4d
11: Tizen::Ui::_ControlManager::OpenWindow(Tizen::Ui::_Window&, bool) + 0x2e (0xb3bc8f5f) [/usr/lib/osp/libosp-uifw.so] + 0x2bbf5f
12: Tizen::Ui::_Window::Open(bool) + 0x3c (0xb3bb6275) [/usr/lib/osp/libosp-uifw.so] + 0x2a9275
13: Tizen::Ui::_WindowImpl::Open(bool) + 0x12 (0xb3bc62eb) [/usr/lib/osp/libosp-uifw.so] + 0x2b92eb
14: Tizen::App::_UiAppImpl::AddFrame(Tizen::Ui::Controls::Frame const&) + 0x40 (0xb3f75309) [/usr/lib/osp/libosp-uifw.so] + 0x668309
15: Tizen::App::UiApp::AddFrame(Tizen::Ui::Controls::Frame const&) + 0x14 (0xb3f746cd) [/usr/lib/osp/libosp-uifw.so] + 0x6676cd
16: MyHondanaApp::OnAppInitialized() + 0x100 (0xb2ed93f0) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x1a3f0
17: Tizen::App::_UiAppImpl::OnAppInitialized() + 0x18 (0xb3f74bb1) [/usr/lib/osp/libosp-uifw.so] + 0x667bb1
18: Tizen::App::_AppImpl::OnService(service_s*, void*) + 0x1da (0xb451752f) [/usr/lib/osp/libosp-appfw.so] + 0xf052f
19: (0xb42f9bdd) [/usr/lib/libcapi-appfw-application.so.0] + 0x9bdd
20: (0xb6e10f28) [/usr/lib/libappcore-efl.so.1] + 0x2f28
21: (0xb531c94c) [/usr/lib/libappcore-common.so.1] + 0x194c
22: (0xb531d024) [/usr/lib/libappcore-common.so.1] + 0x2024
23: (0xb65a9225) [/usr/lib/libaul.so.0] + 0x3225
dladdr failed 24: (0x82150) (null)
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
