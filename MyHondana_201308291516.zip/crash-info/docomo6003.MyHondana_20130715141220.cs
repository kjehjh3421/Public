S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 3391
Date: 2013-07-15 14:12:20(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=3391 tid=3391
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 3391, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x00000000, esi = 0xb254c9a1
ebp = 0xbf8b5c58, esp = 0xbf8b5bd0
eax = 0x00000000, ebx = 0xb256670c
ecx = 0x00000000, edx = 0x00000000
eip = 0xb2507a29

Memory Information
MemTotal:   509368 KB
MemFree:     16692 KB
Buffers:      2492 KB
Cached:     321236 KB
VmPeak:     265280 KB
VmSize:     224684 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       87188 KB
VmRSS:       67776 KB
VmData:      84360 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      102244 KB
VmPTE:         184 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
aba27000 aba39000 r-xp /usr/lib/libhogweed.so.2.0
aba3a000 aba9a000 r-xp /usr/lib/sse2/libgmp.so.10.0.1
abaa1000 abac7000 r-xp /usr/lib/libnettle.so.4.0
abac8000 abb92000 r-xp /usr/lib/libgnutls.so.26.22.4
abba8000 abbb9000 r-xp /usr/lib/gio/modules/libgiognutls.so
ad7c5000 ad7c7000 r-xp /usr/lib/remix/libeet_sndfile_reader.so
ad7c8000 ad7cb000 r-xp /usr/lib/remix/libtizen_sound_player.so.1.0.0
ad7cc000 ad7cd000 r-xp /usr/lib/edje/modules/multisense_factory/linux-gnu-i686-1.0.0/module.so
ad7d3000 ad7f7000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
ae2d4000 ae2d9000 r-xp /usr/lib/libefl-assist.so.0.1.0
afab8000 afb2b000 r-xp /usr/lib/host-gl/libGL.so.1.2
afb4e000 afb5c000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afb5d000 afb94000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afb98000 afb9a000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afb9b000 afba2000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afba3000 afbb0000 r-xp /usr/lib/libdrm-client.so.0.0.1
afbb1000 afbbf000 r-xp /usr/lib/libudev.so.0.13.1
afbc0000 afc02000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc03000 afc8f000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afc95000 afc9f000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afca0000 afcb8000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afcb9000 afcbf000 r-xp /usr/lib/libmmffile.so.0.0.0
afcc0000 afcc8000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afcc9000 afccb000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afccc000 afced000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afcee000 afcf0000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afcf1000 afd0f000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd10000 afd16000 r-xp /usr/lib/libmemenv.so.1.1.0
afd17000 afd60000 r-xp /usr/lib/libleveldb.so.1.1.0
afd62000 afd6d000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd6e000 afdaa000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afdac000 afdc1000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afdc2000 afde2000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afde4000 afe1a000 r-xp /usr/lib/libxslt.so.1.1.16
afe1b000 afe23000 r-xp /usr/lib/libeeze.so.1.7.99
afe24000 afe29000 r-xp /usr/lib/libeukit.so.1.7.99
afe2a000 afe34000 r-xp /usr/lib/libenchant.so.1.6.1
afe35000 afe3f000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe40000 afe4c000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afe4d000 afe7c000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afe82000 afe86000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afe87000 afe93000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afe95000 afe9c000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afe9d000 afeac000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afead000 afeb0000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
afeb1000 afec2000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
afec3000 afef2000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
afef3000 afef9000 r-xp /usr/lib/libogg.so.0.7.1
afefa000 aff25000 r-xp /usr/lib/libvorbis.so.0.4.3
aff26000 aff2b000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff2c000 aff30000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff31000 aff36000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff37000 aff5c000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
aff5d000 aff77000 r-xp /usr/lib/libnetwork.so.0.0.0
aff79000 affa5000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
affa6000 b1f91000 r-xp /usr/lib/libewebkit2.so.0.11.72
b208b000 b21f6000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b2202000 b2286000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2288000 b22a4000 r-xp /usr/lib/libwifi-direct.so.0.0
b22a5000 b22b0000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b22b1000 b22bc000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b22bd000 b22cb000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b22cc000 b236e000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2374000 b2486000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b248c000 b24b1000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b24b3000 b24e0000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b24e6000 b24e7000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
b24e8000 b24e9000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b24f2000 b2564000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2567000 b2597000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2598000 b25eb000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b25ec000 b25f2000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b25f3000 b25f8000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b25f9000 b2641000 r-xp /usr/lib/libpulse.so.0.12.4
b2642000 b2646000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b2647000 b2739000 r-xp /usr/lib/libasound.so.2.0.0
b273d000 b2762000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2763000 b2777000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2778000 b2858000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b285d000 b28bc000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b28bd000 b28c9000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b28ca000 b28dd000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b28de000 b28e1000 r-xp /usr/lib/libmm_ta.so.0.0.0
b28e2000 b28f9000 r-xp /usr/lib/libICE.so.6.3.0
b28fc000 b2903000 r-xp /usr/lib/libSM.so.6.0.1
b2904000 b2905000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2906000 b2911000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2912000 b2917000 r-xp /usr/lib/libsysman.so.0.2.0
b2918000 b2923000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2927000 b292b000 r-xp /usr/lib/libmmfsession.so.0.0.0
b292c000 b2989000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b298b000 b2993000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2994000 b2996000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2997000 b29fa000 r-xp /usr/lib/libtiff.so.5.1.0
b29fd000 b2a4f000 r-xp /usr/lib/libturbojpeg.so
b2a60000 b2a67000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2a68000 b2a71000 r-xp /usr/lib/libgif.so.4.1.6
b2a72000 b2a98000 r-xp /usr/lib/libavutil.so.51.73.101
b2a9f000 b2ae4000 r-xp /usr/lib/libswscale.so.2.1.101
b2ae5000 b2e4a000 r-xp /usr/lib/libavcodec.so.54.59.100
b316b000 b3192000 r-xp /usr/lib/libpng12.so.0.50.0
b3193000 b319a000 r-xp /usr/lib/libfeedback.so.0.1.4
b319b000 b31aa000 r-xp /usr/lib/libtts.so
b31ab000 b31c1000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b31c2000 b32dc000 r-xp /usr/lib/libcairo.so.2.11200.12
b32df000 b3303000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3304000 b40ea000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b415a000 b4160000 r-xp /usr/lib/libslp_devman_plugin.so
b4161000 b4163000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4164000 b4167000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4168000 b416c000 r-xp /usr/lib/libdevice-node.so.0.1
b416d000 b417b000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b417c000 b4185000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4186000 b418c000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b418d000 b418f000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4190000 b4194000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4195000 b419c000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b419d000 b41a0000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b41a1000 b41a2000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41a3000 b41b6000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b41b8000 b41c0000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41c1000 b41f1000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b41f2000 b41f6000 r-xp /usr/lib/libuuid.so.1.3.0
b41f7000 b4208000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4209000 b420a000 r-xp /usr/lib/libpmapi.so.1.2
b420b000 b4217000 r-xp /usr/lib/libminizip.so.1.0.0
b4218000 b4229000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b422a000 b4252000 r-xp /usr/lib/libpcre.so.0.0.1
b4253000 b4257000 r-xp /usr/lib/libheynoti.so.0.0.2
b4258000 b425d000 r-xp /usr/lib/libhaptic.so.0.1
b425e000 b425f000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4260000 b4267000 r-xp /usr/lib/libdevman.so.0.1
b4268000 b426e000 r-xp /usr/lib/libchromium.so.1.0
b426f000 b4277000 r-xp /usr/lib/libalarm.so.0.0.0
b4278000 b4281000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b4282000 b429a000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b429b000 b4745000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4767000 b4771000 r-xp /lib/libnss_files-2.13.so
b4773000 b477c000 r-xp /lib/libnss_nis-2.13.so
b477e000 b4791000 r-xp /lib/libnsl-2.13.so
b4795000 b479b000 r-xp /lib/libnss_compat-2.13.so
b499d000 b49b7000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b49b8000 b4b01000 r-xp /usr/lib/libxml2.so.2.7.8
b4b07000 b4b2d000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b2e000 b4b31000 r-xp /usr/lib/libiniparser.so.0
b4b33000 b4b9c000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4b9e000 b4bba000 r-xp /usr/lib/libcom-core.so.0.0.1
b4bbb000 b4bc2000 r-xp /usr/lib/libappsvc.so.0.1.0
b4bc3000 b4bc6000 r-xp /usr/lib/libdri2.so.0.0.0
b4bc7000 b4bd2000 r-xp /usr/lib/libdrm.so.2.4.0
b4bd3000 b4bd8000 r-xp /usr/lib/libtbm.so.1.0.0
b4bd9000 b4bdd000 r-xp /usr/lib/libXv.so.1.0.0
b4bde000 b4cfc000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d0b000 b4d20000 r-xp /usr/lib/libnotification.so.0.1.0
b4d21000 b4d2a000 r-xp /usr/lib/libutilX.so.1.1.0
b4d2b000 b4d5e000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d60000 b4d71000 r-xp /lib/libresolv-2.13.so
b4d75000 b4d78000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d79000 b4ede000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4ee2000 b5052000 r-xp /usr/lib/libcrypto.so.1.0.0
b506a000 b50c0000 r-xp /usr/lib/libssl.so.1.0.0
b50c5000 b50f4000 r-xp /usr/lib/libidn.so.11.5.44
b50f5000 b5104000 r-xp /usr/lib/libcares.so.2.0.0
b5105000 b512c000 r-xp /lib/libexpat.so.1.5.2
b512e000 b5161000 r-xp /usr/lib/libicule.so.48.1
b5162000 b516d000 r-xp /usr/lib/libsf_common.so
b516e000 b524a000 r-xp /usr/lib/libstdc++.so.6.0.14
b5256000 b5259000 r-xp /usr/lib/libapp-checker.so.0.1.0
b525a000 b527f000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5280000 b5285000 r-xp /usr/lib/libffi.so.5.0.10
b5286000 b5287000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5288000 b52b9000 r-xp /usr/lib/libexif.so.12.3.3
b52c6000 b52d2000 r-xp /usr/lib/libethumb.so.1.7.99
b52d3000 b5337000 r-xp /usr/lib/libsndfile.so.1.0.25
b533d000 b5340000 r-xp /usr/lib/libctxdata.so.0.0.0
b5341000 b5358000 r-xp /usr/lib/libremix.so.0.0.0
b5359000 b535b000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b535c000 b5389000 r-xp /usr/lib/liblua-5.1.so
b538a000 b5394000 r-xp /usr/lib/libembryo.so.1.7.99
b5395000 b5398000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5399000 b53fa000 r-xp /usr/lib/libcurl.so.4.3.0
b53fc000 b5402000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5403000 b5414000 r-xp /usr/lib/libXext.so.6.4.0
b5415000 b541a000 r-xp /usr/lib/libXtst.so.6.1.0
b541b000 b5423000 r-xp /usr/lib/libXrender.so.1.3.0
b5424000 b542d000 r-xp /usr/lib/libXrandr.so.2.2.0
b542e000 b5430000 r-xp /usr/lib/libXinerama.so.1.0.0
b5431000 b543f000 r-xp /usr/lib/libXi.so.6.1.0
b5440000 b5444000 r-xp /usr/lib/libXfixes.so.3.1.0
b5445000 b5447000 r-xp /usr/lib/libXgesture.so.7.0.0
b5448000 b544a000 r-xp /usr/lib/libXcomposite.so.1.0.0
b544b000 b544d000 r-xp /usr/lib/libXdamage.so.1.1.0
b544e000 b5458000 r-xp /usr/lib/libXcursor.so.1.0.2
b5459000 b54f0000 r-xp /usr/lib/libpixman-1.so.0.28.2
b54f5000 b552a000 r-xp /usr/lib/libfontconfig.so.1.5.0
b552c000 b55b1000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b55bb000 b55d1000 r-xp /usr/lib/libfribidi.so.0.3.1
b55d2000 b5657000 r-xp /usr/lib/libfreetype.so.6.8.1
b565b000 b56a2000 r-xp /usr/lib/libjpeg.so.8.0.2
b56b3000 b56d2000 r-xp /lib/libz.so.1.2.5
b56d3000 b56df000 r-xp /usr/lib/libemotion.so.1.7.99
b56e0000 b56e6000 r-xp /usr/lib/libecore_fb.so.1.7.99
b56e8000 b56f8000 r-xp /usr/lib/libsensor.so.1.1.0
b56fb000 b5701000 r-xp /usr/lib/libappcore-common.so.1.1
b680a000 b6965000 r-xp /usr/lib/libicuuc.so.48.1
b6973000 b6b52000 r-xp /usr/lib/libicui18n.so.48.1
b6b59000 b6b5c000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b5d000 b6b69000 r-xp /usr/lib/libvconf.so.0.2.45
b6b6a000 b6b73000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6b74000 b6b85000 r-xp /usr/lib/libail.so.0.1.0
b6b86000 b6b96000 r-xp /usr/lib/libaul.so.0.1.0
b6b97000 b6be7000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6be8000 b6c2b000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c2d000 b6c88000 r-xp /usr/lib/libeina.so.1.7.99
b6c8a000 b6ca9000 r-xp /usr/lib/libecore.so.1.7.99
b6cb8000 b6ce3000 r-xp /usr/lib/libecore_con.so.1.7.99
b6ce5000 b6cf0000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6cf1000 b6cfd000 r-xp /usr/lib/libedbus.so.1.7.99
b6cfe000 b6d01000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d02000 b6d08000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d09000 b6d2b000 r-xp /usr/lib/libefreet.so.1.7.99
b6d2d000 b6dc4000 r-xp /usr/lib/libedje.so.1.7.99
b6dc6000 b6ddd000 r-xp /usr/lib/libecore_input.so.1.7.99
b6df1000 b6df8000 r-xp /usr/lib/libecore_file.so.1.7.99
b6df9000 b6e26000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e28000 b6f32000 r-xp /usr/lib/libevas.so.1.7.99
b6f4d000 b6f6a000 r-xp /usr/lib/libeet.so.1.7.99
b6f6b000 b6f8f000 r-xp /lib/libm-2.13.so
b6f91000 b7161000 r-xp /usr/lib/libelementary.so.1.7.99
b716e000 b7179000 r-xp /usr/lib/libcapi-web-favorites.so
b717a000 b717c000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b717f000 b7183000 r-xp /lib/libattr.so.1.1.0
b7184000 b7186000 r-xp /usr/lib/libXau.so.6.0.0
b7188000 b718f000 r-xp /lib/librt-2.13.so
b7191000 b7199000 r-xp /lib/libcrypt-2.13.so
b71c2000 b71c5000 r-xp /lib/libcap.so.2.21
b71c6000 b71c8000 r-xp /usr/lib/libiri.so
b71c9000 b71e3000 r-xp /lib/libgcc_s-4.5.3.so.1
b71e4000 b7204000 r-xp /usr/lib/libxcb.so.1.1.0
b7206000 b720f000 r-xp /lib/libunwind.so.8.0.1
b7219000 b736f000 r-xp /lib/libc-2.13.so
b7375000 b737a000 r-xp /usr/lib/libsmack.so.1.0.0
b737b000 b73c7000 r-xp /usr/lib/libdbus-1.so.3.7.2
b73c8000 b73cd000 r-xp /usr/lib/libbundle.so.0.1.22
b73ce000 b73d0000 r-xp /lib/libdl-2.13.so
b73d3000 b74fc000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b74fd000 b7512000 r-xp /lib/libpthread-2.13.so
b7517000 b7518000 r-xp /usr/lib/libdlog.so.0.0.0
b7519000 b75c3000 r-xp /usr/lib/libsqlite3.so.0.8.6
b75c6000 b75d2000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b75d3000 b7708000 r-xp /usr/lib/libX11.so.6.3.0
b770d000 b7715000 r-xp /usr/lib/libecore_imf.so.1.7.99
b7716000 b771b000 r-xp /usr/lib/libappcore-efl.so.1.1
b771d000 b7721000 r-xp /usr/lib/libsys-assert.so
b7725000 b7726000 r-xp [vdso]
b7726000 b7742000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:3391)
Call Stack Count: 23
 0: non-virtual thunk to MyHondanaLoginForm::OnLoadingCompleted() + 0x38 (0xb25209a8) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x2e9a8
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
