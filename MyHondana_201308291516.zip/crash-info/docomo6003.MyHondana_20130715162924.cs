S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 6777
Date: 2013-07-15 16:29:24(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=6777 tid=6777
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 6777, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x0948a188, esi = 0x000000a6
ebp = 0xbf8b5a48, esp = 0xbf8b57d0
eax = 0x00000000, ebx = 0xb256670c
ecx = 0x00000000, edx = 0x00000000
eip = 0xb250cfe8

Memory Information
MemTotal:   509368 KB
MemFree:      5596 KB
Buffers:      2792 KB
Cached:     326068 KB
VmPeak:     236876 KB
VmSize:     231580 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      108184 KB
VmRSS:      106616 KB
VmData:      89580 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100580 KB
VmPTE:         228 KB
VmSwap:        268 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
afab7000 afb2a000 r-xp /usr/lib/host-gl/libGL.so.1.2
afb4d000 afb5b000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afb5c000 afb93000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afb97000 afb99000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afb9a000 afba1000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afba2000 afbaf000 r-xp /usr/lib/libdrm-client.so.0.0.1
afbb0000 afbbe000 r-xp /usr/lib/libudev.so.0.13.1
afbbf000 afc01000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc02000 afc8e000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afc94000 afc9e000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afc9f000 afcb7000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afcb8000 afcbe000 r-xp /usr/lib/libmmffile.so.0.0.0
afcbf000 afcc7000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afcc8000 afcca000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afccb000 afcec000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afced000 afcef000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afcf0000 afd0e000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd0f000 afd15000 r-xp /usr/lib/libmemenv.so.1.1.0
afd16000 afd5f000 r-xp /usr/lib/libleveldb.so.1.1.0
afd61000 afd6c000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd6d000 afda9000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afdab000 afdc0000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afdc1000 afde1000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afde3000 afe19000 r-xp /usr/lib/libxslt.so.1.1.16
afe1a000 afe22000 r-xp /usr/lib/libeeze.so.1.7.99
afe23000 afe28000 r-xp /usr/lib/libeukit.so.1.7.99
afe29000 afe33000 r-xp /usr/lib/libenchant.so.1.6.1
afe34000 afe3e000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe3f000 afe4b000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afe4c000 afe7b000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afe81000 afe85000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afe86000 afe92000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afe94000 afe9b000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afe9c000 afeab000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afeac000 afeaf000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
afeb0000 afec1000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
afec2000 afef1000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
afef2000 afef8000 r-xp /usr/lib/libogg.so.0.7.1
afef9000 aff24000 r-xp /usr/lib/libvorbis.so.0.4.3
aff25000 aff2a000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff2b000 aff2f000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff30000 aff35000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff36000 aff5b000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
aff5c000 aff76000 r-xp /usr/lib/libnetwork.so.0.0.0
aff78000 affa4000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
affa5000 b1f90000 r-xp /usr/lib/libewebkit2.so.0.11.72
b208a000 b21f5000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b2201000 b2285000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2287000 b22a3000 r-xp /usr/lib/libwifi-direct.so.0.0
b22a4000 b22af000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b22b0000 b22bb000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b22bc000 b22ca000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b22cb000 b236d000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2373000 b2485000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b248b000 b24b0000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b24b2000 b24df000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b24e4000 b24e6000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
b24e7000 b24e8000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b24f1000 b2564000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2567000 b2597000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2598000 b25eb000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b25ec000 b25f2000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b25f3000 b25f8000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b25f9000 b2641000 r-xp /usr/lib/libpulse.so.0.12.4
b2642000 b2646000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b2647000 b2739000 r-xp /usr/lib/libasound.so.2.0.0
b273d000 b2762000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2763000 b2777000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2778000 b2858000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b285d000 b28bc000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b28bd000 b28c9000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b28ca000 b28dd000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b28de000 b28e1000 r-xp /usr/lib/libmm_ta.so.0.0.0
b28e2000 b28f9000 r-xp /usr/lib/libICE.so.6.3.0
b28fc000 b2903000 r-xp /usr/lib/libSM.so.6.0.1
b2904000 b2905000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2906000 b2911000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2912000 b2917000 r-xp /usr/lib/libsysman.so.0.2.0
b2918000 b2923000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2927000 b292b000 r-xp /usr/lib/libmmfsession.so.0.0.0
b292c000 b2989000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b298b000 b2993000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2994000 b2996000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2997000 b29fa000 r-xp /usr/lib/libtiff.so.5.1.0
b29fd000 b2a4f000 r-xp /usr/lib/libturbojpeg.so
b2a60000 b2a67000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2a68000 b2a71000 r-xp /usr/lib/libgif.so.4.1.6
b2a72000 b2a98000 r-xp /usr/lib/libavutil.so.51.73.101
b2a9f000 b2ae4000 r-xp /usr/lib/libswscale.so.2.1.101
b2ae5000 b2e4a000 r-xp /usr/lib/libavcodec.so.54.59.100
b316b000 b3192000 r-xp /usr/lib/libpng12.so.0.50.0
b3193000 b319a000 r-xp /usr/lib/libfeedback.so.0.1.4
b319b000 b31aa000 r-xp /usr/lib/libtts.so
b31ab000 b31c1000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b31c2000 b32dc000 r-xp /usr/lib/libcairo.so.2.11200.12
b32df000 b3303000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3304000 b40ea000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b415a000 b4160000 r-xp /usr/lib/libslp_devman_plugin.so
b4161000 b4163000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4164000 b4167000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4168000 b416c000 r-xp /usr/lib/libdevice-node.so.0.1
b416d000 b417b000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b417c000 b4185000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4186000 b418c000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b418d000 b418f000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4190000 b4194000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4195000 b419c000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b419d000 b41a0000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b41a1000 b41a2000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41a3000 b41b6000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b41b8000 b41c0000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41c1000 b41f1000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b41f2000 b41f6000 r-xp /usr/lib/libuuid.so.1.3.0
b41f7000 b4208000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4209000 b420a000 r-xp /usr/lib/libpmapi.so.1.2
b420b000 b4217000 r-xp /usr/lib/libminizip.so.1.0.0
b4218000 b4229000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b422a000 b4252000 r-xp /usr/lib/libpcre.so.0.0.1
b4253000 b4257000 r-xp /usr/lib/libheynoti.so.0.0.2
b4258000 b425d000 r-xp /usr/lib/libhaptic.so.0.1
b425e000 b425f000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4260000 b4267000 r-xp /usr/lib/libdevman.so.0.1
b4268000 b426e000 r-xp /usr/lib/libchromium.so.1.0
b426f000 b4277000 r-xp /usr/lib/libalarm.so.0.0.0
b4278000 b4281000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b4282000 b429a000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b429b000 b4745000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4767000 b4771000 r-xp /lib/libnss_files-2.13.so
b4773000 b477c000 r-xp /lib/libnss_nis-2.13.so
b477e000 b4791000 r-xp /lib/libnsl-2.13.so
b4795000 b479b000 r-xp /lib/libnss_compat-2.13.so
b499d000 b49b7000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b49b8000 b4b01000 r-xp /usr/lib/libxml2.so.2.7.8
b4b07000 b4b2d000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b2e000 b4b31000 r-xp /usr/lib/libiniparser.so.0
b4b33000 b4b9c000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4b9e000 b4bba000 r-xp /usr/lib/libcom-core.so.0.0.1
b4bbb000 b4bc2000 r-xp /usr/lib/libappsvc.so.0.1.0
b4bc3000 b4bc6000 r-xp /usr/lib/libdri2.so.0.0.0
b4bc7000 b4bd2000 r-xp /usr/lib/libdrm.so.2.4.0
b4bd3000 b4bd8000 r-xp /usr/lib/libtbm.so.1.0.0
b4bd9000 b4bdd000 r-xp /usr/lib/libXv.so.1.0.0
b4bde000 b4cfc000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d0b000 b4d20000 r-xp /usr/lib/libnotification.so.0.1.0
b4d21000 b4d2a000 r-xp /usr/lib/libutilX.so.1.1.0
b4d2b000 b4d5e000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d60000 b4d71000 r-xp /lib/libresolv-2.13.so
b4d75000 b4d78000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d79000 b4ede000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4ee2000 b5052000 r-xp /usr/lib/libcrypto.so.1.0.0
b506a000 b50c0000 r-xp /usr/lib/libssl.so.1.0.0
b50c5000 b50f4000 r-xp /usr/lib/libidn.so.11.5.44
b50f5000 b5104000 r-xp /usr/lib/libcares.so.2.0.0
b5105000 b512c000 r-xp /lib/libexpat.so.1.5.2
b512e000 b5161000 r-xp /usr/lib/libicule.so.48.1
b5162000 b516d000 r-xp /usr/lib/libsf_common.so
b516e000 b524a000 r-xp /usr/lib/libstdc++.so.6.0.14
b5256000 b5259000 r-xp /usr/lib/libapp-checker.so.0.1.0
b525a000 b527f000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5280000 b5285000 r-xp /usr/lib/libffi.so.5.0.10
b5286000 b5287000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5288000 b52b9000 r-xp /usr/lib/libexif.so.12.3.3
b52c6000 b52d2000 r-xp /usr/lib/libethumb.so.1.7.99
b52d3000 b5337000 r-xp /usr/lib/libsndfile.so.1.0.25
b533d000 b5340000 r-xp /usr/lib/libctxdata.so.0.0.0
b5341000 b5358000 r-xp /usr/lib/libremix.so.0.0.0
b5359000 b535b000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b535c000 b5389000 r-xp /usr/lib/liblua-5.1.so
b538a000 b5394000 r-xp /usr/lib/libembryo.so.1.7.99
b5395000 b5398000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5399000 b53fa000 r-xp /usr/lib/libcurl.so.4.3.0
b53fc000 b5402000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5403000 b5414000 r-xp /usr/lib/libXext.so.6.4.0
b5415000 b541a000 r-xp /usr/lib/libXtst.so.6.1.0
b541b000 b5423000 r-xp /usr/lib/libXrender.so.1.3.0
b5424000 b542d000 r-xp /usr/lib/libXrandr.so.2.2.0
b542e000 b5430000 r-xp /usr/lib/libXinerama.so.1.0.0
b5431000 b543f000 r-xp /usr/lib/libXi.so.6.1.0
b5440000 b5444000 r-xp /usr/lib/libXfixes.so.3.1.0
b5445000 b5447000 r-xp /usr/lib/libXgesture.so.7.0.0
b5448000 b544a000 r-xp /usr/lib/libXcomposite.so.1.0.0
b544b000 b544d000 r-xp /usr/lib/libXdamage.so.1.1.0
b544e000 b5458000 r-xp /usr/lib/libXcursor.so.1.0.2
b5459000 b54f0000 r-xp /usr/lib/libpixman-1.so.0.28.2
b54f5000 b552a000 r-xp /usr/lib/libfontconfig.so.1.5.0
b552c000 b55b1000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b55bb000 b55d1000 r-xp /usr/lib/libfribidi.so.0.3.1
b55d2000 b5657000 r-xp /usr/lib/libfreetype.so.6.8.1
b565b000 b56a2000 r-xp /usr/lib/libjpeg.so.8.0.2
b56b3000 b56d2000 r-xp /lib/libz.so.1.2.5
b56d3000 b56df000 r-xp /usr/lib/libemotion.so.1.7.99
b56e0000 b56e6000 r-xp /usr/lib/libecore_fb.so.1.7.99
b56e8000 b56f8000 r-xp /usr/lib/libsensor.so.1.1.0
b56fb000 b5701000 r-xp /usr/lib/libappcore-common.so.1.1
b680a000 b6965000 r-xp /usr/lib/libicuuc.so.48.1
b6973000 b6b52000 r-xp /usr/lib/libicui18n.so.48.1
b6b59000 b6b5c000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b5d000 b6b69000 r-xp /usr/lib/libvconf.so.0.2.45
b6b6a000 b6b73000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6b74000 b6b85000 r-xp /usr/lib/libail.so.0.1.0
b6b86000 b6b96000 r-xp /usr/lib/libaul.so.0.1.0
b6b97000 b6be7000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6be8000 b6c2b000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c2d000 b6c88000 r-xp /usr/lib/libeina.so.1.7.99
b6c8a000 b6ca9000 r-xp /usr/lib/libecore.so.1.7.99
b6cb8000 b6ce3000 r-xp /usr/lib/libecore_con.so.1.7.99
b6ce5000 b6cf0000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6cf1000 b6cfd000 r-xp /usr/lib/libedbus.so.1.7.99
b6cfe000 b6d01000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d02000 b6d08000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d09000 b6d2b000 r-xp /usr/lib/libefreet.so.1.7.99
b6d2d000 b6dc4000 r-xp /usr/lib/libedje.so.1.7.99
b6dc6000 b6ddd000 r-xp /usr/lib/libecore_input.so.1.7.99
b6df1000 b6df8000 r-xp /usr/lib/libecore_file.so.1.7.99
b6df9000 b6e26000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e28000 b6f32000 r-xp /usr/lib/libevas.so.1.7.99
b6f4d000 b6f6a000 r-xp /usr/lib/libeet.so.1.7.99
b6f6b000 b6f8f000 r-xp /lib/libm-2.13.so
b6f91000 b7161000 r-xp /usr/lib/libelementary.so.1.7.99
b716e000 b7179000 r-xp /usr/lib/libcapi-web-favorites.so
b717a000 b717c000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b717f000 b7183000 r-xp /lib/libattr.so.1.1.0
b7184000 b7186000 r-xp /usr/lib/libXau.so.6.0.0
b7188000 b718f000 r-xp /lib/librt-2.13.so
b7191000 b7199000 r-xp /lib/libcrypt-2.13.so
b71c2000 b71c5000 r-xp /lib/libcap.so.2.21
b71c6000 b71c8000 r-xp /usr/lib/libiri.so
b71c9000 b71e3000 r-xp /lib/libgcc_s-4.5.3.so.1
b71e4000 b7204000 r-xp /usr/lib/libxcb.so.1.1.0
b7206000 b720f000 r-xp /lib/libunwind.so.8.0.1
b7219000 b736f000 r-xp /lib/libc-2.13.so
b7375000 b737a000 r-xp /usr/lib/libsmack.so.1.0.0
b737b000 b73c7000 r-xp /usr/lib/libdbus-1.so.3.7.2
b73c8000 b73cd000 r-xp /usr/lib/libbundle.so.0.1.22
b73ce000 b73d0000 r-xp /lib/libdl-2.13.so
b73d3000 b74fc000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b74fd000 b7512000 r-xp /lib/libpthread-2.13.so
b7517000 b7518000 r-xp /usr/lib/libdlog.so.0.0.0
b7519000 b75c3000 r-xp /usr/lib/libsqlite3.so.0.8.6
b75c6000 b75d2000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b75d3000 b7708000 r-xp /usr/lib/libX11.so.6.3.0
b770d000 b7715000 r-xp /usr/lib/libecore_imf.so.1.7.99
b7716000 b771b000 r-xp /usr/lib/libappcore-efl.so.1.1
b771d000 b7721000 r-xp /usr/lib/libsys-assert.so
b7725000 b7726000 r-xp [vdso]
b7726000 b7742000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:6777)
Call Stack Count: 29
 0: Tizen::Base::Runtime::_Event::ProcessListeners(std::tr1::shared_ptr<Tizen::Base::Runtime::IEventArg>) + 0x40c (0xb444679c) [/usr/lib/osp/libosp-appfw.so] + 0x1ab79c
 1: Tizen::Base::Runtime::_Event::Fire(std::tr1::shared_ptr<Tizen::Base::Runtime::IEventArg>) + 0x62 (0xb4446c32) [/usr/lib/osp/libosp-appfw.so] + 0x1abc32
 2: Tizen::Base::Runtime::_Event::Fire(Tizen::Base::Runtime::IEventArg&) + 0x77 (0xb4446d47) [/usr/lib/osp/libosp-appfw.so] + 0x1abd47
 3: (0xb23bb6e2) [/usr/lib/osp/libosp-net.so.1] + 0x486e2
 4: Tizen::Net::Http::_HttpTransactionImpl::OnHttpBodyReceived(void*, unsigned int, unsigned int, void*) + 0x186 (0xb23bd2f6) [/usr/lib/osp/libosp-net.so.1] + 0x4a2f6
 5: Curl_client_write + 0x1c0 (0xb53acbf0) [/usr/lib/libcurl.so.4] + 0x13bf0
 6: Curl_httpchunk_read + 0x2bf (0xb53cc82f) [/usr/lib/libcurl.so.4] + 0x3382f
 7: Curl_readwrite + 0x97f (0xb53c6b1f) [/usr/lib/libcurl.so.4] + 0x2db1f
 8: multi_runsingle + 0xb72 (0xb53d1272) [/usr/lib/libcurl.so.4] + 0x38272
 9: multi_socket + 0x24c (0xb53d1e2c) [/usr/lib/libcurl.so.4] + 0x38e2c
10: curl_multi_socket_action + 0x2c (0xb53d1f3c) [/usr/lib/libcurl.so.4] + 0x38f3c
11: Tizen::Net::Http::_HttpTransactionImpl::OnSocketReceivedEvent(_GIOChannel*, GIOCondition, void*) + 0xb8 (0xb23c1c68) [/usr/lib/osp/libosp-net.so.1] + 0x4ec68
12: g_io_unix_dispatch + 0x4b (0xb745e50b) [/usr/lib/libglib-2.0.so.0] + 0x8b50b
13: g_main_context_dispatch + 0x133 (0xb741ba13) [/usr/lib/libglib-2.0.so.0] + 0x48a13
14: _ecore_glib_select + 0x3fb (0xb6c9dd5b) [/usr/lib/libecore.so.1] + 0x13d5b
15: _ecore_main_select + 0x3a5 (0xb6c97595) [/usr/lib/libecore.so.1] + 0xd595
16: _ecore_main_loop_iterate_internal + 0x3b9 (0xb6c980e9) [/usr/lib/libecore.so.1] + 0xe0e9
17: ecore_main_loop_begin + 0x3f (0xb6c9845f) [/usr/lib/libecore.so.1] + 0xe45f
18: elm_run + 0x17 (0xb7081ee7) [/usr/lib/libelementary.so.1] + 0xf0ee7
19: appcore_efl_main + 0x42e (0xb77192ee) [/usr/lib/libappcore-efl.so.1] + 0x32ee
20: app_efl_main + 0xe8 (0xb41a7d98) [/usr/lib/libcapi-appfw-application.so.0] + 0x4d98
21: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x122 (0xb439e612) [/usr/lib/osp/libosp-appfw.so] + 0x103612
22: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3cbaea1) [/usr/lib/osp/libosp-uifw.so] + 0x9b6ea1
23: OspMain + 0x19f (0xb251cbcf) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x2bbcf
24: main + 0x503 (0xb717b0c3) [/opt/apps/docomo6003/bin/MyHondana] + 0x10c3
25: __launchpad_main_loop + 0x1c17 (0x804bf97) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bf97
26: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
27: __libc_start_main + 0xe6 (0xb722fda6) [/lib/libc.so.6] + 0x16da6
28: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)

Latest Debug Message Information
--------- beginning of /dev/log_main
07-15 15:55:30.573 I/osp-installer( 4704): InstallerError ManifestXmlStep::OnStateManifestXml()(123) > manifest file=[/opt/usr/apps/__@@osp_tmp@@__/info/manifest.xml]
07-15 15:55:30.583 I/osp-installer( 4704): virtual bool ManifestHandler::OnStartElement(const char*)(106) > ------------------------------------------
07-15 15:55:30.583 I/osp-installer( 4704): virtual bool ManifestHandler::OnStartElement(const char*)(107) > manifest.xml
07-15 15:55:30.583 I/osp-installer( 4704): virtual bool ManifestHandler::OnStartElement(const char*)(108) > ------------------------------------------
07-15 15:55:30.583 I/osp-installer( 4704): virtual bool ManifestHandler::OnStartElement(const char*)(109) > <Manifest>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIdValue(const char*)(943) > <Package>docomo6003</Package>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIdValue(const char*)(959) > input package = [docomo6003], manifest = [docomo6003] is the same.
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnVersionValue(const char*)(969) > <Version>1.0.0</Version>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnTypeValue(const char*)(978) > <Type>C++App</Type>
07-15 15:55:30.583 I/osp-installer( 4704): virtual bool ManifestHandler::OnStartElement(const char*)(113) > <Apps>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnApiVersionValue(const char*)(1010) > <ApiVersion>2.1</ApiVersion>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnPrivilegesStartElement()(371) > <Privileges>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnPrivilegeValue(const char*)(1033) > <Privilege>http://tizen.org/privilege/web.privacy</Privilege>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnPrivilegeValue(const char*)(1033) > <Privilege>http://tizen.org/privilege/web.service</Privilege>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnPrivilegeValue(const char*)(1033) > <Privilege>http://tizen.org/privilege/http</Privilege>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnPrivilegeValue(const char*)(1033) > <Privilege>http://tizen.org/privilege/power</Privilege>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnPrivilegesEndElement()(769) > </Privileges>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnUiAppStartElement()(385) > <UiApp>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::ParseAppAttribute(XmlAttribute*, bool)(1410) >  - Name=MyHondana
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::ParseAppAttribute(XmlAttribute*, bool)(1423) >  - Main=True
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::ParseAppAttribute(XmlAttribute*, bool)(1441) >  - LaunchingHistoryVisible=True
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::ParseAppAttribute(XmlAttribute*, bool)(1449) >  - HwAcceleration=On
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::ParseAppAttribute(XmlAttribute*, bool)(1515) >  - MenuIconVisible=True
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::ParseAppAttribute(XmlAttribute*, bool)(1562) >  - app=docomo6003.MyHondana
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnUiScalabilityStartElement()(459) > <UiScalability>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnUiScalabilityStartElement()(473) > <CoordinateSystem=Logical>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnUiScalabilityStartElement()(485) > <BaseScreenSize=Normal>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnUiScalabilityStartElement()(497) > <LogicalCoordinate=720>
07-15 15:55:30.583 I/osp-installer( 4704): virtual bool ManifestHandler::OnEndElement(const char*)(243) > </UiScalability>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnUiThemeStartElement()(510) > <UiTheme>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnUiThemeStartElement()(524) > <SystemTheme=Black>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnNameValue(const char*)(1189) > <DisplayName Locale="eng-GB">d book MyShelf</DisplayName>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnNameValue(const char*)(1189) > <DisplayName Locale="jpn-JP">d ﾌﾞｯｸ ﾏｲ本棚</DisplayName>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIconsStartElement()(421) > <Icons>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIconsStartElement()(441) > ScreenWidth = [720]
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIconsStartElement()(446) > DefaultIconType = [Xhigh]
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIconValue(const char*)(1041) > <Icon>main_icon.png</Icon>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIconValue(const char*)(1048) >  - Section=MainMenu
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIconValue(const char*)(1056) > __pDefaultIconType=Xhigh
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnIconsEndElement()(842) > </Icons>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnUiAppEndElement()(789) > </UiApp>
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnAppsEndElement()(820) > </Apps>
07-15 15:55:30.583 E/osp-installer( 4704): static bool InstallerUtil::IsDefaultExternalStorage()(1148) > vconf_get_int(db/setting/default_memory/download) failed.
07-15 15:55:30.583 I/osp-installer( 4704): bool ManifestHandler::OnManifestEndElement()(935) > </Manifest>
07-15 15:55:30.583 I/osp-installer( 4704): virtual InstallerError ManifestXmlStep::Run(InstallationContext*)(66) > [STATE_DONE]
07-15 15:55:30.583 I/osp-installer( 4704): virtual InstallerError ManifestXmlStep::Run(InstallationContext*)(81) > ------------------------------------------
07-15 15:55:30.583 I/osp-installer( 4704): virtual InstallerError ManifestXmlStep::Run(InstallationContext*)(82) >  ManifestXmlStep - END
07-15 15:55:30.583 I/osp-installer( 4704): virtual InstallerError ManifestXmlStep::Run(InstallationContext*)(83) > ------------------------------------------
07-15 15:55:30.583 E/Tizen::App( 4704): result Tizen::App::Package::_PackageInfoImpl::Construct(const Tizen::App::PackageId&)(1072) > [E_PKG_NOT_INSTALLED] pkgmgrinfo_pkginfo_get_pkginfo() is failed. result=[-1], package=[docomo6003]
07-15 15:55:30.583 E/Tizen::App( 4704): Tizen::App::Package::PackageInfo* Tizen::App::Package::_PackageManagerImpl::GetPackageInfoN(const Tizen::App::PackageId&) const(274) > [E_PKG_NOT_INSTALLED] package (docomo6003) is not found.
07-15 15:55:30.583 I/osp-installer( 4704): virtual InstallerError UnpackStep::Run(InstallationContext*)(74) >  UnpackStep - START
07-15 15:55:30.583 I/osp-installer( 4704): virtual InstallerError UnpackStep::Run(InstallationContext*)(83) > [STATE_UNZIP]
07-15 15:55:30.593 E/osp-installer( 4704): static bool InstallerUtil::CreateSymlink(const Tizen::Base::String&, const Tizen::Base::String&, bool)(259) > symlink() is failed(File exists), oldpath=[/opt/usr/apps/docomo6003], newpath=[/opt/apps/docomo6003]
07-15 15:55:30.593 I/osp-installer( 4704): static bool InstallerUtil::CreateSymlinkForAppDirectory(const Tizen::Base::String&, Tizen::Base::String&)(533) > CreateSymlinkForAppDirectory(): output path=[/opt/apps/docomo6003]
07-15 15:55:30.593 I/osp-installer( 4704): InstallerError UnpackStep::OnUnzip()(181) > UnzipTo - START
07-15 15:55:30.653 I/osp-installer( 4704): InstallerError UnpackStep::OnUnzip()(184) > UnzipTo - END
07-15 15:55:30.653 I/osp-installer( 4704): virtual InstallerError UnpackStep::Run(InstallationContext*)(98) > [STATE_DONE]
07-15 15:55:30.663 I/osp-installer( 4704): virtual InstallerError UnpackStep::Run(InstallationContext*)(113) >  UnpackStep - END
07-15 15:55:30.663 I/osp-installer( 4704): virtual InstallerError LicenseStep::Run(InstallationContext*)(39) >  LicenseStep - START
07-15 15:55:30.663 I/osp-installer( 4704): virtual InstallerError LicenseStep::Run(InstallationContext*)(48) > [STATE_LICENSE_VERIFICATION]
07-15 15:55:30.663 I/osp-installer( 4704): virtual InstallerError LicenseStep::Run(InstallationContext*)(53) > [STATE_DONE]
07-15 15:55:30.663 I/osp-installer( 4704): virtual InstallerError LicenseStep::Run(InstallationContext*)(68) >  LicenseStep - END
07-15 15:55:30.663 I/osp-installer( 4704): virtual InstallerError SignatureStep::Run(InstallationContext*)(51) >  SignatureStep - START
07-15 15:55:30.663 I/osp-installer( 4704): virtual InstallerError SignatureStep::Run(InstallationContext*)(66) > [STATE_SIGNER_INIT]
07-15 15:55:30.663 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(70) > ValidateSignatures start >>
07-15 15:55:30.663 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(81) > ValidationCore::VCoreInit() is done
07-15 15:55:30.663 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(88) > rootPath=[/opt/apps/docomo6003/]
07-15 15:55:30.663 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(96) > signatureFinder.find() is done
07-15 15:55:30.673 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(102) > SignatureFiles: file=[signature1.xml]
07-15 15:55:30.673 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(103) > SignatureFiles: number=[1]
07-15 15:55:30.683 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(117) > ValidationCore::SignatureReader() is done
07-15 15:55:30.683 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(136) > Default distributor cert value=[MIICmzCCAgQCCQDXI7WLdVZwiTANBgkqhkiG9w0BAQUFADCBjzELMAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTEiMCAGA1UECwwZVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEkMCIGA1UEAwwbVGl6ZW4gUHVibGljIERpc3RyaWJ1dG9yIENBMB4XDTEyMTAyOTEzMDMwNFoXDTIyMTAyNzEzMDMwNFowgZMxCzAJBgNVBAYTAktSMQ4wDAYDVQQIDAVTdXdvbjEOMAwGA1UEBwwFU3V3b24xFjAUBgNVBAoMDVRpemVuIFRlc3QgQ0ExIjAgBgNVBAsMGVRpemVuIERpc3RyaWJ1dG9yIFRlc3QgQ0ExKDAmBgNVBAMMH1RpemVuIFB1YmxpYyBEaXN0cmlidXRvciBTaWduZXIwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBALtMvlc5hENK90ZdA+y66+Sy0enD1gpZDBh5T9RP0oRsptJv5jjNTseQbQi0SZOdOXb6J7iQdlBCtR343RpIEz8HmrBy7mSY7mgwoU4EPpp4CTSUeAuKcmvrNOngTp5Hv7Ngf02TTHOLK3hZLpGayaDviyNZB5PdqQdBhokKjzAzAgMBAAEwDQYJKoZIhvcNAQEFBQADgYEAvGp1gxxAIlFfhJH1efjb9BJK/rtRkbYn9+EzGEbEULg1svsgnyWisFimI3uFvgI/swzr1eKVY3Sc8MQ3+Fdy3EkbDZ2+WAubhcEkorTWjzWz2fL1vKaYjeIsuEX6TVRUugHWudPzcEuQRLQf8ibZWjbQdBmpeQYBMg5x+xKLCJc=]
07-15 15:55:30.683 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(136) > Default distributor cert value=[MIICtDCCAh2gAwIBAgIJAMDbehElPNKvMA0GCSqGSIb3DQEBBQUAMIGVMQswCQYDVQQGEwJLUjEOMAwGA1UECAwFU3V3b24xDjAMBgNVBAcMBVN1d29uMRYwFAYDVQQKDA1UaXplbiBUZXN0IENBMSMwIQYDVQQLDBpUVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEpMCcGA1UEAwwgVGl6ZW4gUHVibGljIERpc3RyaWJ1dG9yIFJvb3QgQ0EwHhcNMTIxMDI5MTMwMjUwWhcNMjIxMDI3MTMwMjUwWjCBjzELMAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTEiMCAGA1UECwwZVGl6ZW4gRGlzdHJpYnV0b3IgVGVzdCBDQTEkMCIGA1UEAwwbVGl6ZW4gUHVibGljIERpc3RyaWJ1dG9yIENBMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDeOTS/3nXvkDEmsFCJIvRlQ3RKDcxdWJJp625pFqHdmoJBdV+x6jl1raGK2Y1sp2Gdvpjc/z92yzApbE/UVLPh/tRNZPeGhzU4ejDDm7kzdr2f7Ia0U98K+OoY12ucwg7TYNItj9is7Cj4blGfuMDzd2ah2AgnCGlwNwV/pv+uVQIDAQABoxAwDjAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBACqJKO33YdoGudwanZIxMdXuxnnD9R6u72ltKk1S4zPfMJJv482CRGCI4FK6djhlsI4i0Lt1SVIJEed+yc3qckGm19dW+4xdlkekon7pViEBWuyHw8OWv3RXtTum1+PGHjBJ2eYY4ZKIpz73U/1NC16sTB/0VhfnkHwPltmrpYVe]
07-15 15:55:30.683 I/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(149) > validator.check() start >>
07-15 15:55:31.073 E/osp-installer( 4704): bool SignatureManager::ValidateSignatures()(165) > validator.check() is failed, valRes=[1]
07-15 15:55:31.073 I/osp-installer( 4704): InstallerError SignatureStep::OnStateSignerInit()(133) >   ## __pSignatureManager->ValidateSignatures() result = [false]
07-15 15:55:31.073 I/osp-installer( 4704): InstallerError SignatureStep::OnStateSignerInit()(157) > _pSignatureManager->ValidateSignatures() does not be passed, using another validator.
07-15 15:55:31.073 I/osp-installer( 4704): virtual InstallerError SignatureStep::Run(InstallationContext*)(71) > [STATE_SIGNER_CERT]
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnStartElement(const char*)(90) > ------------------------------------------
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnStartElement(const char*)(91) > signature.xml
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnStartElement(const char*)(92) > ------------------------------------------
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnStartElement(const char*)(93) > <Signature>
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnSignatureStartElement()(170) > <DistributorSignature>
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnReferenceStartElement()(208) > Reference URI=[bin/MyHondana.exe]
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnDigestValue(const char*)(288) > digest value=[0XVTdqkGRnK2SsD0obEPKWBINV3NqSq5LfVqFQ9DYZc=]
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnReferenceStartElement()(208) > Reference URI=[info/manifest.xml]
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnDigestValue(const char*)(288) > digest value=[iVxcqCzW4tHw4zqQ6XqV36vfR45asnMZ8PjghUxaO2c=]
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnEndElement(const char*)(122) > </Signature>
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnStartElement(const char*)(90) > ------------------------------------------
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnStartElement(const char*)(91) > signature.xml
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnStartElement(const char*)(92) > ------------------------------------------
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnStartElement(const char*)(93) > <Signature>
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnSignatureStartElement()(170) > <AuthorSignature>
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnReferenceStartElement()(208) > Reference URI=[bin/MyHondana.exe]
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnDigestValue(const char*)(288) > digest value=[0XVTdqkGRnK2SsD0obEPKWBINV3NqSq5LfVqFQ9DYZc=]
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnReferenceStartElement()(208) > Reference URI=[info/manifest.xml]
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureHandler::OnDigestValue(const char*)(288) > digest value=[iVxcqCzW4tHw4zqQ6XqV36vfR45asnMZ8PjghUxaO2c=]
07-15 15:55:31.073 I/osp-installer( 4704): virtual bool SignatureHandler::OnEndElement(const char*)(122) > </Signature>
07-15 15:55:31.073 I/osp-installer( 4704): virtual InstallerError SignatureStep::Run(InstallationContext*)(76) > [STATE_CERT_CHAIN]
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureManager::AddCert()(452) > AddCertificate - AuthorCertChain
07-15 15:55:31.073 I/osp-installer( 4704): bool SignatureManager::AddCertificate(Tizen::Security::Cert::X509CertificatePath*, Tizen::Base::Collection::IList*)(808) > [cert][0]
07-15 15:55:31.073 E/Tizen::Security::Cert( 4704): virtual result Tizen::Security::Cert::_X509Certificate::ParseObject()(962) > [E_PARSING_FAILED] Failed to parse certificate.
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddCertificate(Tizen::Security::Cert::X509CertificatePath*, Tizen::Base::Collection::IList*)(808) > [cert][1]
07-15 15:55:31.083 E/Tizen::Security::Cert( 4704): virtual result Tizen::Security::Cert::_X509Certificate::ParseObject()(962) > [E_PARSING_FAILED] Failed to parse certificate.
07-15 15:55:31.083 E/Tizen::Security::Cert( 4704): virtual result Tizen::Security::Cert::_X509Certificate::ParseObject()(962) > [E_PARSING_FAILED] Failed to parse certificate.
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddCert()(466) > AddCertificate - DistributorCert
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddCertificate(Tizen::Security::Cert::X509CertificatePath*, Tizen::Base::Collection::IList*)(808) > [cert][0]
07-15 15:55:31.083 E/Tizen::Security::Cert( 4704): virtual result Tizen::Security::Cert::_X509Certificate::ParseObject()(962) > [E_PARSING_FAILED] Failed to parse certificate.
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddCertificate(Tizen::Security::Cert::X509CertificatePath*, Tizen::Base::Collection::IList*)(808) > [cert][1]
07-15 15:55:31.083 E/Tizen::Security::Cert( 4704): virtual result Tizen::Security::Cert::_X509Certificate::ParseObject()(962) > [E_PARSING_FAILED] Failed to parse certificate.
07-15 15:55:31.083 E/Tizen::Security::Cert( 4704): virtual result Tizen::Security::Cert::_X509Certificate::ParseObject()(962) > [E_PARSING_FAILED] Failed to parse certificate.
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddDistributorRootCert(Tizen::Security::Cert::X509CertificatePath*)(981) > ------------------------------------------
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddDistributorRootCert(Tizen::Security::Cert::X509CertificatePath*)(982) > Issuer  = [/C=KR/ST=Suwon/L=Suwon/O=Tizen Test CA/OU=TTizen Distributor Test CA/CN=Tizen Public Distributor Root CA]
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddDistributorRootCert(Tizen::Security::Cert::X509CertificatePath*)(983) > Subject = [/C=KR/ST=Suwon/L=Suwon/O=Tizen Test CA/OU=TTizen Distributor Test CA/CN=Tizen Public Distributor Root CA]
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddDistributorRootCert(Tizen::Security::Cert::X509CertificatePath*)(984) > ------------------------------------------
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddDistributorRootCert(Tizen::Security::Cert::X509CertificatePath*)(988) > subject, issuer is matched.
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::AddDistributorRootCert(Tizen::Security::Cert::X509CertificatePath*)(993) > AddCertificate() RootCert = [2]
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::VerifyChain()(490) > AuthorCert Validate - START
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::Validate(Tizen::Security::Cert::X509CertificatePath*)(766) > ------------------------------------------
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::Validate(Tizen::Security::Cert::X509CertificatePath*)(767) > # signature.xml
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::Validate(Tizen::Security::Cert::X509CertificatePath*)(786) > Validate() success!
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::Validate(Tizen::Security::Cert::X509CertificatePath*)(787) > ------------------------------------------
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::VerifyChain()(492) > AuthorCert Validate - END
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::SetCertificatePath(SignatureFileType, Tizen::Security::Cert::X509CertificatePath*)(680) > ------------------------------------------
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::SetCertificatePath(SignatureFileType, Tizen::Security::Cert::X509CertificatePath*)(681) > CertValue[0], certType[1]
07-15 15:55:31.083 I/osp-installer( 4704): bool SignatureManager::SetCertificatePath(SignatureFileType, Tizen::Security::Cert::X509CertificatePath*)(682) > [MIICszCCAhygAwIBAgIGAT965MiTMA0GCSqGSIb3DQEBBQUAMIGEMQswCQYDVQQGEwJLUjEOMAwGA1UECAwFU3V3b24xDjAMBgNVBAcMBVN1d29uMRYwFAYDVQQKDA1UaXplbiBUZXN0IENBMSAwHgYDVQQLDBdUaXplbiBEZXZlbG9wZXIgVGVzdCBDQTEbMBkGA1UEAwwSVGl6ZW4gRGV2ZWxvcGVyIENBMB4XDTEyMTEwMTAwMDAwMFoXDTE5MDEwMTAwMDAwMFowgYAxCzAJBgNVBAYTAlRJMQ4wDAYDVQQIDAV0aXplbjEOMAwGA1UEBwwFdGl6ZW4xDjAMBgNVBAoMBXRpemVuMQ4wDAYDVQQLDAV0aXplbjEhMB8GCSqGSIb3DQEJARYSc2lob25nQGEydGVjLmNvLmtyMQ4wDAYDVQQDDAV0aXplbjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEA1awEuweUORm7dRVVhKD5fTmkEzTAC
End of latest debug message
