S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 10288
Date: 2013-07-16 15:24:47(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=10288 tid=10288
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 10288, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xbf96c6b8, esi = 0x00000048
ebp = 0xbf96c658, esp = 0xbf96c610
eax = 0x00000048, ebx = 0xb241dc58
ecx = 0xbf96c660, edx = 0xb25f6190
eip = 0xb23d3e2d

Memory Information
MemTotal:   509368 KB
MemFree:     14656 KB
Buffers:      3316 KB
Cached:     337552 KB
VmPeak:     317996 KB
VmSize:     293332 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      136404 KB
VmRSS:      126760 KB
VmData:     140960 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100780 KB
VmPTE:         268 KB
VmSwap:        640 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
aae39000 aae3e000 r-xp /usr/lib/libefl-assist.so.0.1.0
ab640000 ab642000 r-xp /usr/lib/libhaptic-module.so
ac9e1000 ac9e3000 r-xp /usr/lib/remix/libeet_sndfile_reader.so
ac9e4000 ac9e7000 r-xp /usr/lib/remix/libtizen_sound_player.so.1.0.0
ac9e8000 ac9e9000 r-xp /usr/lib/edje/modules/multisense_factory/linux-gnu-i686-1.0.0/module.so
ac9ef000 aca13000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
afb63000 afbd6000 r-xp /usr/lib/host-gl/libGL.so.1.2
afbf9000 afc07000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afc08000 afc3f000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afc43000 afc45000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afc46000 afc4d000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc4e000 afc5b000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc5c000 afc6a000 r-xp /usr/lib/libudev.so.0.13.1
afc6b000 afcad000 r-xp /usr/lib/libSLP-location.so.0.0.0
afcae000 afd3a000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afd40000 afd4a000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afd4b000 afd63000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd64000 afd6a000 r-xp /usr/lib/libmmffile.so.0.0.0
afd6b000 afd73000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd74000 afd76000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd77000 afd98000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd99000 afd9b000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd9c000 afdba000 r-xp /usr/lib/libmedia-service.so.1.0.0
afdbb000 afdc1000 r-xp /usr/lib/libmemenv.so.1.1.0
afdc2000 afe0b000 r-xp /usr/lib/libleveldb.so.1.1.0
afe0d000 afe18000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afe19000 afe55000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe57000 afe6c000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe6d000 afe8d000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe8f000 afec5000 r-xp /usr/lib/libxslt.so.1.1.16
afec6000 afece000 r-xp /usr/lib/libeeze.so.1.7.99
afecf000 afed4000 r-xp /usr/lib/libeukit.so.1.7.99
afed5000 afedf000 r-xp /usr/lib/libenchant.so.1.6.1
afee0000 afeea000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afeeb000 afef7000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afef8000 aff27000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
aff2d000 aff31000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
aff32000 aff3e000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
aff40000 aff47000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
aff48000 aff57000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff58000 aff5b000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff5c000 aff6d000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff6e000 aff9d000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff9e000 affa4000 r-xp /usr/lib/libogg.so.0.7.1
affa5000 affd0000 r-xp /usr/lib/libvorbis.so.0.4.3
affd1000 affd6000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
affd7000 affdb000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
affdc000 affe1000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
affe2000 b0007000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
b0008000 b0022000 r-xp /usr/lib/libnetwork.so.0.0.0
b0024000 b0050000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b0051000 b203c000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2136000 b22a1000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b22ad000 b2331000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2333000 b234f000 r-xp /usr/lib/libwifi-direct.so.0.0
b2350000 b235b000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b235c000 b2367000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2368000 b2376000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b2377000 b2419000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b241f000 b2531000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2537000 b255c000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b255e000 b258b000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b258e000 b258f000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
b2590000 b2592000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
b2593000 b2594000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b259d000 b2610000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2613000 b2643000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2644000 b2697000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2698000 b269e000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b269f000 b26a4000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b26a5000 b26ed000 r-xp /usr/lib/libpulse.so.0.12.4
b26ee000 b26f2000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26f3000 b27e5000 r-xp /usr/lib/libasound.so.2.0.0
b27e9000 b280e000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b280f000 b2823000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2824000 b2904000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b2909000 b2968000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b2969000 b2975000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2976000 b2989000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b298a000 b298d000 r-xp /usr/lib/libmm_ta.so.0.0.0
b298e000 b29a5000 r-xp /usr/lib/libICE.so.6.3.0
b29a8000 b29af000 r-xp /usr/lib/libSM.so.6.0.1
b29b0000 b29b1000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b29b2000 b29bd000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b29be000 b29c3000 r-xp /usr/lib/libsysman.so.0.2.0
b29c4000 b29cf000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b29d3000 b29d7000 r-xp /usr/lib/libmmfsession.so.0.0.0
b29d8000 b2a35000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2a37000 b2a3f000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2a40000 b2a42000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2a43000 b2aa6000 r-xp /usr/lib/libtiff.so.5.1.0
b2aa9000 b2afb000 r-xp /usr/lib/libturbojpeg.so
b2b0c000 b2b13000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2b14000 b2b1d000 r-xp /usr/lib/libgif.so.4.1.6
b2b1e000 b2b44000 r-xp /usr/lib/libavutil.so.51.73.101
b2b4b000 b2b90000 r-xp /usr/lib/libswscale.so.2.1.101
b2b91000 b2ef6000 r-xp /usr/lib/libavcodec.so.54.59.100
b3217000 b323e000 r-xp /usr/lib/libpng12.so.0.50.0
b323f000 b3246000 r-xp /usr/lib/libfeedback.so.0.1.4
b3247000 b3256000 r-xp /usr/lib/libtts.so
b3257000 b326d000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b326e000 b3388000 r-xp /usr/lib/libcairo.so.2.11200.12
b338b000 b33af000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b33b0000 b4196000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4206000 b420c000 r-xp /usr/lib/libslp_devman_plugin.so
b420d000 b420f000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4210000 b4213000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4214000 b4218000 r-xp /usr/lib/libdevice-node.so.0.1
b4219000 b4227000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4228000 b4231000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4232000 b4238000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b4239000 b423b000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b423c000 b4240000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4241000 b4248000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4249000 b424c000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b424d000 b424e000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b424f000 b4262000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4264000 b426c000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b426d000 b429d000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b429e000 b42a2000 r-xp /usr/lib/libuuid.so.1.3.0
b42a3000 b42b4000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b42b5000 b42b6000 r-xp /usr/lib/libpmapi.so.1.2
b42b7000 b42c3000 r-xp /usr/lib/libminizip.so.1.0.0
b42c4000 b42d5000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42d6000 b42fe000 r-xp /usr/lib/libpcre.so.0.0.1
b42ff000 b4303000 r-xp /usr/lib/libheynoti.so.0.0.2
b4304000 b4309000 r-xp /usr/lib/libhaptic.so.0.1
b430a000 b430b000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b430c000 b4313000 r-xp /usr/lib/libdevman.so.0.1
b4314000 b431a000 r-xp /usr/lib/libchromium.so.1.0
b431b000 b4323000 r-xp /usr/lib/libalarm.so.0.0.0
b4324000 b432d000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b432e000 b4346000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4347000 b47f1000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4813000 b481d000 r-xp /lib/libnss_files-2.13.so
b481f000 b4828000 r-xp /lib/libnss_nis-2.13.so
b482a000 b483d000 r-xp /lib/libnsl-2.13.so
b4841000 b4847000 r-xp /lib/libnss_compat-2.13.so
b4a49000 b4a63000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a64000 b4bad000 r-xp /usr/lib/libxml2.so.2.7.8
b4bb3000 b4bd9000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4bda000 b4bdd000 r-xp /usr/lib/libiniparser.so.0
b4bdf000 b4c48000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c4a000 b4c66000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c67000 b4c6e000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c6f000 b4c72000 r-xp /usr/lib/libdri2.so.0.0.0
b4c73000 b4c7e000 r-xp /usr/lib/libdrm.so.2.4.0
b4c7f000 b4c84000 r-xp /usr/lib/libtbm.so.1.0.0
b4c85000 b4c89000 r-xp /usr/lib/libXv.so.1.0.0
b4c8a000 b4da8000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4db7000 b4dcc000 r-xp /usr/lib/libnotification.so.0.1.0
b4dcd000 b4dd6000 r-xp /usr/lib/libutilX.so.1.1.0
b4dd7000 b4e0a000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4e0c000 b4e1d000 r-xp /lib/libresolv-2.13.so
b4e21000 b4e24000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4e25000 b4f8a000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f8e000 b50fe000 r-xp /usr/lib/libcrypto.so.1.0.0
b5116000 b516c000 r-xp /usr/lib/libssl.so.1.0.0
b5171000 b51a0000 r-xp /usr/lib/libidn.so.11.5.44
b51a1000 b51b0000 r-xp /usr/lib/libcares.so.2.0.0
b51b1000 b51d8000 r-xp /lib/libexpat.so.1.5.2
b51da000 b520d000 r-xp /usr/lib/libicule.so.48.1
b520e000 b5219000 r-xp /usr/lib/libsf_common.so
b521a000 b52f6000 r-xp /usr/lib/libstdc++.so.6.0.14
b5302000 b5305000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5306000 b532b000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b532c000 b5331000 r-xp /usr/lib/libffi.so.5.0.10
b5332000 b5333000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5334000 b5365000 r-xp /usr/lib/libexif.so.12.3.3
b5372000 b537e000 r-xp /usr/lib/libethumb.so.1.7.99
b537f000 b53e3000 r-xp /usr/lib/libsndfile.so.1.0.25
b53e9000 b53ec000 r-xp /usr/lib/libctxdata.so.0.0.0
b53ed000 b5404000 r-xp /usr/lib/libremix.so.0.0.0
b5405000 b5407000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5408000 b5435000 r-xp /usr/lib/liblua-5.1.so
b5436000 b5440000 r-xp /usr/lib/libembryo.so.1.7.99
b5441000 b5444000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5445000 b54a6000 r-xp /usr/lib/libcurl.so.4.3.0
b54a8000 b54ae000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b54af000 b54c0000 r-xp /usr/lib/libXext.so.6.4.0
b54c1000 b54c6000 r-xp /usr/lib/libXtst.so.6.1.0
b54c7000 b54cf000 r-xp /usr/lib/libXrender.so.1.3.0
b54d0000 b54d9000 r-xp /usr/lib/libXrandr.so.2.2.0
b54da000 b54dc000 r-xp /usr/lib/libXinerama.so.1.0.0
b54dd000 b54eb000 r-xp /usr/lib/libXi.so.6.1.0
b54ec000 b54f0000 r-xp /usr/lib/libXfixes.so.3.1.0
b54f1000 b54f3000 r-xp /usr/lib/libXgesture.so.7.0.0
b54f4000 b54f6000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54f7000 b54f9000 r-xp /usr/lib/libXdamage.so.1.1.0
b54fa000 b5504000 r-xp /usr/lib/libXcursor.so.1.0.2
b5505000 b559c000 r-xp /usr/lib/libpixman-1.so.0.28.2
b55a1000 b55d6000 r-xp /usr/lib/libfontconfig.so.1.5.0
b55d8000 b565d000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5667000 b567d000 r-xp /usr/lib/libfribidi.so.0.3.1
b567e000 b5703000 r-xp /usr/lib/libfreetype.so.6.8.1
b5707000 b574e000 r-xp /usr/lib/libjpeg.so.8.0.2
b575f000 b577e000 r-xp /lib/libz.so.1.2.5
b577f000 b578b000 r-xp /usr/lib/libemotion.so.1.7.99
b578c000 b5792000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5794000 b57a4000 r-xp /usr/lib/libsensor.so.1.1.0
b57a7000 b57ad000 r-xp /usr/lib/libappcore-common.so.1.1
b68b6000 b6a11000 r-xp /usr/lib/libicuuc.so.48.1
b6a1f000 b6bfe000 r-xp /usr/lib/libicui18n.so.48.1
b6c05000 b6c08000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6c09000 b6c15000 r-xp /usr/lib/libvconf.so.0.2.45
b6c16000 b6c1f000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6c20000 b6c31000 r-xp /usr/lib/libail.so.0.1.0
b6c32000 b6c42000 r-xp /usr/lib/libaul.so.0.1.0
b6c43000 b6c93000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c94000 b6cd7000 r-xp /usr/lib/libecore_x.so.1.7.99
b6cd9000 b6d34000 r-xp /usr/lib/libeina.so.1.7.99
b6d36000 b6d55000 r-xp /usr/lib/libecore.so.1.7.99
b6d64000 b6d8f000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d91000 b6d9c000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d9d000 b6da9000 r-xp /usr/lib/libedbus.so.1.7.99
b6daa000 b6dad000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6dae000 b6db4000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6db5000 b6dd7000 r-xp /usr/lib/libefreet.so.1.7.99
b6dd9000 b6e70000 r-xp /usr/lib/libedje.so.1.7.99
b6e72000 b6e89000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e9d000 b6ea4000 r-xp /usr/lib/libecore_file.so.1.7.99
b6ea5000 b6ed2000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6ed4000 b6fde000 r-xp /usr/lib/libevas.so.1.7.99
b6ff9000 b7016000 r-xp /usr/lib/libeet.so.1.7.99
b7017000 b703b000 r-xp /lib/libm-2.13.so
b703d000 b720d000 r-xp /usr/lib/libelementary.so.1.7.99
b721a000 b7225000 r-xp /usr/lib/libcapi-web-favorites.so
b7226000 b7228000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b722b000 b722f000 r-xp /lib/libattr.so.1.1.0
b7230000 b7232000 r-xp /usr/lib/libXau.so.6.0.0
b7234000 b723b000 r-xp /lib/librt-2.13.so
b723d000 b7245000 r-xp /lib/libcrypt-2.13.so
b726e000 b7271000 r-xp /lib/libcap.so.2.21
b7272000 b7274000 r-xp /usr/lib/libiri.so
b7275000 b728f000 r-xp /lib/libgcc_s-4.5.3.so.1
b7290000 b72b0000 r-xp /usr/lib/libxcb.so.1.1.0
b72b2000 b72bb000 r-xp /lib/libunwind.so.8.0.1
b72c5000 b741b000 r-xp /lib/libc-2.13.so
b7421000 b7426000 r-xp /usr/lib/libsmack.so.1.0.0
b7427000 b7473000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7474000 b7479000 r-xp /usr/lib/libbundle.so.0.1.22
b747a000 b747c000 r-xp /lib/libdl-2.13.so
b747f000 b75a8000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b75a9000 b75be000 r-xp /lib/libpthread-2.13.so
b75c3000 b75c4000 r-xp /usr/lib/libdlog.so.0.0.0
b75c5000 b766f000 r-xp /usr/lib/libsqlite3.so.0.8.6
b7672000 b767e000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b767f000 b77b4000 r-xp /usr/lib/libX11.so.6.3.0
b77b9000 b77c1000 r-xp /usr/lib/libecore_imf.so.1.7.99
b77c2000 b77c7000 r-xp /usr/lib/libappcore-efl.so.1.1
b77c9000 b77cd000 r-xp /usr/lib/libsys-assert.so
b77d1000 b77d2000 r-xp [vdso]
b77d2000 b77ee000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:10288)
Call Stack Count: 31
 0: _ZThn16_N19MyHondanaMarketForm30OnHttpAuthenticationRequestedNERKN5Tizen4Base6StringES4_RKNS0_3Web8Controls23AuthenticationChall + 0x61 (0xb25e8ea1) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x4bea1
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
