S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 5267
Date: 2013-07-16 17:12:18(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=5267 tid=5267
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 5267, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xbffc5018, esi = 0x0000004f
ebp = 0xbffc4f58, esp = 0xbffc4f10
eax = 0x0ad55b08, ebx = 0xb23c3c58
ecx = 0x0000004f, edx = 0xbffc5038
eip = 0xb2379e2d

Memory Information
MemTotal:   509368 KB
MemFree:      4900 KB
Buffers:      2560 KB
Cached:     285944 KB
VmPeak:     284520 KB
VmSize:     284456 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      119196 KB
VmRSS:      119196 KB
VmData:     139280 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100784 KB
VmPTE:         252 KB
VmSwap:          4 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
aaddf000 aade4000 r-xp /usr/lib/libefl-assist.so.0.1.0
ab5e6000 ab5e8000 r-xp /usr/lib/libhaptic-module.so
ac987000 ac989000 r-xp /usr/lib/remix/libeet_sndfile_reader.so
ac98a000 ac98d000 r-xp /usr/lib/remix/libtizen_sound_player.so.1.0.0
ac98e000 ac98f000 r-xp /usr/lib/edje/modules/multisense_factory/linux-gnu-i686-1.0.0/module.so
ac995000 ac9b9000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
afb09000 afb7c000 r-xp /usr/lib/host-gl/libGL.so.1.2
afb9f000 afbad000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afbae000 afbe5000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afbe9000 afbeb000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afbec000 afbf3000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afbf4000 afc01000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc02000 afc10000 r-xp /usr/lib/libudev.so.0.13.1
afc11000 afc53000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc54000 afce0000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afce6000 afcf0000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afcf1000 afd09000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd0a000 afd10000 r-xp /usr/lib/libmmffile.so.0.0.0
afd11000 afd19000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd1a000 afd1c000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd1d000 afd3e000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd3f000 afd41000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd42000 afd60000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd61000 afd67000 r-xp /usr/lib/libmemenv.so.1.1.0
afd68000 afdb1000 r-xp /usr/lib/libleveldb.so.1.1.0
afdb3000 afdbe000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afdbf000 afdfb000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afdfd000 afe12000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe13000 afe33000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe35000 afe6b000 r-xp /usr/lib/libxslt.so.1.1.16
afe6c000 afe74000 r-xp /usr/lib/libeeze.so.1.7.99
afe75000 afe7a000 r-xp /usr/lib/libeukit.so.1.7.99
afe7b000 afe85000 r-xp /usr/lib/libenchant.so.1.6.1
afe86000 afe90000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe91000 afe9d000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afe9e000 afecd000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afed3000 afed7000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afed8000 afee4000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afee6000 afeed000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afeee000 afefd000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afefe000 aff01000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff02000 aff13000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff14000 aff43000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff44000 aff4a000 r-xp /usr/lib/libogg.so.0.7.1
aff4b000 aff76000 r-xp /usr/lib/libvorbis.so.0.4.3
aff77000 aff7c000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff7d000 aff81000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff82000 aff87000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff88000 affad000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affae000 affc8000 r-xp /usr/lib/libnetwork.so.0.0.0
affca000 afff6000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
afff7000 b1fe2000 r-xp /usr/lib/libewebkit2.so.0.11.72
b20dc000 b2247000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b2253000 b22d7000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b22d9000 b22f5000 r-xp /usr/lib/libwifi-direct.so.0.0
b22f6000 b2301000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b2302000 b230d000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b230e000 b231c000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b231d000 b23bf000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b23c5000 b24d7000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b24dd000 b2502000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b2504000 b2531000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2534000 b2535000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
b2536000 b2538000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
b2539000 b253a000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b2543000 b25b7000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b25ba000 b25ea000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b25eb000 b263e000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b263f000 b2645000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2646000 b264b000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b264c000 b2694000 r-xp /usr/lib/libpulse.so.0.12.4
b2695000 b2699000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b269a000 b278c000 r-xp /usr/lib/libasound.so.2.0.0
b2790000 b27b5000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b27b6000 b27ca000 r-xp /usr/lib/libmmfsound.so.0.1.0
b27cb000 b28ab000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b28b0000 b290f000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b2910000 b291c000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b291d000 b2930000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b2931000 b2934000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2935000 b294c000 r-xp /usr/lib/libICE.so.6.3.0
b294f000 b2956000 r-xp /usr/lib/libSM.so.6.0.1
b2957000 b2958000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2959000 b2964000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2965000 b296a000 r-xp /usr/lib/libsysman.so.0.2.0
b296b000 b2976000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b297a000 b297e000 r-xp /usr/lib/libmmfsession.so.0.0.0
b297f000 b29dc000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b29de000 b29e6000 r-xp /usr/lib/libxcb-render.so.0.0.0
b29e7000 b29e9000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b29ea000 b2a4d000 r-xp /usr/lib/libtiff.so.5.1.0
b2a50000 b2aa2000 r-xp /usr/lib/libturbojpeg.so
b2ab3000 b2aba000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2abb000 b2ac4000 r-xp /usr/lib/libgif.so.4.1.6
b2ac5000 b2aeb000 r-xp /usr/lib/libavutil.so.51.73.101
b2af2000 b2b37000 r-xp /usr/lib/libswscale.so.2.1.101
b2b38000 b2e9d000 r-xp /usr/lib/libavcodec.so.54.59.100
b31be000 b31e5000 r-xp /usr/lib/libpng12.so.0.50.0
b31e6000 b31ed000 r-xp /usr/lib/libfeedback.so.0.1.4
b31ee000 b31fd000 r-xp /usr/lib/libtts.so
b31fe000 b3214000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b3215000 b332f000 r-xp /usr/lib/libcairo.so.2.11200.12
b3332000 b3356000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3357000 b413d000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41ad000 b41b3000 r-xp /usr/lib/libslp_devman_plugin.so
b41b4000 b41b6000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41b7000 b41ba000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41bb000 b41bf000 r-xp /usr/lib/libdevice-node.so.0.1
b41c0000 b41ce000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b41cf000 b41d8000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b41d9000 b41df000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41e0000 b41e2000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b41e3000 b41e7000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b41e8000 b41ef000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b41f0000 b41f3000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b41f4000 b41f5000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41f6000 b4209000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b420b000 b4213000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4214000 b4244000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4245000 b4249000 r-xp /usr/lib/libuuid.so.1.3.0
b424a000 b425b000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b425c000 b425d000 r-xp /usr/lib/libpmapi.so.1.2
b425e000 b426a000 r-xp /usr/lib/libminizip.so.1.0.0
b426b000 b427c000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b427d000 b42a5000 r-xp /usr/lib/libpcre.so.0.0.1
b42a6000 b42aa000 r-xp /usr/lib/libheynoti.so.0.0.2
b42ab000 b42b0000 r-xp /usr/lib/libhaptic.so.0.1
b42b1000 b42b2000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42b3000 b42ba000 r-xp /usr/lib/libdevman.so.0.1
b42bb000 b42c1000 r-xp /usr/lib/libchromium.so.1.0
b42c2000 b42ca000 r-xp /usr/lib/libalarm.so.0.0.0
b42cb000 b42d4000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b42d5000 b42ed000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b42ee000 b4798000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b47ba000 b47c4000 r-xp /lib/libnss_files-2.13.so
b47c6000 b47cf000 r-xp /lib/libnss_nis-2.13.so
b47d1000 b47e4000 r-xp /lib/libnsl-2.13.so
b47e8000 b47ee000 r-xp /lib/libnss_compat-2.13.so
b49f0000 b4a0a000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a0b000 b4b54000 r-xp /usr/lib/libxml2.so.2.7.8
b4b5a000 b4b80000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b81000 b4b84000 r-xp /usr/lib/libiniparser.so.0
b4b86000 b4bef000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4bf1000 b4c0d000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c0e000 b4c15000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c16000 b4c19000 r-xp /usr/lib/libdri2.so.0.0.0
b4c1a000 b4c25000 r-xp /usr/lib/libdrm.so.2.4.0
b4c26000 b4c2b000 r-xp /usr/lib/libtbm.so.1.0.0
b4c2c000 b4c30000 r-xp /usr/lib/libXv.so.1.0.0
b4c31000 b4d4f000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d5e000 b4d73000 r-xp /usr/lib/libnotification.so.0.1.0
b4d74000 b4d7d000 r-xp /usr/lib/libutilX.so.1.1.0
b4d7e000 b4db1000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4db3000 b4dc4000 r-xp /lib/libresolv-2.13.so
b4dc8000 b4dcb000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4dcc000 b4f31000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f35000 b50a5000 r-xp /usr/lib/libcrypto.so.1.0.0
b50bd000 b5113000 r-xp /usr/lib/libssl.so.1.0.0
b5118000 b5147000 r-xp /usr/lib/libidn.so.11.5.44
b5148000 b5157000 r-xp /usr/lib/libcares.so.2.0.0
b5158000 b517f000 r-xp /lib/libexpat.so.1.5.2
b5181000 b51b4000 r-xp /usr/lib/libicule.so.48.1
b51b5000 b51c0000 r-xp /usr/lib/libsf_common.so
b51c1000 b529d000 r-xp /usr/lib/libstdc++.so.6.0.14
b52a9000 b52ac000 r-xp /usr/lib/libapp-checker.so.0.1.0
b52ad000 b52d2000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b52d3000 b52d8000 r-xp /usr/lib/libffi.so.5.0.10
b52d9000 b52da000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b52db000 b530c000 r-xp /usr/lib/libexif.so.12.3.3
b5319000 b5325000 r-xp /usr/lib/libethumb.so.1.7.99
b5326000 b538a000 r-xp /usr/lib/libsndfile.so.1.0.25
b5390000 b5393000 r-xp /usr/lib/libctxdata.so.0.0.0
b5394000 b53ab000 r-xp /usr/lib/libremix.so.0.0.0
b53ac000 b53ae000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b53af000 b53dc000 r-xp /usr/lib/liblua-5.1.so
b53dd000 b53e7000 r-xp /usr/lib/libembryo.so.1.7.99
b53e8000 b53eb000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b53ec000 b544d000 r-xp /usr/lib/libcurl.so.4.3.0
b544f000 b5455000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5456000 b5467000 r-xp /usr/lib/libXext.so.6.4.0
b5468000 b546d000 r-xp /usr/lib/libXtst.so.6.1.0
b546e000 b5476000 r-xp /usr/lib/libXrender.so.1.3.0
b5477000 b5480000 r-xp /usr/lib/libXrandr.so.2.2.0
b5481000 b5483000 r-xp /usr/lib/libXinerama.so.1.0.0
b5484000 b5492000 r-xp /usr/lib/libXi.so.6.1.0
b5493000 b5497000 r-xp /usr/lib/libXfixes.so.3.1.0
b5498000 b549a000 r-xp /usr/lib/libXgesture.so.7.0.0
b549b000 b549d000 r-xp /usr/lib/libXcomposite.so.1.0.0
b549e000 b54a0000 r-xp /usr/lib/libXdamage.so.1.1.0
b54a1000 b54ab000 r-xp /usr/lib/libXcursor.so.1.0.2
b54ac000 b5543000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5548000 b557d000 r-xp /usr/lib/libfontconfig.so.1.5.0
b557f000 b5604000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b560e000 b5624000 r-xp /usr/lib/libfribidi.so.0.3.1
b5625000 b56aa000 r-xp /usr/lib/libfreetype.so.6.8.1
b56ae000 b56f5000 r-xp /usr/lib/libjpeg.so.8.0.2
b5706000 b5725000 r-xp /lib/libz.so.1.2.5
b5726000 b5732000 r-xp /usr/lib/libemotion.so.1.7.99
b5733000 b5739000 r-xp /usr/lib/libecore_fb.so.1.7.99
b573b000 b574b000 r-xp /usr/lib/libsensor.so.1.1.0
b574e000 b5754000 r-xp /usr/lib/libappcore-common.so.1.1
b685d000 b69b8000 r-xp /usr/lib/libicuuc.so.48.1
b69c6000 b6ba5000 r-xp /usr/lib/libicui18n.so.48.1
b6bac000 b6baf000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6bb0000 b6bbc000 r-xp /usr/lib/libvconf.so.0.2.45
b6bbd000 b6bc6000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6bc7000 b6bd8000 r-xp /usr/lib/libail.so.0.1.0
b6bd9000 b6be9000 r-xp /usr/lib/libaul.so.0.1.0
b6bea000 b6c3a000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c3b000 b6c7e000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c80000 b6cdb000 r-xp /usr/lib/libeina.so.1.7.99
b6cdd000 b6cfc000 r-xp /usr/lib/libecore.so.1.7.99
b6d0b000 b6d36000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d38000 b6d43000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d44000 b6d50000 r-xp /usr/lib/libedbus.so.1.7.99
b6d51000 b6d54000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d55000 b6d5b000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d5c000 b6d7e000 r-xp /usr/lib/libefreet.so.1.7.99
b6d80000 b6e17000 r-xp /usr/lib/libedje.so.1.7.99
b6e19000 b6e30000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e44000 b6e4b000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e4c000 b6e79000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e7b000 b6f85000 r-xp /usr/lib/libevas.so.1.7.99
b6fa0000 b6fbd000 r-xp /usr/lib/libeet.so.1.7.99
b6fbe000 b6fe2000 r-xp /lib/libm-2.13.so
b6fe4000 b71b4000 r-xp /usr/lib/libelementary.so.1.7.99
b71c1000 b71cc000 r-xp /usr/lib/libcapi-web-favorites.so
b71cd000 b71cf000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b71d2000 b71d6000 r-xp /lib/libattr.so.1.1.0
b71d7000 b71d9000 r-xp /usr/lib/libXau.so.6.0.0
b71db000 b71e2000 r-xp /lib/librt-2.13.so
b71e4000 b71ec000 r-xp /lib/libcrypt-2.13.so
b7215000 b7218000 r-xp /lib/libcap.so.2.21
b7219000 b721b000 r-xp /usr/lib/libiri.so
b721c000 b7236000 r-xp /lib/libgcc_s-4.5.3.so.1
b7237000 b7257000 r-xp /usr/lib/libxcb.so.1.1.0
b7259000 b7262000 r-xp /lib/libunwind.so.8.0.1
b726c000 b73c2000 r-xp /lib/libc-2.13.so
b73c8000 b73cd000 r-xp /usr/lib/libsmack.so.1.0.0
b73ce000 b741a000 r-xp /usr/lib/libdbus-1.so.3.7.2
b741b000 b7420000 r-xp /usr/lib/libbundle.so.0.1.22
b7421000 b7423000 r-xp /lib/libdl-2.13.so
b7426000 b754f000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7550000 b7565000 r-xp /lib/libpthread-2.13.so
b756a000 b756b000 r-xp /usr/lib/libdlog.so.0.0.0
b756c000 b7616000 r-xp /usr/lib/libsqlite3.so.0.8.6
b7619000 b7625000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b7626000 b775b000 r-xp /usr/lib/libX11.so.6.3.0
b7760000 b7768000 r-xp /usr/lib/libecore_imf.so.1.7.99
b7769000 b776e000 r-xp /usr/lib/libappcore-efl.so.1.1
b7770000 b7774000 r-xp /usr/lib/libsys-assert.so
b7778000 b7779000 r-xp [vdso]
b7779000 b7795000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:5267)
Call Stack Count: 50
 0: MyHondanaMarketForm::OnInitializing() + 0xaa (0xb258e5fa) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x4b5fa
 1: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x3d (0xb366ebbd) [/usr/lib/osp/libosp-uifw.so] + 0x317bbd
 2: Tizen::Ui::Controls::_FormImpl::OnAttachedToMainTree() + 0x3a (0xb39a31fa) [/usr/lib/osp/libosp-uifw.so] + 0x64c1fa
 3: Tizen::Ui::_Control::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0x115 (0xb3647875) [/usr/lib/osp/libosp-uifw.so] + 0x2f0875
 4: Tizen::Ui::_Control::EndAttaching(Tizen::Ui::_Control&) + 0x24c (0xb364d3dc) [/usr/lib/osp/libosp-uifw.so] + 0x2f63dc
 5: Tizen::Ui::_Control::AttachChild(Tizen::Ui::_Control&) + 0xa5 (0xb3650b45) [/usr/lib/osp/libosp-uifw.so] + 0x2f9b45
 6: Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool) + 0xe6 (0xb36830a6) [/usr/lib/osp/libosp-uifw.so] + 0x32c0a6
 7: Tizen::Ui::Container::AddControl(Tizen::Ui::Control*) + 0x52 (0xb363d3d2) [/usr/lib/osp/libosp-uifw.so] + 0x2e63d2
 8: Tizen::Ui::Container::AddControl(Tizen::Ui::Control const&) + 0x24 (0xb363d4b4) [/usr/lib/osp/libosp-uifw.so] + 0x2e64b4
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
