S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 3689
Date: 2013-07-17 16:20:19(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=3689 tid=3689
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 3689, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xbfba8e68, esi = 0x00000000
ebp = 0xbfba8e88, esp = 0xbfba8e20
eax = 0x08563fc0, ebx = 0xb4755a10
ecx = 0x0000000a, edx = 0xa60eee0e
eip = 0xb459370c

Memory Information
MemTotal:   509368 KB
MemFree:     66348 KB
Buffers:      3920 KB
Cached:     230696 KB
VmPeak:     342524 KB
VmSize:     275424 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      154028 KB
VmRSS:      110884 KB
VmData:     125740 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100776 KB
VmPTE:         256 KB
VmSwap:          4 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
aad84000 aad89000 r-xp /usr/lib/libefl-assist.so.0.1.0
ac92c000 ac92e000 r-xp /usr/lib/remix/libeet_sndfile_reader.so
ac92f000 ac932000 r-xp /usr/lib/remix/libtizen_sound_player.so.1.0.0
ac933000 ac934000 r-xp /usr/lib/edje/modules/multisense_factory/linux-gnu-i686-1.0.0/module.so
ac93a000 ac95e000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
afaae000 afb21000 r-xp /usr/lib/host-gl/libGL.so.1.2
afb44000 afb52000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afb53000 afb8a000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afb8e000 afb90000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afb91000 afb98000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afb99000 afba6000 r-xp /usr/lib/libdrm-client.so.0.0.1
afba7000 afbb5000 r-xp /usr/lib/libudev.so.0.13.1
afbb6000 afbf8000 r-xp /usr/lib/libSLP-location.so.0.0.0
afbf9000 afc85000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afc8b000 afc95000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afc96000 afcae000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afcaf000 afcb5000 r-xp /usr/lib/libmmffile.so.0.0.0
afcb6000 afcbe000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afcbf000 afcc1000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afcc2000 afce3000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afce4000 afce6000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afce7000 afd05000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd06000 afd0c000 r-xp /usr/lib/libmemenv.so.1.1.0
afd0d000 afd56000 r-xp /usr/lib/libleveldb.so.1.1.0
afd58000 afd63000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd64000 afda0000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afda2000 afdb7000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afdb8000 afdd8000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afdda000 afe10000 r-xp /usr/lib/libxslt.so.1.1.16
afe11000 afe19000 r-xp /usr/lib/libeeze.so.1.7.99
afe1a000 afe1f000 r-xp /usr/lib/libeukit.so.1.7.99
afe20000 afe2a000 r-xp /usr/lib/libenchant.so.1.6.1
afe2b000 afe35000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe36000 afe42000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afe43000 afe72000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afe78000 afe7c000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afe7d000 afe89000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afe8b000 afe92000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afe93000 afea2000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afea3000 afea6000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
afea7000 afeb8000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
afeb9000 afee8000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
afee9000 afeef000 r-xp /usr/lib/libogg.so.0.7.1
afef0000 aff1b000 r-xp /usr/lib/libvorbis.so.0.4.3
aff1c000 aff21000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff22000 aff26000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff27000 aff2c000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff2d000 aff52000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
aff53000 aff6d000 r-xp /usr/lib/libnetwork.so.0.0.0
aff6f000 aff9b000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
aff9c000 b1f87000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2081000 b21ec000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b21f8000 b227c000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b227e000 b229a000 r-xp /usr/lib/libwifi-direct.so.0.0
b229b000 b22a6000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b22a7000 b22b2000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b22b3000 b22c1000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b22c2000 b2364000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b236a000 b247c000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2482000 b24a7000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b24a9000 b24d6000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b24d9000 b24da000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
b24db000 b24dd000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
b24de000 b24df000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b24e8000 b255c000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b255f000 b258f000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2590000 b25e3000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b25e4000 b25ea000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b25eb000 b25f0000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b25f1000 b2639000 r-xp /usr/lib/libpulse.so.0.12.4
b263a000 b263e000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b263f000 b2731000 r-xp /usr/lib/libasound.so.2.0.0
b2735000 b275a000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b275b000 b276f000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2770000 b2850000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b2855000 b28b4000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b28b5000 b28c1000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b28c2000 b28d5000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b28d6000 b28d9000 r-xp /usr/lib/libmm_ta.so.0.0.0
b28da000 b28f1000 r-xp /usr/lib/libICE.so.6.3.0
b28f4000 b28fb000 r-xp /usr/lib/libSM.so.6.0.1
b28fc000 b28fd000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b28fe000 b2909000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b290a000 b290f000 r-xp /usr/lib/libsysman.so.0.2.0
b2910000 b291b000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b291f000 b2923000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2924000 b2981000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2983000 b298b000 r-xp /usr/lib/libxcb-render.so.0.0.0
b298c000 b298e000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b298f000 b29f2000 r-xp /usr/lib/libtiff.so.5.1.0
b29f5000 b2a47000 r-xp /usr/lib/libturbojpeg.so
b2a58000 b2a5f000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2a60000 b2a69000 r-xp /usr/lib/libgif.so.4.1.6
b2a6a000 b2a90000 r-xp /usr/lib/libavutil.so.51.73.101
b2a97000 b2adc000 r-xp /usr/lib/libswscale.so.2.1.101
b2add000 b2e42000 r-xp /usr/lib/libavcodec.so.54.59.100
b3163000 b318a000 r-xp /usr/lib/libpng12.so.0.50.0
b318b000 b3192000 r-xp /usr/lib/libfeedback.so.0.1.4
b3193000 b31a2000 r-xp /usr/lib/libtts.so
b31a3000 b31b9000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b31ba000 b32d4000 r-xp /usr/lib/libcairo.so.2.11200.12
b32d7000 b32fb000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b32fc000 b40e2000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4152000 b4158000 r-xp /usr/lib/libslp_devman_plugin.so
b4159000 b415b000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b415c000 b415f000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4160000 b4164000 r-xp /usr/lib/libdevice-node.so.0.1
b4165000 b4173000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4174000 b417d000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b417e000 b4184000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b4185000 b4187000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4188000 b418c000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b418d000 b4194000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4195000 b4198000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b4199000 b419a000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b419b000 b41ae000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b41b0000 b41b8000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41b9000 b41e9000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b41ea000 b41ee000 r-xp /usr/lib/libuuid.so.1.3.0
b41ef000 b4200000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4201000 b4202000 r-xp /usr/lib/libpmapi.so.1.2
b4203000 b420f000 r-xp /usr/lib/libminizip.so.1.0.0
b4210000 b4221000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4222000 b424a000 r-xp /usr/lib/libpcre.so.0.0.1
b424b000 b424f000 r-xp /usr/lib/libheynoti.so.0.0.2
b4250000 b4255000 r-xp /usr/lib/libhaptic.so.0.1
b4256000 b4257000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4258000 b425f000 r-xp /usr/lib/libdevman.so.0.1
b4260000 b4266000 r-xp /usr/lib/libchromium.so.1.0
b4267000 b426f000 r-xp /usr/lib/libalarm.so.0.0.0
b4270000 b4279000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b427a000 b4292000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4293000 b473d000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b475f000 b4769000 r-xp /lib/libnss_files-2.13.so
b476b000 b4774000 r-xp /lib/libnss_nis-2.13.so
b4776000 b4789000 r-xp /lib/libnsl-2.13.so
b478d000 b4793000 r-xp /lib/libnss_compat-2.13.so
b4995000 b49af000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b49b0000 b4af9000 r-xp /usr/lib/libxml2.so.2.7.8
b4aff000 b4b25000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b26000 b4b29000 r-xp /usr/lib/libiniparser.so.0
b4b2b000 b4b94000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4b96000 b4bb2000 r-xp /usr/lib/libcom-core.so.0.0.1
b4bb3000 b4bba000 r-xp /usr/lib/libappsvc.so.0.1.0
b4bbb000 b4bbe000 r-xp /usr/lib/libdri2.so.0.0.0
b4bbf000 b4bca000 r-xp /usr/lib/libdrm.so.2.4.0
b4bcb000 b4bd0000 r-xp /usr/lib/libtbm.so.1.0.0
b4bd1000 b4bd5000 r-xp /usr/lib/libXv.so.1.0.0
b4bd6000 b4cf4000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d03000 b4d18000 r-xp /usr/lib/libnotification.so.0.1.0
b4d19000 b4d22000 r-xp /usr/lib/libutilX.so.1.1.0
b4d23000 b4d56000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d58000 b4d69000 r-xp /lib/libresolv-2.13.so
b4d6d000 b4d70000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d71000 b4ed6000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4eda000 b504a000 r-xp /usr/lib/libcrypto.so.1.0.0
b5062000 b50b8000 r-xp /usr/lib/libssl.so.1.0.0
b50bd000 b50ec000 r-xp /usr/lib/libidn.so.11.5.44
b50ed000 b50fc000 r-xp /usr/lib/libcares.so.2.0.0
b50fd000 b5124000 r-xp /lib/libexpat.so.1.5.2
b5126000 b5159000 r-xp /usr/lib/libicule.so.48.1
b515a000 b5165000 r-xp /usr/lib/libsf_common.so
b5166000 b5242000 r-xp /usr/lib/libstdc++.so.6.0.14
b524e000 b5251000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5252000 b5277000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5278000 b527d000 r-xp /usr/lib/libffi.so.5.0.10
b527e000 b527f000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5280000 b52b1000 r-xp /usr/lib/libexif.so.12.3.3
b52be000 b52ca000 r-xp /usr/lib/libethumb.so.1.7.99
b52cb000 b532f000 r-xp /usr/lib/libsndfile.so.1.0.25
b5335000 b5338000 r-xp /usr/lib/libctxdata.so.0.0.0
b5339000 b5350000 r-xp /usr/lib/libremix.so.0.0.0
b5351000 b5353000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5354000 b5381000 r-xp /usr/lib/liblua-5.1.so
b5382000 b538c000 r-xp /usr/lib/libembryo.so.1.7.99
b538d000 b5390000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5391000 b53f2000 r-xp /usr/lib/libcurl.so.4.3.0
b53f4000 b53fa000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b53fb000 b540c000 r-xp /usr/lib/libXext.so.6.4.0
b540d000 b5412000 r-xp /usr/lib/libXtst.so.6.1.0
b5413000 b541b000 r-xp /usr/lib/libXrender.so.1.3.0
b541c000 b5425000 r-xp /usr/lib/libXrandr.so.2.2.0
b5426000 b5428000 r-xp /usr/lib/libXinerama.so.1.0.0
b5429000 b5437000 r-xp /usr/lib/libXi.so.6.1.0
b5438000 b543c000 r-xp /usr/lib/libXfixes.so.3.1.0
b543d000 b543f000 r-xp /usr/lib/libXgesture.so.7.0.0
b5440000 b5442000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5443000 b5445000 r-xp /usr/lib/libXdamage.so.1.1.0
b5446000 b5450000 r-xp /usr/lib/libXcursor.so.1.0.2
b5451000 b54e8000 r-xp /usr/lib/libpixman-1.so.0.28.2
b54ed000 b5522000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5524000 b55a9000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b55b3000 b55c9000 r-xp /usr/lib/libfribidi.so.0.3.1
b55ca000 b564f000 r-xp /usr/lib/libfreetype.so.6.8.1
b5653000 b569a000 r-xp /usr/lib/libjpeg.so.8.0.2
b56ab000 b56ca000 r-xp /lib/libz.so.1.2.5
b56cb000 b56d7000 r-xp /usr/lib/libemotion.so.1.7.99
b56d8000 b56de000 r-xp /usr/lib/libecore_fb.so.1.7.99
b56e0000 b56f0000 r-xp /usr/lib/libsensor.so.1.1.0
b56f3000 b56f9000 r-xp /usr/lib/libappcore-common.so.1.1
b6802000 b695d000 r-xp /usr/lib/libicuuc.so.48.1
b696b000 b6b4a000 r-xp /usr/lib/libicui18n.so.48.1
b6b51000 b6b54000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b55000 b6b61000 r-xp /usr/lib/libvconf.so.0.2.45
b6b62000 b6b6b000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6b6c000 b6b7d000 r-xp /usr/lib/libail.so.0.1.0
b6b7e000 b6b8e000 r-xp /usr/lib/libaul.so.0.1.0
b6b8f000 b6bdf000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6be0000 b6c23000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c25000 b6c80000 r-xp /usr/lib/libeina.so.1.7.99
b6c82000 b6ca1000 r-xp /usr/lib/libecore.so.1.7.99
b6cb0000 b6cdb000 r-xp /usr/lib/libecore_con.so.1.7.99
b6cdd000 b6ce8000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6ce9000 b6cf5000 r-xp /usr/lib/libedbus.so.1.7.99
b6cf6000 b6cf9000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6cfa000 b6d00000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d01000 b6d23000 r-xp /usr/lib/libefreet.so.1.7.99
b6d25000 b6dbc000 r-xp /usr/lib/libedje.so.1.7.99
b6dbe000 b6dd5000 r-xp /usr/lib/libecore_input.so.1.7.99
b6de9000 b6df0000 r-xp /usr/lib/libecore_file.so.1.7.99
b6df1000 b6e1e000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e20000 b6f2a000 r-xp /usr/lib/libevas.so.1.7.99
b6f45000 b6f62000 r-xp /usr/lib/libeet.so.1.7.99
b6f63000 b6f87000 r-xp /lib/libm-2.13.so
b6f89000 b7159000 r-xp /usr/lib/libelementary.so.1.7.99
b7166000 b7171000 r-xp /usr/lib/libcapi-web-favorites.so
b7172000 b7174000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7177000 b717b000 r-xp /lib/libattr.so.1.1.0
b717c000 b717e000 r-xp /usr/lib/libXau.so.6.0.0
b7180000 b7187000 r-xp /lib/librt-2.13.so
b7189000 b7191000 r-xp /lib/libcrypt-2.13.so
b71ba000 b71bd000 r-xp /lib/libcap.so.2.21
b71be000 b71c0000 r-xp /usr/lib/libiri.so
b71c1000 b71db000 r-xp /lib/libgcc_s-4.5.3.so.1
b71dc000 b71fc000 r-xp /usr/lib/libxcb.so.1.1.0
b71fe000 b7207000 r-xp /lib/libunwind.so.8.0.1
b7211000 b7367000 r-xp /lib/libc-2.13.so
b736d000 b7372000 r-xp /usr/lib/libsmack.so.1.0.0
b7373000 b73bf000 r-xp /usr/lib/libdbus-1.so.3.7.2
b73c0000 b73c5000 r-xp /usr/lib/libbundle.so.0.1.22
b73c6000 b73c8000 r-xp /lib/libdl-2.13.so
b73cb000 b74f4000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b74f5000 b750a000 r-xp /lib/libpthread-2.13.so
b750f000 b7510000 r-xp /usr/lib/libdlog.so.0.0.0
b7511000 b75bb000 r-xp /usr/lib/libsqlite3.so.0.8.6
b75be000 b75ca000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b75cb000 b7700000 r-xp /usr/lib/libX11.so.6.3.0
b7705000 b770d000 r-xp /usr/lib/libecore_imf.so.1.7.99
b770e000 b7713000 r-xp /usr/lib/libappcore-efl.so.1.1
b7715000 b7719000 r-xp /usr/lib/libsys-assert.so
b771d000 b771e000 r-xp [vdso]
b771e000 b773a000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:3689)
Call Stack Count: 15
 0: g_io_unix_dispatch + 0x4b (0xb745650b) [/usr/lib/libglib-2.0.so.0] + 0x8b50b
 1: g_main_context_dispatch + 0x133 (0xb7413a13) [/usr/lib/libglib-2.0.so.0] + 0x48a13
 2: _ecore_glib_select + 0x3fb (0xb6c95d5b) [/usr/lib/libecore.so.1] + 0x13d5b
 3: _ecore_main_select + 0x3a5 (0xb6c8f595) [/usr/lib/libecore.so.1] + 0xd595
 4: _ecore_main_loop_iterate_internal + 0x2a3 (0xb6c8ffd3) [/usr/lib/libecore.so.1] + 0xdfd3
 5: ecore_main_loop_iterate + 0x38 (0xb6c903a8) [/usr/lib/libecore.so.1] + 0xe3a8
 6: elm_shutdown + 0x55 (0xb7079555) [/usr/lib/libelementary.so.1] + 0xf0555
 7: ea_mod_shutdown + 0xb0 (0xaad85cc0) [/usr/lib/libefl-assist.so.0] + 0x1cc0
 8: _dl_fini + 0x1d4 (0xb772d1d4) [/lib/ld-linux.so.2] + 0xf1d4
 9: __run_exit_handlers + 0xdf (0xb724083f) [/lib/libc.so.6] + 0x2f83f
10: __GI_exit + 0x2f (0xb724089f) [/lib/libc.so.6] + 0x2f89f
11: __launchpad_main_loop + 0x1c23 (0x804bfa3) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bfa3
12: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
13: __libc_start_main + 0xe6 (0xb7227da6) [/lib/libc.so.6] + 0x16da6
14: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
