S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 7750
Date: 2013-07-19 14:06:20(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=7750 tid=7750
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 7750, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xb2594bd0, esi = 0x099c4158
ebp = 0xbfa670e8, esp = 0xbfa670ac
eax = 0x00000000, ebx = 0xb41b72f4
ecx = 0x00000000, edx = 0x00000006
eip = 0xb3994cf7

Memory Information
MemTotal:   509368 KB
MemFree:     18256 KB
Buffers:      2720 KB
Cached:     276292 KB
VmPeak:     237144 KB
VmSize:     231748 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      108696 KB
VmRSS:      107212 KB
VmData:      89732 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100592 KB
VmPTE:         224 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
aacf7000 aacf9000 r-xp /usr/lib/libhaptic-module.so
afb1c000 afb8f000 r-xp /usr/lib/host-gl/libGL.so.1.2
afbb2000 afbc0000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afbc1000 afbf8000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afbfc000 afbfe000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afbff000 afc06000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc07000 afc14000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc15000 afc23000 r-xp /usr/lib/libudev.so.0.13.1
afc24000 afc66000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc67000 afcf3000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afcf9000 afd03000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afd04000 afd1c000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd1d000 afd23000 r-xp /usr/lib/libmmffile.so.0.0.0
afd24000 afd2c000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd2d000 afd2f000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd30000 afd51000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd52000 afd54000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd55000 afd73000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd74000 afd7a000 r-xp /usr/lib/libmemenv.so.1.1.0
afd7b000 afdc4000 r-xp /usr/lib/libleveldb.so.1.1.0
afdc6000 afdd1000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afdd2000 afe0e000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe10000 afe25000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe26000 afe46000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe48000 afe7e000 r-xp /usr/lib/libxslt.so.1.1.16
afe7f000 afe87000 r-xp /usr/lib/libeeze.so.1.7.99
afe88000 afe8d000 r-xp /usr/lib/libeukit.so.1.7.99
afe8e000 afe98000 r-xp /usr/lib/libenchant.so.1.6.1
afe99000 afea3000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afea4000 afeb0000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afeb1000 afee0000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afee6000 afeea000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afeeb000 afef7000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afef9000 aff00000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
aff01000 aff10000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff11000 aff14000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff15000 aff26000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff27000 aff56000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff57000 aff5d000 r-xp /usr/lib/libogg.so.0.7.1
aff5e000 aff89000 r-xp /usr/lib/libvorbis.so.0.4.3
aff8a000 aff8f000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff90000 aff94000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff95000 aff9a000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff9b000 affc0000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affc1000 affdb000 r-xp /usr/lib/libnetwork.so.0.0.0
affdd000 b0009000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b000a000 b1ff5000 r-xp /usr/lib/libewebkit2.so.0.11.72
b20ef000 b225a000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b2266000 b22ea000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b22ec000 b2308000 r-xp /usr/lib/libwifi-direct.so.0.0
b2309000 b2314000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b2315000 b2320000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2321000 b232f000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b2330000 b23d2000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b23d8000 b24ea000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b24f0000 b2515000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b2517000 b2544000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2549000 b254b000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
b254c000 b254d000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b2556000 b25ca000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b25cd000 b25fd000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b25fe000 b2651000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2652000 b2658000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2659000 b265e000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b265f000 b26a7000 r-xp /usr/lib/libpulse.so.0.12.4
b26a8000 b26ac000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26ad000 b279f000 r-xp /usr/lib/libasound.so.2.0.0
b27a3000 b27c8000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b27c9000 b27dd000 r-xp /usr/lib/libmmfsound.so.0.1.0
b27de000 b28be000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b28c3000 b2922000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b2923000 b292f000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2930000 b2943000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b2944000 b2947000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2948000 b295f000 r-xp /usr/lib/libICE.so.6.3.0
b2962000 b2969000 r-xp /usr/lib/libSM.so.6.0.1
b296a000 b296b000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b296c000 b2977000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2978000 b297d000 r-xp /usr/lib/libsysman.so.0.2.0
b297e000 b2989000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b298d000 b2991000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2992000 b29ef000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b29f1000 b29f9000 r-xp /usr/lib/libxcb-render.so.0.0.0
b29fa000 b29fc000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b29fd000 b2a60000 r-xp /usr/lib/libtiff.so.5.1.0
b2a63000 b2ab5000 r-xp /usr/lib/libturbojpeg.so
b2ac6000 b2acd000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ace000 b2ad7000 r-xp /usr/lib/libgif.so.4.1.6
b2ad8000 b2afe000 r-xp /usr/lib/libavutil.so.51.73.101
b2b05000 b2b4a000 r-xp /usr/lib/libswscale.so.2.1.101
b2b4b000 b2eb0000 r-xp /usr/lib/libavcodec.so.54.59.100
b31d1000 b31f8000 r-xp /usr/lib/libpng12.so.0.50.0
b31f9000 b3200000 r-xp /usr/lib/libfeedback.so.0.1.4
b3201000 b3210000 r-xp /usr/lib/libtts.so
b3211000 b3227000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b3228000 b3342000 r-xp /usr/lib/libcairo.so.2.11200.12
b3345000 b3369000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b336a000 b4150000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41c0000 b41c6000 r-xp /usr/lib/libslp_devman_plugin.so
b41c7000 b41c9000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41ca000 b41cd000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41ce000 b41d2000 r-xp /usr/lib/libdevice-node.so.0.1
b41d3000 b41e1000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b41e2000 b41eb000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b41ec000 b41f2000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41f3000 b41f5000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b41f6000 b41fa000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b41fb000 b4202000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4203000 b4206000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b4207000 b4208000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4209000 b421c000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b421e000 b4226000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4227000 b4257000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4258000 b425c000 r-xp /usr/lib/libuuid.so.1.3.0
b425d000 b426e000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b426f000 b4270000 r-xp /usr/lib/libpmapi.so.1.2
b4271000 b427d000 r-xp /usr/lib/libminizip.so.1.0.0
b427e000 b428f000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4290000 b42b8000 r-xp /usr/lib/libpcre.so.0.0.1
b42b9000 b42bd000 r-xp /usr/lib/libheynoti.so.0.0.2
b42be000 b42c3000 r-xp /usr/lib/libhaptic.so.0.1
b42c4000 b42c5000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42c6000 b42cd000 r-xp /usr/lib/libdevman.so.0.1
b42ce000 b42d4000 r-xp /usr/lib/libchromium.so.1.0
b42d5000 b42dd000 r-xp /usr/lib/libalarm.so.0.0.0
b42de000 b42e7000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b42e8000 b4300000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4301000 b47ab000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b47cd000 b47d7000 r-xp /lib/libnss_files-2.13.so
b47d9000 b47e2000 r-xp /lib/libnss_nis-2.13.so
b47e4000 b47f7000 r-xp /lib/libnsl-2.13.so
b47fb000 b4801000 r-xp /lib/libnss_compat-2.13.so
b4a03000 b4a1d000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a1e000 b4b67000 r-xp /usr/lib/libxml2.so.2.7.8
b4b6d000 b4b93000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b94000 b4b97000 r-xp /usr/lib/libiniparser.so.0
b4b99000 b4c02000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c04000 b4c20000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c21000 b4c28000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c29000 b4c2c000 r-xp /usr/lib/libdri2.so.0.0.0
b4c2d000 b4c38000 r-xp /usr/lib/libdrm.so.2.4.0
b4c39000 b4c3e000 r-xp /usr/lib/libtbm.so.1.0.0
b4c3f000 b4c43000 r-xp /usr/lib/libXv.so.1.0.0
b4c44000 b4d62000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d71000 b4d86000 r-xp /usr/lib/libnotification.so.0.1.0
b4d87000 b4d90000 r-xp /usr/lib/libutilX.so.1.1.0
b4d91000 b4dc4000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4dc6000 b4dd7000 r-xp /lib/libresolv-2.13.so
b4ddb000 b4dde000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4ddf000 b4f44000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f48000 b50b8000 r-xp /usr/lib/libcrypto.so.1.0.0
b50d0000 b5126000 r-xp /usr/lib/libssl.so.1.0.0
b512b000 b515a000 r-xp /usr/lib/libidn.so.11.5.44
b515b000 b516a000 r-xp /usr/lib/libcares.so.2.0.0
b516b000 b5192000 r-xp /lib/libexpat.so.1.5.2
b5194000 b51c7000 r-xp /usr/lib/libicule.so.48.1
b51c8000 b51d3000 r-xp /usr/lib/libsf_common.so
b51d4000 b52b0000 r-xp /usr/lib/libstdc++.so.6.0.14
b52bc000 b52bf000 r-xp /usr/lib/libapp-checker.so.0.1.0
b52c0000 b52e5000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b52e6000 b52eb000 r-xp /usr/lib/libffi.so.5.0.10
b52ec000 b52ed000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b52ee000 b531f000 r-xp /usr/lib/libexif.so.12.3.3
b532c000 b5338000 r-xp /usr/lib/libethumb.so.1.7.99
b5339000 b539d000 r-xp /usr/lib/libsndfile.so.1.0.25
b53a3000 b53a6000 r-xp /usr/lib/libctxdata.so.0.0.0
b53a7000 b53be000 r-xp /usr/lib/libremix.so.0.0.0
b53bf000 b53c1000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b53c2000 b53ef000 r-xp /usr/lib/liblua-5.1.so
b53f0000 b53fa000 r-xp /usr/lib/libembryo.so.1.7.99
b53fb000 b53fe000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b53ff000 b5460000 r-xp /usr/lib/libcurl.so.4.3.0
b5462000 b5468000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5469000 b547a000 r-xp /usr/lib/libXext.so.6.4.0
b547b000 b5480000 r-xp /usr/lib/libXtst.so.6.1.0
b5481000 b5489000 r-xp /usr/lib/libXrender.so.1.3.0
b548a000 b5493000 r-xp /usr/lib/libXrandr.so.2.2.0
b5494000 b5496000 r-xp /usr/lib/libXinerama.so.1.0.0
b5497000 b54a5000 r-xp /usr/lib/libXi.so.6.1.0
b54a6000 b54aa000 r-xp /usr/lib/libXfixes.so.3.1.0
b54ab000 b54ad000 r-xp /usr/lib/libXgesture.so.7.0.0
b54ae000 b54b0000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54b1000 b54b3000 r-xp /usr/lib/libXdamage.so.1.1.0
b54b4000 b54be000 r-xp /usr/lib/libXcursor.so.1.0.2
b54bf000 b5556000 r-xp /usr/lib/libpixman-1.so.0.28.2
b555b000 b5590000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5592000 b5617000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5621000 b5637000 r-xp /usr/lib/libfribidi.so.0.3.1
b5638000 b56bd000 r-xp /usr/lib/libfreetype.so.6.8.1
b56c1000 b5708000 r-xp /usr/lib/libjpeg.so.8.0.2
b5719000 b5738000 r-xp /lib/libz.so.1.2.5
b5739000 b5745000 r-xp /usr/lib/libemotion.so.1.7.99
b5746000 b574c000 r-xp /usr/lib/libecore_fb.so.1.7.99
b574e000 b575e000 r-xp /usr/lib/libsensor.so.1.1.0
b5761000 b5767000 r-xp /usr/lib/libappcore-common.so.1.1
b6870000 b69cb000 r-xp /usr/lib/libicuuc.so.48.1
b69d9000 b6bb8000 r-xp /usr/lib/libicui18n.so.48.1
b6bbf000 b6bc2000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6bc3000 b6bcf000 r-xp /usr/lib/libvconf.so.0.2.45
b6bd0000 b6bd9000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6bda000 b6beb000 r-xp /usr/lib/libail.so.0.1.0
b6bec000 b6bfc000 r-xp /usr/lib/libaul.so.0.1.0
b6bfd000 b6c4d000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c4e000 b6c91000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c93000 b6cee000 r-xp /usr/lib/libeina.so.1.7.99
b6cf0000 b6d0f000 r-xp /usr/lib/libecore.so.1.7.99
b6d1e000 b6d49000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d4b000 b6d56000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d57000 b6d63000 r-xp /usr/lib/libedbus.so.1.7.99
b6d64000 b6d67000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d68000 b6d6e000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d6f000 b6d91000 r-xp /usr/lib/libefreet.so.1.7.99
b6d93000 b6e2a000 r-xp /usr/lib/libedje.so.1.7.99
b6e2c000 b6e43000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e57000 b6e5e000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e5f000 b6e8c000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e8e000 b6f98000 r-xp /usr/lib/libevas.so.1.7.99
b6fb3000 b6fd0000 r-xp /usr/lib/libeet.so.1.7.99
b6fd1000 b6ff5000 r-xp /lib/libm-2.13.so
b6ff7000 b71c7000 r-xp /usr/lib/libelementary.so.1.7.99
b71d4000 b71df000 r-xp /usr/lib/libcapi-web-favorites.so
b71e0000 b71e2000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b71e5000 b71e9000 r-xp /lib/libattr.so.1.1.0
b71ea000 b71ec000 r-xp /usr/lib/libXau.so.6.0.0
b71ee000 b71f5000 r-xp /lib/librt-2.13.so
b71f7000 b71ff000 r-xp /lib/libcrypt-2.13.so
b7228000 b722b000 r-xp /lib/libcap.so.2.21
b722c000 b722e000 r-xp /usr/lib/libiri.so
b722f000 b7249000 r-xp /lib/libgcc_s-4.5.3.so.1
b724a000 b726a000 r-xp /usr/lib/libxcb.so.1.1.0
b726c000 b7275000 r-xp /lib/libunwind.so.8.0.1
b727f000 b73d5000 r-xp /lib/libc-2.13.so
b73db000 b73e0000 r-xp /usr/lib/libsmack.so.1.0.0
b73e1000 b742d000 r-xp /usr/lib/libdbus-1.so.3.7.2
b742e000 b7433000 r-xp /usr/lib/libbundle.so.0.1.22
b7434000 b7436000 r-xp /lib/libdl-2.13.so
b7439000 b7562000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7563000 b7578000 r-xp /lib/libpthread-2.13.so
b757d000 b757e000 r-xp /usr/lib/libdlog.so.0.0.0
b757f000 b7629000 r-xp /usr/lib/libsqlite3.so.0.8.6
b762c000 b7638000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b7639000 b776e000 r-xp /usr/lib/libX11.so.6.3.0
b7773000 b777b000 r-xp /usr/lib/libecore_imf.so.1.7.99
b777c000 b7781000 r-xp /usr/lib/libappcore-efl.so.1.1
b7783000 b7787000 r-xp /usr/lib/libsys-assert.so
b778b000 b778c000 r-xp [vdso]
b778c000 b77a8000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:7750)
Call Stack Count: 38
 0: non-virtual thunk to MyHondanaMainForm::OnActionPerformed(Tizen::Ui::Control const&, int) + 0x53 (0xb2594c23) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3ec23
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
