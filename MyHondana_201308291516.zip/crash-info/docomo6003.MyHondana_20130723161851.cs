S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 6653
Date: 2013-07-23 16:18:51(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=6653 tid=6653
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 6653, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x0000004e, esi = 0xb72bd070
ebp = 0xbfc1a4ac, esp = 0xbfc1a4ac
eax = 0x00000000, ebx = 0xb73f8ff4
ecx = 0x0000004e, edx = 0x00000000
eip = 0xb731d338

Memory Information
MemTotal:   509368 KB
MemFree:     22560 KB
Buffers:     18540 KB
Cached:     305448 KB
VmPeak:     247252 KB
VmSize:     222576 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       75612 KB
VmRSS:       66036 KB
VmData:      83940 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100768 KB
VmPTE:         188 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
ad84b000 ad84d000 r-xp /usr/lib/remix/libeet_sndfile_reader.so
ad84e000 ad851000 r-xp /usr/lib/remix/libtizen_sound_player.so.1.0.0
ad852000 ad853000 r-xp /usr/lib/edje/modules/multisense_factory/linux-gnu-i686-1.0.0/module.so
ad859000 ad87d000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
ae35a000 ae35f000 r-xp /usr/lib/libefl-assist.so.0.1.0
afb3e000 afbb1000 r-xp /usr/lib/host-gl/libGL.so.1.2
afbd4000 afbe2000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afbe3000 afc1a000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afc1e000 afc20000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afc21000 afc28000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc29000 afc36000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc37000 afc45000 r-xp /usr/lib/libudev.so.0.13.1
afc46000 afc88000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc89000 afd15000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afd1b000 afd25000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afd26000 afd3e000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd3f000 afd45000 r-xp /usr/lib/libmmffile.so.0.0.0
afd46000 afd4e000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd4f000 afd51000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd52000 afd73000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd74000 afd76000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd77000 afd95000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd96000 afd9c000 r-xp /usr/lib/libmemenv.so.1.1.0
afd9d000 afde6000 r-xp /usr/lib/libleveldb.so.1.1.0
afde8000 afdf3000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afdf4000 afe30000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe32000 afe47000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe48000 afe68000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe6a000 afea0000 r-xp /usr/lib/libxslt.so.1.1.16
afea1000 afea9000 r-xp /usr/lib/libeeze.so.1.7.99
afeaa000 afeaf000 r-xp /usr/lib/libeukit.so.1.7.99
afeb0000 afeba000 r-xp /usr/lib/libenchant.so.1.6.1
afebb000 afec5000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afec6000 afed2000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afed3000 aff02000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
aff08000 aff0c000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
aff0d000 aff19000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
aff1b000 aff22000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
aff23000 aff32000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff33000 aff36000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff37000 aff48000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff49000 aff78000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff79000 aff7f000 r-xp /usr/lib/libogg.so.0.7.1
aff80000 affab000 r-xp /usr/lib/libvorbis.so.0.4.3
affac000 affb1000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
affb2000 affb6000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
affb7000 affbc000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
affbd000 affe2000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affe3000 afffd000 r-xp /usr/lib/libnetwork.so.0.0.0
affff000 b002b000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b002c000 b2017000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2111000 b227c000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b2288000 b230c000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b230e000 b232a000 r-xp /usr/lib/libwifi-direct.so.0.0
b232b000 b2336000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b2337000 b2342000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2343000 b2351000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b2352000 b23f4000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b23fa000 b250c000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2512000 b2537000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b2539000 b2566000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b256c000 b256d000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
b256e000 b256f000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b2578000 b25ec000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b25ef000 b261f000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2620000 b2673000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2674000 b267a000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b267b000 b2680000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2681000 b26c9000 r-xp /usr/lib/libpulse.so.0.12.4
b26ca000 b26ce000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26cf000 b27c1000 r-xp /usr/lib/libasound.so.2.0.0
b27c5000 b27ea000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b27eb000 b27ff000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2800000 b28e0000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b28e5000 b2944000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b2945000 b2951000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2952000 b2965000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b2966000 b2969000 r-xp /usr/lib/libmm_ta.so.0.0.0
b296a000 b2981000 r-xp /usr/lib/libICE.so.6.3.0
b2984000 b298b000 r-xp /usr/lib/libSM.so.6.0.1
b298c000 b298d000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b298e000 b2999000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b299a000 b299f000 r-xp /usr/lib/libsysman.so.0.2.0
b29a0000 b29ab000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b29af000 b29b3000 r-xp /usr/lib/libmmfsession.so.0.0.0
b29b4000 b2a11000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2a13000 b2a1b000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2a1c000 b2a1e000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2a1f000 b2a82000 r-xp /usr/lib/libtiff.so.5.1.0
b2a85000 b2ad7000 r-xp /usr/lib/libturbojpeg.so
b2ae8000 b2aef000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2af0000 b2af9000 r-xp /usr/lib/libgif.so.4.1.6
b2afa000 b2b20000 r-xp /usr/lib/libavutil.so.51.73.101
b2b27000 b2b6c000 r-xp /usr/lib/libswscale.so.2.1.101
b2b6d000 b2ed2000 r-xp /usr/lib/libavcodec.so.54.59.100
b31f3000 b321a000 r-xp /usr/lib/libpng12.so.0.50.0
b321b000 b3222000 r-xp /usr/lib/libfeedback.so.0.1.4
b3223000 b3232000 r-xp /usr/lib/libtts.so
b3233000 b3249000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b324a000 b3364000 r-xp /usr/lib/libcairo.so.2.11200.12
b3367000 b338b000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b338c000 b4172000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41e2000 b41e8000 r-xp /usr/lib/libslp_devman_plugin.so
b41e9000 b41eb000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41ec000 b41ef000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41f0000 b41f4000 r-xp /usr/lib/libdevice-node.so.0.1
b41f5000 b4203000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4204000 b420d000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b420e000 b4214000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b4215000 b4217000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4218000 b421c000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b421d000 b4224000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4225000 b4228000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b4229000 b422a000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b422b000 b423e000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4240000 b4248000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4249000 b4279000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b427a000 b427e000 r-xp /usr/lib/libuuid.so.1.3.0
b427f000 b4290000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4291000 b4292000 r-xp /usr/lib/libpmapi.so.1.2
b4293000 b429f000 r-xp /usr/lib/libminizip.so.1.0.0
b42a0000 b42b1000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42b2000 b42da000 r-xp /usr/lib/libpcre.so.0.0.1
b42db000 b42df000 r-xp /usr/lib/libheynoti.so.0.0.2
b42e0000 b42e5000 r-xp /usr/lib/libhaptic.so.0.1
b42e6000 b42e7000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42e8000 b42ef000 r-xp /usr/lib/libdevman.so.0.1
b42f0000 b42f6000 r-xp /usr/lib/libchromium.so.1.0
b42f7000 b42ff000 r-xp /usr/lib/libalarm.so.0.0.0
b4300000 b4309000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b430a000 b4322000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4323000 b47cd000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b47ef000 b47f9000 r-xp /lib/libnss_files-2.13.so
b47fb000 b4804000 r-xp /lib/libnss_nis-2.13.so
b4806000 b4819000 r-xp /lib/libnsl-2.13.so
b481d000 b4823000 r-xp /lib/libnss_compat-2.13.so
b4a25000 b4a3f000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a40000 b4b89000 r-xp /usr/lib/libxml2.so.2.7.8
b4b8f000 b4bb5000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4bb6000 b4bb9000 r-xp /usr/lib/libiniparser.so.0
b4bbb000 b4c24000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c26000 b4c42000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c43000 b4c4a000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c4b000 b4c4e000 r-xp /usr/lib/libdri2.so.0.0.0
b4c4f000 b4c5a000 r-xp /usr/lib/libdrm.so.2.4.0
b4c5b000 b4c60000 r-xp /usr/lib/libtbm.so.1.0.0
b4c61000 b4c65000 r-xp /usr/lib/libXv.so.1.0.0
b4c66000 b4d84000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d93000 b4da8000 r-xp /usr/lib/libnotification.so.0.1.0
b4da9000 b4db2000 r-xp /usr/lib/libutilX.so.1.1.0
b4db3000 b4de6000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4de8000 b4df9000 r-xp /lib/libresolv-2.13.so
b4dfd000 b4e00000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4e01000 b4f66000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f6a000 b50da000 r-xp /usr/lib/libcrypto.so.1.0.0
b50f2000 b5148000 r-xp /usr/lib/libssl.so.1.0.0
b514d000 b517c000 r-xp /usr/lib/libidn.so.11.5.44
b517d000 b518c000 r-xp /usr/lib/libcares.so.2.0.0
b518d000 b51b4000 r-xp /lib/libexpat.so.1.5.2
b51b6000 b51e9000 r-xp /usr/lib/libicule.so.48.1
b51ea000 b51f5000 r-xp /usr/lib/libsf_common.so
b51f6000 b52d2000 r-xp /usr/lib/libstdc++.so.6.0.14
b52de000 b52e1000 r-xp /usr/lib/libapp-checker.so.0.1.0
b52e2000 b5307000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5308000 b530d000 r-xp /usr/lib/libffi.so.5.0.10
b530e000 b530f000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5310000 b5341000 r-xp /usr/lib/libexif.so.12.3.3
b534e000 b535a000 r-xp /usr/lib/libethumb.so.1.7.99
b535b000 b53bf000 r-xp /usr/lib/libsndfile.so.1.0.25
b53c5000 b53c8000 r-xp /usr/lib/libctxdata.so.0.0.0
b53c9000 b53e0000 r-xp /usr/lib/libremix.so.0.0.0
b53e1000 b53e3000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b53e4000 b5411000 r-xp /usr/lib/liblua-5.1.so
b5412000 b541c000 r-xp /usr/lib/libembryo.so.1.7.99
b541d000 b5420000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5421000 b5482000 r-xp /usr/lib/libcurl.so.4.3.0
b5484000 b548a000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b548b000 b549c000 r-xp /usr/lib/libXext.so.6.4.0
b549d000 b54a2000 r-xp /usr/lib/libXtst.so.6.1.0
b54a3000 b54ab000 r-xp /usr/lib/libXrender.so.1.3.0
b54ac000 b54b5000 r-xp /usr/lib/libXrandr.so.2.2.0
b54b6000 b54b8000 r-xp /usr/lib/libXinerama.so.1.0.0
b54b9000 b54c7000 r-xp /usr/lib/libXi.so.6.1.0
b54c8000 b54cc000 r-xp /usr/lib/libXfixes.so.3.1.0
b54cd000 b54cf000 r-xp /usr/lib/libXgesture.so.7.0.0
b54d0000 b54d2000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54d3000 b54d5000 r-xp /usr/lib/libXdamage.so.1.1.0
b54d6000 b54e0000 r-xp /usr/lib/libXcursor.so.1.0.2
b54e1000 b5578000 r-xp /usr/lib/libpixman-1.so.0.28.2
b557d000 b55b2000 r-xp /usr/lib/libfontconfig.so.1.5.0
b55b4000 b5639000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5643000 b5659000 r-xp /usr/lib/libfribidi.so.0.3.1
b565a000 b56df000 r-xp /usr/lib/libfreetype.so.6.8.1
b56e3000 b572a000 r-xp /usr/lib/libjpeg.so.8.0.2
b573b000 b575a000 r-xp /lib/libz.so.1.2.5
b575b000 b5767000 r-xp /usr/lib/libemotion.so.1.7.99
b5768000 b576e000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5770000 b5780000 r-xp /usr/lib/libsensor.so.1.1.0
b5783000 b5789000 r-xp /usr/lib/libappcore-common.so.1.1
b6892000 b69ed000 r-xp /usr/lib/libicuuc.so.48.1
b69fb000 b6bda000 r-xp /usr/lib/libicui18n.so.48.1
b6be1000 b6be4000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6be5000 b6bf1000 r-xp /usr/lib/libvconf.so.0.2.45
b6bf2000 b6bfb000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6bfc000 b6c0d000 r-xp /usr/lib/libail.so.0.1.0
b6c0e000 b6c1e000 r-xp /usr/lib/libaul.so.0.1.0
b6c1f000 b6c6f000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c70000 b6cb3000 r-xp /usr/lib/libecore_x.so.1.7.99
b6cb5000 b6d10000 r-xp /usr/lib/libeina.so.1.7.99
b6d12000 b6d31000 r-xp /usr/lib/libecore.so.1.7.99
b6d40000 b6d6b000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d6d000 b6d78000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d79000 b6d85000 r-xp /usr/lib/libedbus.so.1.7.99
b6d86000 b6d89000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d8a000 b6d90000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d91000 b6db3000 r-xp /usr/lib/libefreet.so.1.7.99
b6db5000 b6e4c000 r-xp /usr/lib/libedje.so.1.7.99
b6e4e000 b6e65000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e79000 b6e80000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e81000 b6eae000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6eb0000 b6fba000 r-xp /usr/lib/libevas.so.1.7.99
b6fd5000 b6ff2000 r-xp /usr/lib/libeet.so.1.7.99
b6ff3000 b7017000 r-xp /lib/libm-2.13.so
b7019000 b71e9000 r-xp /usr/lib/libelementary.so.1.7.99
b71f6000 b7201000 r-xp /usr/lib/libcapi-web-favorites.so
b7202000 b7204000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7207000 b720b000 r-xp /lib/libattr.so.1.1.0
b720c000 b720e000 r-xp /usr/lib/libXau.so.6.0.0
b7210000 b7217000 r-xp /lib/librt-2.13.so
b7219000 b7221000 r-xp /lib/libcrypt-2.13.so
b724a000 b724d000 r-xp /lib/libcap.so.2.21
b724e000 b7250000 r-xp /usr/lib/libiri.so
b7251000 b726b000 r-xp /lib/libgcc_s-4.5.3.so.1
b726c000 b728c000 r-xp /usr/lib/libxcb.so.1.1.0
b728e000 b7297000 r-xp /lib/libunwind.so.8.0.1
b72a1000 b73f7000 r-xp /lib/libc-2.13.so
b73fd000 b7402000 r-xp /usr/lib/libsmack.so.1.0.0
b7403000 b744f000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7450000 b7455000 r-xp /usr/lib/libbundle.so.0.1.22
b7456000 b7458000 r-xp /lib/libdl-2.13.so
b745b000 b7584000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7585000 b759a000 r-xp /lib/libpthread-2.13.so
b759f000 b75a0000 r-xp /usr/lib/libdlog.so.0.0.0
b75a1000 b764b000 r-xp /usr/lib/libsqlite3.so.0.8.6
b764e000 b765a000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b765b000 b7790000 r-xp /usr/lib/libX11.so.6.3.0
b7795000 b779d000 r-xp /usr/lib/libecore_imf.so.1.7.99
b779e000 b77a3000 r-xp /usr/lib/libappcore-efl.so.1.1
b77a5000 b77a9000 r-xp /usr/lib/libsys-assert.so
b77ad000 b77ae000 r-xp [vdso]
b77ae000 b77ca000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:6653)
Call Stack Count: 37
 0: _IO_vfprintf + 0x1ccd (0xb72dfaed) [/lib/libc.so.6] + 0x3eaed
 1: __vsnprintf_chk + 0xd4 (0xb73817b4) [/lib/libc.so.6] + 0xe07b4
 2: __dlog_vprint + 0x87 (0xb759fa97) [/usr/lib/libdlog.so.0] + 0xa97
 3: (0xb44ae376) [/usr/lib/osp/libosp-appfw.so] + 0x18b376
 4: AppLogInternal + 0x43 (0xb44ae633) [/usr/lib/osp/libosp-appfw.so] + 0x18b633
 5: MyHondanaLoginForm::OnWebDataReceived(Tizen::Base::String const&, Tizen::Net::Http::HttpHeader const&) + 0x432 (0xb25a7712) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x2f712
 6: non-virtual thunk to MyHondanaLoginForm::OnWebDataReceived(Tizen::Base::String const&, Tizen::Net::Http::HttpHeader const&) + 0x53 (0xb25a7953) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x2f953
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)

Latest Debug Message Information
--------- beginning of /dev/log_main
07-23 15:29:37.192 I/osp-installer( 5122): bool SignatureManager::ValidateSignatures()(103) > SignatureFiles: number=[-1]
07-23 15:29:37.192 I/osp-installer( 5122): bool SignatureManager::ValidateSignatures()(117) > ValidationCore::SignatureReader() is done
07-23 15:29:37.192 I/osp-installer( 5122): bool SignatureManager::ValidateSignatures()(129) > Author cert value=[MIICszCCAhygAwIBAgIGAT965MiTMA0GCSqGSIb3DQEBBQUAMIGEMQswCQYDVQQGEwJLUjEOMAwGA1UECAwFU3V3b24xDjAMBgNVBAcMBVN1d29uMRYwFAYDVQQKDA1UaXplbiBUZXN0IENBMSAwHgYDVQQLDBdUaXplbiBEZXZlbG9wZXIgVGVzdCBDQTEbMBkGA1UEAwwSVGl6ZW4gRGV2ZWxvcGVyIENBMB4XDTEyMTEwMTAwMDAwMFoXDTE5MDEwMTAwMDAwMFowgYAxCzAJBgNVBAYTAlRJMQ4wDAYDVQQIDAV0aXplbjEOMAwGA1UEBwwFdGl6ZW4xDjAMBgNVBAoMBXRpemVuMQ4wDAYDVQQLDAV0aXplbjEhMB8GCSqGSIb3DQEJARYSc2lob25nQGEydGVjLmNvLmtyMQ4wDAYDVQQDDAV0aXplbjCBnzANBgkqhkiG9w0BAQEFAAOBjQAwgYkCgYEA1awEuweUORm7dRVVhKD5fTmkEzTACqmv2KZS31O4KSYWFqi+dYGVG6Pg3RZJxEiF9Kcu6PJySvSg13hi1wIy4pyAJUXMeDJq1BMZwmQS/TIv6PZ/m5OkIZ/S3GV/tMiGTW4v1K254onjl1J2TJCBx1wMDT8xnAljRyNk2w8TUn8CAwEAAaMyMDAwDAYDVR0TAQH/BAIwADALBgNVHQ8EBAMCB4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwDQYJKoZIhvcNAQEFBQADgYEAlZ2p37BQWIeui/MFoGnx6WTTP2KFi8NSqgbzjoC1m2ah/oGQWEEjPk4eFp8yhPMyEtlyos0QVs3LT7fUEZPQ7b8SkwXi/64LLNTmdeU3c1zs0mfG8Dgn9CTc9oFvPu4PFBYtOkBtAc7dVtgwS6CyJzXBK9gS17uhOfJJ+x925iU=]
07-23 15:29:37.192 I/osp-installer( 5122): bool SignatureManager::ValidateSignatures()(129) > Author cert value=[MIICpzCCAhCgAwIBAgIJAKzDjmEF+1OXMA0GCSqGSIb3DQEBBQUAMIGTMQswCQYDVQQGEwJLUjEOMAwGA1UECAwFU3V3b24xDjAMBgNVBAcMBVN1d29uMRYwFAYDVQQKDA1UaXplbiBUZXN0IENBMSUwIwYDVQQLDBxUaXplbiBUZXN0IERldmVsb3BlciBSb290IENBMSUwIwYDVQQDDBxUaXplbiBUZXN0IERldmVsb3BlciBSb290IENBMB4XDTEyMTAyOTEzMDEyMloXDTIyMTAyNzEzMDEyMlowgYQxCzAJBgNVBAYTAktSMQ4wDAYDVQQIDAVTdXdvbjEOMAwGA1UEBwwFU3V3b24xFjAUBgNVBAoMDVRpemVuIFRlc3QgQ0ExIDAeBgNVBAsMF1RpemVuIERldmVsb3BlciBUZXN0IENBMRswGQYDVQQDDBJUaXplbiBEZXZlbG9wZXIgQ0EwgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMyG0DSTHBgalQo1seDKxpCU61gji+QQlxQkPQOvBrmuF6Z90zFCprTtg2sRjTLCNoRd75+VCCHuKGcrD27t7hwAekusPrpzdsq5QoBMvNjGDM22lC45PJ4d86DEDY4erxeJ5aSQxqbfXK4pKe9NwxdkKuA8dTYZM1UcmhXs7YALAgMBAAGjEDAOMAwGA1UdEwQFMAMBAf8wDQYJKoZIhvcNAQEFBQADgYEACbr/OPNMJ+Ejrxfm/YjCiRPpjJLnwXS2IDtitbxot6bEdZkZvOFXOC0Ca4GT+jtvOcSlU7tM3Mdd1MrKe1kkoVd1vhCV8V4CK3/DPj8aN3rxfMfQitA6XMDcxzhsyMWz56OdifX50dvS/G/ad+kGhNhOOEKSE8zUyEDCGwqkfXk=]
07-23 15:29:37.202 I/osp-installer( 5122): bool SignatureManager::ValidateSignatures()(149) > validator.check() start >>
07-23 15:29:37.342 I/osp-installer( 5122): bool SignatureManager::ValidateSignatures()(166) > Signature validator.check success, file=[author-signature.xml], number=[-1]
07-23 15:29:37.342 I/osp-installer( 5122): bool SignatureManager::ValidateSignatures()(175) > Author root cert value=[MIICnzCCAggCCQCn+GGT4zh+BjANBgkqhkiG9w0BAQUFADCBkzELMAkGA1UEBhMCS1IxDjAMBgNVBAgMBVN1d29uMQ4wDAYDVQQHDAVTdXdvbjEWMBQGA1UECgwNVGl6ZW4gVGVzdCBDQTElMCMGA1UECwwcVGl6ZW4gVGVzdCBEZXZlbG9wZXIgUm9vdCBDQTElMCMGA1UEAwwcVGl6ZW4gVGVzdCBEZXZlbG9wZXIgUm9vdCBDQTAeFw0xMjEwMjYwOTUwMTNaFw0yMjEwMjQwOTUwMTNaMIGTMQswCQYDVQQGEwJLUjEOMAwGA1UECAwFU3V3b24xDjAMBgNVBAcMBVN1d29uMRYwFAYDVQQKDA1UaXplbiBUZXN0IENBMSUwIwYDVQQLDBxUaXplbiBUZXN0IERldmVsb3BlciBSb290IENBMSUwIwYDVQQDDBxUaXplbiBUZXN0IERldmVsb3BlciBSb290IENBMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDWT6ZH5JyGadTUK1QmNwU8j+py4WtuElJE+4/wPFP8/KBmvvmIrGVjhUbKXToKIo8N6C/0SLxGEWuRAIoZHhg5JVbw1Ay7smgJJHizDUAqMTmV6LI9yTFbBV+OlO2Dir4LVdQ/XDBiqqslr7pqXgsg1V2g7x+tOI/f3dn2kWoVZQIDAQABMA0GCSqGSIb3DQEBBQUAA4GBADGJYMtzUBDK+KKLZQ6zYmrKb+OWLlmEr/t/c2afKjTKUtommcz8VeTPqrDBOwxlVPdxlbhisCYzzvwnWeZk1aeptxxU3kdW9N3/wocN5nBzgqkkHJnj/ptqjrH2v/m0Z3hBuI4/akHIIfCBF8mUHwqcxYsRdcCIrkgp2AivbSaM]
07-23 15:29:37.342 I/osp-installer( 5122): bool SignatureManager::ValidateSignatures()(215) > ValidateSignatures done successfully <<
07-23 15:29:37.342 I/osp-installer( 5122): InstallerError SignatureStep::OnStateSignerInit()(133) >   ## __pSignatureManager->ValidateSignatures() result = [true]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureManager::ValidatePartialReferences()(222) > ValidatePartialReferences start >>
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnStartElement(const char*)(90) > ------------------------------------------
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnStartElement(const char*)(91) > signature.xml
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnStartElement(const char*)(92) > ------------------------------------------
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnStartElement(const char*)(93) > <Signature>
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnSignatureStartElement()(170) > <DistributorSignature>
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnReferenceStartElement()(208) > Reference URI=[bin/MyHondana.exe]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnDigestValue(const char*)(288) > digest value=[QGN74QQuqU4pycKmf7XCuG1VNdQzxGD7p9yoe3IMeZY=]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnReferenceStartElement()(208) > Reference URI=[info/manifest.xml]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnDigestValue(const char*)(288) > digest value=[iVxcqCzW4tHw4zqQ6XqV36vfR45asnMZ8PjghUxaO2c=]
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnEndElement(const char*)(122) > </Signature>
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnStartElement(const char*)(90) > ------------------------------------------
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnStartElement(const char*)(91) > signature.xml
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnStartElement(const char*)(92) > ------------------------------------------
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnStartElement(const char*)(93) > <Signature>
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnSignatureStartElement()(170) > <AuthorSignature>
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnReferenceStartElement()(208) > Reference URI=[bin/MyHondana.exe]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnDigestValue(const char*)(288) > digest value=[QGN74QQuqU4pycKmf7XCuG1VNdQzxGD7p9yoe3IMeZY=]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnReferenceStartElement()(208) > Reference URI=[info/manifest.xml]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureHandler::OnDigestValue(const char*)(288) > digest value=[iVxcqCzW4tHw4zqQ6XqV36vfR45asnMZ8PjghUxaO2c=]
07-23 15:29:37.362 I/osp-installer( 5122): virtual bool SignatureHandler::OnEndElement(const char*)(122) > </Signature>
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureManager::CompareReferences(Tizen::Base::Collection::HashMap*, Tizen::Base::Collection::HashMap*)(722) > pAuthorValue=[iVxcqCzW4tHw4zqQ6XqV36vfR45asnMZ8PjghUxaO2c=]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureManager::CompareReferences(Tizen::Base::Collection::HashMap*, Tizen::Base::Collection::HashMap*)(723) > pDistValue=[iVxcqCzW4tHw4zqQ6XqV36vfR45asnMZ8PjghUxaO2c=]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureManager::CompareReferences(Tizen::Base::Collection::HashMap*, Tizen::Base::Collection::HashMap*)(732) > filePath=[/opt/apps/docomo6003/info/manifest.xml]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[1574]
07-23 15:29:37.362 E/Tizen::Io( 5122): int Tizen::Io::File::Read(void*, int)(162) > [E_END_OF_FILE] The end of file is reached.
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[0]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureManager::CompareReferences(Tizen::Base::Collection::HashMap*, Tizen::Base::Collection::HashMap*)(736) > fileDigest=[iVxcqCzW4tHw4zqQ6XqV36vfR45asnMZ8PjghUxaO2c=]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureManager::CompareReferences(Tizen::Base::Collection::HashMap*, Tizen::Base::Collection::HashMap*)(722) > pAuthorValue=[QGN74QQuqU4pycKmf7XCuG1VNdQzxGD7p9yoe3IMeZY=]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureManager::CompareReferences(Tizen::Base::Collection::HashMap*, Tizen::Base::Collection::HashMap*)(723) > pDistValue=[QGN74QQuqU4pycKmf7XCuG1VNdQzxGD7p9yoe3IMeZY=]
07-23 15:29:37.362 I/osp-installer( 5122): bool SignatureManager::CompareReferences(Tizen::Base::Collection::HashMap*, Tizen::Base::Collection::HashMap*)(732) > filePath=[/opt/apps/docomo6003/bin/MyHondana.exe]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.362 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.372 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.382 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[65536]
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[2472]
07-23 15:29:37.392 E/Tizen::Io( 5122): int Tizen::Io::File::Read(void*, int)(162) > [E_END_OF_FILE] The end of file is reached.
07-23 15:29:37.392 I/osp-installer( 5122): static bool InstallerUtil::GetFileDigest(const Tizen::Base::String&, Tizen::Base::String&)(947) > readBytes for Hash=[0]
07-23 15:29:37.392 I/osp-installer( 5122): bool SignatureManager::CompareReferences(Tizen::Base::Collection::HashMap*, Tizen::Base::Collection::HashMap*)(736) > fileDigest=[QGN74QQuqU4pycKmf7XCuG1VNdQzxGD7p9yoe3IMeZY=]
07-23 15:29:37.392 I/osp-installer( 5122): InstallerError SignatureStep::OnStateSignerInit()(139) >   ## __pSignatureManager->ValidatePartialReferences() result = [true]
07-23 15:29:37.402 I/osp-installer( 5122): InstallerError SignatureStep::OnStateSignerInit()(152) > _pSignatureManager->ValidateSignatures() is done.
07-23 15:29:37.402 I/osp-installer( 5122): virtual InstallerError SignatureStep::Run(InstallationContext*)(81) > [STATE_ROOT_CERT]
07-23 15:29:37.402 I/osp-installer( 5122): InstallerError SignatureStep::OnStateRootCert()(227) > Package = [docomo6003], CertType = [64], ApiVisibility = [100], preloaded = [0], privilege level = [0]
07-23 15:29:37.402 E/osp-installer( 5122): static result PrivilegeHandler::PickExternalPrivilege(const Tizen::Base::Collection::IList&, Tizen::Base::Collection::IList&, Tizen::Base::Collection::IList&)(62) > [E_DATABASE] Privilege database error.
07-23 15:29:37.402 I/osp-installer( 5122): static result PrivilegeHandler::GenerateCipherPrivilege(const Tizen::App::AppId&, const Tizen::Base::Collection::IList&, int, Tizen::Base::String&, Tizen::Base::String&, Tizen::Base::Collection::IList&)(174) > Working with normal PrivilegeDb.
07-23 15:29:37.402 I/osp-installer( 5122): virtual InstallerError SignatureStep::Run(InstallationContext*)(86) > [STATE_CONTEXT_AUDIT]
07-23 15:29:37.402 I/osp-installer( 5122): virtual InstallerError SignatureStep::Run(InstallationContext*)(91) > [STATE_DONE]
07-23 15:29:37.402 I/osp-installer( 5122): virtual InstallerError SignatureStep::Run(InstallationContext*)(106) >  SignatureStep - END
07-23 15:29:37.402 I/osp-installer( 5122): static bool InstallerManager::SendEvent(InstallationContext*, const Tizen::App::PackageId&, const Tizen::Base::String&, const Tizen::Base::String&)(956) > pkgmgr_installer_send_signal(tpk, docomo6003, install_percent, 60)
07-23 15:29:37.402 I/osp-installer( 5122): virtual InstallerError Installer::OnRegister()(104) > ------------------------------------------
07-23 15:29:37.402 I/osp-installer( 5122): virtual InstallerError Installer::OnRegister()(105) > Installer::OnRegister() - START
07-23 15:29:37.552 I/osp-installer( 5122): virtual InstallerError Installer::OnRegister()(122) > Installer::OnRegister() - END
07-23 15:29:37.552 I/osp-installer( 5122): virtual InstallerError Installer::OnRegister()(123) > ------------------------------------------
07-23 15:29:37.552 I/osp-installer( 5122): virtual InstallerError Installer::OnEnd()(131) > ------------------------------------------
07-23 15:29:37.552 I/osp-installer( 5122): virtual InstallerError Installer::OnEnd()(132) > Installer::OnEnd() - START
07-23 15:29:37.552 I/osp-installer( 5122): bool SmackManager::IsSmackEnable()(470) > [smack is on.]
07-23 15:29:37.552 I/osp-installer( 5122): int SmackManager::Install(const char*)(504) > [smack] app_install(docomo6003)
07-23 15:29:37.562 I/osp-installer( 5122): int SmackManager::Install(const char*)(506) > [smack] app_install(docomo6003), result = [0]
07-23 15:29:37.562 I/osp-installer( 5122): static bool InstallerUtil::CreateInfoFile(const Tizen::Base::String&, const Tizen::Base::String*)(547) > ------------------------------------------
07-23 15:29:37.562 I/osp-installer( 5122): static bool InstallerUtil::CreateInfoFile(const Tizen::Base::String&, const Tizen::Base::String*)(548) > CreateInfoFile(), filePath = [/opt/apps/docomo6003/info/version.info]
07-23 15:29:37.562 I/osp-installer( 5122): static bool InstallerUtil::CreateInfoFile(const Tizen::Base::String&, const Tizen::Base::String*)(554) > string = [2.1]
07-23 15:29:37.562 I/osp-installer( 5122): static bool InstallerUtil::CreateInfoFile(const Tizen::Base::String&, const Tizen::Base::String*)(556) > ------------------------------------------
07-23 15:29:37.562 I/osp-installer( 5122): bool ConfigurationManager::FindPrivilege(InstallationContext*, const Tizen::Base::String&) const(958) > Privilege = [http://tizen.org/privilege/web.service]
07-23 15:29:37.562 I/osp-installer( 5122): bool ConfigurationManager::CreateFile(InstallationContext*)(94) > WEB_SERVICE privilege 
End of latest debug message
