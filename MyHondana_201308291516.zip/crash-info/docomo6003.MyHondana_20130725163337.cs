S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 6848
Date: 2013-07-25 16:33:37(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=6848 tid=6848
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 6848, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x08631178, esi = 0x08733368
ebp = 0xbfa4ef48, esp = 0xbfa4eebc
eax = 0x08750100, ebx = 0xb25b1668
ecx = 0x087c2868, edx = 0x00000000
eip = 0x00000011

Memory Information
MemTotal:   509368 KB
MemFree:     14460 KB
Buffers:     12444 KB
Cached:     281216 KB
VmPeak:     229248 KB
VmSize:     228144 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      102148 KB
VmRSS:      102148 KB
VmData:      84152 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100856 KB
VmPTE:         220 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
ac285000 ac2a9000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
ac2ae000 ac2b0000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
afae0000 afb53000 r-xp /usr/lib/host-gl/libGL.so.1.2
afb76000 afb84000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afb85000 afbbc000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afbc0000 afbc2000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afbc3000 afbca000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afbcb000 afbd8000 r-xp /usr/lib/libdrm-client.so.0.0.1
afbd9000 afbe7000 r-xp /usr/lib/libudev.so.0.13.1
afbe8000 afc2a000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc2b000 afcb7000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afcbd000 afcc7000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afcc8000 afce0000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afce1000 afce7000 r-xp /usr/lib/libmmffile.so.0.0.0
afce8000 afcf0000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afcf1000 afcf3000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afcf4000 afd15000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd16000 afd18000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd19000 afd37000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd38000 afd3e000 r-xp /usr/lib/libmemenv.so.1.1.0
afd3f000 afd88000 r-xp /usr/lib/libleveldb.so.1.1.0
afd8a000 afd95000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd96000 afdd2000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afdd4000 afde9000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afdea000 afe0a000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe0c000 afe42000 r-xp /usr/lib/libxslt.so.1.1.16
afe43000 afe4b000 r-xp /usr/lib/libeeze.so.1.7.99
afe4c000 afe51000 r-xp /usr/lib/libeukit.so.1.7.99
afe52000 afe5c000 r-xp /usr/lib/libenchant.so.1.6.1
afe5d000 afe67000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe68000 afe74000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afe75000 afea4000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afeaa000 afeae000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afeaf000 afebb000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afebd000 afec4000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afec5000 afed4000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afed5000 afed8000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
afed9000 afeea000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
afeeb000 aff1a000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff1b000 aff21000 r-xp /usr/lib/libogg.so.0.7.1
aff22000 aff4d000 r-xp /usr/lib/libvorbis.so.0.4.3
aff4e000 aff53000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff54000 aff58000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff59000 aff5e000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff5f000 aff84000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
aff85000 aff9f000 r-xp /usr/lib/libnetwork.so.0.0.0
affa1000 affcd000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
affce000 b1fb9000 r-xp /usr/lib/libewebkit2.so.0.11.72
b20b3000 b221e000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b222a000 b22ae000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b22b0000 b22cc000 r-xp /usr/lib/libwifi-direct.so.0.0
b22cd000 b22d8000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b22d9000 b22e4000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b22e5000 b22f3000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b22f4000 b2396000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b239c000 b24ae000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b24b4000 b24d9000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b24db000 b2508000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b250e000 b250f000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
b2510000 b2511000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b251a000 b25ad000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b25b2000 b25e2000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b25e3000 b2636000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2637000 b263d000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b263e000 b2643000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2644000 b268c000 r-xp /usr/lib/libpulse.so.0.12.4
b268d000 b2691000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b2692000 b2784000 r-xp /usr/lib/libasound.so.2.0.0
b2788000 b27ad000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b27ae000 b27c2000 r-xp /usr/lib/libmmfsound.so.0.1.0
b27c3000 b28a3000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b28a8000 b2907000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b2908000 b2914000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2915000 b2928000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b2929000 b292c000 r-xp /usr/lib/libmm_ta.so.0.0.0
b292d000 b2944000 r-xp /usr/lib/libICE.so.6.3.0
b2947000 b294e000 r-xp /usr/lib/libSM.so.6.0.1
b294f000 b2950000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2951000 b295c000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b295d000 b2962000 r-xp /usr/lib/libsysman.so.0.2.0
b2963000 b296e000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2972000 b2976000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2977000 b29d4000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b29d6000 b29de000 r-xp /usr/lib/libxcb-render.so.0.0.0
b29df000 b29e1000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b29e2000 b2a45000 r-xp /usr/lib/libtiff.so.5.1.0
b2a48000 b2a9a000 r-xp /usr/lib/libturbojpeg.so
b2aab000 b2ab2000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2ab3000 b2abc000 r-xp /usr/lib/libgif.so.4.1.6
b2abd000 b2ae3000 r-xp /usr/lib/libavutil.so.51.73.101
b2aea000 b2b2f000 r-xp /usr/lib/libswscale.so.2.1.101
b2b30000 b2e95000 r-xp /usr/lib/libavcodec.so.54.59.100
b31b6000 b31dd000 r-xp /usr/lib/libpng12.so.0.50.0
b31de000 b31e5000 r-xp /usr/lib/libfeedback.so.0.1.4
b31e6000 b31f5000 r-xp /usr/lib/libtts.so
b31f6000 b320c000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b320d000 b3327000 r-xp /usr/lib/libcairo.so.2.11200.12
b332a000 b334e000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b334f000 b4135000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41a5000 b41ab000 r-xp /usr/lib/libslp_devman_plugin.so
b41ac000 b41ae000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41af000 b41b2000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41b3000 b41b7000 r-xp /usr/lib/libdevice-node.so.0.1
b41b8000 b41c6000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b41c7000 b41d0000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b41d1000 b41d7000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41d8000 b41da000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b41db000 b41df000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b41e0000 b41e7000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b41e8000 b41eb000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b41ec000 b41ed000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41ee000 b4201000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4203000 b420b000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b420c000 b423c000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b423d000 b4241000 r-xp /usr/lib/libuuid.so.1.3.0
b4242000 b4253000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4254000 b4255000 r-xp /usr/lib/libpmapi.so.1.2
b4256000 b4262000 r-xp /usr/lib/libminizip.so.1.0.0
b4263000 b4274000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4275000 b429d000 r-xp /usr/lib/libpcre.so.0.0.1
b429e000 b42a2000 r-xp /usr/lib/libheynoti.so.0.0.2
b42a3000 b42a8000 r-xp /usr/lib/libhaptic.so.0.1
b42a9000 b42aa000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42ab000 b42b2000 r-xp /usr/lib/libdevman.so.0.1
b42b3000 b42b9000 r-xp /usr/lib/libchromium.so.1.0
b42ba000 b42c2000 r-xp /usr/lib/libalarm.so.0.0.0
b42c3000 b42cc000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b42cd000 b42e5000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b42e6000 b4790000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b47b2000 b47bc000 r-xp /lib/libnss_files-2.13.so
b47be000 b47c7000 r-xp /lib/libnss_nis-2.13.so
b47c9000 b47dc000 r-xp /lib/libnsl-2.13.so
b47e0000 b47e6000 r-xp /lib/libnss_compat-2.13.so
b49e8000 b4a02000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a03000 b4b4c000 r-xp /usr/lib/libxml2.so.2.7.8
b4b52000 b4b78000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b79000 b4b7c000 r-xp /usr/lib/libiniparser.so.0
b4b7e000 b4be7000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4be9000 b4c05000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c06000 b4c0d000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c0e000 b4c11000 r-xp /usr/lib/libdri2.so.0.0.0
b4c12000 b4c1d000 r-xp /usr/lib/libdrm.so.2.4.0
b4c1e000 b4c23000 r-xp /usr/lib/libtbm.so.1.0.0
b4c24000 b4c28000 r-xp /usr/lib/libXv.so.1.0.0
b4c29000 b4d47000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d56000 b4d6b000 r-xp /usr/lib/libnotification.so.0.1.0
b4d6c000 b4d75000 r-xp /usr/lib/libutilX.so.1.1.0
b4d76000 b4da9000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4dab000 b4dbc000 r-xp /lib/libresolv-2.13.so
b4dc0000 b4dc3000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4dc4000 b4f29000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f2d000 b509d000 r-xp /usr/lib/libcrypto.so.1.0.0
b50b5000 b510b000 r-xp /usr/lib/libssl.so.1.0.0
b5110000 b513f000 r-xp /usr/lib/libidn.so.11.5.44
b5140000 b514f000 r-xp /usr/lib/libcares.so.2.0.0
b5150000 b5177000 r-xp /lib/libexpat.so.1.5.2
b5179000 b51ac000 r-xp /usr/lib/libicule.so.48.1
b51ad000 b51b8000 r-xp /usr/lib/libsf_common.so
b51b9000 b5295000 r-xp /usr/lib/libstdc++.so.6.0.14
b52a1000 b52a4000 r-xp /usr/lib/libapp-checker.so.0.1.0
b52a5000 b52ca000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b52cb000 b52d0000 r-xp /usr/lib/libffi.so.5.0.10
b52d1000 b52d2000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b52d3000 b5304000 r-xp /usr/lib/libexif.so.12.3.3
b5311000 b531d000 r-xp /usr/lib/libethumb.so.1.7.99
b531e000 b5382000 r-xp /usr/lib/libsndfile.so.1.0.25
b5388000 b538b000 r-xp /usr/lib/libctxdata.so.0.0.0
b538c000 b53a3000 r-xp /usr/lib/libremix.so.0.0.0
b53a4000 b53a6000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b53a7000 b53d4000 r-xp /usr/lib/liblua-5.1.so
b53d5000 b53df000 r-xp /usr/lib/libembryo.so.1.7.99
b53e0000 b53e3000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b53e4000 b5445000 r-xp /usr/lib/libcurl.so.4.3.0
b5447000 b544d000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b544e000 b545f000 r-xp /usr/lib/libXext.so.6.4.0
b5460000 b5465000 r-xp /usr/lib/libXtst.so.6.1.0
b5466000 b546e000 r-xp /usr/lib/libXrender.so.1.3.0
b546f000 b5478000 r-xp /usr/lib/libXrandr.so.2.2.0
b5479000 b547b000 r-xp /usr/lib/libXinerama.so.1.0.0
b547c000 b548a000 r-xp /usr/lib/libXi.so.6.1.0
b548b000 b548f000 r-xp /usr/lib/libXfixes.so.3.1.0
b5490000 b5492000 r-xp /usr/lib/libXgesture.so.7.0.0
b5493000 b5495000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5496000 b5498000 r-xp /usr/lib/libXdamage.so.1.1.0
b5499000 b54a3000 r-xp /usr/lib/libXcursor.so.1.0.2
b54a4000 b553b000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5540000 b5575000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5577000 b55fc000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5606000 b561c000 r-xp /usr/lib/libfribidi.so.0.3.1
b561d000 b56a2000 r-xp /usr/lib/libfreetype.so.6.8.1
b56a6000 b56ed000 r-xp /usr/lib/libjpeg.so.8.0.2
b56fe000 b571d000 r-xp /lib/libz.so.1.2.5
b571e000 b572a000 r-xp /usr/lib/libemotion.so.1.7.99
b572b000 b5731000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5733000 b5743000 r-xp /usr/lib/libsensor.so.1.1.0
b5746000 b574c000 r-xp /usr/lib/libappcore-common.so.1.1
b6855000 b69b0000 r-xp /usr/lib/libicuuc.so.48.1
b69be000 b6b9d000 r-xp /usr/lib/libicui18n.so.48.1
b6ba4000 b6ba7000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6ba8000 b6bb4000 r-xp /usr/lib/libvconf.so.0.2.45
b6bb5000 b6bbe000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6bbf000 b6bd0000 r-xp /usr/lib/libail.so.0.1.0
b6bd1000 b6be1000 r-xp /usr/lib/libaul.so.0.1.0
b6be2000 b6c32000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c33000 b6c76000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c78000 b6cd3000 r-xp /usr/lib/libeina.so.1.7.99
b6cd5000 b6cf4000 r-xp /usr/lib/libecore.so.1.7.99
b6d03000 b6d2e000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d30000 b6d3b000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d3c000 b6d48000 r-xp /usr/lib/libedbus.so.1.7.99
b6d49000 b6d4c000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d4d000 b6d53000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d54000 b6d76000 r-xp /usr/lib/libefreet.so.1.7.99
b6d78000 b6e0f000 r-xp /usr/lib/libedje.so.1.7.99
b6e11000 b6e28000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e3c000 b6e43000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e44000 b6e71000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e73000 b6f7d000 r-xp /usr/lib/libevas.so.1.7.99
b6f98000 b6fb5000 r-xp /usr/lib/libeet.so.1.7.99
b6fb6000 b6fda000 r-xp /lib/libm-2.13.so
b6fdc000 b71ac000 r-xp /usr/lib/libelementary.so.1.7.99
b71b9000 b71c4000 r-xp /usr/lib/libcapi-web-favorites.so
b71c5000 b71c7000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b71ca000 b71ce000 r-xp /lib/libattr.so.1.1.0
b71cf000 b71d1000 r-xp /usr/lib/libXau.so.6.0.0
b71d3000 b71da000 r-xp /lib/librt-2.13.so
b71dc000 b71e4000 r-xp /lib/libcrypt-2.13.so
b720d000 b7210000 r-xp /lib/libcap.so.2.21
b7211000 b7213000 r-xp /usr/lib/libiri.so
b7214000 b722e000 r-xp /lib/libgcc_s-4.5.3.so.1
b722f000 b724f000 r-xp /usr/lib/libxcb.so.1.1.0
b7251000 b725a000 r-xp /lib/libunwind.so.8.0.1
b7264000 b73ba000 r-xp /lib/libc-2.13.so
b73c0000 b73c5000 r-xp /usr/lib/libsmack.so.1.0.0
b73c6000 b7412000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7413000 b7418000 r-xp /usr/lib/libbundle.so.0.1.22
b7419000 b741b000 r-xp /lib/libdl-2.13.so
b741e000 b7547000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7548000 b755d000 r-xp /lib/libpthread-2.13.so
b7562000 b7563000 r-xp /usr/lib/libdlog.so.0.0.0
b7564000 b760e000 r-xp /usr/lib/libsqlite3.so.0.8.6
b7611000 b761d000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b761e000 b7753000 r-xp /usr/lib/libX11.so.6.3.0
b7758000 b7760000 r-xp /usr/lib/libecore_imf.so.1.7.99
b7761000 b7766000 r-xp /usr/lib/libappcore-efl.so.1.1
b7768000 b776c000 r-xp /usr/lib/libsys-assert.so
b7770000 b7771000 r-xp [vdso]
b7771000 b778d000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:6848)
Call Stack Count: 22
 0: Tizen::Ui::_ControlImpl::OnDetachingFromMainTree() + 0x1a (0xb36639fa) [/usr/lib/osp/libosp-uifw.so] + 0x3149fa
 1: Tizen::Ui::Controls::_FormImpl::OnDetachingFromMainTree() + 0x32 (0xb3998ef2) [/usr/lib/osp/libosp-uifw.so] + 0x649ef2
 2: Tizen::Ui::_Control::CallOnDetachingFromMainTree(Tizen::Ui::_Control&) + 0x8f (0xb36402bf) [/usr/lib/osp/libosp-uifw.so] + 0x2f12bf
 3: Tizen::Ui::_Control::DetachChild(Tizen::Ui::_Control&) + 0x12c (0xb3647a3c) [/usr/lib/osp/libosp-uifw.so] + 0x2f8a3c
 4: Tizen::Ui::_Control::DetachAllChildren(bool, bool) + 0x177 (0xb3647d77) [/usr/lib/osp/libosp-uifw.so] + 0x2f8d77
 5: Tizen::Ui::_ContainerImpl::RemoveAllChildren(bool, bool) + 0x4e (0xb367c01e) [/usr/lib/osp/libosp-uifw.so] + 0x32d01e
 6: Tizen::Ui::_WindowImpl::Destroy() + 0x6f (0xb367e51f) [/usr/lib/osp/libosp-uifw.so] + 0x32f51f
 7: Tizen::App::_UiAppImpl::RemoveAllFrames() + 0x8a (0xb3d079ca) [/usr/lib/osp/libosp-uifw.so] + 0x9b89ca
 8: Tizen::App::_UiAppImpl::OnUiAppImplTerminating() + 0x27 (0xb3d07ff7) [/usr/lib/osp/libosp-uifw.so] + 0x9b8ff7
 9: Tizen::App::_UiAppImpl::OnTerminate() + 0x66 (0xb3d080c6) [/usr/lib/osp/libosp-uifw.so] + 0x9b90c6
10: Tizen::App::_AppImpl::OnTerminate(void*) + 0x65 (0xb43e9065) [/usr/lib/osp/libosp-appfw.so] + 0x103065
11: app_appcore_terminate + 0x2f (0xb41f294f) [/usr/lib/libcapi-appfw-application.so.0] + 0x494f
12: appcore_efl_main + 0x45c (0xb776431c) [/usr/lib/libappcore-efl.so.1] + 0x331c
13: app_efl_main + 0xe8 (0xb41f2d98) [/usr/lib/libcapi-appfw-application.so.0] + 0x4d98
14: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x122 (0xb43e9612) [/usr/lib/osp/libosp-appfw.so] + 0x103612
15: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3d05ea1) [/usr/lib/osp/libosp-uifw.so] + 0x9b6ea1
16: OspMain + 0x19f (0xb2550aef) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x36aef
17: main + 0x503 (0xb71c60c3) [/opt/apps/docomo6003/bin/MyHondana] + 0x10c3
18: __launchpad_main_loop + 0x1c17 (0x804bf97) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bf97
19: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
20: __libc_start_main + 0xe6 (0xb727ada6) [/lib/libc.so.6] + 0x16da6
21: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)

Latest Debug Message Information
--------- beginning of /dev/log_main
07-25 15:01:36.792 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:36.792 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:36.792 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:36.792 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:36.792 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:36.792 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:36.792 E/Tizen::Ui::Animations( 5738): result Tizen::Ui::Animations::_VisualElementImpl::SetImageSource(const Tizen::Base::String&)(994) > [E_SYSTEM] Realizing back-buffer surface failed.
07-25 15:01:38.382 E/Tizen::Ui( 5738): Tizen::Ui::_Control* Tizen::Ui::_Control::GetTopmostChildAt(const Tizen::Graphics::Point&) const(4351) > [E_SYSTEM] pHitTestElm is null.
07-25 15:01:38.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:38.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:38.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:38.382 E/Tizen::Ui( 5738): result Tizen::Ui::_MultiFingerInfo::SetFingerInfo(long unsigned int, const Tizen::Graphics::FloatPoint&, const Tizen::Graphics::FloatPoint&, Tizen::Ui::_TouchStatus)(533) > [E_INVALID_CONDITION] [E_INVALID_CONDITION] pFingerInfo is null
07-25 15:01:38.382 E/Tizen::Ui( 5738): void Tizen::Ui::_TouchManager::SetTouchCanceled(Tizen::Ui::_Control*)(850) > [E_SYSTEM] System error occurred.
07-25 15:01:38.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:38.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:38.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:39.442 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:39.442 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:39.442 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:39.442 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:39.442 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:39.442 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:39.442 E/Tizen::Ui::Animations( 5738): result Tizen::Ui::Animations::_VisualElementImpl::SetImageSource(const Tizen::Base::String&)(994) > [E_SYSTEM] Realizing back-buffer surface failed.
07-25 15:01:54.352 E/Tizen::Ui( 5738): Tizen::Ui::_Control* Tizen::Ui::_Control::GetTopmostChildAt(const Tizen::Graphics::Point&) const(4351) > [E_SYSTEM] pHitTestElm is null.
07-25 15:01:54.352 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:54.352 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:54.352 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:54.352 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:54.352 E/Tizen::Ui( 5738): result Tizen::Ui::_MultiFingerInfo::SetFingerInfo(long unsigned int, const Tizen::Graphics::FloatPoint&, const Tizen::Graphics::FloatPoint&, Tizen::Ui::_TouchStatus)(533) > [E_INVALID_CONDITION] [E_INVALID_CONDITION] pFingerInfo is null
07-25 15:01:54.352 E/Tizen::Ui( 5738): void Tizen::Ui::_TouchManager::SetTouchCanceled(Tizen::Ui::_Control*)(850) > [E_SYSTEM] System error occurred.
07-25 15:01:54.352 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:54.352 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:54.352 E/Tizen::Ui( 5738): result Tizen::Ui::_ControlImpl::Draw(bool)(3305) > [E_INVALID_OPERATION] The control should be attached to the main tree.
07-25 15:01:55.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:55.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:55.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:55.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:55.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:55.382 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:55.382 E/Tizen::Ui::Animations( 5738): result Tizen::Ui::Animations::_VisualElementImpl::SetImageSource(const Tizen::Base::String&)(994) > [E_SYSTEM] Realizing back-buffer surface failed.
07-25 15:01:57.992 E/Tizen::Ui( 5738): Tizen::Ui::_Control* Tizen::Ui::_Control::GetTopmostChildAt(const Tizen::Graphics::Point&) const(4351) > [E_SYSTEM] pHitTestElm is null.
07-25 15:01:57.992 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.002 E/Tizen::Ui( 5738): result Tizen::Ui::_MultiFingerInfo::SetFingerInfo(long unsigned int, const Tizen::Graphics::FloatPoint&, const Tizen::Graphics::FloatPoint&, Tizen::Ui::_TouchStatus)(533) > [E_INVALID_CONDITION] [E_INVALID_CONDITION] pFingerInfo is null
07-25 15:01:58.002 E/Tizen::Ui( 5738): void Tizen::Ui::_TouchManager::SetTouchCanceled(Tizen::Ui::_Control*)(850) > [E_SYSTEM] System error occurred.
07-25 15:01:58.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.002 E/Tizen::Ui( 5738): result Tizen::Ui::_ControlImpl::Draw(bool)(3305) > [E_INVALID_OPERATION] The control should be attached to the main tree.
07-25 15:01:58.862 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.862 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.862 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.862 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.862 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.862 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:01:58.882 E/Tizen::Ui::Animations( 5738): result Tizen::Ui::Animations::_VisualElementImpl::SetImageSource(const Tizen::Base::String&)(994) > [E_SYSTEM] Realizing back-buffer surface failed.
07-25 15:02:05.912 E/Tizen::Ui( 5738): Tizen::Ui::_Control* Tizen::Ui::_Control::GetTopmostChildAt(const Tizen::Graphics::Point&) const(4351) > [E_SYSTEM] pHitTestElm is null.
07-25 15:02:05.912 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:05.912 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:05.912 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:05.912 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:05.912 E/Tizen::Ui( 5738): result Tizen::Ui::_MultiFingerInfo::SetFingerInfo(long unsigned int, const Tizen::Graphics::FloatPoint&, const Tizen::Graphics::FloatPoint&, Tizen::Ui::_TouchStatus)(533) > [E_INVALID_CONDITION] [E_INVALID_CONDITION] pFingerInfo is null
07-25 15:02:05.912 E/Tizen::Ui( 5738): void Tizen::Ui::_TouchManager::SetTouchCanceled(Tizen::Ui::_Control*)(850) > [E_SYSTEM] System error occurred.
07-25 15:02:05.912 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:05.912 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:05.912 E/Tizen::Ui( 5738): result Tizen::Ui::_ControlImpl::Draw(bool)(3305) > [E_INVALID_OPERATION] The control should be attached to the main tree.
07-25 15:02:06.782 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:06.782 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:06.782 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:06.782 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:06.782 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:06.782 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:06.782 E/Tizen::Ui::Animations( 5738): result Tizen::Ui::Animations::_VisualElementImpl::SetImageSource(const Tizen::Base::String&)(994) > [E_SYSTEM] Realizing back-buffer surface failed.
07-25 15:02:09.002 E/Tizen::Ui( 5738): Tizen::Ui::_Control* Tizen::Ui::_Control::GetTopmostChildAt(const Tizen::Graphics::Point&) const(4351) > [E_SYSTEM] pHitTestElm is null.
07-25 15:02:09.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:09.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:09.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:09.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:09.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:09.002 E/Tizen::Ui( 5738): result Tizen::Ui::_MultiFingerInfo::SetFingerInfo(long unsigned int, const Tizen::Graphics::FloatPoint&, const Tizen::Graphics::FloatPoint&, Tizen::Ui::_TouchStatus)(533) > [E_INVALID_CONDITION] [E_INVALID_CONDITION] pFingerInfo is null
07-25 15:02:09.002 E/Tizen::Ui( 5738): void Tizen::Ui::_TouchManager::SetTouchCanceled(Tizen::Ui::_Control*)(850) > [E_SYSTEM] System error occurred.
07-25 15:02:09.002 E/Tizen::Ui( 5738): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 15:02:09.002 E/Tizen::Ui( 5738): result Tizen::Ui::_ControlImpl::Draw(bool)(3305) > [E_INVALID_OPERATION] The control should be attached to the main tree.
07-25 15:59:21.482 E/Tizen::Base::Collection( 2267): virtual result Tizen::Base::Collection::ArrayList::IndexOf(const Tizen::Base::Object&, int, int, int&) const(293) > [E_OBJ_NOT_FOUND] The arraylist is empty.
07-25 15:59:21.482 E/Tizen::Base::Collection( 2267): virtual result Tizen::Base::Collection::ArrayList::Remove(const Tizen::Base::Object&)(396) > [E_OBJ_NOT_FOUND] Propagating.
07-25 15:59:21.492 E/Tizen::Io( 2267): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-25 15:59:21.502 E/Tizen::Io( 2267): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-25 15:59:21.502 E/Tizen::Io( 2267): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-25 15:59:22.862 E/Tizen::Base( 6083): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-25 15:59:22.862 E/Tizen::Base::Runtime( 6083): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-25 15:59:22.872 E/Tizen::Base::Runtime( 6083): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-25 15:59:22.872 I/osp-installer( 6083): int main(int, char**)(71) >  # argv[0] = [/usr/etc/package-manager/backend/tpk]
07-25 15:59:22.872 I/osp-installer( 6083): int main(int, char**)(71) >  # argv[1] = [-k]
07-25 15:59:22.872 I/osp-installer( 6083): int main(int, char**)(71) >  # argv[2] = [docomo6003_-1864223038]
07-25 15:59:22.872 I/osp-installer( 6083): int main(int, char**)(71) >  # argv[3] = [-r]
07-25 15:59:22.872 I/osp-installer( 6083): int main(int, char**)(71) >  # argv[4] = [docomo6003]
07-25 15:59:22.872 I/osp-installer( 6083): int main(int, char**)(71) >  # argv[5] = [-q]
07-25 15:59:22.872 I/osp-installer( 6083): int main(int, char**)(115) >  # path = [docomo6003]
07-25 15:59:22.872 I/osp-installer( 6083): int main(int, char**)(213) > rdsPackage = docomo6003
07-25 15:59:22.872 I/osp-installer( 6083): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(141) > ------------------------------------------
07-25 15:59:22.872 I/osp-installer( 6083): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(142) > InstallerManager
07-25 15:59:22.872 I/osp-installer( 6083): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(143) > ------------------------------------------
07-25 15:59:22.872 I/osp-installer( 6083): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(144) >  # operation = [Reinstall]
07-25 15:59:22.872 I/osp-installer( 6083): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(145) >  # path      = [docomo6003]
07-25 15:59:22.872 I/osp-installer( 6083): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(146) > ------------------------------------------
07-25 15:59:22.872 I/osp-installer( 6083): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(230) > operation is INSTALLER_OPERATION_REINSTALL
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerManager::SendEvent(InstallationContext*, const Tizen::App::PackageId&, const Tizen::Base::String&, const Tizen::Base::String&)(956) > pkgmgr_installer_send_signal(tpk, docomo6003, start, install)
07-25 15:59:22.882 I/osp-installer( 6083): Installer* InstallerManager::CreateInstaller(InstallerType)(281) > InstallerType = [DirectoryInstaller]
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(840) > .rds_delta file
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(001)=[#delete]
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(002)=[#add]
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(003)=[res/screen-density-xhigh/popup_btn_sort_normal.#.png]
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(004)=[res/screen-density-xhigh/popup_btn_sort_select.#.png]
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(005)=[#modify]
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(006)=[author-signature.xml]
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(007)=[signature1.xml]
07-25 15:59:22.882 I/osp-installer( 6083): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(008)=[bin/MyHondana.exe]
0
End of latest debug message
