S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 3923
Date: 2013-07-25 21:19:57(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=3923 tid=3923
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 3923, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x09678ed8, esi = 0x0977e800
ebp = 0xbf872d58, esp = 0xbf872ccc
eax = 0x09799040, ebx = 0xb25ea9e8
ecx = 0x0980b9c8, edx = 0x00000000
eip = 0x00000011

Memory Information
MemTotal:   509368 KB
MemFree:      9256 KB
Buffers:     51860 KB
Cached:     244932 KB
VmPeak:     229776 KB
VmSize:     224480 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      102692 KB
VmRSS:      101212 KB
VmData:      83564 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100712 KB
VmPTE:         216 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
ac2e7000 ac2e9000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
afb19000 afb8c000 r-xp /usr/lib/host-gl/libGL.so.1.2
afbaf000 afbbd000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afbbe000 afbf5000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afbf9000 afbfb000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afbfc000 afc03000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc04000 afc11000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc12000 afc20000 r-xp /usr/lib/libudev.so.0.13.1
afc21000 afc63000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc64000 afcf0000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afcf6000 afd00000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afd01000 afd19000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd1a000 afd20000 r-xp /usr/lib/libmmffile.so.0.0.0
afd21000 afd29000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd2a000 afd2c000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd2d000 afd4e000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd4f000 afd51000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd52000 afd70000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd71000 afd77000 r-xp /usr/lib/libmemenv.so.1.1.0
afd78000 afdc1000 r-xp /usr/lib/libleveldb.so.1.1.0
afdc3000 afdce000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afdcf000 afe0b000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe0d000 afe22000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe23000 afe43000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe45000 afe7b000 r-xp /usr/lib/libxslt.so.1.1.16
afe7c000 afe84000 r-xp /usr/lib/libeeze.so.1.7.99
afe85000 afe8a000 r-xp /usr/lib/libeukit.so.1.7.99
afe8b000 afe95000 r-xp /usr/lib/libenchant.so.1.6.1
afe96000 afea0000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afea1000 afead000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afeae000 afedd000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afee3000 afee7000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afee8000 afef4000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afef6000 afefd000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afefe000 aff0d000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff0e000 aff11000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff12000 aff23000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff24000 aff53000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff54000 aff5a000 r-xp /usr/lib/libogg.so.0.7.1
aff5b000 aff86000 r-xp /usr/lib/libvorbis.so.0.4.3
aff87000 aff8c000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff8d000 aff91000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff92000 aff97000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff98000 affbd000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affbe000 affd8000 r-xp /usr/lib/libnetwork.so.0.0.0
affda000 b0006000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b0007000 b1ff2000 r-xp /usr/lib/libewebkit2.so.0.11.72
b20ec000 b2257000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b2263000 b22e7000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b22e9000 b2305000 r-xp /usr/lib/libwifi-direct.so.0.0
b2306000 b2311000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b2312000 b231d000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b231e000 b232c000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b232d000 b23cf000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b23d5000 b24e7000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b24ed000 b2512000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b2514000 b2541000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2549000 b254a000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b2553000 b25e7000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b25ec000 b261c000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b261d000 b2670000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2671000 b2677000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2678000 b267d000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b267e000 b26c6000 r-xp /usr/lib/libpulse.so.0.12.4
b26c7000 b26cb000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26cc000 b27be000 r-xp /usr/lib/libasound.so.2.0.0
b27c2000 b27e7000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b27e8000 b27fc000 r-xp /usr/lib/libmmfsound.so.0.1.0
b27fd000 b28dd000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b28e2000 b2941000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b2942000 b294e000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b294f000 b2962000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b2963000 b2966000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2967000 b297e000 r-xp /usr/lib/libICE.so.6.3.0
b2981000 b2988000 r-xp /usr/lib/libSM.so.6.0.1
b2989000 b298a000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b298b000 b2996000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2997000 b299c000 r-xp /usr/lib/libsysman.so.0.2.0
b299d000 b29a8000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b29ac000 b29b0000 r-xp /usr/lib/libmmfsession.so.0.0.0
b29b1000 b2a0e000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2a10000 b2a18000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2a19000 b2a1b000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2a1c000 b2a7f000 r-xp /usr/lib/libtiff.so.5.1.0
b2a82000 b2ad4000 r-xp /usr/lib/libturbojpeg.so
b2ae5000 b2aec000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2aed000 b2af6000 r-xp /usr/lib/libgif.so.4.1.6
b2af7000 b2b1d000 r-xp /usr/lib/libavutil.so.51.73.101
b2b24000 b2b69000 r-xp /usr/lib/libswscale.so.2.1.101
b2b6a000 b2ecf000 r-xp /usr/lib/libavcodec.so.54.59.100
b31f0000 b3217000 r-xp /usr/lib/libpng12.so.0.50.0
b3218000 b321f000 r-xp /usr/lib/libfeedback.so.0.1.4
b3220000 b322f000 r-xp /usr/lib/libtts.so
b3230000 b3246000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b3247000 b3361000 r-xp /usr/lib/libcairo.so.2.11200.12
b3364000 b3388000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3389000 b416f000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41df000 b41e5000 r-xp /usr/lib/libslp_devman_plugin.so
b41e6000 b41e8000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41e9000 b41ec000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41ed000 b41f1000 r-xp /usr/lib/libdevice-node.so.0.1
b41f2000 b4200000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4201000 b420a000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b420b000 b4211000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b4212000 b4214000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4215000 b4219000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b421a000 b4221000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4222000 b4225000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b4226000 b4227000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4228000 b423b000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b423d000 b4245000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4246000 b4276000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4277000 b427b000 r-xp /usr/lib/libuuid.so.1.3.0
b427c000 b428d000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b428e000 b428f000 r-xp /usr/lib/libpmapi.so.1.2
b4290000 b429c000 r-xp /usr/lib/libminizip.so.1.0.0
b429d000 b42ae000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42af000 b42d7000 r-xp /usr/lib/libpcre.so.0.0.1
b42d8000 b42dc000 r-xp /usr/lib/libheynoti.so.0.0.2
b42dd000 b42e2000 r-xp /usr/lib/libhaptic.so.0.1
b42e3000 b42e4000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42e5000 b42ec000 r-xp /usr/lib/libdevman.so.0.1
b42ed000 b42f3000 r-xp /usr/lib/libchromium.so.1.0
b42f4000 b42fc000 r-xp /usr/lib/libalarm.so.0.0.0
b42fd000 b4306000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b4307000 b431f000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4320000 b47ca000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b47ec000 b47f6000 r-xp /lib/libnss_files-2.13.so
b47f8000 b4801000 r-xp /lib/libnss_nis-2.13.so
b4803000 b4816000 r-xp /lib/libnsl-2.13.so
b481a000 b4820000 r-xp /lib/libnss_compat-2.13.so
b4a22000 b4a3c000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a3d000 b4b86000 r-xp /usr/lib/libxml2.so.2.7.8
b4b8c000 b4bb2000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4bb3000 b4bb6000 r-xp /usr/lib/libiniparser.so.0
b4bb8000 b4c21000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c23000 b4c3f000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c40000 b4c47000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c48000 b4c4b000 r-xp /usr/lib/libdri2.so.0.0.0
b4c4c000 b4c57000 r-xp /usr/lib/libdrm.so.2.4.0
b4c58000 b4c5d000 r-xp /usr/lib/libtbm.so.1.0.0
b4c5e000 b4c62000 r-xp /usr/lib/libXv.so.1.0.0
b4c63000 b4d81000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d90000 b4da5000 r-xp /usr/lib/libnotification.so.0.1.0
b4da6000 b4daf000 r-xp /usr/lib/libutilX.so.1.1.0
b4db0000 b4de3000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4de5000 b4df6000 r-xp /lib/libresolv-2.13.so
b4dfa000 b4dfd000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4dfe000 b4f63000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f67000 b50d7000 r-xp /usr/lib/libcrypto.so.1.0.0
b50ef000 b5145000 r-xp /usr/lib/libssl.so.1.0.0
b514a000 b5179000 r-xp /usr/lib/libidn.so.11.5.44
b517a000 b5189000 r-xp /usr/lib/libcares.so.2.0.0
b518a000 b51b1000 r-xp /lib/libexpat.so.1.5.2
b51b3000 b51e6000 r-xp /usr/lib/libicule.so.48.1
b51e7000 b51f2000 r-xp /usr/lib/libsf_common.so
b51f3000 b52cf000 r-xp /usr/lib/libstdc++.so.6.0.14
b52db000 b52de000 r-xp /usr/lib/libapp-checker.so.0.1.0
b52df000 b5304000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5305000 b530a000 r-xp /usr/lib/libffi.so.5.0.10
b530b000 b530c000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b530d000 b533e000 r-xp /usr/lib/libexif.so.12.3.3
b534b000 b5357000 r-xp /usr/lib/libethumb.so.1.7.99
b5358000 b53bc000 r-xp /usr/lib/libsndfile.so.1.0.25
b53c2000 b53c5000 r-xp /usr/lib/libctxdata.so.0.0.0
b53c6000 b53dd000 r-xp /usr/lib/libremix.so.0.0.0
b53de000 b53e0000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b53e1000 b540e000 r-xp /usr/lib/liblua-5.1.so
b540f000 b5419000 r-xp /usr/lib/libembryo.so.1.7.99
b541a000 b541d000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b541e000 b547f000 r-xp /usr/lib/libcurl.so.4.3.0
b5481000 b5487000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5488000 b5499000 r-xp /usr/lib/libXext.so.6.4.0
b549a000 b549f000 r-xp /usr/lib/libXtst.so.6.1.0
b54a0000 b54a8000 r-xp /usr/lib/libXrender.so.1.3.0
b54a9000 b54b2000 r-xp /usr/lib/libXrandr.so.2.2.0
b54b3000 b54b5000 r-xp /usr/lib/libXinerama.so.1.0.0
b54b6000 b54c4000 r-xp /usr/lib/libXi.so.6.1.0
b54c5000 b54c9000 r-xp /usr/lib/libXfixes.so.3.1.0
b54ca000 b54cc000 r-xp /usr/lib/libXgesture.so.7.0.0
b54cd000 b54cf000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54d0000 b54d2000 r-xp /usr/lib/libXdamage.so.1.1.0
b54d3000 b54dd000 r-xp /usr/lib/libXcursor.so.1.0.2
b54de000 b5575000 r-xp /usr/lib/libpixman-1.so.0.28.2
b557a000 b55af000 r-xp /usr/lib/libfontconfig.so.1.5.0
b55b1000 b5636000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5640000 b5656000 r-xp /usr/lib/libfribidi.so.0.3.1
b5657000 b56dc000 r-xp /usr/lib/libfreetype.so.6.8.1
b56e0000 b5727000 r-xp /usr/lib/libjpeg.so.8.0.2
b5738000 b5757000 r-xp /lib/libz.so.1.2.5
b5758000 b5764000 r-xp /usr/lib/libemotion.so.1.7.99
b5765000 b576b000 r-xp /usr/lib/libecore_fb.so.1.7.99
b576d000 b577d000 r-xp /usr/lib/libsensor.so.1.1.0
b5780000 b5786000 r-xp /usr/lib/libappcore-common.so.1.1
b688f000 b69ea000 r-xp /usr/lib/libicuuc.so.48.1
b69f8000 b6bd7000 r-xp /usr/lib/libicui18n.so.48.1
b6bde000 b6be1000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6be2000 b6bee000 r-xp /usr/lib/libvconf.so.0.2.45
b6bef000 b6bf8000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6bf9000 b6c0a000 r-xp /usr/lib/libail.so.0.1.0
b6c0b000 b6c1b000 r-xp /usr/lib/libaul.so.0.1.0
b6c1c000 b6c6c000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c6d000 b6cb0000 r-xp /usr/lib/libecore_x.so.1.7.99
b6cb2000 b6d0d000 r-xp /usr/lib/libeina.so.1.7.99
b6d0f000 b6d2e000 r-xp /usr/lib/libecore.so.1.7.99
b6d3d000 b6d68000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d6a000 b6d75000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d76000 b6d82000 r-xp /usr/lib/libedbus.so.1.7.99
b6d83000 b6d86000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d87000 b6d8d000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d8e000 b6db0000 r-xp /usr/lib/libefreet.so.1.7.99
b6db2000 b6e49000 r-xp /usr/lib/libedje.so.1.7.99
b6e4b000 b6e62000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e76000 b6e7d000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e7e000 b6eab000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6ead000 b6fb7000 r-xp /usr/lib/libevas.so.1.7.99
b6fd2000 b6fef000 r-xp /usr/lib/libeet.so.1.7.99
b6ff0000 b7014000 r-xp /lib/libm-2.13.so
b7016000 b71e6000 r-xp /usr/lib/libelementary.so.1.7.99
b71f3000 b71fe000 r-xp /usr/lib/libcapi-web-favorites.so
b71ff000 b7201000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7204000 b7208000 r-xp /lib/libattr.so.1.1.0
b7209000 b720b000 r-xp /usr/lib/libXau.so.6.0.0
b720d000 b7214000 r-xp /lib/librt-2.13.so
b7216000 b721e000 r-xp /lib/libcrypt-2.13.so
b7247000 b724a000 r-xp /lib/libcap.so.2.21
b724b000 b724d000 r-xp /usr/lib/libiri.so
b724e000 b7268000 r-xp /lib/libgcc_s-4.5.3.so.1
b7269000 b7289000 r-xp /usr/lib/libxcb.so.1.1.0
b728b000 b7294000 r-xp /lib/libunwind.so.8.0.1
b729e000 b73f4000 r-xp /lib/libc-2.13.so
b73fa000 b73ff000 r-xp /usr/lib/libsmack.so.1.0.0
b7400000 b744c000 r-xp /usr/lib/libdbus-1.so.3.7.2
b744d000 b7452000 r-xp /usr/lib/libbundle.so.0.1.22
b7453000 b7455000 r-xp /lib/libdl-2.13.so
b7458000 b7581000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7582000 b7597000 r-xp /lib/libpthread-2.13.so
b759c000 b759d000 r-xp /usr/lib/libdlog.so.0.0.0
b759e000 b7648000 r-xp /usr/lib/libsqlite3.so.0.8.6
b764b000 b7657000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b7658000 b778d000 r-xp /usr/lib/libX11.so.6.3.0
b7792000 b779a000 r-xp /usr/lib/libecore_imf.so.1.7.99
b779b000 b77a0000 r-xp /usr/lib/libappcore-efl.so.1.1
b77a2000 b77a6000 r-xp /usr/lib/libsys-assert.so
b77aa000 b77ab000 r-xp [vdso]
b77ab000 b77c7000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:3923)
Call Stack Count: 22
 0: Tizen::Ui::_ControlImpl::OnDetachingFromMainTree() + 0x1a (0xb369d9fa) [/usr/lib/osp/libosp-uifw.so] + 0x3149fa
 1: Tizen::Ui::Controls::_FormImpl::OnDetachingFromMainTree() + 0x32 (0xb39d2ef2) [/usr/lib/osp/libosp-uifw.so] + 0x649ef2
 2: Tizen::Ui::_Control::CallOnDetachingFromMainTree(Tizen::Ui::_Control&) + 0x8f (0xb367a2bf) [/usr/lib/osp/libosp-uifw.so] + 0x2f12bf
 3: Tizen::Ui::_Control::DetachChild(Tizen::Ui::_Control&) + 0x12c (0xb3681a3c) [/usr/lib/osp/libosp-uifw.so] + 0x2f8a3c
 4: Tizen::Ui::_Control::DetachAllChildren(bool, bool) + 0x177 (0xb3681d77) [/usr/lib/osp/libosp-uifw.so] + 0x2f8d77
 5: Tizen::Ui::_ContainerImpl::RemoveAllChildren(bool, bool) + 0x4e (0xb36b601e) [/usr/lib/osp/libosp-uifw.so] + 0x32d01e
 6: Tizen::Ui::_WindowImpl::Destroy() + 0x6f (0xb36b851f) [/usr/lib/osp/libosp-uifw.so] + 0x32f51f
 7: Tizen::App::_UiAppImpl::RemoveAllFrames() + 0x8a (0xb3d419ca) [/usr/lib/osp/libosp-uifw.so] + 0x9b89ca
 8: Tizen::App::_UiAppImpl::OnUiAppImplTerminating() + 0x27 (0xb3d41ff7) [/usr/lib/osp/libosp-uifw.so] + 0x9b8ff7
 9: Tizen::App::_UiAppImpl::OnTerminate() + 0x66 (0xb3d420c6) [/usr/lib/osp/libosp-uifw.so] + 0x9b90c6
10: Tizen::App::_AppImpl::OnTerminate(void*) + 0x65 (0xb4423065) [/usr/lib/osp/libosp-appfw.so] + 0x103065
11: app_appcore_terminate + 0x2f (0xb422c94f) [/usr/lib/libcapi-appfw-application.so.0] + 0x494f
12: appcore_efl_main + 0x45c (0xb779e31c) [/usr/lib/libappcore-efl.so.1] + 0x331c
13: app_efl_main + 0xe8 (0xb422cd98) [/usr/lib/libcapi-appfw-application.so.0] + 0x4d98
14: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x122 (0xb4423612) [/usr/lib/osp/libosp-appfw.so] + 0x103612
15: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3d3fea1) [/usr/lib/osp/libosp-uifw.so] + 0x9b6ea1
16: OspMain + 0x19f (0xb2589baf) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x36baf
17: main + 0x503 (0xb72000c3) [/opt/apps/docomo6003/bin/MyHondana] + 0x10c3
18: __launchpad_main_loop + 0x1c17 (0x804bf97) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bf97
19: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
20: __libc_start_main + 0xe6 (0xb72b4da6) [/lib/libc.so.6] + 0x16da6
21: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)

Latest Debug Message Information
--------- beginning of /dev/log_main
07-25 20:15:38.862 E/Tizen::Ui( 2567): void Tizen::Ui::_TouchManager::SetTouchCanceled(Tizen::Ui::_Control*)(850) > [E_SYSTEM] System error occurred.
07-25 20:15:38.862 E/Tizen::Ui( 2567): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 20:15:38.862 E/Tizen::Ui( 2567): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 20:15:39.842 E/Tizen::Ui( 2567): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 20:15:39.842 E/Tizen::Ui( 2567): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 20:15:39.842 E/Tizen::Ui( 2567): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 20:15:39.842 E/Tizen::Ui( 2567): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 20:15:39.842 E/Tizen::Ui( 2567): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 20:15:39.842 E/Tizen::Ui( 2567): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-25 20:15:39.842 E/Tizen::Ui::Animations( 2567): result Tizen::Ui::Animations::_VisualElementImpl::SetImageSource(const Tizen::Base::String&)(994) > [E_SYSTEM] Realizing back-buffer surface failed.
07-25 21:00:07.432 E/Tizen::Base::Collection( 2216): virtual result Tizen::Base::Collection::ArrayList::IndexOf(const Tizen::Base::Object&, int, int, int&) const(293) > [E_OBJ_NOT_FOUND] The arraylist is empty.
07-25 21:00:07.432 E/Tizen::Base::Collection( 2216): virtual result Tizen::Base::Collection::ArrayList::Remove(const Tizen::Base::Object&)(396) > [E_OBJ_NOT_FOUND] Propagating.
07-25 21:00:07.442 E/Tizen::Io( 2216): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-25 21:00:07.442 E/Tizen::Io( 2216): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-25 21:00:07.442 E/Tizen::Io( 2216): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-25 21:00:08.502 E/Tizen::Base( 2798): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-25 21:00:08.502 E/Tizen::Base::Runtime( 2798): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-25 21:00:08.502 E/Tizen::Base::Runtime( 2798): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-25 21:00:08.502 I/osp-installer( 2798): int main(int, char**)(71) >  # argv[0] = [/usr/etc/package-manager/backend/tpk]
07-25 21:00:08.502 I/osp-installer( 2798): int main(int, char**)(71) >  # argv[1] = [-k]
07-25 21:00:08.502 I/osp-installer( 2798): int main(int, char**)(71) >  # argv[2] = [docomo6003_-998452972]
07-25 21:00:08.502 I/osp-installer( 2798): int main(int, char**)(71) >  # argv[3] = [-r]
07-25 21:00:08.502 I/osp-installer( 2798): int main(int, char**)(71) >  # argv[4] = [docomo6003]
07-25 21:00:08.502 I/osp-installer( 2798): int main(int, char**)(71) >  # argv[5] = [-q]
07-25 21:00:08.522 I/osp-installer( 2798): int main(int, char**)(115) >  # path = [docomo6003]
07-25 21:00:08.522 I/osp-installer( 2798): int main(int, char**)(213) > rdsPackage = docomo6003
07-25 21:00:08.522 I/osp-installer( 2798): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(141) > ------------------------------------------
07-25 21:00:08.522 I/osp-installer( 2798): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(142) > InstallerManager
07-25 21:00:08.522 I/osp-installer( 2798): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(143) > ------------------------------------------
07-25 21:00:08.522 I/osp-installer( 2798): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(144) >  # operation = [Reinstall]
07-25 21:00:08.522 I/osp-installer( 2798): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(145) >  # path      = [docomo6003]
07-25 21:00:08.522 I/osp-installer( 2798): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(146) > ------------------------------------------
07-25 21:00:08.522 I/osp-installer( 2798): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(230) > operation is INSTALLER_OPERATION_REINSTALL
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerManager::SendEvent(InstallationContext*, const Tizen::App::PackageId&, const Tizen::Base::String&, const Tizen::Base::String&)(956) > pkgmgr_installer_send_signal(tpk, docomo6003, start, install)
07-25 21:00:08.522 I/osp-installer( 2798): Installer* InstallerManager::CreateInstaller(InstallerType)(281) > InstallerType = [DirectoryInstaller]
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(840) > .rds_delta file
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(001)=[#delete]
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(002)=[#add]
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(003)=[#modify]
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(004)=[author-signature.xml]
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(005)=[signature1.xml]
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerUtil::GetRdsList(const Tizen::App::PackageId&, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*, Tizen::Base::Collection::IList*)(876) > .rds_delta: line(006)=[bin/MyHondana.exe]
07-25 21:00:08.522 I/osp-installer( 2798): bool PermissionManager::CopyForRds(InstallationContext*, Tizen::Base::Collection::IList*, bool&)(293) > copy file from[/opt/usr/apps/tmp/docomo6003/author-signature.xml] to[/opt/apps/docomo6003/author-signature.xml]
07-25 21:00:08.522 I/osp-installer( 2798): static bool InstallerUtil::Remove(const Tizen::Base::String&)(94) > Remove(): file=[/opt/apps/docomo6003/author-signature.xml]
07-25 21:00:08.532 I/osp-installer( 2798): bool PermissionManager::CopyForRds(InstallationContext*, Tizen::Base::Collection::IList*, bool&)(293) > copy file from[/opt/usr/apps/tmp/docomo6003/signature1.xml] to[/opt/apps/docomo6003/signature1.xml]
07-25 21:00:08.532 I/osp-installer( 2798): static bool InstallerUtil::Remove(const Tizen::Base::String&)(94) > Remove(): file=[/opt/apps/docomo6003/signature1.xml]
07-25 21:00:08.532 I/osp-installer( 2798): bool PermissionManager::CopyForRds(InstallationContext*, Tizen::Base::Collection::IList*, bool&)(293) > copy file from[/opt/usr/apps/tmp/docomo6003/bin/MyHondana.exe] to[/opt/apps/docomo6003/bin/MyHondana.exe]
07-25 21:00:08.532 I/osp-installer( 2798): static bool InstallerUtil::Remove(const Tizen::Base::String&)(94) > Remove(): file=[/opt/apps/docomo6003/bin/MyHondana.exe]
07-25 21:00:08.562 I/osp-installer( 2798): bool SmackManager::IsSmackEnable()(470) > [smack is on.]
07-25 21:00:08.562 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(570) > [smack] app_label_dir(_, /opt/apps/docomo6003)
07-25 21:00:08.562 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(572) > [smack] app_label_dir(_, /opt/apps/docomo6003), result = [0]
07-25 21:00:08.562 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.562 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/bin], mode=[0755], appOwner=[false]
07-25 21:00:08.562 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(570) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/bin)
07-25 21:00:08.562 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(572) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/bin), result = [0]
07-25 21:00:08.562 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.562 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/info], mode=[0644], appOwner=[false]
07-25 21:00:08.562 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(570) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/info)
07-25 21:00:08.562 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(572) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/info), result = [0]
07-25 21:00:08.572 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.572 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/res/screen-density-xhigh], mode=[0644], appOwner=[false]
07-25 21:00:08.572 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.572 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/res/screen-size-normal], mode=[0644], appOwner=[false]
07-25 21:00:08.572 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.572 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/res], mode=[0644], appOwner=[false]
07-25 21:00:08.572 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(570) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/res)
07-25 21:00:08.582 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(572) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/res), result = [0]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/lib], mode=[0755], appOwner=[false]
07-25 21:00:08.582 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(570) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/lib)
07-25 21:00:08.582 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(572) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/lib), result = [0]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared/res/screen-density-xhigh], mode=[0644], appOwner=[false]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared/res], mode=[0644], appOwner=[false]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared/trusted], mode=[0644], appOwner=[false]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared/data], mode=[0644], appOwner=[false]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared], mode=[0644], appOwner=[false]
07-25 21:00:08.582 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(570) > [smack] app_label_dir(*, /opt/apps/docomo6003/shared)
07-25 21:00:08.582 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(572) > [smack] app_label_dir(*, /opt/apps/docomo6003/shared), result = [0]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared/res/screen-density-xhigh], mode=[0644], appOwner=[false]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared/res], mode=[0644], appOwner=[false]
07-25 21:00:08.582 I/osp-installer( 2798): bool SmackManager::AddLabelSharedDir(const Tizen::App::PackageId&, const Tizen::Base::String&)(262) > Invalid Directory = [/opt/apps/docomo6003/shared/res]
07-25 21:00:08.582 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.582 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared/data], mode=[0644], appOwner=[true]
07-25 21:00:08.582 I/osp-installer( 2798): int SmackManager::AddLabelSharedDir(const char*, const char*, const char*)(603) > [smack] app_label_shared_dir(docomo6003, *, /opt/apps/docomo6003/shared/data)
07-25 21:00:08.592 I/osp-installer( 2798): int SmackManager::AddLabelSharedDir(const char*, const char*, const char*)(605) > [smack] app_label_shared_dir(docomo6003, *, /opt/apps/docomo6003/shared/data), result = [0]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/shared/trusted], mode=[0644], appOwner=[true]
07-25 21:00:08.592 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(570) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/shared/trusted)
07-25 21:00:08.592 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(572) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/shared/trusted), result = [0]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/setting], mode=[0666], appOwner=[false]
07-25 21:00:08.592 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(570) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/setting)
07-25 21:00:08.592 I/osp-installer( 2798): int SmackManager::AddLabelDir(const char*, const char*)(572) > [smack] app_label_dir(docomo6003, /opt/apps/docomo6003/setting), result = [0]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/data/files/files/thumbnail], mode=[0644], appOwner=[true]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/data/files/files], mode=[0644], appOwner=[true]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/data/files], mode=[0644], appOwner=[true]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/data/.webkit/iconDatabase], mode=[0644], appOwner=[true]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/data/.webkit/soupData/cache], mode=[0644], appOwner=[true]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps/docomo6003/data/.webkit/soupData/cookie], mode=[0644], appOwner=[true]
07-25 21:00:08.592 E/Tizen::Io( 2798): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-25 21:00:08.592 I/osp-installer( 2798): static bool InstallerUtil::ChangeDirectoryPermission(const Tizen::Base::String&, int, bool)(376) > path=[/opt/apps
End of latest debug message
