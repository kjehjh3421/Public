S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG4
Build-Date: 2013.07.22 22:21:22

Crash Information
Process Name: MyHondana
PID: 16686
Date: 2013-07-25 23:13:21(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=16686 tid=16686
Signal: 6
      (SIGABRT)
      si_code: -6
      signal sent by tkill (sent by pid 16686, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0x0000412e
r2   = 0x00000006, r3   = 0x0000412e
r4   = 0x00000006, r5   = 0xb6cacbe4
r6   = 0xb6cac000, r7   = 0x0000010c
r8   = 0x00000be4, r9   = 0xbed7a974
r10  = 0xb6fe8000, fp   = 0xbed7a668
ip   = 0xb6fe84c0, sp   = 0xbed79c68
lr   = 0xb6bb355c, pc   = 0xb6baf760
cpsr = 0x280f0010

Memory Information
MemTotal:  2063780 KB
MemFree:   1029192 KB
Buffers:     72612 KB
Cached:     556436 KB
VmPeak:     135944 KB
VmSize:     127968 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       35160 KB
VmRSS:       35160 KB
VmData:      26648 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       66912 KB
VmPTE:         112 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00071000 rw-p [heap]
00071000 0039f000 rw-p [heap]
af962000 b0161000 rwxp [stack:16700]
b0565000 b0569000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b0572000 b0d71000 rwxp [stack:16688]
b0d71000 b0d77000 r-xp /usr/lib/libUMP.so
b0d7f000 b0ecd000 r-xp /usr/lib/r3p2/libMali.so
b0ed9000 b0f02000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0f0e000 b0f2c000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b1266000 b12b2000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b12bb000 b12c0000 r-xp /usr/lib/libjson.so.0.0.1
b12c8000 b12cc000 r-xp /usr/lib/liblocation-pos-log.so
b12d4000 b12e6000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b12ee000 b12f0000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b12f8000 b12fd000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b1305000 b1310000 r-xp /usr/lib/libdrm-trusted.so.0.0.54
b1318000 b131a000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b1322000 b132f000 r-xp /usr/lib/libdrm-client.so.0.0.91
b1338000 b1340000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b1362000 b1399000 r-xp /usr/lib/libpulse.so.0.16.2
b13a1000 b1405000 r-xp /usr/lib/libasound.so.2.0.0
b140f000 b1412000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b141b000 b141f000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b1428000 b1443000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b144c000 b1451000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b1459000 b1486000 r-xp /usr/lib/libSLP-location.so.0.0.0
b148f000 b1497000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b1498000 b149c000 r-xp /usr/lib/libmmffile.so.0.0.0
b14a4000 b14ac000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b14ad000 b14c6000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b14cf000 b14ea000 r-xp /usr/lib/libmedia-service.so.1.0.0
b14f2000 b14fd000 r-xp /usr/lib/libmdm-common.so.1.0.38
b1505000 b1511000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b1519000 b1520000 r-xp /usr/lib/libenchant.so.1.6.1
b1528000 b152b000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b1534000 b153d000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b1546000 b154a000 r-xp /usr/lib/libmmfsession.so.0.0.0
b1553000 b1562000 r-xp /usr/lib/libmmfsound.so.0.1.0
b156a000 b156f000 r-xp /usr/lib/libmemenv.so.1.1.0
b1577000 b15b5000 r-xp /usr/lib/libleveldb.so.1.1.0
b15be000 b15e8000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b15f1000 b15f3000 r-xp /usr/lib/libsecfw.so
b15fb000 b1604000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b160f000 b161e000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b1626000 b163e000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b1640000 b164d000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b1656000 b165f000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b1667000 b16aa000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b16b2000 b174e000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b175a000 b177f000 r-xp /usr/lib/libxslt.so.1.1.16
b1788000 b178a000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b1792000 b179a000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b17a2000 b17ae000 r-xp /usr/lib/libcapi-location-manager.so.0.1.14
b17b6000 b17b9000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b17c1000 b17c6000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b17ce000 b17f5000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.71
b17fd000 b1816000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.1
b181e000 b185c000 r-xp /usr/lib/libmdm.so.1.0.67
b1864000 b1879000 r-xp /usr/lib/libnetwork.so.0.0.0
b1881000 b188a000 r-xp /usr/lib/libcapi-web-favorites.so
b1892000 b2af2000 r-xp /usr/lib/libewebkit2.so.0.10.154.1
b2be5000 b2c38000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2c41000 b2c58000 r-xp /usr/lib/libwifi-direct.so.0.0
b2c60000 b2c68000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.10
b2c70000 b2c79000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2c82000 b2c8d000 r-xp /usr/lib/libcapi-network-connection.so.0.1.13
b2c95000 b2d01000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2d0f000 b2dc4000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2dd1000 b2deb000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2df4000 b2e12000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2e21000 b2e2b000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b2e33000 b2ea3000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2eaf000 b2f2b000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2f33000 b2fc3000 r-xp /usr/lib/libCOREGL.so.3.0
b2fcd000 b2fd0000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2fd8000 b2fdf000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2fe8000 b2ff7000 r-xp /usr/lib/libICE.so.6.3.0
b3001000 b3006000 r-xp /usr/lib/libSM.so.6.0.1
b300e000 b300f000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b3017000 b3019000 r-xp /usr/lib/libledplayer.so.0.1
b3021000 b3027000 r-xp /usr/lib/libxcb-render.so.0.0.0
b302f000 b3030000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b3039000 b3040000 r-xp /usr/lib/libGLESv2.so.2.0
b3048000 b308f000 r-xp /usr/lib/libtiff.so.5.1.0
b309a000 b30c3000 r-xp /usr/lib/libturbojpeg.so
b30dc000 b30e0000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b30e9000 b30ef000 r-xp /usr/lib/libgif.so.4.1.6
b30f7000 b3119000 r-xp /usr/lib/libavutil.so.51.73.101
b3128000 b3156000 r-xp /usr/lib/libswscale.so.2.1.101
b315f000 b3456000 r-xp /usr/lib/libavcodec.so.54.59.100
b377d000 b3796000 r-xp /usr/lib/libpng12.so.0.50.0
b379f000 b37a6000 r-xp /usr/lib/libfeedback.so.0.1.4
b37af000 b37c3000 r-xp /usr/lib/libtts.so
b37cb000 b37cd000 r-xp /usr/lib/libEGL.so.1.4
b37d5000 b388c000 r-xp /usr/lib/libcairo.so.2.11200.12
b3896000 b38af000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b38b9000 b38bd000 r-xp /usr/lib/libss-client.so.1.0.0
b38c6000 b38c8000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b38d0000 b4193000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4204000 b420d000 r-xp /usr/lib/libslp_devman_plugin.so
b4216000 b4218000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4220000 b4223000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b422b000 b4231000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4239000 b423c000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b4244000 b4251000 r-xp /usr/lib/libmodem.so.0.0.0
b4259000 b425c000 r-xp /usr/lib/libdevice-node.so.0.1
b4264000 b4274000 r-xp /usr/lib/libaccounts-svc.so.0.2.71
b427c000 b427f000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b4287000 b428b000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4293000 b4299000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b42a1000 b42a2000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b42ab000 b42ae000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b42b6000 b42b9000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b42c2000 b42c5000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b42cd000 b42ce000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b42d6000 b42e4000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b42ed000 b4312000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b431a000 b431d000 r-xp /usr/lib/libuuid.so.1.3.0
b4326000 b433a000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4343000 b434b000 r-xp /usr/lib/libminizip.so.1.0.0
b4353000 b435f000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4368000 b4386000 r-xp /usr/lib/libpcre.so.0.0.1
b438e000 b4392000 r-xp /usr/lib/libheynoti.so.0.0.2
b439a000 b43a8000 r-xp /usr/lib/libdeviced.so.0.1.0
b43b0000 b43bb000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b43c8000 b43ce000 r-xp /usr/lib/libdevman.so.0.1
b43d6000 b43da000 r-xp /usr/lib/libchromium.so.1.0
b43e2000 b43e9000 r-xp /usr/lib/libalarm.so.0.0.0
b43f1000 b43fb000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b4404000 b4717000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4740000 b474a000 r-xp /lib/libnss_files-2.13.so
b475a000 b476a000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b476b000 b477f000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4787000 b47a4000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b47ac000 b47af000 r-xp /usr/lib/libiniparser.so.0
b47b8000 b480b000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4815000 b4829000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b4832000 b4834000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b483d000 b484e000 r-xp /usr/lib/libcom-core.so.0.0.1
b4856000 b485c000 r-xp /usr/lib/libappsvc.so.0.1.0
b4864000 b4866000 r-xp /usr/lib/libdri2.so.0.0.0
b486e000 b4876000 r-xp /usr/lib/libdrm.so.2.4.0
b487e000 b4882000 r-xp /usr/lib/libtbm.so.1.0.0
b488a000 b488d000 r-xp /usr/lib/libXv.so.1.0.0
b4895000 b48a9000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b48b1000 b497d000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4993000 b49a2000 r-xp /usr/lib/libnotification.so.0.1.0
b49aa000 b49ce000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b49d8000 b49e8000 r-xp /lib/libresolv-2.13.so
b49ec000 b49ee000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b49f6000 b4ace000 r-xp /usr/lib/libxml2.so.2.7.8
b4adb000 b4bb8000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4bc3000 b4bc8000 r-xp /usr/lib/libcheck.so.0.0.0
b4bd0000 b4bda000 r-xp /usr/lib/libspdy.so.0.0.0
b4be3000 b4d36000 r-xp /usr/lib/libcrypto.so.1.0.0
b4d54000 b4da0000 r-xp /usr/lib/libssl.so.1.0.0
b4dac000 b4dda000 r-xp /usr/lib/libidn.so.11.5.44
b4de3000 b4ded000 r-xp /usr/lib/libcares.so.2.1.0
b4df5000 b4e0c000 r-xp /lib/libexpat.so.1.5.2
b4e16000 b4e3a000 r-xp /usr/lib/libicule.so.48.1
b4e43000 b4e52000 r-xp /usr/lib/libsf_common.so
b4e5a000 b4ef5000 r-xp /usr/lib/libstdc++.so.6.0.14
b4f08000 b4f20000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4f21000 b4f24000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4f2c000 b4f30000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4f39000 b4f3e000 r-xp /usr/lib/libffi.so.5.0.10
b4f46000 b4f47000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4f4f000 b4f59000 r-xp /usr/lib/libXext.so.6.4.0
b4f62000 b4f65000 r-xp /usr/lib/libXtst.so.6.1.0
b4f6d000 b4f73000 r-xp /usr/lib/libXrender.so.1.3.0
b4f7b000 b4f81000 r-xp /usr/lib/libXrandr.so.2.2.0
b4f89000 b4f8a000 r-xp /usr/lib/libXinerama.so.1.0.0
b4f93000 b4f9c000 r-xp /usr/lib/libXi.so.6.1.0
b4fa4000 b4fa7000 r-xp /usr/lib/libXfixes.so.3.1.0
b4faf000 b4fb1000 r-xp /usr/lib/libXgesture.so.7.0.0
b4fb9000 b4fba000 r-xp /usr/lib/libXdamage.so.1.1.0
b4fc3000 b4fca000 r-xp /usr/lib/libXcursor.so.1.0.2
b4fd2000 b4ff5000 r-xp /usr/lib/libexif.so.12.3.3
b5009000 b5013000 r-xp /usr/lib/libethumb.so.1.7.99
b501b000 b505f000 r-xp /usr/lib/libsndfile.so.1.0.25
b506d000 b506f000 r-xp /usr/lib/libctxdata.so.0.0.0
b5077000 b5085000 r-xp /usr/lib/libremix.so.0.0.0
b508d000 b508e000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5096000 b50af000 r-xp /usr/lib/liblua-5.1.so
b50b8000 b50bf000 r-xp /usr/lib/libembryo.so.1.7.99
b50c8000 b5108000 r-xp /usr/lib/libcurl.so.4.3.0
b5111000 b517b000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5188000 b51ac000 r-xp /usr/lib/libfontconfig.so.1.5.0
b51b5000 b5211000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5223000 b5237000 r-xp /usr/lib/libfribidi.so.0.3.1
b523f000 b5297000 r-xp /usr/lib/libfreetype.so.6.8.1
b52a2000 b52c6000 r-xp /usr/lib/libjpeg.so.8.0.2
b52de000 b52f5000 r-xp /lib/libz.so.1.2.5
b52fd000 b5305000 r-xp /usr/lib/libemotion.so.1.7.99
b530d000 b5312000 r-xp /usr/lib/libecore_fb.so.1.7.99
b531b000 b5329000 r-xp /usr/lib/libsensor.so.1.1.0
b5335000 b533b000 r-xp /usr/lib/libappcore-common.so.1.1
b5343000 b5345000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.80
b534d000 b5358000 r-xp /usr/lib/libresourced.so.0.2.80
b5360000 b5363000 r-xp /usr/lib/libproc-stat.so.0.2.80
b6360000 b6448000 r-xp /usr/lib/libicuuc.so.48.1
b6455000 b6575000 r-xp /usr/lib/libicui18n.so.48.1
b6583000 b6586000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b658e000 b6596000 r-xp /usr/lib/libvconf.so.0.2.45
b6597000 b659d000 r-xp /usr/lib/libxdgmime.so.1.1.0
b65a5000 b65b1000 r-xp /usr/lib/libail.so.0.1.0
b65b9000 b65c4000 r-xp /usr/lib/libaul.so.0.1.0
b65cc000 b65e3000 r-xp /usr/lib/libecore_input.so.1.7.99
b65fe000 b661b000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6624000 b6626000 r-xp /usr/lib/libXcomposite.so.1.0.0
b662e000 b6662000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b666b000 b669a000 r-xp /usr/lib/libecore_x.so.1.7.99
b66a4000 b66e3000 r-xp /usr/lib/libeina.so.1.7.99
b66ec000 b6701000 r-xp /usr/lib/libecore.so.1.7.99
b6718000 b6733000 r-xp /usr/lib/libecore_con.so.1.7.99
b673c000 b6741000 r-xp /usr/lib/libecore_imf.so.1.7.99
b674a000 b6752000 r-xp /usr/lib/libethumb_client.so.1.7.99
b675a000 b6763000 r-xp /usr/lib/libedbus.so.1.7.99
b676b000 b676d000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6775000 b6779000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6782000 b6798000 r-xp /usr/lib/libefreet.so.1.7.99
b67a2000 b67fe000 r-xp /usr/lib/libedje.so.1.7.99
b6808000 b680d000 r-xp /usr/lib/libecore_file.so.1.7.99
b6815000 b68c5000 r-xp /usr/lib/libevas.so.1.7.99
b68df000 b68f2000 r-xp /usr/lib/libeet.so.1.7.99
b68fb000 b6965000 r-xp /lib/libm-2.13.so
b696e000 b696f000 r-xp /usr/lib/libpmapi.so.1.2
b6977000 b697e000 r-xp /usr/lib/libutilX.so.1.1.0
b6986000 b6aa9000 r-xp /usr/lib/libelementary.so.1.7.99
b6abe000 b6ac1000 r-xp /lib/libattr.so.1.1.0
b6ac9000 b6acb000 r-xp /usr/lib/libXau.so.6.0.0
b6ad3000 b6ad9000 r-xp /lib/librt-2.13.so
b6ae2000 b6aea000 r-xp /lib/libcrypt-2.13.so
b6b1a000 b6b1d000 r-xp /lib/libcap.so.2.21
b6b25000 b6b27000 r-xp /usr/lib/libiri.so
b6b2f000 b6b44000 r-xp /usr/lib/libxcb.so.1.1.0
b6b4c000 b6b57000 r-xp /lib/libunwind.so.8.0.1
b6b85000 b6ca2000 r-xp /lib/libc-2.13.so
b6cb0000 b6cb9000 r-xp /lib/libgcc_s-4.5.3.so.1
b6cc1000 b6ced000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6cf6000 b6cf9000 r-xp /usr/lib/libbundle.so.0.1.22
b6d01000 b6d03000 r-xp /lib/libdl-2.13.so
b6d0c000 b6d0f000 r-xp /usr/lib/libsmack.so.1.0.0
b6d17000 b6df1000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6dfa000 b6e0e000 r-xp /lib/libpthread-2.13.so
b6e20000 b6e28000 r-xp /usr/lib/libappcore-efl.so.1.1
b6e31000 b6e32000 r-xp /usr/lib/libdlog.so.0.0.0
b6e3b000 b6ea8000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6eb2000 b6ebc000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ec5000 b6fab000 r-xp /usr/lib/libX11.so.6.3.0
b6fb6000 b6fb7000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6fbf000 b6fc3000 r-xp /usr/lib/libsys-assert.so
b6fcb000 b6fe8000 r-xp /lib/ld-2.13.so
bed5c000 bed7d000 rwxp [stack]
End of Maps Information

Callstack Information (PID:16686)
Call Stack Count: 40
 0: gsignal + 0x3c (0xb6baf760) [/lib/libc.so.6] + 0x2a760
 1: abort + 0x1ac (0xb6bb355c) [/lib/libc.so.6] + 0x2e55c
 2: __assert_fail + 0x10c (0xb6ba863c) [/lib/libc.so.6] + 0x2363c
 3: SysAssertfInternal + 0x9e (0xb4543f3f) [/usr/lib/osp/libosp-appfw.so] + 0x13ff3f
 4: Tizen::Ui::Control::SetPropagatedKeyEventListener(Tizen::Ui::IPropagatedKeyEventListener*) + 0x34 (0xb3b6e551) [/usr/lib/osp/libosp-uifw.so] + 0x29e551
 5: SortPopupPanel::Construct(Tizen::Graphics::Rectangle) + 0x28 (0xb2e90d40) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x5dd40
 6: MyHondanaMainForm::SortMenu() + 0x23c (0xb2e748d4) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x418d4
 7: MyHondanaMainForm::OnInitializing() + 0x160 (0xb2e6a05c) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3705c
 8: non-virtual thunk to MyHondanaMainForm::OnInitializing() + 0x20 (0xb2e76198) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x43198
 9: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x22 (0xb3b87a27) [/usr/lib/osp/libosp-uifw.so] + 0x2b7a27
10: Tizen::Ui::Controls::_FormImpl::OnAttachedToMainTree() + 0x28 (0xb3d498b5) [/usr/lib/osp/libosp-uifw.so] + 0x4798b5
11: Tizen::Ui::_Control::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0xb2 (0xb3b700bf) [/usr/lib/osp/libosp-uifw.so] + 0x2a00bf
12: Tizen::Ui::_Control::EndAttaching(Tizen::Ui::_Control&) + 0xf2 (0xb3b73247) [/usr/lib/osp/libosp-uifw.so] + 0x2a3247
13: Tizen::Ui::_Control::AttachChild(Tizen::Ui::_Control&) + 0x5a (0xb3b75c1f) [/usr/lib/osp/libosp-uifw.so] + 0x2a5c1f
14: Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool) + 0xa4 (0xb3b92f59) [/usr/lib/osp/libosp-uifw.so] + 0x2c2f59
15: Tizen::Ui::Container::AddControl(Tizen::Ui::Control*) + 0x26 (0xb3b6a43f) [/usr/lib/osp/libosp-uifw.so] + 0x29a43f
16: Tizen::Ui::Container::AddControl(Tizen::Ui::Control const&) + 0x6 (0xb3b6a4cb) [/usr/lib/osp/libosp-uifw.so] + 0x29a4cb
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
