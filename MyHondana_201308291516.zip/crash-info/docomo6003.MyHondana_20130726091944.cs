S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 2580
Date: 2013-07-26 09:19:44(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=2580 tid=2580
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2580, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xbfa45190, esi = 0xb26136bc
ebp = 0xbfa453a8, esp = 0xbfa45190
eax = 0x00000001, ebx = 0x00000000
ecx = 0x09ff63c8, edx = 0x00000000
eip = 0xb25d62cd

Memory Information
MemTotal:   509368 KB
MemFree:     55812 KB
Buffers:     20276 KB
Cached:     222832 KB
VmPeak:     236116 KB
VmSize:     230828 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      111172 KB
VmRSS:      106600 KB
VmData:      85352 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100724 KB
VmPTE:         216 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
ac310000 ac312000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
afb40000 afbb3000 r-xp /usr/lib/host-gl/libGL.so.1.2
afbd6000 afbe4000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afbe5000 afc1c000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afc20000 afc22000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afc23000 afc2a000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc2b000 afc38000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc39000 afc47000 r-xp /usr/lib/libudev.so.0.13.1
afc48000 afc8a000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc8b000 afd17000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afd1d000 afd27000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afd28000 afd40000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd41000 afd47000 r-xp /usr/lib/libmmffile.so.0.0.0
afd48000 afd50000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd51000 afd53000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd54000 afd75000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd76000 afd78000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd79000 afd97000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd98000 afd9e000 r-xp /usr/lib/libmemenv.so.1.1.0
afd9f000 afde8000 r-xp /usr/lib/libleveldb.so.1.1.0
afdea000 afdf5000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afdf6000 afe32000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe34000 afe49000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe4a000 afe6a000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe6c000 afea2000 r-xp /usr/lib/libxslt.so.1.1.16
afea3000 afeab000 r-xp /usr/lib/libeeze.so.1.7.99
afeac000 afeb1000 r-xp /usr/lib/libeukit.so.1.7.99
afeb2000 afebc000 r-xp /usr/lib/libenchant.so.1.6.1
afebd000 afec7000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afec8000 afed4000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afed5000 aff04000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
aff0a000 aff0e000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
aff0f000 aff1b000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
aff1d000 aff24000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
aff25000 aff34000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff35000 aff38000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff39000 aff4a000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff4b000 aff7a000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff7b000 aff81000 r-xp /usr/lib/libogg.so.0.7.1
aff82000 affad000 r-xp /usr/lib/libvorbis.so.0.4.3
affae000 affb3000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
affb4000 affb8000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
affb9000 affbe000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
affbf000 affe4000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affe5000 affff000 r-xp /usr/lib/libnetwork.so.0.0.0
b0001000 b002d000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b002e000 b2019000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2113000 b227e000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b228a000 b230e000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2310000 b232c000 r-xp /usr/lib/libwifi-direct.so.0.0
b232d000 b2338000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b2339000 b2344000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2345000 b2353000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b2354000 b23f6000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b23fc000 b250e000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2514000 b2539000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b253b000 b2568000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b256b000 b256d000 r-xp /usr/lib/libhaptic-module.so
b2570000 b2571000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b257a000 b260f000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2614000 b2644000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2645000 b2698000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2699000 b269f000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b26a0000 b26a5000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b26a6000 b26ee000 r-xp /usr/lib/libpulse.so.0.12.4
b26ef000 b26f3000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26f4000 b27e6000 r-xp /usr/lib/libasound.so.2.0.0
b27ea000 b280f000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2810000 b2824000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2825000 b2905000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b290a000 b2969000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b296a000 b2976000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2977000 b298a000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b298b000 b298e000 r-xp /usr/lib/libmm_ta.so.0.0.0
b298f000 b29a6000 r-xp /usr/lib/libICE.so.6.3.0
b29a9000 b29b0000 r-xp /usr/lib/libSM.so.6.0.1
b29b1000 b29b2000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b29b3000 b29be000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b29bf000 b29c4000 r-xp /usr/lib/libsysman.so.0.2.0
b29c5000 b29d0000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b29d4000 b29d8000 r-xp /usr/lib/libmmfsession.so.0.0.0
b29d9000 b2a36000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2a38000 b2a40000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2a41000 b2a43000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2a44000 b2aa7000 r-xp /usr/lib/libtiff.so.5.1.0
b2aaa000 b2afc000 r-xp /usr/lib/libturbojpeg.so
b2b0d000 b2b14000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2b15000 b2b1e000 r-xp /usr/lib/libgif.so.4.1.6
b2b1f000 b2b45000 r-xp /usr/lib/libavutil.so.51.73.101
b2b4c000 b2b91000 r-xp /usr/lib/libswscale.so.2.1.101
b2b92000 b2ef7000 r-xp /usr/lib/libavcodec.so.54.59.100
b3218000 b323f000 r-xp /usr/lib/libpng12.so.0.50.0
b3240000 b3247000 r-xp /usr/lib/libfeedback.so.0.1.4
b3248000 b3257000 r-xp /usr/lib/libtts.so
b3258000 b326e000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b326f000 b3389000 r-xp /usr/lib/libcairo.so.2.11200.12
b338c000 b33b0000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b33b1000 b4197000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4207000 b420d000 r-xp /usr/lib/libslp_devman_plugin.so
b420e000 b4210000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4211000 b4214000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4215000 b4219000 r-xp /usr/lib/libdevice-node.so.0.1
b421a000 b4228000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4229000 b4232000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4233000 b4239000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b423a000 b423c000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b423d000 b4241000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4242000 b4249000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b424a000 b424d000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b424e000 b424f000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4250000 b4263000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4265000 b426d000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b426e000 b429e000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b429f000 b42a3000 r-xp /usr/lib/libuuid.so.1.3.0
b42a4000 b42b5000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b42b6000 b42b7000 r-xp /usr/lib/libpmapi.so.1.2
b42b8000 b42c4000 r-xp /usr/lib/libminizip.so.1.0.0
b42c5000 b42d6000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42d7000 b42ff000 r-xp /usr/lib/libpcre.so.0.0.1
b4300000 b4304000 r-xp /usr/lib/libheynoti.so.0.0.2
b4305000 b430a000 r-xp /usr/lib/libhaptic.so.0.1
b430b000 b430c000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b430d000 b4314000 r-xp /usr/lib/libdevman.so.0.1
b4315000 b431b000 r-xp /usr/lib/libchromium.so.1.0
b431c000 b4324000 r-xp /usr/lib/libalarm.so.0.0.0
b4325000 b432e000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b432f000 b4347000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4348000 b47f2000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4814000 b481e000 r-xp /lib/libnss_files-2.13.so
b4820000 b4829000 r-xp /lib/libnss_nis-2.13.so
b482b000 b483e000 r-xp /lib/libnsl-2.13.so
b4842000 b4848000 r-xp /lib/libnss_compat-2.13.so
b4a4a000 b4a64000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a65000 b4bae000 r-xp /usr/lib/libxml2.so.2.7.8
b4bb4000 b4bda000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4bdb000 b4bde000 r-xp /usr/lib/libiniparser.so.0
b4be0000 b4c49000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c4b000 b4c67000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c68000 b4c6f000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c70000 b4c73000 r-xp /usr/lib/libdri2.so.0.0.0
b4c74000 b4c7f000 r-xp /usr/lib/libdrm.so.2.4.0
b4c80000 b4c85000 r-xp /usr/lib/libtbm.so.1.0.0
b4c86000 b4c8a000 r-xp /usr/lib/libXv.so.1.0.0
b4c8b000 b4da9000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4db8000 b4dcd000 r-xp /usr/lib/libnotification.so.0.1.0
b4dce000 b4dd7000 r-xp /usr/lib/libutilX.so.1.1.0
b4dd8000 b4e0b000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4e0d000 b4e1e000 r-xp /lib/libresolv-2.13.so
b4e22000 b4e25000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4e26000 b4f8b000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f8f000 b50ff000 r-xp /usr/lib/libcrypto.so.1.0.0
b5117000 b516d000 r-xp /usr/lib/libssl.so.1.0.0
b5172000 b51a1000 r-xp /usr/lib/libidn.so.11.5.44
b51a2000 b51b1000 r-xp /usr/lib/libcares.so.2.0.0
b51b2000 b51d9000 r-xp /lib/libexpat.so.1.5.2
b51db000 b520e000 r-xp /usr/lib/libicule.so.48.1
b520f000 b521a000 r-xp /usr/lib/libsf_common.so
b521b000 b52f7000 r-xp /usr/lib/libstdc++.so.6.0.14
b5303000 b5306000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5307000 b532c000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b532d000 b5332000 r-xp /usr/lib/libffi.so.5.0.10
b5333000 b5334000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5335000 b5366000 r-xp /usr/lib/libexif.so.12.3.3
b5373000 b537f000 r-xp /usr/lib/libethumb.so.1.7.99
b5380000 b53e4000 r-xp /usr/lib/libsndfile.so.1.0.25
b53ea000 b53ed000 r-xp /usr/lib/libctxdata.so.0.0.0
b53ee000 b5405000 r-xp /usr/lib/libremix.so.0.0.0
b5406000 b5408000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5409000 b5436000 r-xp /usr/lib/liblua-5.1.so
b5437000 b5441000 r-xp /usr/lib/libembryo.so.1.7.99
b5442000 b5445000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5446000 b54a7000 r-xp /usr/lib/libcurl.so.4.3.0
b54a9000 b54af000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b54b0000 b54c1000 r-xp /usr/lib/libXext.so.6.4.0
b54c2000 b54c7000 r-xp /usr/lib/libXtst.so.6.1.0
b54c8000 b54d0000 r-xp /usr/lib/libXrender.so.1.3.0
b54d1000 b54da000 r-xp /usr/lib/libXrandr.so.2.2.0
b54db000 b54dd000 r-xp /usr/lib/libXinerama.so.1.0.0
b54de000 b54ec000 r-xp /usr/lib/libXi.so.6.1.0
b54ed000 b54f1000 r-xp /usr/lib/libXfixes.so.3.1.0
b54f2000 b54f4000 r-xp /usr/lib/libXgesture.so.7.0.0
b54f5000 b54f7000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54f8000 b54fa000 r-xp /usr/lib/libXdamage.so.1.1.0
b54fb000 b5505000 r-xp /usr/lib/libXcursor.so.1.0.2
b5506000 b559d000 r-xp /usr/lib/libpixman-1.so.0.28.2
b55a2000 b55d7000 r-xp /usr/lib/libfontconfig.so.1.5.0
b55d9000 b565e000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5668000 b567e000 r-xp /usr/lib/libfribidi.so.0.3.1
b567f000 b5704000 r-xp /usr/lib/libfreetype.so.6.8.1
b5708000 b574f000 r-xp /usr/lib/libjpeg.so.8.0.2
b5760000 b577f000 r-xp /lib/libz.so.1.2.5
b5780000 b578c000 r-xp /usr/lib/libemotion.so.1.7.99
b578d000 b5793000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5795000 b57a5000 r-xp /usr/lib/libsensor.so.1.1.0
b57a8000 b57ae000 r-xp /usr/lib/libappcore-common.so.1.1
b68b7000 b6a12000 r-xp /usr/lib/libicuuc.so.48.1
b6a20000 b6bff000 r-xp /usr/lib/libicui18n.so.48.1
b6c06000 b6c09000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6c0a000 b6c16000 r-xp /usr/lib/libvconf.so.0.2.45
b6c17000 b6c20000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6c21000 b6c32000 r-xp /usr/lib/libail.so.0.1.0
b6c33000 b6c43000 r-xp /usr/lib/libaul.so.0.1.0
b6c44000 b6c94000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c95000 b6cd8000 r-xp /usr/lib/libecore_x.so.1.7.99
b6cda000 b6d35000 r-xp /usr/lib/libeina.so.1.7.99
b6d37000 b6d56000 r-xp /usr/lib/libecore.so.1.7.99
b6d65000 b6d90000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d92000 b6d9d000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d9e000 b6daa000 r-xp /usr/lib/libedbus.so.1.7.99
b6dab000 b6dae000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6daf000 b6db5000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6db6000 b6dd8000 r-xp /usr/lib/libefreet.so.1.7.99
b6dda000 b6e71000 r-xp /usr/lib/libedje.so.1.7.99
b6e73000 b6e8a000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e9e000 b6ea5000 r-xp /usr/lib/libecore_file.so.1.7.99
b6ea6000 b6ed3000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6ed5000 b6fdf000 r-xp /usr/lib/libevas.so.1.7.99
b6ffa000 b7017000 r-xp /usr/lib/libeet.so.1.7.99
b7018000 b703c000 r-xp /lib/libm-2.13.so
b703e000 b720e000 r-xp /usr/lib/libelementary.so.1.7.99
b721b000 b7226000 r-xp /usr/lib/libcapi-web-favorites.so
b7227000 b7229000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b722c000 b7230000 r-xp /lib/libattr.so.1.1.0
b7231000 b7233000 r-xp /usr/lib/libXau.so.6.0.0
b7235000 b723c000 r-xp /lib/librt-2.13.so
b723e000 b7246000 r-xp /lib/libcrypt-2.13.so
b726f000 b7272000 r-xp /lib/libcap.so.2.21
b7273000 b7275000 r-xp /usr/lib/libiri.so
b7276000 b7290000 r-xp /lib/libgcc_s-4.5.3.so.1
b7291000 b72b1000 r-xp /usr/lib/libxcb.so.1.1.0
b72b3000 b72bc000 r-xp /lib/libunwind.so.8.0.1
b72c6000 b741c000 r-xp /lib/libc-2.13.so
b7422000 b7427000 r-xp /usr/lib/libsmack.so.1.0.0
b7428000 b7474000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7475000 b747a000 r-xp /usr/lib/libbundle.so.0.1.22
b747b000 b747d000 r-xp /lib/libdl-2.13.so
b7480000 b75a9000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b75aa000 b75bf000 r-xp /lib/libpthread-2.13.so
b75c4000 b75c5000 r-xp /usr/lib/libdlog.so.0.0.0
b75c6000 b7670000 r-xp /usr/lib/libsqlite3.so.0.8.6
b7673000 b767f000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b7680000 b77b5000 r-xp /usr/lib/libX11.so.6.3.0
b77ba000 b77c2000 r-xp /usr/lib/libecore_imf.so.1.7.99
b77c3000 b77c8000 r-xp /usr/lib/libappcore-efl.so.1.1
b77ca000 b77ce000 r-xp /usr/lib/libsys-assert.so
b77d2000 b77d3000 r-xp [vdso]
b77d3000 b77ef000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:2580)
Call Stack Count: 37
 0: (0xb37fe9f2) [/usr/lib/osp/libosp-uifw.so] + 0x44d9f2
 1: Tizen::Base::Runtime::_Event::ProcessListeners(std::tr1::shared_ptr<Tizen::Base::Runtime::IEventArg>) + 0x40c (0xb44f379c) [/usr/lib/osp/libosp-appfw.so] + 0x1ab79c
 2: Tizen::Base::Runtime::_Event::Fire(std::tr1::shared_ptr<Tizen::Base::Runtime::IEventArg>) + 0x62 (0xb44f3c32) [/usr/lib/osp/libosp-appfw.so] + 0x1abc32
 3: Tizen::Base::Runtime::_Event::Fire(Tizen::Base::Runtime::IEventArg&) + 0x77 (0xb44f3d47) [/usr/lib/osp/libosp-appfw.so] + 0x1abd47
 4: (0xb39dcc61) [/usr/lib/osp/libosp-uifw.so] + 0x62bc61
 5: (0xb37fa102) [/usr/lib/osp/libosp-uifw.so] + 0x449102
 6: Tizen::Base::Runtime::_Event::ProcessListeners(std::tr1::shared_ptr<Tizen::Base::Runtime::IEventArg>) + 0x40c (0xb44f379c) [/usr/lib/osp/libosp-appfw.so] + 0x1ab79c
 7: Tizen::Base::Runtime::_Event::Fire(std::tr1::shared_ptr<Tizen::Base::Runtime::IEventArg>) + 0x62 (0xb44f3c32) [/usr/lib/osp/libosp-appfw.so] + 0x1abc32
 8: Tizen::Base::Runtime::_Event::Fire(Tizen::Base::Runtime::IEventArg&) + 0x77 (0xb44f3d47) [/usr/lib/osp/libosp-appfw.so] + 0x1abd47
 9: Tizen::Ui::Controls::_Button::FireActionEvent() + 0x4d (0xb380cc0d) [/usr/lib/osp/libosp-uifw.so] + 0x45bc0d
10: (0xb3811e25) [/usr/lib/osp/libosp-uifw.so] + 0x460e25
11: Tizen::Ui::Controls::_Button::OnTouchReleased(Tizen::Ui::_Control const&, Tizen::Ui::_TouchInfo const&) + 0x25 (0xb3807cc5) [/usr/lib/osp/libosp-uifw.so] + 0x456cc5
12: Tizen::Ui::_ControlImpl::CallOnTouchReleased(Tizen::Ui::_Control const&, Tizen::Ui::_TouchInfo const&) + 0xef (0xb36cbe1f) [/usr/lib/osp/libosp-uifw.so] + 0x31ae1f
13: Tizen::Ui::_ControlImpl::_PropagatedTouchEventListener::OnTouchReleased(Tizen::Ui::_Control const&, Tizen::Ui::_TouchInfo const&) + 0x435 (0xb36da445) [/usr/lib/osp/libosp-uifw.so] + 0x329445
14: Tizen::Ui::_UiTouchEvent::FireListener(Tizen::Ui::_ITouchEventListener const*, Tizen::Ui::_Control const*, bool, bool&) + 0x31c (0xb3775c7c) [/usr/lib/osp/libosp-uifw.so] + 0x3c4c7c
15: Tizen::Ui::_UiTouchEvent::OnEventProcessing(Tizen::Ui::_Control const&, bool&) + 0xab (0xb37762bb) [/usr/lib/osp/libosp-uifw.so] + 0x3c52bb
16: Tizen::Ui::_UiEvent::ProcessEvent(Tizen::Ui::_Control const&, bool&) + 0x64 (0xb3763704) [/usr/lib/osp/libosp-uifw.so] + 0x3b2704
17: Tizen::Ui::_UiEventManager::ProcessBubblingEvent(Tizen::Base::Collection::LinkedListT<Tizen::Base::_HandleT<Tizen::Ui::_Control> > const&, Tizen::Ui::_UiEvent const&, bool&) + 0xa0 (0xb3764590) [/usr/lib/osp/libosp-uifw.so] + 0x3b3590
18: Tizen::Ui::_UiEventManager::ProcessEvent(Tizen::Ui::_UiEvent const&, bool&) + 0x2e5 (0xb37648f5) [/usr/lib/osp/libosp-uifw.so] + 0x3b38f5
19: Tizen::Ui::_UiEventManager::Fire(Tizen::Ui::_UiEvent const&) + 0xe3 (0xb3764ae3) [/usr/lib/osp/libosp-uifw.so] + 0x3b3ae3
20: Tizen::Ui::_UiEventManager::SendEvent(Tizen::Ui::_UiEvent const&) + 0x24 (0xb3764be4) [/usr/lib/osp/libosp-uifw.so] + 0x3b3be4
21: (0xb374be5e) [/usr/lib/osp/libosp-uifw.so] + 0x39ae5e
22: (0xb37510e7) [/usr/lib/osp/libosp-uifw.so] + 0x3a00e7
23: _ecore_event_call + 0x421 (0xb6d401c1) [/usr/lib/libecore.so.1] + 0x91c1
24: _ecore_main_loop_iterate_internal + 0x1ea (0xb6d44f1a) [/usr/lib/libecore.so.1] + 0xdf1a
25: ecore_main_loop_begin + 0x3f (0xb6d4545f) [/usr/lib/libecore.so.1] + 0xe45f
26: elm_run + 0x17 (0xb712eee7) [/usr/lib/libelementary.so.1] + 0xf0ee7
27: appcore_efl_main + 0x42e (0xb77c62ee) [/usr/lib/libappcore-efl.so.1] + 0x32ee
28: app_efl_main + 0xe8 (0xb4254d98) [/usr/lib/libcapi-appfw-application.so.0] + 0x4d98
29: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x122 (0xb444b612) [/usr/lib/osp/libosp-appfw.so] + 0x103612
30: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3d67ea1) [/usr/lib/osp/libosp-uifw.so] + 0x9b6ea1
31: OspMain + 0x19f (0xb25b118f) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3718f
32: main + 0x503 (0xb72280c3) [/opt/apps/docomo6003/bin/MyHondana] + 0x10c3
33: __launchpad_main_loop + 0x1c17 (0x804bf97) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bf97
34: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
35: __libc_start_main + 0xe6 (0xb72dcda6) [/lib/libc.so.6] + 0x16da6
36: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
