S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 2587
Date: 2013-07-30 15:38:44(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=2587 tid=2587
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2587, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x000000a4, esi = 0xbfe26874
ebp = 0xbfe267e8, esp = 0xbfe267a0
eax = 0xb47dc960, ebx = 0xb47eba10
ecx = 0xb47eba10, edx = 0xb47dc848
eip = 0xb44af265

Memory Information
MemTotal:   509368 KB
MemFree:     14784 KB
Buffers:     62152 KB
Cached:     275576 KB
VmPeak:     149404 KB
VmSize:     149340 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       39092 KB
VmRSS:       39092 KB
VmData:      24256 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100644 KB
VmPTE:         136 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
af9da000 afa4d000 r-xp /usr/lib/host-gl/libGL.so.1.2
afa70000 afa7e000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afa7f000 afab6000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afc11000 afc13000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afc14000 afc1b000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc1c000 afc29000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc2a000 afc38000 r-xp /usr/lib/libudev.so.0.13.1
afc39000 afc7b000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc7c000 afd08000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afd0e000 afd18000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afd19000 afd31000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd32000 afd38000 r-xp /usr/lib/libmmffile.so.0.0.0
afd39000 afd41000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd42000 afd44000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd45000 afd66000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd67000 afd69000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd6a000 afd88000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd89000 afd8f000 r-xp /usr/lib/libmemenv.so.1.1.0
afd90000 afdd9000 r-xp /usr/lib/libleveldb.so.1.1.0
afddb000 afde6000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afde7000 afe23000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe25000 afe3a000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe3b000 afe5b000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe5d000 afe93000 r-xp /usr/lib/libxslt.so.1.1.16
afe94000 afe9c000 r-xp /usr/lib/libeeze.so.1.7.99
afe9d000 afea2000 r-xp /usr/lib/libeukit.so.1.7.99
afea3000 afead000 r-xp /usr/lib/libenchant.so.1.6.1
afeae000 afeb8000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afeb9000 afec5000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afec6000 afef5000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afefb000 afeff000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
aff00000 aff0c000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
aff0e000 aff15000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
aff16000 aff25000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff26000 aff29000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff2a000 aff3b000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff3c000 aff6b000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff6c000 aff72000 r-xp /usr/lib/libogg.so.0.7.1
aff73000 aff9e000 r-xp /usr/lib/libvorbis.so.0.4.3
aff9f000 affa4000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
affa5000 affa9000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
affaa000 affaf000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
affb0000 affd5000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affd6000 afff0000 r-xp /usr/lib/libnetwork.so.0.0.0
afff2000 b001e000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b001f000 b200a000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2104000 b226f000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b227b000 b22a8000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b22a9000 b22ce000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b22d0000 b2354000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2356000 b2372000 r-xp /usr/lib/libwifi-direct.so.0.0
b2373000 b237e000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b237f000 b238a000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b238b000 b2399000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b239a000 b243c000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2442000 b2554000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b256b000 b25f0000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b25f5000 b2625000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2626000 b2679000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b267a000 b2680000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2681000 b2686000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2687000 b26cf000 r-xp /usr/lib/libpulse.so.0.12.4
b26d0000 b26d4000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26d5000 b27c7000 r-xp /usr/lib/libasound.so.2.0.0
b27cb000 b27f0000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b27f1000 b2805000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2806000 b28e6000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b28eb000 b294a000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b294b000 b2957000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2958000 b296b000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b296c000 b296f000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2970000 b2987000 r-xp /usr/lib/libICE.so.6.3.0
b298a000 b2991000 r-xp /usr/lib/libSM.so.6.0.1
b2992000 b2993000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2994000 b299f000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b29a0000 b29a5000 r-xp /usr/lib/libsysman.so.0.2.0
b29a6000 b29b1000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b29b5000 b29b9000 r-xp /usr/lib/libmmfsession.so.0.0.0
b29ba000 b2a17000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2a19000 b2a21000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2a22000 b2a24000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2a25000 b2a88000 r-xp /usr/lib/libtiff.so.5.1.0
b2a8b000 b2add000 r-xp /usr/lib/libturbojpeg.so
b2aee000 b2af5000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2af6000 b2aff000 r-xp /usr/lib/libgif.so.4.1.6
b2b00000 b2b26000 r-xp /usr/lib/libavutil.so.51.73.101
b2b2d000 b2b72000 r-xp /usr/lib/libswscale.so.2.1.101
b2b73000 b2ed8000 r-xp /usr/lib/libavcodec.so.54.59.100
b31f9000 b3220000 r-xp /usr/lib/libpng12.so.0.50.0
b3221000 b3228000 r-xp /usr/lib/libfeedback.so.0.1.4
b3229000 b3238000 r-xp /usr/lib/libtts.so
b3239000 b324f000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b3250000 b336a000 r-xp /usr/lib/libcairo.so.2.11200.12
b336d000 b3391000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3392000 b4178000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41e8000 b41ee000 r-xp /usr/lib/libslp_devman_plugin.so
b41ef000 b41f1000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41f2000 b41f5000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41f6000 b41fa000 r-xp /usr/lib/libdevice-node.so.0.1
b41fb000 b4209000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b420a000 b4213000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4214000 b421a000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b421b000 b421d000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b421e000 b4222000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4223000 b422a000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b422b000 b422e000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b422f000 b4230000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4231000 b4244000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4246000 b424e000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b424f000 b427f000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4280000 b4284000 r-xp /usr/lib/libuuid.so.1.3.0
b4285000 b4296000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4297000 b4298000 r-xp /usr/lib/libpmapi.so.1.2
b4299000 b42a5000 r-xp /usr/lib/libminizip.so.1.0.0
b42a6000 b42b7000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42b8000 b42e0000 r-xp /usr/lib/libpcre.so.0.0.1
b42e1000 b42e5000 r-xp /usr/lib/libheynoti.so.0.0.2
b42e6000 b42eb000 r-xp /usr/lib/libhaptic.so.0.1
b42ec000 b42ed000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42ee000 b42f5000 r-xp /usr/lib/libdevman.so.0.1
b42f6000 b42fc000 r-xp /usr/lib/libchromium.so.1.0
b42fd000 b4305000 r-xp /usr/lib/libalarm.so.0.0.0
b4306000 b430f000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b4310000 b4328000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4329000 b47d3000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b47f5000 b47ff000 r-xp /lib/libnss_files-2.13.so
b4801000 b480a000 r-xp /lib/libnss_nis-2.13.so
b480c000 b481f000 r-xp /lib/libnsl-2.13.so
b4823000 b4829000 r-xp /lib/libnss_compat-2.13.so
b4a2b000 b4a45000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a46000 b4b8f000 r-xp /usr/lib/libxml2.so.2.7.8
b4b95000 b4bbb000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4bbc000 b4bbf000 r-xp /usr/lib/libiniparser.so.0
b4bc1000 b4c2a000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c2c000 b4c48000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c49000 b4c50000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c51000 b4c54000 r-xp /usr/lib/libdri2.so.0.0.0
b4c55000 b4c60000 r-xp /usr/lib/libdrm.so.2.4.0
b4c61000 b4c66000 r-xp /usr/lib/libtbm.so.1.0.0
b4c67000 b4c6b000 r-xp /usr/lib/libXv.so.1.0.0
b4c6c000 b4d8a000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d99000 b4dae000 r-xp /usr/lib/libnotification.so.0.1.0
b4daf000 b4db8000 r-xp /usr/lib/libutilX.so.1.1.0
b4db9000 b4dec000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4dee000 b4dff000 r-xp /lib/libresolv-2.13.so
b4e03000 b4e06000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4e07000 b4f6c000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f70000 b50e0000 r-xp /usr/lib/libcrypto.so.1.0.0
b50f8000 b514e000 r-xp /usr/lib/libssl.so.1.0.0
b5153000 b5182000 r-xp /usr/lib/libidn.so.11.5.44
b5183000 b5192000 r-xp /usr/lib/libcares.so.2.0.0
b5193000 b51ba000 r-xp /lib/libexpat.so.1.5.2
b51bc000 b51ef000 r-xp /usr/lib/libicule.so.48.1
b51f0000 b51fb000 r-xp /usr/lib/libsf_common.so
b51fc000 b52d8000 r-xp /usr/lib/libstdc++.so.6.0.14
b52e4000 b52e7000 r-xp /usr/lib/libapp-checker.so.0.1.0
b52e8000 b530d000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b530e000 b5313000 r-xp /usr/lib/libffi.so.5.0.10
b5314000 b5315000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5316000 b5347000 r-xp /usr/lib/libexif.so.12.3.3
b5354000 b5360000 r-xp /usr/lib/libethumb.so.1.7.99
b5361000 b53c5000 r-xp /usr/lib/libsndfile.so.1.0.25
b53cb000 b53ce000 r-xp /usr/lib/libctxdata.so.0.0.0
b53cf000 b53e6000 r-xp /usr/lib/libremix.so.0.0.0
b53e7000 b53e9000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b53ea000 b5417000 r-xp /usr/lib/liblua-5.1.so
b5418000 b5422000 r-xp /usr/lib/libembryo.so.1.7.99
b5423000 b5426000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5427000 b5488000 r-xp /usr/lib/libcurl.so.4.3.0
b548a000 b5490000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5491000 b54a2000 r-xp /usr/lib/libXext.so.6.4.0
b54a3000 b54a8000 r-xp /usr/lib/libXtst.so.6.1.0
b54a9000 b54b1000 r-xp /usr/lib/libXrender.so.1.3.0
b54b2000 b54bb000 r-xp /usr/lib/libXrandr.so.2.2.0
b54bc000 b54be000 r-xp /usr/lib/libXinerama.so.1.0.0
b54bf000 b54cd000 r-xp /usr/lib/libXi.so.6.1.0
b54ce000 b54d2000 r-xp /usr/lib/libXfixes.so.3.1.0
b54d3000 b54d5000 r-xp /usr/lib/libXgesture.so.7.0.0
b54d6000 b54d8000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54d9000 b54db000 r-xp /usr/lib/libXdamage.so.1.1.0
b54dc000 b54e6000 r-xp /usr/lib/libXcursor.so.1.0.2
b54e7000 b557e000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5583000 b55b8000 r-xp /usr/lib/libfontconfig.so.1.5.0
b55ba000 b563f000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5649000 b565f000 r-xp /usr/lib/libfribidi.so.0.3.1
b5660000 b56e5000 r-xp /usr/lib/libfreetype.so.6.8.1
b56e9000 b5730000 r-xp /usr/lib/libjpeg.so.8.0.2
b5741000 b5760000 r-xp /lib/libz.so.1.2.5
b5761000 b576d000 r-xp /usr/lib/libemotion.so.1.7.99
b576e000 b5774000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5776000 b5786000 r-xp /usr/lib/libsensor.so.1.1.0
b5789000 b578f000 r-xp /usr/lib/libappcore-common.so.1.1
b6898000 b69f3000 r-xp /usr/lib/libicuuc.so.48.1
b6a01000 b6be0000 r-xp /usr/lib/libicui18n.so.48.1
b6be7000 b6bea000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6beb000 b6bf7000 r-xp /usr/lib/libvconf.so.0.2.45
b6bf8000 b6c01000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6c02000 b6c13000 r-xp /usr/lib/libail.so.0.1.0
b6c14000 b6c24000 r-xp /usr/lib/libaul.so.0.1.0
b6c25000 b6c75000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c76000 b6cb9000 r-xp /usr/lib/libecore_x.so.1.7.99
b6cbb000 b6d16000 r-xp /usr/lib/libeina.so.1.7.99
b6d18000 b6d37000 r-xp /usr/lib/libecore.so.1.7.99
b6d46000 b6d71000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d73000 b6d7e000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d7f000 b6d8b000 r-xp /usr/lib/libedbus.so.1.7.99
b6d8c000 b6d8f000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d90000 b6d96000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d97000 b6db9000 r-xp /usr/lib/libefreet.so.1.7.99
b6dbb000 b6e52000 r-xp /usr/lib/libedje.so.1.7.99
b6e54000 b6e6b000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e7f000 b6e86000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e87000 b6eb4000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6eb6000 b6fc0000 r-xp /usr/lib/libevas.so.1.7.99
b6fdb000 b6ff8000 r-xp /usr/lib/libeet.so.1.7.99
b6ff9000 b701d000 r-xp /lib/libm-2.13.so
b701f000 b71ef000 r-xp /usr/lib/libelementary.so.1.7.99
b71fa000 b71fb000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b71fc000 b7207000 r-xp /usr/lib/libcapi-web-favorites.so
b7208000 b720a000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b720d000 b7211000 r-xp /lib/libattr.so.1.1.0
b7212000 b7214000 r-xp /usr/lib/libXau.so.6.0.0
b7216000 b721d000 r-xp /lib/librt-2.13.so
b721f000 b7227000 r-xp /lib/libcrypt-2.13.so
b7250000 b7253000 r-xp /lib/libcap.so.2.21
b7254000 b7256000 r-xp /usr/lib/libiri.so
b7257000 b7271000 r-xp /lib/libgcc_s-4.5.3.so.1
b7272000 b7292000 r-xp /usr/lib/libxcb.so.1.1.0
b7294000 b729d000 r-xp /lib/libunwind.so.8.0.1
b72a7000 b73fd000 r-xp /lib/libc-2.13.so
b7403000 b7408000 r-xp /usr/lib/libsmack.so.1.0.0
b7409000 b7455000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7456000 b745b000 r-xp /usr/lib/libbundle.so.0.1.22
b745c000 b745e000 r-xp /lib/libdl-2.13.so
b7461000 b758a000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b758b000 b75a0000 r-xp /lib/libpthread-2.13.so
b75a5000 b75a6000 r-xp /usr/lib/libdlog.so.0.0.0
b75a7000 b7651000 r-xp /usr/lib/libsqlite3.so.0.8.6
b7654000 b7660000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b7661000 b7796000 r-xp /usr/lib/libX11.so.6.3.0
b779b000 b77a3000 r-xp /usr/lib/libecore_imf.so.1.7.99
b77a4000 b77a9000 r-xp /usr/lib/libappcore-efl.so.1.1
b77ab000 b77af000 r-xp /usr/lib/libsys-assert.so
b77b3000 b77b4000 r-xp [vdso]
b77b4000 b77d0000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:2587)
Call Stack Count: 55
 0: Tizen::Ui::_UiBuilderControlLayout::GetLayoutElement(Tizen::Base::String const&, Tizen::Base::String&) const + 0x49 (0xb3721e99) [/usr/lib/osp/libosp-uifw.so] + 0x38fe99
 1: (0xb37228a5) [/usr/lib/osp/libosp-uifw.so] + 0x3908a5
 2: (0xb3722e10) [/usr/lib/osp/libosp-uifw.so] + 0x390e10
 3: (0xb372334a) [/usr/lib/osp/libosp-uifw.so] + 0x39134a
 4: xmlParseStartTag + 0x45c (0xb4a7ac9c) [/usr/lib/libxml2.so.2] + 0x34c9c
 5: xmlParseElement + 0x258 (0xb4a85cb8) [/usr/lib/libxml2.so.2] + 0x3fcb8
 6: xmlParseContent + 0x15a (0xb4a84a6a) [/usr/lib/libxml2.so.2] + 0x3ea6a
 7: xmlParseElement + 0x126 (0xb4a85b86) [/usr/lib/libxml2.so.2] + 0x3fb86
 8: xmlParseContent + 0x15a (0xb4a84a6a) [/usr/lib/libxml2.so.2] + 0x3ea6a
 9: xmlParseElement + 0x126 (0xb4a85b86) [/usr/lib/libxml2.so.2] + 0x3fb86
10: xmlParseDocument + 0x2ba (0xb4a86c6a) [/usr/lib/libxml2.so.2] + 0x40c6a
11: xmlSAXUserParseMemory + 0x79 (0xb4a871d9) [/usr/lib/libxml2.so.2] + 0x411d9
12: (0xb37222d6) [/usr/lib/osp/libosp-uifw.so] + 0x3902d6
13: Tizen::Ui::_UiBuilder::Parse() + 0x785 (0xb3713495) [/usr/lib/osp/libosp-uifw.so] + 0x381495
14: Tizen::Ui::Controls::Form::Construct(Tizen::Base::String const&) + 0x5d (0xb37bf51d) [/usr/lib/osp/libosp-uifw.so] + 0x42d51d
15: MyHondanaLoginForm::Initialize() + 0x5a (0xb25a52aa) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3a2aa
16: MyHondanaFormFactory::CreateFormN(Tizen::Base::String const&, Tizen::Base::String const&) + 0x372 (0xb25a1082) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x36082
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)

Latest Debug Message Information
--------- beginning of /dev/log_main
07-30 15:35:53.404 E/Tizen::Base( 1812): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-30 15:35:53.414 E/Tizen::Base::Runtime( 1812): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-30 15:35:53.414 E/Tizen::Base::Runtime( 1812): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-30 15:35:53.494 E/Tizen::Base( 1833): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-30 15:35:53.494 E/Tizen::Base::Runtime( 1833): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-30 15:35:53.494 E/Tizen::Base::Runtime( 1833): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-30 15:35:58.824 E/Tizen::Base( 2243): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-30 15:35:58.824 E/Tizen::Base::Runtime( 2243): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-30 15:35:58.824 E/Tizen::Base::Runtime( 2243): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-30 15:35:58.834 I/osp-app-service( 2243): int OspMain(int, char**)(38) > Application started.
07-30 15:35:58.974 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:58.974 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:58.974 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:58.974 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.174 E/Tizen::Base( 2252): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-30 15:35:59.174 E/Tizen::Base::Runtime( 2252): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-30 15:35:59.174 E/Tizen::Base::Runtime( 2252): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-30 15:35:59.184 I/osp-channel-service( 2252): int OspMain(int, char**)(35) > Application started.
07-30 15:35:59.224 E/Tizen::Base( 2251): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-30 15:35:59.234 E/Tizen::Base::Runtime( 2251): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-30 15:35:59.234 E/Tizen::Base::Runtime( 2251): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-30 15:35:59.244 I/osp-security-service( 2251): int OspMain(int, char**)(54) > Application started.
07-30 15:35:59.254 E/Tizen::Io( 2252): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.254 E/Tizen::Io( 2252): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.254 E/Tizen::Io( 2252): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.254 E/Tizen::Io( 2252): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.304 E/Tizen::System( 2243): result Tizen::System::_SystemInfo::GetValue(const Tizen::Base::String&, bool&)(1181) > [E_OBJ_NOT_FOUND] It is failed to get system information http://tizen.org/feature/input.keys.back from configration file.
07-30 15:35:59.304 E/Tizen::System( 2243): result Tizen::System::_SystemInfo::GetValue(const Tizen::Base::String&, bool&)(1181) > [E_OBJ_NOT_FOUND] It is failed to get system information http://tizen.org/feature/input.keys.menu from configration file.
07-30 15:35:59.354 E/Tizen::Io( 2251): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.354 E/Tizen::Io( 2251): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.354 E/Tizen::Io( 2251): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.354 E/Tizen::Io( 2251): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:35:59.364 I/osp-security-service( 2251): virtual bool SecurityService::OnAppInitializing(Tizen::App::AppRegistry&)(77) > Enter
07-30 15:35:59.364 I/osp-security-service( 2251): result PrivilegeService::Construct()(62) > Entered.
07-30 15:35:59.364 I/osp-security-service( 2251): result PrivilegeService::Construct()(70) > Leaved.
07-30 15:35:59.704 E/Tizen::Io( 2251): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-30 15:35:59.794 E/Tizen::Io( 2251): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-30 15:35:59.884 E/Tizen::Io( 2251): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-30 15:36:00.804 E/Tizen::Text( 2243): static Tizen::Text::_EncodingCore* Tizen::Text::_Ucs2EncodingCore::GetEncodingCoreImplN(const Tizen::Base::String&, const Tizen::Base::String&)(60) > [E_UNSUPPORTED_TYPE] It is the unsupported type
07-30 15:36:01.014 E/Tizen::Io( 2251): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-30 15:36:01.024 E/Tizen::Io( 2251): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-30 15:36:01.024 E/Tizen::Io( 2251): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-30 15:36:01.094 E/Tizen::Io( 2251): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-30 15:36:01.104 I/osp-security-service( 2251): virtual bool SecurityService::OnAppInitializing(Tizen::App::AppRegistry&)(92) > Exit
07-30 15:36:02.034 E/Tizen::Base( 2243): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(11) MUST be greater than or equal to 0, and less than the length of this string(11).
07-30 15:36:02.174 E/Tizen::Base( 2308): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-30 15:36:02.184 E/Tizen::Base::Runtime( 2308): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-30 15:36:02.184 E/Tizen::Base::Runtime( 2308): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-30 15:36:02.204 I/osp-common-service( 2308): int OspMain(int, char**)(38) > Application started.
07-30 15:36:02.224 E/Tizen::Base( 2309): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-30 15:36:02.234 E/Tizen::Base::Runtime( 2309): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-30 15:36:02.234 E/Tizen::Base::Runtime( 2309): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-30 15:36:02.264 E/Tizen::Io( 2308): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.294 E/Tizen::Io( 2308): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.294 E/Tizen::Io( 2308): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.294 E/Tizen::Io( 2308): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.344 E/Tizen::Io( 2309): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.344 E/Tizen::Io( 2309): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.344 E/Tizen::Io( 2309): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.344 E/Tizen::Io( 2309): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.374 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.374 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.374 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.384 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(zunqjlsnce.Memo)
07-30 15:36:02.404 E/Tizen::Net::Wifi( 2309): result WifiService::Construct()(87) > [E_UNSUPPORTED_OPERATION] Wi-Fi Direct is not supported.
07-30 15:36:02.404 E/Tizen::Net::Wifi( 2309): result WifiConnectivityIpcStub::Construct()(87) > [E_UNSUPPORTED_OPERATION] Failed to construct WifiService.
07-30 15:36:02.414 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.414 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.414 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.424 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(zktdpemtmw.Phone)
07-30 15:36:02.434 E/Tizen::Net::Bluetooth( 2309): result BluetoothService::Construct()(61) > [E_UNSUPPORTED_OPERATION] Bluetooth is not supported.
07-30 15:36:02.434 E/Tizen::Net::Bluetooth( 2309): result BluetoothConnectivityIpcStub::Construct()(67) > [E_UNSUPPORTED_OPERATION] Failed to construct BluetoothService.
07-30 15:36:02.454 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.454 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.454 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.454 E/Tizen::App( 2243): static Tizen::Base::String Tizen::App::_ContextManager::_Util::QueryFeatureFromPackageManager(const Tizen::Base::String&, const Tizen::Base::String&, const Tizen::Base::String&)(502) > Cannot acquire feature list.
07-30 15:36:02.454 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(zktdpemtmw._AppControl)
07-30 15:36:02.474 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.474 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.474 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.474 E/Tizen::App( 2243): result Tizen::App::_ConditionManagerService::RegisterAppLaunch(const Tizen::App::AppId&, const Tizen::Base::String&, const Tizen::Base::Collection::IList*, Tizen::App::AppManager::LaunchOption, const Tizen::Base::String*)(360) > [E_OBJ_ALREADY_EXIST]
07-30 15:36:02.474 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.474 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.474 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.494 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(vxqbrefica.Email)
07-30 15:36:02.494 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.504 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.504 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.504 E/Tizen::App( 2243): static Tizen::Base::String Tizen::App::_ContextManager::_Util::QueryFeatureFromPackageManager(const Tizen::Base::String&, const Tizen::Base::String&, const Tizen::Base::String&)(502) > Cannot acquire feature list.
07-30 15:36:02.504 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(vxqbrefica._AppControl)
07-30 15:36:02.504 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.504 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.504 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.504 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(tlp6xwqzos.Calculator)
07-30 15:36:02.514 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.514 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.514 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.514 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.514 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(sjjevolsjk.osp-common-service)
07-30 15:36:02.534 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.534 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.534 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.534 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.534 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(q7097a278m.osp-security-service)
07-30 15:36:02.534 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.534 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.534 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.544 E/Tizen::App( 2243): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(ph1vq2phrp.Calendar)
07-30 15:36:02.544 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.554 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.554 E/Tizen::Io( 2243): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 15:36:02.554 E/Tizen::App( 2243): static Tizen::Base::String Tizen::App::_ContextManager::_Util::QueryFeatureFromPackageManager(const Tizen::Base::String&, const Tizen::Base::String&, const Tizen::Ba
End of latest debug message
