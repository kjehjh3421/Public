S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG4
Build-Date: 2013.07.22 22:21:22

Crash Information
Process Name: MyHondana
PID: 25956
Date: 2013-07-30 15:43:18(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=25956 tid=25956
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 25956, uid 5000)

Register Information
r0   = 0xbe86ae7c, r1   = 0x000000a4
r2   = 0x00003294, r3   = 0x00000000
r4   = 0xbe86ae7c, r5   = 0x000000a4
r6   = 0xbe86b04c, r7   = 0xbe86ae7c
r8   = 0xb46d8390, r9   = 0xbe86b068
r10  = 0x00000068, fp   = 0x00000000
ip   = 0xb46db380, sp   = 0xbe86ae18
lr   = 0xb44e4eb3, pc   = 0xb44e4eba
cpsr = 0x40030030

Memory Information
MemTotal:  2063780 KB
MemFree:   1105552 KB
Buffers:     57984 KB
Cached:     500440 KB
VmPeak:     117696 KB
VmSize:     113576 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       26088 KB
VmRSS:       26088 KB
VmData:      16668 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       66860 KB
VmPTE:          98 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00071000 rw-p [heap]
00071000 00204000 rw-p [heap]
b0514000 b0518000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b0521000 b0d20000 rwxp [stack:25964]
b0d20000 b0d26000 r-xp /usr/lib/libUMP.so
b0d2e000 b0e7c000 r-xp /usr/lib/r3p2/libMali.so
b0e88000 b0eb1000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0ebd000 b0edb000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b1215000 b1261000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b126a000 b126f000 r-xp /usr/lib/libjson.so.0.0.1
b1277000 b127b000 r-xp /usr/lib/liblocation-pos-log.so
b1283000 b1295000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b129d000 b129f000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b12a7000 b12ac000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b12b4000 b12bf000 r-xp /usr/lib/libdrm-trusted.so.0.0.54
b12c7000 b12c9000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b12d1000 b12de000 r-xp /usr/lib/libdrm-client.so.0.0.91
b12e7000 b12ef000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b1311000 b1348000 r-xp /usr/lib/libpulse.so.0.16.2
b1350000 b13b4000 r-xp /usr/lib/libasound.so.2.0.0
b13be000 b13c1000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b13ca000 b13ce000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b13d7000 b13f2000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b13fb000 b1400000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b1408000 b1435000 r-xp /usr/lib/libSLP-location.so.0.0.0
b143e000 b1446000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b1447000 b144b000 r-xp /usr/lib/libmmffile.so.0.0.0
b1453000 b145b000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b145c000 b1475000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b147e000 b1499000 r-xp /usr/lib/libmedia-service.so.1.0.0
b14a1000 b14ac000 r-xp /usr/lib/libmdm-common.so.1.0.38
b14b4000 b14c0000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b14c8000 b14cf000 r-xp /usr/lib/libenchant.so.1.6.1
b14d7000 b14da000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b14e3000 b14ec000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b14f5000 b14f9000 r-xp /usr/lib/libmmfsession.so.0.0.0
b1502000 b1511000 r-xp /usr/lib/libmmfsound.so.0.1.0
b1519000 b151e000 r-xp /usr/lib/libmemenv.so.1.1.0
b1526000 b1564000 r-xp /usr/lib/libleveldb.so.1.1.0
b156d000 b1597000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b15a0000 b15a2000 r-xp /usr/lib/libsecfw.so
b15aa000 b15b3000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b15be000 b15cd000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b15d5000 b15ed000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b15ef000 b15fc000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b1605000 b160e000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b1616000 b1659000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b1661000 b16fd000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b1709000 b172e000 r-xp /usr/lib/libxslt.so.1.1.16
b1737000 b1739000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b1741000 b1749000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b1751000 b175d000 r-xp /usr/lib/libcapi-location-manager.so.0.1.14
b1765000 b1768000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b1770000 b1775000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b177d000 b17a4000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.71
b17ac000 b17c5000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.1
b17cd000 b180b000 r-xp /usr/lib/libmdm.so.1.0.67
b1813000 b1828000 r-xp /usr/lib/libnetwork.so.0.0.0
b1830000 b1839000 r-xp /usr/lib/libcapi-web-favorites.so
b1841000 b2aa1000 r-xp /usr/lib/libewebkit2.so.0.10.154.1
b2b94000 b2bb2000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2bbb000 b2bd5000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2bde000 b2c31000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2c3a000 b2c51000 r-xp /usr/lib/libwifi-direct.so.0.0
b2c59000 b2c61000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.10
b2c69000 b2c72000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2c7b000 b2c86000 r-xp /usr/lib/libcapi-network-connection.so.0.1.13
b2c8e000 b2cfa000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2d08000 b2dbd000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2dd0000 b2dda000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b2de2000 b2e45000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2e52000 b2ece000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2ed6000 b2f66000 r-xp /usr/lib/libCOREGL.so.3.0
b2f70000 b2f73000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2f7b000 b2f82000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2f8b000 b2f9a000 r-xp /usr/lib/libICE.so.6.3.0
b2fa4000 b2fa9000 r-xp /usr/lib/libSM.so.6.0.1
b2fb1000 b2fb2000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2fba000 b2fbc000 r-xp /usr/lib/libledplayer.so.0.1
b2fc4000 b2fca000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2fd2000 b2fd3000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2fdc000 b2fe3000 r-xp /usr/lib/libGLESv2.so.2.0
b2feb000 b3032000 r-xp /usr/lib/libtiff.so.5.1.0
b303d000 b3066000 r-xp /usr/lib/libturbojpeg.so
b307f000 b3083000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b308c000 b3092000 r-xp /usr/lib/libgif.so.4.1.6
b309a000 b30bc000 r-xp /usr/lib/libavutil.so.51.73.101
b30cb000 b30f9000 r-xp /usr/lib/libswscale.so.2.1.101
b3102000 b33f9000 r-xp /usr/lib/libavcodec.so.54.59.100
b3720000 b3739000 r-xp /usr/lib/libpng12.so.0.50.0
b3742000 b3749000 r-xp /usr/lib/libfeedback.so.0.1.4
b3752000 b3766000 r-xp /usr/lib/libtts.so
b376e000 b3770000 r-xp /usr/lib/libEGL.so.1.4
b3778000 b382f000 r-xp /usr/lib/libcairo.so.2.11200.12
b3839000 b3852000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b385c000 b3860000 r-xp /usr/lib/libss-client.so.1.0.0
b3869000 b386b000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b3873000 b4136000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41a7000 b41b0000 r-xp /usr/lib/libslp_devman_plugin.so
b41b9000 b41bb000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41c3000 b41c6000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41ce000 b41d4000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41dc000 b41df000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b41e7000 b41f4000 r-xp /usr/lib/libmodem.so.0.0.0
b41fc000 b41ff000 r-xp /usr/lib/libdevice-node.so.0.1
b4207000 b4217000 r-xp /usr/lib/libaccounts-svc.so.0.2.71
b421f000 b4222000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b422a000 b422e000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4236000 b423c000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b4244000 b4245000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b424e000 b4251000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4259000 b425c000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4265000 b4268000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b4270000 b4271000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4279000 b4287000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4290000 b42b5000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b42bd000 b42c0000 r-xp /usr/lib/libuuid.so.1.3.0
b42c9000 b42dd000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b42e6000 b42ee000 r-xp /usr/lib/libminizip.so.1.0.0
b42f6000 b4302000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b430b000 b4329000 r-xp /usr/lib/libpcre.so.0.0.1
b4331000 b4335000 r-xp /usr/lib/libheynoti.so.0.0.2
b433d000 b434b000 r-xp /usr/lib/libdeviced.so.0.1.0
b4353000 b435e000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b436b000 b4371000 r-xp /usr/lib/libdevman.so.0.1
b4379000 b437d000 r-xp /usr/lib/libchromium.so.1.0
b4385000 b438c000 r-xp /usr/lib/libalarm.so.0.0.0
b4394000 b439e000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b43a7000 b46ba000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b46e3000 b46ed000 r-xp /lib/libnss_files-2.13.so
b46fd000 b470d000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b470e000 b4722000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b472a000 b4747000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b474f000 b4752000 r-xp /usr/lib/libiniparser.so.0
b475b000 b47ae000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b47b8000 b47cc000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b47d5000 b47d7000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b47e0000 b47f1000 r-xp /usr/lib/libcom-core.so.0.0.1
b47f9000 b47ff000 r-xp /usr/lib/libappsvc.so.0.1.0
b4807000 b4809000 r-xp /usr/lib/libdri2.so.0.0.0
b4811000 b4819000 r-xp /usr/lib/libdrm.so.2.4.0
b4821000 b4825000 r-xp /usr/lib/libtbm.so.1.0.0
b482d000 b4830000 r-xp /usr/lib/libXv.so.1.0.0
b4838000 b484c000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4854000 b4920000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4936000 b4945000 r-xp /usr/lib/libnotification.so.0.1.0
b494d000 b4971000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b497b000 b498b000 r-xp /lib/libresolv-2.13.so
b498f000 b4991000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4999000 b4a71000 r-xp /usr/lib/libxml2.so.2.7.8
b4a7e000 b4b5b000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4b66000 b4b6b000 r-xp /usr/lib/libcheck.so.0.0.0
b4b73000 b4b7d000 r-xp /usr/lib/libspdy.so.0.0.0
b4b86000 b4cd9000 r-xp /usr/lib/libcrypto.so.1.0.0
b4cf7000 b4d43000 r-xp /usr/lib/libssl.so.1.0.0
b4d4f000 b4d7d000 r-xp /usr/lib/libidn.so.11.5.44
b4d86000 b4d90000 r-xp /usr/lib/libcares.so.2.1.0
b4d98000 b4daf000 r-xp /lib/libexpat.so.1.5.2
b4db9000 b4ddd000 r-xp /usr/lib/libicule.so.48.1
b4de6000 b4df5000 r-xp /usr/lib/libsf_common.so
b4dfd000 b4e98000 r-xp /usr/lib/libstdc++.so.6.0.14
b4eab000 b4ec3000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4ec4000 b4ec7000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4ecf000 b4ed3000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4edc000 b4ee1000 r-xp /usr/lib/libffi.so.5.0.10
b4ee9000 b4eea000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4ef2000 b4efc000 r-xp /usr/lib/libXext.so.6.4.0
b4f05000 b4f08000 r-xp /usr/lib/libXtst.so.6.1.0
b4f10000 b4f16000 r-xp /usr/lib/libXrender.so.1.3.0
b4f1e000 b4f24000 r-xp /usr/lib/libXrandr.so.2.2.0
b4f2c000 b4f2d000 r-xp /usr/lib/libXinerama.so.1.0.0
b4f36000 b4f3f000 r-xp /usr/lib/libXi.so.6.1.0
b4f47000 b4f4a000 r-xp /usr/lib/libXfixes.so.3.1.0
b4f52000 b4f54000 r-xp /usr/lib/libXgesture.so.7.0.0
b4f5c000 b4f5d000 r-xp /usr/lib/libXdamage.so.1.1.0
b4f66000 b4f6d000 r-xp /usr/lib/libXcursor.so.1.0.2
b4f75000 b4f98000 r-xp /usr/lib/libexif.so.12.3.3
b4fac000 b4fb6000 r-xp /usr/lib/libethumb.so.1.7.99
b4fbe000 b5002000 r-xp /usr/lib/libsndfile.so.1.0.25
b5010000 b5012000 r-xp /usr/lib/libctxdata.so.0.0.0
b501a000 b5028000 r-xp /usr/lib/libremix.so.0.0.0
b5030000 b5031000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5039000 b5052000 r-xp /usr/lib/liblua-5.1.so
b505b000 b5062000 r-xp /usr/lib/libembryo.so.1.7.99
b506b000 b50ab000 r-xp /usr/lib/libcurl.so.4.3.0
b50b4000 b511e000 r-xp /usr/lib/libpixman-1.so.0.28.2
b512b000 b514f000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5158000 b51b4000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b51c6000 b51da000 r-xp /usr/lib/libfribidi.so.0.3.1
b51e2000 b523a000 r-xp /usr/lib/libfreetype.so.6.8.1
b5245000 b5269000 r-xp /usr/lib/libjpeg.so.8.0.2
b5281000 b5298000 r-xp /lib/libz.so.1.2.5
b52a0000 b52a8000 r-xp /usr/lib/libemotion.so.1.7.99
b52b0000 b52b5000 r-xp /usr/lib/libecore_fb.so.1.7.99
b52be000 b52cc000 r-xp /usr/lib/libsensor.so.1.1.0
b52d8000 b52de000 r-xp /usr/lib/libappcore-common.so.1.1
b52e6000 b52e8000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.80
b52f0000 b52fb000 r-xp /usr/lib/libresourced.so.0.2.80
b5303000 b5306000 r-xp /usr/lib/libproc-stat.so.0.2.80
b6303000 b63eb000 r-xp /usr/lib/libicuuc.so.48.1
b63f8000 b6518000 r-xp /usr/lib/libicui18n.so.48.1
b6526000 b6529000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6531000 b6539000 r-xp /usr/lib/libvconf.so.0.2.45
b653a000 b6540000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6548000 b6554000 r-xp /usr/lib/libail.so.0.1.0
b655c000 b6567000 r-xp /usr/lib/libaul.so.0.1.0
b656f000 b6586000 r-xp /usr/lib/libecore_input.so.1.7.99
b65a1000 b65be000 r-xp /usr/lib/libecore_evas.so.1.7.99
b65c7000 b65c9000 r-xp /usr/lib/libXcomposite.so.1.0.0
b65d1000 b6605000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b660e000 b663d000 r-xp /usr/lib/libecore_x.so.1.7.99
b6647000 b6686000 r-xp /usr/lib/libeina.so.1.7.99
b668f000 b66a4000 r-xp /usr/lib/libecore.so.1.7.99
b66bb000 b66d6000 r-xp /usr/lib/libecore_con.so.1.7.99
b66df000 b66e4000 r-xp /usr/lib/libecore_imf.so.1.7.99
b66ed000 b66f5000 r-xp /usr/lib/libethumb_client.so.1.7.99
b66fd000 b6706000 r-xp /usr/lib/libedbus.so.1.7.99
b670e000 b6710000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6718000 b671c000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6725000 b673b000 r-xp /usr/lib/libefreet.so.1.7.99
b6745000 b67a1000 r-xp /usr/lib/libedje.so.1.7.99
b67ab000 b67b0000 r-xp /usr/lib/libecore_file.so.1.7.99
b67b8000 b6868000 r-xp /usr/lib/libevas.so.1.7.99
b6882000 b6895000 r-xp /usr/lib/libeet.so.1.7.99
b689e000 b6908000 r-xp /lib/libm-2.13.so
b6911000 b6912000 r-xp /usr/lib/libpmapi.so.1.2
b691a000 b6921000 r-xp /usr/lib/libutilX.so.1.1.0
b6929000 b6a4c000 r-xp /usr/lib/libelementary.so.1.7.99
b6a61000 b6a64000 r-xp /lib/libattr.so.1.1.0
b6a6c000 b6a6e000 r-xp /usr/lib/libXau.so.6.0.0
b6a76000 b6a7c000 r-xp /lib/librt-2.13.so
b6a85000 b6a8d000 r-xp /lib/libcrypt-2.13.so
b6abd000 b6ac0000 r-xp /lib/libcap.so.2.21
b6ac8000 b6aca000 r-xp /usr/lib/libiri.so
b6ad2000 b6ae7000 r-xp /usr/lib/libxcb.so.1.1.0
b6aef000 b6afa000 r-xp /lib/libunwind.so.8.0.1
b6b28000 b6c45000 r-xp /lib/libc-2.13.so
b6c53000 b6c5c000 r-xp /lib/libgcc_s-4.5.3.so.1
b6c64000 b6c90000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6c99000 b6c9c000 r-xp /usr/lib/libbundle.so.0.1.22
b6ca4000 b6ca6000 r-xp /lib/libdl-2.13.so
b6caf000 b6cb2000 r-xp /usr/lib/libsmack.so.1.0.0
b6cba000 b6d94000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6d9d000 b6db1000 r-xp /lib/libpthread-2.13.so
b6dc3000 b6dcb000 r-xp /usr/lib/libappcore-efl.so.1.1
b6dd4000 b6dd5000 r-xp /usr/lib/libdlog.so.0.0.0
b6dde000 b6e4b000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6e55000 b6e5f000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e68000 b6f4e000 r-xp /usr/lib/libX11.so.6.3.0
b6f59000 b6f5a000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6f62000 b6f66000 r-xp /usr/lib/libsys-assert.so
b6f6e000 b6f8b000 r-xp /lib/ld-2.13.so
be84d000 be86e000 rwxp [stack]
End of Maps Information

Callstack Information (PID:25956)
Call Stack Count: 41
 0: Tizen::Base::String::String(Tizen::Base::String const&) + 0x19 (0xb44e4eba) [/usr/lib/osp/libosp-appfw.so] + 0x13deba
 1: (0xb3b69d23) [/usr/lib/osp/libosp-uifw.so] + 0x2f6d23
 2: Tizen::Ui::_UiBuilderControlLayout::GetLayoutElement(Tizen::Base::String const&, Tizen::Base::String&) const + 0x46 (0xb3b6cacf) [/usr/lib/osp/libosp-uifw.so] + 0x2f9acf
 3: (0xb3b6cee9) [/usr/lib/osp/libosp-uifw.so] + 0x2f9ee9
 4: (0xb3b6d121) [/usr/lib/osp/libosp-uifw.so] + 0x2fa121
 5: (0xb3b6d45d) [/usr/lib/osp/libosp-uifw.so] + 0x2fa45d
 6: xmlParseStartTag + 0x2f2 (0xb49c624b) [/usr/lib/libxml2.so.2] + 0x2d24b
 7: xmlParseElement + 0x17e (0xb49cd713) [/usr/lib/libxml2.so.2] + 0x34713
 8: xmlParseContent + 0xf0 (0xb49ccb89) [/usr/lib/libxml2.so.2] + 0x33b89
 9: xmlParseElement + 0xd4 (0xb49cd669) [/usr/lib/libxml2.so.2] + 0x34669
10: xmlParseContent + 0xf0 (0xb49ccb89) [/usr/lib/libxml2.so.2] + 0x33b89
11: xmlParseElement + 0xd4 (0xb49cd669) [/usr/lib/libxml2.so.2] + 0x34669
12: xmlParseDocument + 0x1b6 (0xb49ce087) [/usr/lib/libxml2.so.2] + 0x35087
13: xmlSAXUserParseMemory + 0x4c (0xb49ce3dd) [/usr/lib/libxml2.so.2] + 0x353dd
14: (0xb3b6cc7b) [/usr/lib/osp/libosp-uifw.so] + 0x2f9c7b
15: Tizen::Ui::_UiBuilder::Parse() + 0x43c (0xb3b64069) [/usr/lib/osp/libosp-uifw.so] + 0x2f1069
16: Tizen::Ui::Controls::Form::Construct(Tizen::Base::String const&) + 0x34 (0xb3bcc421) [/usr/lib/osp/libosp-uifw.so] + 0x359421
17: MyHondanaLoginForm::Initialize() + 0x58 (0xb2e15654) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x33654
18: MyHondanaFormFactory::CreateFormN(Tizen::Base::String const&, Tizen::Base::String const&) + 0x2b0 (0xb2e11eb0) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x2feb0
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
