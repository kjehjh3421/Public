S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 4718
Date: 2013-07-30 16:25:01(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=4718 tid=4718
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 4718, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xbfa32788, esi = 0x00000000
ebp = 0xbfa327a8, esp = 0xbfa3273c
eax = 0x08b09654, ebx = 0xb7ead408
ecx = 0x0000000a, edx = 0x08b7ead8
eip = 0x08b09659

Memory Information
MemTotal:   509368 KB
MemFree:     49196 KB
Buffers:     11200 KB
Cached:     258468 KB
VmPeak:     276072 KB
VmSize:     255364 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      105812 KB
VmRSS:       95580 KB
VmData:     110856 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:       95460 KB
VmPTE:         240 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
aa8ed000 aa8ff000 r-xp /usr/lib/libhogweed.so.2.0
aa900000 aa960000 r-xp /usr/lib/sse2/libgmp.so.10.0.1
aa967000 aa98d000 r-xp /usr/lib/libnettle.so.4.0
aa98e000 aaa58000 r-xp /usr/lib/libgnutls.so.26.22.4
aaa6e000 aaa7f000 r-xp /usr/lib/gio/modules/libgiognutls.so
ace68000 ace6a000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
ad66c000 ad66e000 r-xp /usr/lib/remix/libeet_sndfile_reader.so
ad66f000 ad672000 r-xp /usr/lib/remix/libtizen_sound_player.so.1.0.0
ad673000 ad674000 r-xp /usr/lib/edje/modules/multisense_factory/linux-gnu-i686-1.0.0/module.so
ad67a000 ad69e000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
ae17b000 ae180000 r-xp /usr/lib/libefl-assist.so.0.1.0
af95f000 af9d2000 r-xp /usr/lib/host-gl/libGL.so.1.2
af9f5000 afa03000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afa04000 afa3b000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afbaf000 afbbd000 r-xp /usr/lib/libudev.so.0.13.1
afbbe000 afc00000 r-xp /usr/lib/libSLP-location.so.0.0.0
afd0e000 afd14000 r-xp /usr/lib/libmemenv.so.1.1.0
afd15000 afd5e000 r-xp /usr/lib/libleveldb.so.1.1.0
afd60000 afd6b000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd6c000 afda8000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afdaa000 afdbf000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afdc0000 afde0000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afde2000 afe18000 r-xp /usr/lib/libxslt.so.1.1.16
afe19000 afe21000 r-xp /usr/lib/libeeze.so.1.7.99
afe22000 afe27000 r-xp /usr/lib/libeukit.so.1.7.99
afe28000 afe32000 r-xp /usr/lib/libenchant.so.1.6.1
afe33000 afe3d000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe3e000 afe4a000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afe4b000 afe7a000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afe80000 afe84000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afe85000 afe91000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
aff5b000 aff75000 r-xp /usr/lib/libnetwork.so.0.0.0
affa4000 b1f8f000 r-xp /usr/lib/libewebkit2.so.0.11.72
b22bb000 b22c9000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b24e7000 b24e8000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
b2580000 b25b0000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b25b1000 b2604000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2605000 b260b000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b260c000 b2611000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2612000 b265a000 r-xp /usr/lib/libpulse.so.0.12.4
b265b000 b265f000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b2660000 b2752000 r-xp /usr/lib/libasound.so.2.0.0
b2756000 b277b000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b277c000 b2790000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2791000 b2871000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b2876000 b28d5000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b28d6000 b28e2000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b28e3000 b28f6000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b28f7000 b28fa000 r-xp /usr/lib/libmm_ta.so.0.0.0
b28fb000 b2912000 r-xp /usr/lib/libICE.so.6.3.0
b2915000 b291c000 r-xp /usr/lib/libSM.so.6.0.1
b291d000 b291e000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b291f000 b292a000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b292b000 b2930000 r-xp /usr/lib/libsysman.so.0.2.0
b2931000 b293c000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2940000 b2944000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2945000 b29a2000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b29a4000 b29ac000 r-xp /usr/lib/libxcb-render.so.0.0.0
b29ad000 b29af000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b29b0000 b2a13000 r-xp /usr/lib/libtiff.so.5.1.0
b2a16000 b2a68000 r-xp /usr/lib/libturbojpeg.so
b2a79000 b2a80000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2a81000 b2a8a000 r-xp /usr/lib/libgif.so.4.1.6
b2a8b000 b2ab1000 r-xp /usr/lib/libavutil.so.51.73.101
b2ab8000 b2afd000 r-xp /usr/lib/libswscale.so.2.1.101
b2afe000 b2e63000 r-xp /usr/lib/libavcodec.so.54.59.100
b3184000 b31ab000 r-xp /usr/lib/libpng12.so.0.50.0
b31ac000 b31b3000 r-xp /usr/lib/libfeedback.so.0.1.4
b31b4000 b31c3000 r-xp /usr/lib/libtts.so
b31c4000 b31da000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b31db000 b32f5000 r-xp /usr/lib/libcairo.so.2.11200.12
b32f8000 b331c000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b331d000 b4103000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4173000 b4179000 r-xp /usr/lib/libslp_devman_plugin.so
b417a000 b417c000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b417d000 b4180000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4181000 b4185000 r-xp /usr/lib/libdevice-node.so.0.1
b4186000 b4194000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4195000 b419e000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b419f000 b41a5000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41a6000 b41a8000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b41a9000 b41ad000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b41ae000 b41b5000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b41b6000 b41b9000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b41ba000 b41bb000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41bc000 b41cf000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b41d1000 b41d9000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41da000 b420a000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b420b000 b420f000 r-xp /usr/lib/libuuid.so.1.3.0
b4210000 b4221000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4222000 b4223000 r-xp /usr/lib/libpmapi.so.1.2
b4224000 b4230000 r-xp /usr/lib/libminizip.so.1.0.0
b4231000 b4242000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4243000 b426b000 r-xp /usr/lib/libpcre.so.0.0.1
b426c000 b4270000 r-xp /usr/lib/libheynoti.so.0.0.2
b4271000 b4276000 r-xp /usr/lib/libhaptic.so.0.1
b4277000 b4278000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4279000 b4280000 r-xp /usr/lib/libdevman.so.0.1
b4281000 b4287000 r-xp /usr/lib/libchromium.so.1.0
b4288000 b4290000 r-xp /usr/lib/libalarm.so.0.0.0
b4291000 b429a000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b429b000 b42b3000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b42b4000 b475e000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4780000 b478a000 r-xp /lib/libnss_files-2.13.so
b478c000 b4795000 r-xp /lib/libnss_nis-2.13.so
b4797000 b47aa000 r-xp /lib/libnsl-2.13.so
b47ae000 b47b4000 r-xp /lib/libnss_compat-2.13.so
b49b6000 b49d0000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b49d1000 b4b1a000 r-xp /usr/lib/libxml2.so.2.7.8
b4b20000 b4b46000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b47000 b4b4a000 r-xp /usr/lib/libiniparser.so.0
b4b4c000 b4bb5000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4bb7000 b4bd3000 r-xp /usr/lib/libcom-core.so.0.0.1
b4bd4000 b4bdb000 r-xp /usr/lib/libappsvc.so.0.1.0
b4bdc000 b4bdf000 r-xp /usr/lib/libdri2.so.0.0.0
b4be0000 b4beb000 r-xp /usr/lib/libdrm.so.2.4.0
b4bec000 b4bf1000 r-xp /usr/lib/libtbm.so.1.0.0
b4bf2000 b4bf6000 r-xp /usr/lib/libXv.so.1.0.0
b4bf7000 b4d15000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d24000 b4d39000 r-xp /usr/lib/libnotification.so.0.1.0
b4d3a000 b4d43000 r-xp /usr/lib/libutilX.so.1.1.0
b4d44000 b4d77000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d79000 b4d8a000 r-xp /lib/libresolv-2.13.so
b4d8e000 b4d91000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d92000 b4ef7000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4efb000 b506b000 r-xp /usr/lib/libcrypto.so.1.0.0
b5083000 b50d9000 r-xp /usr/lib/libssl.so.1.0.0
b50de000 b510d000 r-xp /usr/lib/libidn.so.11.5.44
b510e000 b511d000 r-xp /usr/lib/libcares.so.2.0.0
b511e000 b5145000 r-xp /lib/libexpat.so.1.5.2
b5147000 b517a000 r-xp /usr/lib/libicule.so.48.1
b517b000 b5186000 r-xp /usr/lib/libsf_common.so
b5187000 b5263000 r-xp /usr/lib/libstdc++.so.6.0.14
b526f000 b5272000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5273000 b5298000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5299000 b529e000 r-xp /usr/lib/libffi.so.5.0.10
b529f000 b52a0000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b52a1000 b52d2000 r-xp /usr/lib/libexif.so.12.3.3
b52df000 b52eb000 r-xp /usr/lib/libethumb.so.1.7.99
b52ec000 b5350000 r-xp /usr/lib/libsndfile.so.1.0.25
b5356000 b5359000 r-xp /usr/lib/libctxdata.so.0.0.0
b535a000 b5371000 r-xp /usr/lib/libremix.so.0.0.0
b5372000 b5374000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5375000 b53a2000 r-xp /usr/lib/liblua-5.1.so
b53a3000 b53ad000 r-xp /usr/lib/libembryo.so.1.7.99
b53ae000 b53b1000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b53b2000 b5413000 r-xp /usr/lib/libcurl.so.4.3.0
b5415000 b541b000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b541c000 b542d000 r-xp /usr/lib/libXext.so.6.4.0
b542e000 b5433000 r-xp /usr/lib/libXtst.so.6.1.0
b5434000 b543c000 r-xp /usr/lib/libXrender.so.1.3.0
b543d000 b5446000 r-xp /usr/lib/libXrandr.so.2.2.0
b5447000 b5449000 r-xp /usr/lib/libXinerama.so.1.0.0
b544a000 b5458000 r-xp /usr/lib/libXi.so.6.1.0
b5459000 b545d000 r-xp /usr/lib/libXfixes.so.3.1.0
b545e000 b5460000 r-xp /usr/lib/libXgesture.so.7.0.0
b5461000 b5463000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5464000 b5466000 r-xp /usr/lib/libXdamage.so.1.1.0
b5467000 b5471000 r-xp /usr/lib/libXcursor.so.1.0.2
b5472000 b5509000 r-xp /usr/lib/libpixman-1.so.0.28.2
b550e000 b5543000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5545000 b55ca000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b55d4000 b55ea000 r-xp /usr/lib/libfribidi.so.0.3.1
b55eb000 b5670000 r-xp /usr/lib/libfreetype.so.6.8.1
b5674000 b56bb000 r-xp /usr/lib/libjpeg.so.8.0.2
b56cc000 b56eb000 r-xp /lib/libz.so.1.2.5
b56ec000 b56f8000 r-xp /usr/lib/libemotion.so.1.7.99
b56f9000 b56ff000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5701000 b5711000 r-xp /usr/lib/libsensor.so.1.1.0
b5714000 b571a000 r-xp /usr/lib/libappcore-common.so.1.1
b6823000 b697e000 r-xp /usr/lib/libicuuc.so.48.1
b698c000 b6b6b000 r-xp /usr/lib/libicui18n.so.48.1
b6b72000 b6b75000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b76000 b6b82000 r-xp /usr/lib/libvconf.so.0.2.45
b6b83000 b6b8c000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6b8d000 b6b9e000 r-xp /usr/lib/libail.so.0.1.0
b6b9f000 b6baf000 r-xp /usr/lib/libaul.so.0.1.0
b6bb0000 b6c00000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c01000 b6c44000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c46000 b6ca1000 r-xp /usr/lib/libeina.so.1.7.99
b6ca3000 b6cc2000 r-xp /usr/lib/libecore.so.1.7.99
b6cd1000 b6cfc000 r-xp /usr/lib/libecore_con.so.1.7.99
b6cfe000 b6d09000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d0a000 b6d16000 r-xp /usr/lib/libedbus.so.1.7.99
b6d17000 b6d1a000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d1b000 b6d21000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d22000 b6d44000 r-xp /usr/lib/libefreet.so.1.7.99
b6d46000 b6ddd000 r-xp /usr/lib/libedje.so.1.7.99
b6ddf000 b6df6000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e0a000 b6e11000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e12000 b6e3f000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e41000 b6f4b000 r-xp /usr/lib/libevas.so.1.7.99
b6f66000 b6f83000 r-xp /usr/lib/libeet.so.1.7.99
b6f84000 b6fa8000 r-xp /lib/libm-2.13.so
b6faa000 b717a000 r-xp /usr/lib/libelementary.so.1.7.99
b7185000 b7186000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b7193000 b7195000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7198000 b719c000 r-xp /lib/libattr.so.1.1.0
b719d000 b719f000 r-xp /usr/lib/libXau.so.6.0.0
b71a1000 b71a8000 r-xp /lib/librt-2.13.so
b71aa000 b71b2000 r-xp /lib/libcrypt-2.13.so
b71db000 b71de000 r-xp /lib/libcap.so.2.21
b71df000 b71e1000 r-xp /usr/lib/libiri.so
b71e2000 b71fc000 r-xp /lib/libgcc_s-4.5.3.so.1
b71fd000 b721d000 r-xp /usr/lib/libxcb.so.1.1.0
b721f000 b7228000 r-xp /lib/libunwind.so.8.0.1
b7232000 b7388000 r-xp /lib/libc-2.13.so
b738e000 b7393000 r-xp /usr/lib/libsmack.so.1.0.0
b7394000 b73e0000 r-xp /usr/lib/libdbus-1.so.3.7.2
b73e1000 b73e6000 r-xp /usr/lib/libbundle.so.0.1.22
b73e7000 b73e9000 r-xp /lib/libdl-2.13.so
b73ec000 b7515000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7516000 b752b000 r-xp /lib/libpthread-2.13.so
b7530000 b7531000 r-xp /usr/lib/libdlog.so.0.0.0
b7532000 b75dc000 r-xp /usr/lib/libsqlite3.so.0.8.6
b75df000 b75eb000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b75ec000 b7721000 r-xp /usr/lib/libX11.so.6.3.0
b7726000 b772e000 r-xp /usr/lib/libecore_imf.so.1.7.99
b772f000 b7734000 r-xp /usr/lib/libappcore-efl.so.1.1
b7736000 b773a000 r-xp /usr/lib/libsys-assert.so
b773e000 b773f000 r-xp [vdso]
b773f000 b775b000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:4718)
Call Stack Count: 15
 0: g_io_unix_dispatch + 0x4b (0xb747750b) [/usr/lib/libglib-2.0.so.0] + 0x8b50b
 1: g_main_context_dispatch + 0x133 (0xb7434a13) [/usr/lib/libglib-2.0.so.0] + 0x48a13
 2: _ecore_glib_select + 0x3fb (0xb6cb6d5b) [/usr/lib/libecore.so.1] + 0x13d5b
 3: _ecore_main_select + 0x3a5 (0xb6cb0595) [/usr/lib/libecore.so.1] + 0xd595
 4: _ecore_main_loop_iterate_internal + 0x2a3 (0xb6cb0fd3) [/usr/lib/libecore.so.1] + 0xdfd3
 5: ecore_main_loop_iterate + 0x38 (0xb6cb13a8) [/usr/lib/libecore.so.1] + 0xe3a8
 6: elm_shutdown + 0x55 (0xb709a555) [/usr/lib/libelementary.so.1] + 0xf0555
 7: ea_mod_shutdown + 0xb0 (0xae17ccc0) [/usr/lib/libefl-assist.so.0] + 0x1cc0
 8: _dl_fini + 0x1d4 (0xb774e1d4) [/lib/ld-linux.so.2] + 0xf1d4
 9: __run_exit_handlers + 0xdf (0xb726183f) [/lib/libc.so.6] + 0x2f83f
10: __GI_exit + 0x2f (0xb726189f) [/lib/libc.so.6] + 0x2f89f
11: __launchpad_main_loop + 0x1c23 (0x804bfa3) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bfa3
12: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
13: __libc_start_main + 0xe6 (0xb7248da6) [/lib/libc.so.6] + 0x16da6
14: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
