S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 7994
Date: 2013-07-30 19:06:29(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=7994 tid=7994
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 7994, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0xbfa323c8, esi = 0x00000000
ebp = 0xbfa323e8, esp = 0xbfa3237c
eax = 0x08936094, ebx = 0xb4776a10
ecx = 0x0000000a, edx = 0x08c0a338
eip = 0x0893608c

Memory Information
MemTotal:   509368 KB
MemFree:     35408 KB
Buffers:      4416 KB
Cached:     289500 KB
VmPeak:     222820 KB
VmSize:     213244 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       91736 KB
VmRSS:       84116 KB
VmData:      69152 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100824 KB
VmPTE:         212 KB
VmSwap:         16 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
ac3c7000 ac3c8000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
ac3c9000 ac3ed000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
ac427000 ac429000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
af95f000 af9d2000 r-xp /usr/lib/host-gl/libGL.so.1.2
af9f5000 afa03000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afa04000 afa3b000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afb96000 afb98000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afb99000 afba0000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afba1000 afbae000 r-xp /usr/lib/libdrm-client.so.0.0.1
afbaf000 afbbd000 r-xp /usr/lib/libudev.so.0.13.1
afbbe000 afc00000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc01000 afc8d000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afc93000 afc9d000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afc9e000 afcb6000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afcb7000 afcbd000 r-xp /usr/lib/libmmffile.so.0.0.0
afcbe000 afcc6000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afcc7000 afcc9000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afcca000 afceb000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afcec000 afcee000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afcef000 afd0d000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd0e000 afd14000 r-xp /usr/lib/libmemenv.so.1.1.0
afd15000 afd5e000 r-xp /usr/lib/libleveldb.so.1.1.0
afd60000 afd6b000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd6c000 afda8000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afdaa000 afdbf000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afdc0000 afde0000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afde2000 afe18000 r-xp /usr/lib/libxslt.so.1.1.16
afe19000 afe21000 r-xp /usr/lib/libeeze.so.1.7.99
afe22000 afe27000 r-xp /usr/lib/libeukit.so.1.7.99
afe28000 afe32000 r-xp /usr/lib/libenchant.so.1.6.1
afe33000 afe3d000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe3e000 afe4a000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afe4b000 afe7a000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afe80000 afe84000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afe85000 afe91000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afe93000 afe9a000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afe9b000 afeaa000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afeab000 afeae000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
afeaf000 afec0000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
afec1000 afef0000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
afef1000 afef7000 r-xp /usr/lib/libogg.so.0.7.1
afef8000 aff23000 r-xp /usr/lib/libvorbis.so.0.4.3
aff24000 aff29000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff2a000 aff2e000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff2f000 aff34000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff35000 aff5a000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
aff5b000 aff75000 r-xp /usr/lib/libnetwork.so.0.0.0
aff77000 affa3000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
affa4000 b1f8f000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2089000 b21f4000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b2200000 b2284000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2286000 b22a2000 r-xp /usr/lib/libwifi-direct.so.0.0
b22a3000 b22ae000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b22af000 b22ba000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b22bb000 b22c9000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b22ca000 b236c000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2372000 b2484000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b248a000 b24af000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b24b1000 b24de000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b24f0000 b257b000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2580000 b25b0000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b25b1000 b2604000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2605000 b260b000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b260c000 b2611000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2612000 b265a000 r-xp /usr/lib/libpulse.so.0.12.4
b265b000 b265f000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b2660000 b2752000 r-xp /usr/lib/libasound.so.2.0.0
b2756000 b277b000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b277c000 b2790000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2791000 b2871000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b2876000 b28d5000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b28d6000 b28e2000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b28e3000 b28f6000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b28f7000 b28fa000 r-xp /usr/lib/libmm_ta.so.0.0.0
b28fb000 b2912000 r-xp /usr/lib/libICE.so.6.3.0
b2915000 b291c000 r-xp /usr/lib/libSM.so.6.0.1
b291d000 b291e000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b291f000 b292a000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b292b000 b2930000 r-xp /usr/lib/libsysman.so.0.2.0
b2931000 b293c000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b2940000 b2944000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2945000 b29a2000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b29a4000 b29ac000 r-xp /usr/lib/libxcb-render.so.0.0.0
b29ad000 b29af000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b29b0000 b2a13000 r-xp /usr/lib/libtiff.so.5.1.0
b2a16000 b2a68000 r-xp /usr/lib/libturbojpeg.so
b2a79000 b2a80000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2a81000 b2a8a000 r-xp /usr/lib/libgif.so.4.1.6
b2a8b000 b2ab1000 r-xp /usr/lib/libavutil.so.51.73.101
b2ab8000 b2afd000 r-xp /usr/lib/libswscale.so.2.1.101
b2afe000 b2e63000 r-xp /usr/lib/libavcodec.so.54.59.100
b3184000 b31ab000 r-xp /usr/lib/libpng12.so.0.50.0
b31ac000 b31b3000 r-xp /usr/lib/libfeedback.so.0.1.4
b31b4000 b31c3000 r-xp /usr/lib/libtts.so
b31c4000 b31da000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b31db000 b32f5000 r-xp /usr/lib/libcairo.so.2.11200.12
b32f8000 b331c000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b331d000 b4103000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4173000 b4179000 r-xp /usr/lib/libslp_devman_plugin.so
b417a000 b417c000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b417d000 b4180000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4181000 b4185000 r-xp /usr/lib/libdevice-node.so.0.1
b4186000 b4194000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4195000 b419e000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b419f000 b41a5000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41a6000 b41a8000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b41a9000 b41ad000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b41ae000 b41b5000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b41b6000 b41b9000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b41ba000 b41bb000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41bc000 b41cf000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b41d1000 b41d9000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41da000 b420a000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b420b000 b420f000 r-xp /usr/lib/libuuid.so.1.3.0
b4210000 b4221000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4222000 b4223000 r-xp /usr/lib/libpmapi.so.1.2
b4224000 b4230000 r-xp /usr/lib/libminizip.so.1.0.0
b4231000 b4242000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4243000 b426b000 r-xp /usr/lib/libpcre.so.0.0.1
b426c000 b4270000 r-xp /usr/lib/libheynoti.so.0.0.2
b4271000 b4276000 r-xp /usr/lib/libhaptic.so.0.1
b4277000 b4278000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4279000 b4280000 r-xp /usr/lib/libdevman.so.0.1
b4281000 b4287000 r-xp /usr/lib/libchromium.so.1.0
b4288000 b4290000 r-xp /usr/lib/libalarm.so.0.0.0
b4291000 b429a000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b429b000 b42b3000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b42b4000 b475e000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4780000 b478a000 r-xp /lib/libnss_files-2.13.so
b478c000 b4795000 r-xp /lib/libnss_nis-2.13.so
b4797000 b47aa000 r-xp /lib/libnsl-2.13.so
b47ae000 b47b4000 r-xp /lib/libnss_compat-2.13.so
b49b6000 b49d0000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b49d1000 b4b1a000 r-xp /usr/lib/libxml2.so.2.7.8
b4b20000 b4b46000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b47000 b4b4a000 r-xp /usr/lib/libiniparser.so.0
b4b4c000 b4bb5000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4bb7000 b4bd3000 r-xp /usr/lib/libcom-core.so.0.0.1
b4bd4000 b4bdb000 r-xp /usr/lib/libappsvc.so.0.1.0
b4bdc000 b4bdf000 r-xp /usr/lib/libdri2.so.0.0.0
b4be0000 b4beb000 r-xp /usr/lib/libdrm.so.2.4.0
b4bec000 b4bf1000 r-xp /usr/lib/libtbm.so.1.0.0
b4bf2000 b4bf6000 r-xp /usr/lib/libXv.so.1.0.0
b4bf7000 b4d15000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d24000 b4d39000 r-xp /usr/lib/libnotification.so.0.1.0
b4d3a000 b4d43000 r-xp /usr/lib/libutilX.so.1.1.0
b4d44000 b4d77000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d79000 b4d8a000 r-xp /lib/libresolv-2.13.so
b4d8e000 b4d91000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d92000 b4ef7000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4efb000 b506b000 r-xp /usr/lib/libcrypto.so.1.0.0
b5083000 b50d9000 r-xp /usr/lib/libssl.so.1.0.0
b50de000 b510d000 r-xp /usr/lib/libidn.so.11.5.44
b510e000 b511d000 r-xp /usr/lib/libcares.so.2.0.0
b511e000 b5145000 r-xp /lib/libexpat.so.1.5.2
b5147000 b517a000 r-xp /usr/lib/libicule.so.48.1
b517b000 b5186000 r-xp /usr/lib/libsf_common.so
b5187000 b5263000 r-xp /usr/lib/libstdc++.so.6.0.14
b526f000 b5272000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5273000 b5298000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5299000 b529e000 r-xp /usr/lib/libffi.so.5.0.10
b529f000 b52a0000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b52a1000 b52d2000 r-xp /usr/lib/libexif.so.12.3.3
b52df000 b52eb000 r-xp /usr/lib/libethumb.so.1.7.99
b52ec000 b5350000 r-xp /usr/lib/libsndfile.so.1.0.25
b5356000 b5359000 r-xp /usr/lib/libctxdata.so.0.0.0
b535a000 b5371000 r-xp /usr/lib/libremix.so.0.0.0
b5372000 b5374000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5375000 b53a2000 r-xp /usr/lib/liblua-5.1.so
b53a3000 b53ad000 r-xp /usr/lib/libembryo.so.1.7.99
b53ae000 b53b1000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b53b2000 b5413000 r-xp /usr/lib/libcurl.so.4.3.0
b5415000 b541b000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b541c000 b542d000 r-xp /usr/lib/libXext.so.6.4.0
b542e000 b5433000 r-xp /usr/lib/libXtst.so.6.1.0
b5434000 b543c000 r-xp /usr/lib/libXrender.so.1.3.0
b543d000 b5446000 r-xp /usr/lib/libXrandr.so.2.2.0
b5447000 b5449000 r-xp /usr/lib/libXinerama.so.1.0.0
b544a000 b5458000 r-xp /usr/lib/libXi.so.6.1.0
b5459000 b545d000 r-xp /usr/lib/libXfixes.so.3.1.0
b545e000 b5460000 r-xp /usr/lib/libXgesture.so.7.0.0
b5461000 b5463000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5464000 b5466000 r-xp /usr/lib/libXdamage.so.1.1.0
b5467000 b5471000 r-xp /usr/lib/libXcursor.so.1.0.2
b5472000 b5509000 r-xp /usr/lib/libpixman-1.so.0.28.2
b550e000 b5543000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5545000 b55ca000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b55d4000 b55ea000 r-xp /usr/lib/libfribidi.so.0.3.1
b55eb000 b5670000 r-xp /usr/lib/libfreetype.so.6.8.1
b5674000 b56bb000 r-xp /usr/lib/libjpeg.so.8.0.2
b56cc000 b56eb000 r-xp /lib/libz.so.1.2.5
b56ec000 b56f8000 r-xp /usr/lib/libemotion.so.1.7.99
b56f9000 b56ff000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5701000 b5711000 r-xp /usr/lib/libsensor.so.1.1.0
b5714000 b571a000 r-xp /usr/lib/libappcore-common.so.1.1
b6823000 b697e000 r-xp /usr/lib/libicuuc.so.48.1
b698c000 b6b6b000 r-xp /usr/lib/libicui18n.so.48.1
b6b72000 b6b75000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b76000 b6b82000 r-xp /usr/lib/libvconf.so.0.2.45
b6b83000 b6b8c000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6b8d000 b6b9e000 r-xp /usr/lib/libail.so.0.1.0
b6b9f000 b6baf000 r-xp /usr/lib/libaul.so.0.1.0
b6bb0000 b6c00000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c01000 b6c44000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c46000 b6ca1000 r-xp /usr/lib/libeina.so.1.7.99
b6ca3000 b6cc2000 r-xp /usr/lib/libecore.so.1.7.99
b6cd1000 b6cfc000 r-xp /usr/lib/libecore_con.so.1.7.99
b6cfe000 b6d09000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d0a000 b6d16000 r-xp /usr/lib/libedbus.so.1.7.99
b6d17000 b6d1a000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d1b000 b6d21000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d22000 b6d44000 r-xp /usr/lib/libefreet.so.1.7.99
b6d46000 b6ddd000 r-xp /usr/lib/libedje.so.1.7.99
b6ddf000 b6df6000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e0a000 b6e11000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e12000 b6e3f000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e41000 b6f4b000 r-xp /usr/lib/libevas.so.1.7.99
b6f66000 b6f83000 r-xp /usr/lib/libeet.so.1.7.99
b6f84000 b6fa8000 r-xp /lib/libm-2.13.so
b6faa000 b717a000 r-xp /usr/lib/libelementary.so.1.7.99
b7185000 b7186000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b7187000 b7192000 r-xp /usr/lib/libcapi-web-favorites.so
b7193000 b7195000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7198000 b719c000 r-xp /lib/libattr.so.1.1.0
b719d000 b719f000 r-xp /usr/lib/libXau.so.6.0.0
b71a1000 b71a8000 r-xp /lib/librt-2.13.so
b71aa000 b71b2000 r-xp /lib/libcrypt-2.13.so
b71db000 b71de000 r-xp /lib/libcap.so.2.21
b71df000 b71e1000 r-xp /usr/lib/libiri.so
b71e2000 b71fc000 r-xp /lib/libgcc_s-4.5.3.so.1
b71fd000 b721d000 r-xp /usr/lib/libxcb.so.1.1.0
b721f000 b7228000 r-xp /lib/libunwind.so.8.0.1
b7232000 b7388000 r-xp /lib/libc-2.13.so
b738e000 b7393000 r-xp /usr/lib/libsmack.so.1.0.0
b7394000 b73e0000 r-xp /usr/lib/libdbus-1.so.3.7.2
b73e1000 b73e6000 r-xp /usr/lib/libbundle.so.0.1.22
b73e7000 b73e9000 r-xp /lib/libdl-2.13.so
b73ec000 b7515000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7516000 b752b000 r-xp /lib/libpthread-2.13.so
b7530000 b7531000 r-xp /usr/lib/libdlog.so.0.0.0
b7532000 b75dc000 r-xp /usr/lib/libsqlite3.so.0.8.6
b75df000 b75eb000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b75ec000 b7721000 r-xp /usr/lib/libX11.so.6.3.0
b7726000 b772e000 r-xp /usr/lib/libecore_imf.so.1.7.99
b772f000 b7734000 r-xp /usr/lib/libappcore-efl.so.1.1
b7736000 b773a000 r-xp /usr/lib/libsys-assert.so
b773e000 b773f000 r-xp [vdso]
b773f000 b775b000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:7994)
Call Stack Count: 17
 0: g_io_unix_dispatch + 0x4b (0xb747750b) [/usr/lib/libglib-2.0.so.0] + 0x8b50b
 1: g_main_context_dispatch + 0x133 (0xb7434a13) [/usr/lib/libglib-2.0.so.0] + 0x48a13
 2: _ecore_glib_select + 0x3fb (0xb6cb6d5b) [/usr/lib/libecore.so.1] + 0x13d5b
 3: _ecore_main_select + 0x3a5 (0xb6cb0595) [/usr/lib/libecore.so.1] + 0xd595
 4: _ecore_main_loop_iterate_internal + 0x2a3 (0xb6cb0fd3) [/usr/lib/libecore.so.1] + 0xdfd3
 5: ecore_main_loop_iterate + 0x38 (0xb6cb13a8) [/usr/lib/libecore.so.1] + 0xe3a8
 6: elm_shutdown + 0x55 (0xb709a555) [/usr/lib/libelementary.so.1] + 0xf0555
 7: appcore_efl_main + 0x4b3 (0xb7732373) [/usr/lib/libappcore-efl.so.1] + 0x3373
 8: app_efl_main + 0xe8 (0xb41c0d98) [/usr/lib/libcapi-appfw-application.so.0] + 0x4d98
 9: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x122 (0xb43b7612) [/usr/lib/osp/libosp-appfw.so] + 0x103612
10: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3cd3ea1) [/usr/lib/osp/libosp-uifw.so] + 0x9b6ea1
11: OspMain + 0x19f (0xb252601f) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3601f
12: main + 0x503 (0xb71940c3) [/opt/apps/docomo6003/bin/MyHondana] + 0x10c3
13: __launchpad_main_loop + 0x1c17 (0x804bf97) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bf97
14: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
15: __libc_start_main + 0xe6 (0xb7248da6) [/lib/libc.so.6] + 0x16da6
16: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)

Latest Debug Message Information
--------- beginning of /dev/log_main
07-30 17:10:49.052 E/Tizen::Io( 6709): result Tizen::Io::Registry::GetValue(const Tizen::Base::String&, const Tizen::Base::String&, Tizen::Base::String&) const(321) > [E_INVALID_ARG] entryName.GetLength() <= 0
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Base::String HttpCommunicationService::findSessionId(Tizen::Base::String)(388) > (-)findSessionId
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(235) > createHttpPost() cookie1 = 
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(236) > createHttpPost() cookie2 = 
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(243) > createHttpPost() isValidCookie is false
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(249) > createHttpPost() if (!isValidCookie)
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(258) > createHttpPost() Cookie1 = visitInfo=%7B%22access_id%22%3A%22v9v3mmu1oqrc7pibjj9irt0jq0_1375171553%22%2C%22campaign_cd%22%3A%22%22%2C%22access_cnt%22%3A1%7D;
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(261) > createHttpPost() Cookie2 = v9v3mmu1oqrc7pibjj9irt0jq0; visitInfo=%7B%22access_id%22%3A%22v9v3mmu1oqrc7pibjj9irt0jq0_1375171553%22%2C%22campaign_cd%22%3A%22%22%2C%22access_cnt%22%3A1%7D;
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(263) > createHttpPost() sessionId.GetLength = 26
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(264) > createHttpPost() sessionId = v9v3mmu1oqrc7pibjj9irt0jq0
07-30 17:10:49.052 E/Tizen::Net::Http( 6709): result Tizen::Net::Http::_HttpRequestImpl::SetCookie(const Tizen::Base::String&)(676) > [E_INVALID_STATE] The cookieFlag of HttpSession is invalid.
07-30 17:10:49.052 E/Tizen::Net::Http( 6709): result Tizen::Net::Http::HttpRequest::SetCookie(const Tizen::Base::String&)(216) > [E_INVALID_STATE] Propagating.
07-30 17:10:49.052 E/Tizen::Text( 6709): static Tizen::Text::_EncodingCore* Tizen::Text::_Ucs2EncodingCore::GetEncodingCoreImplN(const Tizen::Base::String&, const Tizen::Base::String&)(60) > [E_UNSUPPORTED_TYPE] It is the unsupported type
07-30 17:10:49.052 E/Tizen::Text( 6709): static Tizen::Text::_EncodingCore* Tizen::Text::_Ucs2EncodingCore::GetEncodingCoreImplN(const Tizen::Base::String&, const Tizen::Base::String&)(60) > [E_UNSUPPORTED_TYPE] It is the unsupported type
07-30 17:10:49.052 I/MyHondana( 6709): Tizen::Net::Http::HttpTransaction *HttpCommunicationService::createHttpPost(Tizen::Base::Collection::HashMap *, bool, Tizen::App::App *, Tizen::Base::String)(330) > createHttpPost() if (requestParam->GetCount() > 0)
07-30 17:10:49.052 I/MyHondana( 6709): void HttpCommunicationService::postRequest(Tizen::Net::Http::HttpTransaction *)(462) > postRequest
07-30 17:10:49.052 I/MyHondana( 6709): void MyHondanaMainForm::ParseAndDisplay()(1542) > After traverse
07-30 17:10:49.072 E/Tizen::App( 6709): virtual Tizen::Graphics::Bitmap* Tizen::App::_AppResourceBitmap::GetBitmapN(const Tizen::Base::String&, Tizen::Graphics::BitmapPixelFormat, bool) const(84) > [E_FILE_NOT_FOUND] The specified file does not exist.
07-30 17:10:49.072 E/Tizen::App( 6709): virtual Tizen::Graphics::Bitmap* Tizen::App::_AppResourceBitmap::GetBitmapN(const Tizen::Base::String&, Tizen::Graphics::BitmapPixelFormat, bool) const(84) > [E_FILE_NOT_FOUND] The specified file does not exist.
07-30 17:10:49.072 E/Tizen::App( 6709): virtual Tizen::Graphics::Bitmap* Tizen::App::_AppResourceBitmap::GetBitmapN(const Tizen::Base::String&, Tizen::Graphics::BitmapPixelFormat, bool) const(84) > [E_FILE_NOT_FOUND] The specified file does not exist.
07-30 17:10:49.082 E/Tizen::Ui::Controls( 6709): result Tizen::Ui::Controls::_IconListPresenter::SetItemLayoutVerticalAlignment(Tizen::Ui::Controls::VerticalAlignment)(1148) > [E_INVALID_OPERATION] This isn't horizontal scroll.
07-30 17:10:49.082 E/Tizen::Ui( 6709): virtual result Tizen::Ui::Controls::_IconListView::SetProperty(const Tizen::Base::String&, const Tizen::Ui::Variant&)(86) > [E_INVALID_OPERATION] Propagating.
07-30 17:10:49.082 E/Tizen::Ui( 6709): result Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool)(159) > [E_INVALID_ARG] The child control is already attached to this container.
07-30 17:10:49.082 E/Tizen::Ui( 6709): result Tizen::Ui::Container::AddControl(Tizen::Ui::Control*)(150) > [E_INVALID_ARG] Propagating.
07-30 17:10:49.082 E/Tizen::Ui::Controls( 6709): static Tizen::Ui::Controls::_ScrollPresenter* Tizen::Ui::Controls::_ScrollPresenter::CreateScrollPresenterN(Tizen::Ui::_Control&, Tizen::Ui::Controls::_Scroll&, Tizen::Ui::Controls::_ScrollDirection, bool, bool, bool, bool, float, float, float)(195) > [E_INVALID_ARG] Invalid arguments
07-30 17:10:49.082 E/Tizen::Ui::Controls( 6709): result Tizen::Ui::Controls::_Scroll::Construct(Tizen::Ui::_Control&, Tizen::Ui::Controls::_ScrollDirection, bool, bool, bool, bool, float, float, float)(102) > [E_INVALID_ARG] [E_INVALID_ARG] Propagating.
07-30 17:10:49.082 E/Tizen::Ui::Controls( 6709): static Tizen::Ui::Controls::_Scroll* Tizen::Ui::Controls::_Scroll::CreateScrollN(Tizen::Ui::_Control&, Tizen::Ui::Controls::_ScrollDirection, bool, bool, bool, bool, float, float, float)(72) > [E_INVALID_ARG] Propagating
07-30 17:10:49.082 E/Tizen::Ui::Controls( 6709): virtual void Tizen::Ui::Controls::_TableView::OnBoundsChanged()(1270) > [E_OUT_OF_MEMORY] The memory is insufficient.
07-30 17:10:49.082 E/Tizen::Ui( 6709): result Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool)(159) > [E_INVALID_ARG] The child control is already attached to this container.
07-30 17:10:49.082 E/Tizen::Ui( 6709): result Tizen::Ui::Container::AddControl(Tizen::Ui::Control*)(150) > [E_INVALID_ARG] Propagating.
07-30 17:10:49.442 E/Tizen::Ui( 6709): bool Tizen::Ui::_Control::IsVisible() const(2938) > [E_SYSTEM] This control should be attached to the main tree.
07-30 17:10:49.442 D/MyHondana( 6709): virtual Tizen::Ui::Controls::IconListViewItem *CoverFlowPanel::CreateItem(int)(109) > GetName() = CoverFlowPanel
07-30 17:10:49.452 D/MyHondana( 6709): virtual Tizen::Ui::Controls::IconListViewItem *CoverFlowPanel::CreateItem(int)(109) > GetName() = CoverFlowPanel
07-30 17:10:49.472 D/MyHondana( 6709): virtual Tizen::Ui::Controls::IconListViewItem *CoverFlowPanel::CreateItem(int)(109) > GetName() = CoverFlowPanel
07-30 17:10:49.482 D/MyHondana( 6709): virtual Tizen::Ui::Controls::IconListViewItem *CoverFlowPanel::CreateItem(int)(109) > GetName() = CoverFlowPanel
07-30 17:10:49.502 D/MyHondana( 6709): virtual Tizen::Ui::Controls::IconListViewItem *CoverFlowPanel::CreateItem(int)(109) > GetName() = CoverFlowPanel
07-30 17:10:49.632 E/Tizen::Graphics( 6709): result Tizen::Graphics::_BitmapImpl::Construct(const Tizen::Graphics::_CanvasImpl&, const Tizen::Graphics::FloatRectangle&)(1011) > [E_INVALID_ARG] Both of width(0.000000) and height(0.000000) of a rectangle MUST be greater than 0.
07-30 17:10:49.632 E/Tizen::Graphics( 6709): result Tizen::Graphics::Bitmap::Construct(const Tizen::Graphics::Canvas&, const Tizen::Graphics::FloatRectangle&)(213) > [E_INVALID_ARG] Propagating.
07-30 17:10:49.632 E/Tizen::Ui::Animations( 6709): Tizen::Graphics::Canvas* Tizen::Ui::Animations::_VisualElementImpl::GetCanvasN(const Tizen::Graphics::FloatRectangle&)(3558) > [E_INVALID_STATE] VisualElement is not attached to main tree.
07-30 17:10:49.632 E/Tizen::Ui::Controls( 6709): virtual void Tizen::Ui::Controls::_PopupPresenter::Draw()(434) > [E_INVALID_STATE] Propagating.
07-30 17:10:49.632 E/Tizen::Ui::Controls( 6709): virtual void Tizen::Ui::Controls::_Popup::OnDraw()(463) > [E_INVALID_STATE] Propagating.
07-30 17:10:49.632 E/Tizen::Ui::Animations( 6709): Tizen::Graphics::Canvas* Tizen::Ui::Animations::_VisualElementImpl::GetCanvasN(const Tizen::Graphics::FloatRectangle&)(3558) > [E_INVALID_STATE] VisualElement is not attached to main tree.
07-30 17:10:49.632 E/Tizen::Ui::Controls( 6709): virtual void Tizen::Ui::Controls::_PopupPresenter::Draw()(434) > [E_INVALID_STATE] Propagating.
07-30 17:10:49.632 E/Tizen::Ui::Controls( 6709): virtual void Tizen::Ui::Controls::_Popup::OnDraw()(463) > [E_INVALID_STATE] Propagating.
07-30 17:10:49.642 E/Tizen::Graphics( 6709): result Tizen::Graphics::_Text::TextObject::SetBounds(const Tizen::Graphics::FloatRectangle&)(1127) > [E_OUT_OF_RANGE] The given rectangle(width:-35.000000,height:96.000000) is out of range.
07-30 17:10:49.642 E/Tizen::Graphics( 6709): result Tizen::Graphics::_Text::TextObject::SetBounds(const Tizen::Graphics::FloatRectangle&)(1127) > [E_OUT_OF_RANGE] The given rectangle(width:-35.000000,height:0.000000) is out of range.
07-30 17:10:50.162 E/Tizen::Text( 6709): static Tizen::Text::_EncodingCore* Tizen::Text::_Ucs2EncodingCore::GetEncodingCoreImplN(const Tizen::Base::String&, const Tizen::Base::String&)(60) > [E_UNSUPPORTED_TYPE] It is the unsupported type
07-30 17:10:50.162 I/MyHondana( 6709): virtual void HttpCommunicationService::OnTransactionHeaderCompleted(Tizen::Net::Http::HttpSession &, Tizen::Net::Http::HttpTransaction &, int, bool)(909) > OnTransactionHeaderCompleted
07-30 17:10:50.162 I/MyHondana( 6709): virtual void HttpCommunicationService::OnTransactionHeaderCompleted(Tizen::Net::Http::HttpSession &, Tizen::Net::Http::HttpTransaction &, int, bool)(924) > Authentication is required
07-30 17:10:50.162 I/MyHondana( 6709): virtual void HttpCommunicationService::OnTransactionHeaderCompleted(Tizen::Net::Http::HttpSession &, Tizen::Net::Http::HttpTransaction &, int, bool)(937) > Authentication
07-30 17:10:50.162 E/Tizen::Net::Http( 6709): Tizen::Base::String Tizen::Net::Http::_HttpRequestImpl::GetCookie() const(710) > [E_INVALID_STATE] Cookies is empty.
07-30 17:10:50.172 E/MyHondana( 6709): result Tizen::Base::Collection::__LinkedListEnumeratorT<Type>::MoveNext() [with Type = Tizen::Base::Runtime::_Event::_ListenerInfo, result = long unsigned int](1442) > [E_INVALID_OPERATION] The source collection is modified after the creation of this enumerator.
07-30 17:10:50.762 E/Tizen::Text( 6709): static Tizen::Text::_EncodingCore* Tizen::Text::_Ucs2EncodingCore::GetEncodingCoreImplN(const Tizen::Base::String&, const Tizen::Base::String&)(60) > [E_UNSUPPORTED_TYPE] It is the unsupported type
07-30 17:10:50.762 E/Tizen::Base::Collection( 6709): virtual result Tizen::Base::Collection::MultiHashMap::Add(Tizen::Base::Object*, Tizen::Base::Object*)(563) > [E_OBJ_ALREADY_EXIST] The value is already exist for the key.
07-30 17:10:50.762 E/Tizen::Net::Http( 6709): result Tizen::Net::Http::_HttpHeaderImpl::AddField(const Tizen::Base::String&, const Tizen::Base::String&)(193) > [E_OBJ_ALREADY_EXIST] Failed to add a header field.
07-30 17:10:50.762 I/MyHondana( 6709): virtual void HttpCommunicationService::OnTransactionHeaderCompleted(Tizen::Net::Http::HttpSession &, Tizen::Net::Http::HttpTransaction &, int, bool)(909) > OnTransactionHeaderCompleted
07-30 17:10:50.762 I/MyHondana( 6709): virtual void HttpCommunicationService::OnTransactionHeaderCompleted(Tizen::Net::Http::HttpSession &, Tizen::Net::Http::HttpTransaction &, int, bool)(978) > OnTransactionHeaderCompleted() pHeader size = 330
07-30 17:10:50.762 I/MyHondana( 6709): virtual void HttpCommunicationService::OnTransactionHeaderCompleted(Tizen::Net::Http::HttpSession &, Tizen::Net::Http::HttpTransaction &, int, bool)(979) > OnTransactionHeaderCompleted() pHeader = Expires: Thu, 19 Nov 1981 08:52:00 GMT
07-30 17:10:50.762 I/MyHondana( 6709): Connection: keep-alive
07-30 17:10:50.762 I/MyHondana( 6709): Vary: Accept-Encoding
07-30 17:10:50.762 I/MyHondana( 6709): Content-Length: 1229
07-30 17:10:50.762 I/MyHondana( 6709): Date: Tue, 30 Jul 2013 08:10:39 GMT
07-30 17:10:50.762 I/MyHondana( 6709): Content-Type: text/html; charset=UTF-8
07-30 17:10:50.762 I/MyHondana( 6709): X-Powered-By: PHP/5.2.17
07-30 17:10:50.762 I/MyHondana( 6709): Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
07-30 17:10:50.762 I/MyHondana( 6709): Server: nginx/1.2.5
07-30 17:10:50.762 I/MyHondana( 6709): Pragma: no-cache
07-30 17:10:50.762 E/Tizen::Net::Http( 6709): Tizen::Base::Collection::IEnumerator* Tizen::Net::Http::_HttpHeaderImpl::GetFieldValuesN(const Tizen::Base::String&) const(335) > [E_OBJ_NOT_FOUND] Header value not found.
07-30 17:10:50.762 E/Tizen::Net::Http( 6709): Tizen::Base::Collection::IEnumerator* Tizen::Net::Http::HttpHeader::GetFieldValuesN(const Tizen::Base::String&) const(162) > [E_OBJ_NOT_FOUND] Propagating.
07-30 17:10:50.762 I/MyHondana( 6709): virtual void HttpCommunicationService::OnTransactionReadyToRead(Tizen::Net::Http::HttpSession &, Tizen::Net::Http::HttpTransaction &, int)(766) > OnTransactionReadyToRead
07-30 17:10:50.762 E/Tizen::Text( 6709): static Tizen::Text::_EncodingCore* Tizen::Text::_Ucs2EncodingCore::GetEncodingCoreImplN(const Tizen::Base::String&, const Tizen::Base::String&)(60) > [E_UNSUPPORTED_TYPE] It is the unsupported type
07-30 17:10:50.762 I/MyHondana( 6709): virtual void HttpCommunicationService::OnTransactionCompleted(Tizen::Net::Http::HttpSession &, Tizen::Net::Http::HttpTransaction &)(812) > OnTransactionCompleted
07-30 17:10:50.762 I/MyHondana( 6709): virtual void MyHondanaMainForm::OnResponseReceived(const Tizen::Base::String &)(1639) > OnResponseReceived[1581] : Expires: Thu, 19 Nov 1981 08:52:00 GMT
07-30 17:10:50.762 I/MyHondana( 6709): Connection: keep-alive
07-30 17:10:50.762 I/MyHondana( 6709): Vary: Accept-Encoding
07-30 17:10:50.762 I/MyHondana( 6709): Content-Length: 1229
07-30 17:10:50.762 I/MyHondana( 6709): Date: Tue, 30 Jul 2013 08:10:39 GMT
07-30 17:10:50.762 I/MyHondana( 6709): Content-Type: text/html; charset=UTF-8
07-30 17:10:50.762 I/MyHondana( 6709): X-Powered-By: PHP/5.2.17
07-30 17:10:50.762 I/MyHondana( 6709): Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0
07-30 17:10:50.762 I/MyHondana( 6709): Server: nginx/1.2.5
07-30 17:10:50.762 I/MyHondana( 6709): Pragma: no-cache
07-30 17:10:50.762 I/MyHondana( 6709): 
07-30 17:10:50.762 I/MyHondana( 6709): 
07-30 17:10:50.762 I/MyHondana( 6709): =======================
07-30 17:10:50.762 I/MyHondana( 6709): 
07-30 17:10:50.762 I/MyHondana( 6709): 
07-30 17:10:50.762 I/MyHondana( 6709): <!DOCTYPE HTML>
07-30 17:10:50.762 I/MyHondana( 6709): <html lang="ja">
07-30 17:10:50.762 I/MyHondana( 6709): <head>
07-30 17:10:50.762 I/MyHondana( 6709):     <meta charset="utf-8">
07-30 17:10:50.762 I/MyHondana( 6709):     <meta name="viewport" content="width=320, initial-scale=1.0, user-scalable=yes, maximum-scale=2.0, minimum-scale=1.0, ">
07-30 17:10:50.762 I/MyHondana( 6709):     <meta http-equiv="x-xrds-location" content="http://stg.book.dmkt-sp.jp/auth/xrds" >
07-30 17:10:50.762 I/MyHondana( 6709):     <title>dブック</title>
07-30 17:10:50.762 I/MyHondana( 6709): </head>
07-30 17:10:50.762 I/MyHondana( 6709): <body>
07-30 17:10:50.762 I/MyHondana( 6709): <script>
07-30 17:10:50.762 I/MyHondana( 6709): 
07-30 17:10:50.762 I/MyHondana( 6709): window.onload = function() {
07-30 17:10:50.762 I/MyHondana( 6709):     document.getElementById('#login_form').submit();
07-30 17:10:50.762 I/MyHondana( 6709): }
07-30 17:10:50.762 I/MyHondana( 6709): 
07-30 17:10:50.762 I/MyHondana( 6709): </script>
07-30 17:10:50.762 I/MyHondana( 6709): <form id="login_form" accept-charset="UTF-8" enctype="application/x-www-form-urlencoded" action="https:/
07-30 17:10:50.762 E/MyHondana( 6709): result Tizen::Base::Collection::__LinkedListEnumeratorT<Type>::MoveNext() [with Type = Tizen::Base::Runtime::_Event::_ListenerInfo, result = long unsigned int](1442) > [E_INVALID_OPERATION] The source collection is modified after the creation of this enumerator.
07-30 17:13:48.812 E/Tizen::Base::Collection( 2208): virtual result Tizen::Base::Collection::ArrayList::IndexOf(const Tizen::Base::Object&, int, int, int&) const(293) > [E_OBJ_NOT_FOUND] The arraylist is empty.
07-30 17:13:48.812 E/Tizen::Base::Collection( 2208): virtual result Tizen::Base::Collection::ArrayList::Remove(const Tizen::Base::Object&)(396) > [E_OBJ_NOT_FOUND] Propagating.
07-30 17:13:48.822 E/Tizen::Io( 2208): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 17:13:48.832 E/Tizen::Io( 2208): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 17:13:48.832 E/Tizen::Io( 2208): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-30 17:13:49.992 E/Tizen::Base( 6961): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-30 17:13:50.002 E/Tizen::Base::Runtime( 6961): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-30 17:13:50.002 E/Tizen::Base::Runtime( 6961): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-30 17:13:50.002 I/osp-installer( 6961): int main(int, char**)(71) >  # argv[0] = [/usr/etc/package-manager/backend/tpk]
07-30 17:13:50.002 I/osp-installer( 6961): int main(int, char**)(71) >  # argv[1] = [-k]
07-30 17:13:50.002 I/osp-installer( 6961): int main(int, char**)(71) >  # argv[2] = [docomo6003_811211550]
07-30 17:13:50.002 I/osp-installer( 6961): int main(int, char**)(71) >  # argv[3] = [-r]
07-30 17:13:50.002 I/osp-installer( 6961): int main(int, char**)(71) >  # argv[4] = [docomo6003]
07-30 17:13:50.002 I/osp-installer( 6961): int main(int, char**)(71) >  # argv[5] = [-q]
07-30 17:13:50.002 I/osp-installer( 6961): int main(int, char**)(115) >  # path = [docomo6003]
07-30 17:13:50.002 I/osp-installer( 6961): int main(int, char**)(213) > rdsPackage = docomo6003
07-30 17:13:50.002 I/osp-installer( 6961): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(141) > ------------------------------------------
07-30 17:13:50.002 I/osp-installer( 6961): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(142) > InstallerManager
07-30 17:13:50.002 I/osp-installer( 6961): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(143) > ------------------------------------------
07-30 17:13:50.002 I/osp-installer( 6961): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(144) >  # operation = [Reinstall]
07-30 17:13:50.002 I/osp-installer( 6961): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(145) >  # path      = [docomo6003]
07-30 17:13:50.002 I/osp-installer( 6961): InstallerError InstallerManager::Construct(const Tizen::Base::String&, InstallerOperation, InstallerOption, void*, const Tizen::Base::String*)(146) > ------------------------------------------
07-30 17:13:50.002 I/osp-installer( 6961
End of latest debug message
