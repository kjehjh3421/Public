S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 2712
Date: 2013-07-31 13:41:57(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=2712 tid=2712
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2712, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x087825e0, esi = 0xb25586ac
ebp = 0xbf9412c8, esp = 0xbf941110
eax = 0x00000000, ebx = 0xb257ae28
ecx = 0xb25585d0, edx = 0x000003b8
eip = 0xb250fa65

Memory Information
MemTotal:   509368 KB
MemFree:     39704 KB
Buffers:     59680 KB
Cached:     218672 KB
VmPeak:     219404 KB
VmSize:     214108 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       88804 KB
VmRSS:       87220 KB
VmData:      69496 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100676 KB
VmPTE:         204 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
ac423000 ac425000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
af95b000 af9ce000 r-xp /usr/lib/host-gl/libGL.so.1.2
af9f1000 af9ff000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afa00000 afa37000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afb92000 afb94000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afb95000 afb9c000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afb9d000 afbaa000 r-xp /usr/lib/libdrm-client.so.0.0.1
afbab000 afbb9000 r-xp /usr/lib/libudev.so.0.13.1
afbba000 afbfc000 r-xp /usr/lib/libSLP-location.so.0.0.0
afbfd000 afc89000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afc8f000 afc99000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afc9a000 afcb2000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afcb3000 afcb9000 r-xp /usr/lib/libmmffile.so.0.0.0
afcba000 afcc2000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afcc3000 afcc5000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afcc6000 afce7000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afce8000 afcea000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afceb000 afd09000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd0a000 afd10000 r-xp /usr/lib/libmemenv.so.1.1.0
afd11000 afd5a000 r-xp /usr/lib/libleveldb.so.1.1.0
afd5c000 afd67000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd68000 afda4000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afda6000 afdbb000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afdbc000 afddc000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afdde000 afe14000 r-xp /usr/lib/libxslt.so.1.1.16
afe15000 afe1d000 r-xp /usr/lib/libeeze.so.1.7.99
afe1e000 afe23000 r-xp /usr/lib/libeukit.so.1.7.99
afe24000 afe2e000 r-xp /usr/lib/libenchant.so.1.6.1
afe2f000 afe39000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe3a000 afe46000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afe47000 afe76000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afe7c000 afe80000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afe81000 afe8d000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afe8f000 afe96000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afe97000 afea6000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afea7000 afeaa000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
afeab000 afebc000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
afebd000 afeec000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
afeed000 afef3000 r-xp /usr/lib/libogg.so.0.7.1
afef4000 aff1f000 r-xp /usr/lib/libvorbis.so.0.4.3
aff20000 aff25000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff26000 aff2a000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff2b000 aff30000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff31000 aff56000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
aff57000 aff71000 r-xp /usr/lib/libnetwork.so.0.0.0
aff73000 aff9f000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
affa0000 b1f8b000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2085000 b21f0000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b21fc000 b2280000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2282000 b229e000 r-xp /usr/lib/libwifi-direct.so.0.0
b229f000 b22aa000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b22ab000 b22b6000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b22b7000 b22c5000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b22c6000 b2368000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b236e000 b2480000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2486000 b24ab000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b24ad000 b24da000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b24ec000 b2577000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b257c000 b25ac000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b25ad000 b2600000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2601000 b2607000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b2608000 b260d000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b260e000 b2656000 r-xp /usr/lib/libpulse.so.0.12.4
b2657000 b265b000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b265c000 b274e000 r-xp /usr/lib/libasound.so.2.0.0
b2752000 b2777000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2778000 b278c000 r-xp /usr/lib/libmmfsound.so.0.1.0
b278d000 b286d000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b2872000 b28d1000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b28d2000 b28de000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b28df000 b28f2000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b28f3000 b28f6000 r-xp /usr/lib/libmm_ta.so.0.0.0
b28f7000 b290e000 r-xp /usr/lib/libICE.so.6.3.0
b2911000 b2918000 r-xp /usr/lib/libSM.so.6.0.1
b2919000 b291a000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b291b000 b2926000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2927000 b292c000 r-xp /usr/lib/libsysman.so.0.2.0
b292d000 b2938000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b293c000 b2940000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2941000 b299e000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b29a0000 b29a8000 r-xp /usr/lib/libxcb-render.so.0.0.0
b29a9000 b29ab000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b29ac000 b2a0f000 r-xp /usr/lib/libtiff.so.5.1.0
b2a12000 b2a64000 r-xp /usr/lib/libturbojpeg.so
b2a75000 b2a7c000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2a7d000 b2a86000 r-xp /usr/lib/libgif.so.4.1.6
b2a87000 b2aad000 r-xp /usr/lib/libavutil.so.51.73.101
b2ab4000 b2af9000 r-xp /usr/lib/libswscale.so.2.1.101
b2afa000 b2e5f000 r-xp /usr/lib/libavcodec.so.54.59.100
b3180000 b31a7000 r-xp /usr/lib/libpng12.so.0.50.0
b31a8000 b31af000 r-xp /usr/lib/libfeedback.so.0.1.4
b31b0000 b31bf000 r-xp /usr/lib/libtts.so
b31c0000 b31d6000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b31d7000 b32f1000 r-xp /usr/lib/libcairo.so.2.11200.12
b32f4000 b3318000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3319000 b40ff000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b416f000 b4175000 r-xp /usr/lib/libslp_devman_plugin.so
b4176000 b4178000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4179000 b417c000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b417d000 b4181000 r-xp /usr/lib/libdevice-node.so.0.1
b4182000 b4190000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4191000 b419a000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b419b000 b41a1000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41a2000 b41a4000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b41a5000 b41a9000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b41aa000 b41b1000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b41b2000 b41b5000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b41b6000 b41b7000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41b8000 b41cb000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b41cd000 b41d5000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41d6000 b4206000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4207000 b420b000 r-xp /usr/lib/libuuid.so.1.3.0
b420c000 b421d000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b421e000 b421f000 r-xp /usr/lib/libpmapi.so.1.2
b4220000 b422c000 r-xp /usr/lib/libminizip.so.1.0.0
b422d000 b423e000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b423f000 b4267000 r-xp /usr/lib/libpcre.so.0.0.1
b4268000 b426c000 r-xp /usr/lib/libheynoti.so.0.0.2
b426d000 b4272000 r-xp /usr/lib/libhaptic.so.0.1
b4273000 b4274000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4275000 b427c000 r-xp /usr/lib/libdevman.so.0.1
b427d000 b4283000 r-xp /usr/lib/libchromium.so.1.0
b4284000 b428c000 r-xp /usr/lib/libalarm.so.0.0.0
b428d000 b4296000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b4297000 b42af000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b42b0000 b475a000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b477c000 b4786000 r-xp /lib/libnss_files-2.13.so
b4788000 b4791000 r-xp /lib/libnss_nis-2.13.so
b4793000 b47a6000 r-xp /lib/libnsl-2.13.so
b47aa000 b47b0000 r-xp /lib/libnss_compat-2.13.so
b49b2000 b49cc000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b49cd000 b4b16000 r-xp /usr/lib/libxml2.so.2.7.8
b4b1c000 b4b42000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b43000 b4b46000 r-xp /usr/lib/libiniparser.so.0
b4b48000 b4bb1000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4bb3000 b4bcf000 r-xp /usr/lib/libcom-core.so.0.0.1
b4bd0000 b4bd7000 r-xp /usr/lib/libappsvc.so.0.1.0
b4bd8000 b4bdb000 r-xp /usr/lib/libdri2.so.0.0.0
b4bdc000 b4be7000 r-xp /usr/lib/libdrm.so.2.4.0
b4be8000 b4bed000 r-xp /usr/lib/libtbm.so.1.0.0
b4bee000 b4bf2000 r-xp /usr/lib/libXv.so.1.0.0
b4bf3000 b4d11000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d20000 b4d35000 r-xp /usr/lib/libnotification.so.0.1.0
b4d36000 b4d3f000 r-xp /usr/lib/libutilX.so.1.1.0
b4d40000 b4d73000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d75000 b4d86000 r-xp /lib/libresolv-2.13.so
b4d8a000 b4d8d000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d8e000 b4ef3000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4ef7000 b5067000 r-xp /usr/lib/libcrypto.so.1.0.0
b507f000 b50d5000 r-xp /usr/lib/libssl.so.1.0.0
b50da000 b5109000 r-xp /usr/lib/libidn.so.11.5.44
b510a000 b5119000 r-xp /usr/lib/libcares.so.2.0.0
b511a000 b5141000 r-xp /lib/libexpat.so.1.5.2
b5143000 b5176000 r-xp /usr/lib/libicule.so.48.1
b5177000 b5182000 r-xp /usr/lib/libsf_common.so
b5183000 b525f000 r-xp /usr/lib/libstdc++.so.6.0.14
b526b000 b526e000 r-xp /usr/lib/libapp-checker.so.0.1.0
b526f000 b5294000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5295000 b529a000 r-xp /usr/lib/libffi.so.5.0.10
b529b000 b529c000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b529d000 b52ce000 r-xp /usr/lib/libexif.so.12.3.3
b52db000 b52e7000 r-xp /usr/lib/libethumb.so.1.7.99
b52e8000 b534c000 r-xp /usr/lib/libsndfile.so.1.0.25
b5352000 b5355000 r-xp /usr/lib/libctxdata.so.0.0.0
b5356000 b536d000 r-xp /usr/lib/libremix.so.0.0.0
b536e000 b5370000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5371000 b539e000 r-xp /usr/lib/liblua-5.1.so
b539f000 b53a9000 r-xp /usr/lib/libembryo.so.1.7.99
b53aa000 b53ad000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b53ae000 b540f000 r-xp /usr/lib/libcurl.so.4.3.0
b5411000 b5417000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b5418000 b5429000 r-xp /usr/lib/libXext.so.6.4.0
b542a000 b542f000 r-xp /usr/lib/libXtst.so.6.1.0
b5430000 b5438000 r-xp /usr/lib/libXrender.so.1.3.0
b5439000 b5442000 r-xp /usr/lib/libXrandr.so.2.2.0
b5443000 b5445000 r-xp /usr/lib/libXinerama.so.1.0.0
b5446000 b5454000 r-xp /usr/lib/libXi.so.6.1.0
b5455000 b5459000 r-xp /usr/lib/libXfixes.so.3.1.0
b545a000 b545c000 r-xp /usr/lib/libXgesture.so.7.0.0
b545d000 b545f000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5460000 b5462000 r-xp /usr/lib/libXdamage.so.1.1.0
b5463000 b546d000 r-xp /usr/lib/libXcursor.so.1.0.2
b546e000 b5505000 r-xp /usr/lib/libpixman-1.so.0.28.2
b550a000 b553f000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5541000 b55c6000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b55d0000 b55e6000 r-xp /usr/lib/libfribidi.so.0.3.1
b55e7000 b566c000 r-xp /usr/lib/libfreetype.so.6.8.1
b5670000 b56b7000 r-xp /usr/lib/libjpeg.so.8.0.2
b56c8000 b56e7000 r-xp /lib/libz.so.1.2.5
b56e8000 b56f4000 r-xp /usr/lib/libemotion.so.1.7.99
b56f5000 b56fb000 r-xp /usr/lib/libecore_fb.so.1.7.99
b56fd000 b570d000 r-xp /usr/lib/libsensor.so.1.1.0
b5710000 b5716000 r-xp /usr/lib/libappcore-common.so.1.1
b681f000 b697a000 r-xp /usr/lib/libicuuc.so.48.1
b6988000 b6b67000 r-xp /usr/lib/libicui18n.so.48.1
b6b6e000 b6b71000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b72000 b6b7e000 r-xp /usr/lib/libvconf.so.0.2.45
b6b7f000 b6b88000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6b89000 b6b9a000 r-xp /usr/lib/libail.so.0.1.0
b6b9b000 b6bab000 r-xp /usr/lib/libaul.so.0.1.0
b6bac000 b6bfc000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6bfd000 b6c40000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c42000 b6c9d000 r-xp /usr/lib/libeina.so.1.7.99
b6c9f000 b6cbe000 r-xp /usr/lib/libecore.so.1.7.99
b6ccd000 b6cf8000 r-xp /usr/lib/libecore_con.so.1.7.99
b6cfa000 b6d05000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d06000 b6d12000 r-xp /usr/lib/libedbus.so.1.7.99
b6d13000 b6d16000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d17000 b6d1d000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d1e000 b6d40000 r-xp /usr/lib/libefreet.so.1.7.99
b6d42000 b6dd9000 r-xp /usr/lib/libedje.so.1.7.99
b6ddb000 b6df2000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e06000 b6e0d000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e0e000 b6e3b000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e3d000 b6f47000 r-xp /usr/lib/libevas.so.1.7.99
b6f62000 b6f7f000 r-xp /usr/lib/libeet.so.1.7.99
b6f80000 b6fa4000 r-xp /lib/libm-2.13.so
b6fa6000 b7176000 r-xp /usr/lib/libelementary.so.1.7.99
b7181000 b7182000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b7183000 b718e000 r-xp /usr/lib/libcapi-web-favorites.so
b718f000 b7191000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7194000 b7198000 r-xp /lib/libattr.so.1.1.0
b7199000 b719b000 r-xp /usr/lib/libXau.so.6.0.0
b719d000 b71a4000 r-xp /lib/librt-2.13.so
b71a6000 b71ae000 r-xp /lib/libcrypt-2.13.so
b71d7000 b71da000 r-xp /lib/libcap.so.2.21
b71db000 b71dd000 r-xp /usr/lib/libiri.so
b71de000 b71f8000 r-xp /lib/libgcc_s-4.5.3.so.1
b71f9000 b7219000 r-xp /usr/lib/libxcb.so.1.1.0
b721b000 b7224000 r-xp /lib/libunwind.so.8.0.1
b722e000 b7384000 r-xp /lib/libc-2.13.so
b738a000 b738f000 r-xp /usr/lib/libsmack.so.1.0.0
b7390000 b73dc000 r-xp /usr/lib/libdbus-1.so.3.7.2
b73dd000 b73e2000 r-xp /usr/lib/libbundle.so.0.1.22
b73e3000 b73e5000 r-xp /lib/libdl-2.13.so
b73e8000 b7511000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7512000 b7527000 r-xp /lib/libpthread-2.13.so
b752c000 b752d000 r-xp /usr/lib/libdlog.so.0.0.0
b752e000 b75d8000 r-xp /usr/lib/libsqlite3.so.0.8.6
b75db000 b75e7000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b75e8000 b771d000 r-xp /usr/lib/libX11.so.6.3.0
b7722000 b772a000 r-xp /usr/lib/libecore_imf.so.1.7.99
b772b000 b7730000 r-xp /usr/lib/libappcore-efl.so.1.1
b7732000 b7736000 r-xp /usr/lib/libsys-assert.so
b773a000 b773b000 r-xp [vdso]
b773b000 b7757000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:2712)
Call Stack Count: 28
 0: Tizen::Base::Runtime::_Event::ProcessListeners(std::tr1::shared_ptr<Tizen::Base::Runtime::IEventArg>) + 0x40c (0xb445b79c) [/usr/lib/osp/libosp-appfw.so] + 0x1ab79c
 1: Tizen::Base::Runtime::_Event::Fire(std::tr1::shared_ptr<Tizen::Base::Runtime::IEventArg>) + 0x62 (0xb445bc32) [/usr/lib/osp/libosp-appfw.so] + 0x1abc32
 2: Tizen::Base::Runtime::_Event::Fire(Tizen::Base::Runtime::IEventArg&) + 0x77 (0xb445bd47) [/usr/lib/osp/libosp-appfw.so] + 0x1abd47
 3: (0xb23b66e2) [/usr/lib/osp/libosp-net.so.1] + 0x486e2
 4: Tizen::Net::Http::_HttpTransactionImpl::OnHttpBodyReceived(void*, unsigned int, unsigned int, void*) + 0x186 (0xb23b82f6) [/usr/lib/osp/libosp-net.so.1] + 0x4a2f6
 5: Curl_client_write + 0x1c0 (0xb53c1bf0) [/usr/lib/libcurl.so.4] + 0x13bf0
 6: Curl_readwrite + 0x13ca (0xb53dc56a) [/usr/lib/libcurl.so.4] + 0x2e56a
 7: multi_runsingle + 0xb72 (0xb53e6272) [/usr/lib/libcurl.so.4] + 0x38272
 8: multi_socket + 0x24c (0xb53e6e2c) [/usr/lib/libcurl.so.4] + 0x38e2c
 9: curl_multi_socket_action + 0x2c (0xb53e6f3c) [/usr/lib/libcurl.so.4] + 0x38f3c
10: Tizen::Net::Http::_HttpTransactionImpl::OnSocketReceivedEvent(_GIOChannel*, GIOCondition, void*) + 0xb8 (0xb23bcc68) [/usr/lib/osp/libosp-net.so.1] + 0x4ec68
11: g_io_unix_dispatch + 0x4b (0xb747350b) [/usr/lib/libglib-2.0.so.0] + 0x8b50b
12: g_main_context_dispatch + 0x133 (0xb7430a13) [/usr/lib/libglib-2.0.so.0] + 0x48a13
13: _ecore_glib_select + 0x3fb (0xb6cb2d5b) [/usr/lib/libecore.so.1] + 0x13d5b
14: _ecore_main_select + 0x3a5 (0xb6cac595) [/usr/lib/libecore.so.1] + 0xd595
15: _ecore_main_loop_iterate_internal + 0x3b9 (0xb6cad0e9) [/usr/lib/libecore.so.1] + 0xe0e9
16: ecore_main_loop_begin + 0x3f (0xb6cad45f) [/usr/lib/libecore.so.1] + 0xe45f
17: elm_run + 0x17 (0xb7096ee7) [/usr/lib/libelementary.so.1] + 0xf0ee7
18: appcore_efl_main + 0x42e (0xb772e2ee) [/usr/lib/libappcore-efl.so.1] + 0x32ee
19: app_efl_main + 0xe8 (0xb41bcd98) [/usr/lib/libcapi-appfw-application.so.0] + 0x4d98
20: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x122 (0xb43b3612) [/usr/lib/osp/libosp-appfw.so] + 0x103612
21: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3ccfea1) [/usr/lib/osp/libosp-uifw.so] + 0x9b6ea1
22: OspMain + 0x19f (0xb25220ff) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x360ff
23: main + 0x503 (0xb71900c3) [/opt/apps/docomo6003/bin/MyHondana] + 0x10c3
24: __launchpad_main_loop + 0x1c17 (0x804bf97) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bf97
25: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
26: __libc_start_main + 0xe6 (0xb7244da6) [/lib/libc.so.6] + 0x16da6
27: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)

Latest Debug Message Information
--------- beginning of /dev/log_main
07-31 10:12:15.463 E/Tizen::Base( 1801): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-31 10:12:15.463 E/Tizen::Base::Runtime( 1801): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-31 10:12:15.463 E/Tizen::Base( 1845): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-31 10:12:15.473 E/Tizen::Base::Runtime( 1845): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-31 10:12:15.473 E/Tizen::Base::Runtime( 1845): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-31 10:12:15.483 E/Tizen::Base::Runtime( 1801): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-31 10:12:19.683 E/Tizen::Base( 2227): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-31 10:12:19.683 E/Tizen::Base::Runtime( 2227): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-31 10:12:19.683 E/Tizen::Base::Runtime( 2227): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-31 10:12:19.703 I/osp-app-service( 2227): int OspMain(int, char**)(38) > Application started.
07-31 10:12:19.813 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:19.813 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:19.813 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:19.813 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:19.993 E/Tizen::Base( 2234): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-31 10:12:20.003 E/Tizen::Base::Runtime( 2234): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-31 10:12:20.003 E/Tizen::Base::Runtime( 2234): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-31 10:12:20.013 E/Tizen::Base( 2235): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-31 10:12:20.013 E/Tizen::Base::Runtime( 2235): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-31 10:12:20.013 E/Tizen::Base::Runtime( 2235): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-31 10:12:20.023 I/osp-security-service( 2234): int OspMain(int, char**)(54) > Application started.
07-31 10:12:20.073 I/osp-channel-service( 2235): int OspMain(int, char**)(35) > Application started.
07-31 10:12:20.153 E/Tizen::Io( 2235): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:20.153 E/Tizen::Io( 2235): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:20.153 E/Tizen::Io( 2235): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:20.153 E/Tizen::Io( 2235): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:20.163 E/Tizen::Io( 2234): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:20.163 E/Tizen::Io( 2234): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:20.163 E/Tizen::Io( 2234): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:20.163 E/Tizen::Io( 2234): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:20.173 I/osp-security-service( 2234): virtual bool SecurityService::OnAppInitializing(Tizen::App::AppRegistry&)(77) > Enter
07-31 10:12:20.173 I/osp-security-service( 2234): result PrivilegeService::Construct()(62) > Entered.
07-31 10:12:20.173 I/osp-security-service( 2234): result PrivilegeService::Construct()(70) > Leaved.
07-31 10:12:20.553 E/Tizen::Io( 2234): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-31 10:12:20.603 E/Tizen::System( 2227): result Tizen::System::_SystemInfo::GetValue(const Tizen::Base::String&, bool&)(1181) > [E_OBJ_NOT_FOUND] It is failed to get system information http://tizen.org/feature/input.keys.back from configration file.
07-31 10:12:20.633 E/Tizen::System( 2227): result Tizen::System::_SystemInfo::GetValue(const Tizen::Base::String&, bool&)(1181) > [E_OBJ_NOT_FOUND] It is failed to get system information http://tizen.org/feature/input.keys.menu from configration file.
07-31 10:12:20.633 E/Tizen::Io( 2234): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-31 10:12:20.703 E/Tizen::Io( 2234): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-31 10:12:21.843 E/Tizen::Io( 2234): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-31 10:12:21.863 E/Tizen::Io( 2234): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-31 10:12:21.863 E/Tizen::Io( 2234): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-31 10:12:21.933 E/Tizen::Io( 2234): result Tizen::Io::_DirEnumeratorImpl::MoveNext()(143) > [E_END_OF_FILE] End of directory entries
07-31 10:12:21.943 I/osp-security-service( 2234): virtual bool SecurityService::OnAppInitializing(Tizen::App::AppRegistry&)(92) > Exit
07-31 10:12:22.353 E/Tizen::Text( 2227): static Tizen::Text::_EncodingCore* Tizen::Text::_Ucs2EncodingCore::GetEncodingCoreImplN(const Tizen::Base::String&, const Tizen::Base::String&)(60) > [E_UNSUPPORTED_TYPE] It is the unsupported type
07-31 10:12:23.003 E/Tizen::Base( 2227): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(11) MUST be greater than or equal to 0, and less than the length of this string(11).
07-31 10:12:23.123 E/Tizen::Base( 2285): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-31 10:12:23.123 E/Tizen::Base::Runtime( 2285): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-31 10:12:23.133 E/Tizen::Base::Runtime( 2285): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-31 10:12:23.143 I/osp-common-service( 2285): int OspMain(int, char**)(38) > Application started.
07-31 10:12:23.203 E/Tizen::Base( 2286): result Tizen::Base::String::SubString(int, Tizen::Base::String&) const(1108) > [E_OUT_OF_RANGE] The startIndex(12) MUST be greater than or equal to 0, and less than the length of this string(12).
07-31 10:12:23.203 E/Tizen::Base::Runtime( 2286): static Tizen::Base::Runtime::_EventManager* Tizen::Base::Runtime::_EventManager::GetCurrentEventManager()(292) > [E_OBJ_NOT_FOUND] This is not OSP thread.
07-31 10:12:23.203 E/Tizen::Io( 2285): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.203 E/Tizen::Base::Runtime( 2286): result Tizen::Base::Runtime::_Event::Initialize()(207) > [E_INVALID_OPERATION] Event manager does not exist.
07-31 10:12:23.213 E/Tizen::Io( 2285): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.213 E/Tizen::Io( 2285): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.213 E/Tizen::Io( 2285): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.303 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.303 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.303 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.323 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(zunqjlsnce.Memo)
07-31 10:12:23.323 E/Tizen::Io( 2286): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.323 E/Tizen::Io( 2286): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.323 E/Tizen::Io( 2286): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.323 E/Tizen::Io( 2286): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.333 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.333 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.333 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.333 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(zktdpemtmw.Phone)
07-31 10:12:23.353 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.353 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.353 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.353 E/Tizen::App( 2227): static Tizen::Base::String Tizen::App::_ContextManager::_Util::QueryFeatureFromPackageManager(const Tizen::Base::String&, const Tizen::Base::String&, const Tizen::Base::String&)(502) > Cannot acquire feature list.
07-31 10:12:23.353 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(zktdpemtmw._AppControl)
07-31 10:12:23.373 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.373 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.373 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.373 E/Tizen::App( 2227): result Tizen::App::_ConditionManagerService::RegisterAppLaunch(const Tizen::App::AppId&, const Tizen::Base::String&, const Tizen::Base::Collection::IList*, Tizen::App::AppManager::LaunchOption, const Tizen::Base::String*)(360) > [E_OBJ_ALREADY_EXIST]
07-31 10:12:23.383 E/Tizen::Net::Wifi( 2286): result WifiService::Construct()(87) > [E_UNSUPPORTED_OPERATION] Wi-Fi Direct is not supported.
07-31 10:12:23.383 E/Tizen::Net::Wifi( 2286): result WifiConnectivityIpcStub::Construct()(87) > [E_UNSUPPORTED_OPERATION] Failed to construct WifiService.
07-31 10:12:23.393 E/Tizen::Net::Bluetooth( 2286): result BluetoothService::Construct()(61) > [E_UNSUPPORTED_OPERATION] Bluetooth is not supported.
07-31 10:12:23.393 E/Tizen::Net::Bluetooth( 2286): result BluetoothConnectivityIpcStub::Construct()(67) > [E_UNSUPPORTED_OPERATION] Failed to construct BluetoothService.
07-31 10:12:23.423 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.423 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.423 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.423 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(vxqbrefica.Email)
07-31 10:12:23.433 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.453 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.453 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.453 E/Tizen::App( 2227): static Tizen::Base::String Tizen::App::_ContextManager::_Util::QueryFeatureFromPackageManager(const Tizen::Base::String&, const Tizen::Base::String&, const Tizen::Base::String&)(502) > Cannot acquire feature list.
07-31 10:12:23.453 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(vxqbrefica._AppControl)
07-31 10:12:23.453 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.453 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.453 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.463 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(tlp6xwqzos.Calculator)
07-31 10:12:23.473 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.473 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.473 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.473 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.483 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(sjjevolsjk.osp-common-service)
07-31 10:12:23.483 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.483 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.483 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.483 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.503 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(q7097a278m.osp-security-service)
07-31 10:12:23.523 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.523 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.523 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.523 E/Tizen::App( 2227): void Tizen::App::_ConditionManagerStub::OnInstallComplete(const Tizen::App::AppId&)(132) > failed to GetAppLaunchConditionListN(ph1vq2phrp.Calendar)
07-31 10:12:23.533 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.543 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetIntAt(int, int&) const(810) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.543 E/Tizen::Io( 2227): result Tizen::Io::_DbEnumeratorImpl::GetStringAt(int, Tizen::Base::String&) const(879) > [E_TYPE_MISMATCH] Trying to access column of different type.
07-31 10:12:23.543 E/Tizen::App( 2227): static Tizen::Base::String Tizen::App::_ContextManager::_Util::QueryFeatureFromPackageManager(const Tizen::Base::String&, const Tizen::Base::String&, const Tizen::Ba
End of latest debug message
