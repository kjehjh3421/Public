S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 12784
Date: 2013-08-02 13:34:01(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=12784 tid=12784
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 12784, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x08576fc4, esi = 0x08534630
ebp = 0xbfa40858, esp = 0xbfa40810
eax = 0x00000000, ebx = 0xb472ca10
ecx = 0xb472ca10, edx = 0x3ff00000
eip = 0xb43f029b

Memory Information
MemTotal:   509368 KB
MemFree:     55972 KB
Buffers:      3676 KB
Cached:     279108 KB
VmPeak:     158748 KB
VmSize:     158684 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       43944 KB
VmRSS:       43944 KB
VmData:      33236 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100680 KB
VmPTE:         152 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
af912000 af985000 r-xp /usr/lib/host-gl/libGL.so.1.2
af9a8000 af9b6000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
af9b7000 af9ee000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afb49000 afb4b000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afb4c000 afb53000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afb54000 afb61000 r-xp /usr/lib/libdrm-client.so.0.0.1
afb62000 afb70000 r-xp /usr/lib/libudev.so.0.13.1
afb71000 afbb3000 r-xp /usr/lib/libSLP-location.so.0.0.0
afbb4000 afc40000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afc46000 afc50000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afc51000 afc69000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afc6a000 afc70000 r-xp /usr/lib/libmmffile.so.0.0.0
afc71000 afc79000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afc7a000 afc7c000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afc7d000 afc9e000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afc9f000 afca1000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afca2000 afcc0000 r-xp /usr/lib/libmedia-service.so.1.0.0
afcc1000 afcc7000 r-xp /usr/lib/libmemenv.so.1.1.0
afcc8000 afd11000 r-xp /usr/lib/libleveldb.so.1.1.0
afd13000 afd1e000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd1f000 afd5b000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afd5d000 afd72000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afd73000 afd93000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afd95000 afdcb000 r-xp /usr/lib/libxslt.so.1.1.16
afdcc000 afdd4000 r-xp /usr/lib/libeeze.so.1.7.99
afdd5000 afdda000 r-xp /usr/lib/libeukit.so.1.7.99
afddb000 afde5000 r-xp /usr/lib/libenchant.so.1.6.1
afde6000 afdf0000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afdf1000 afdfd000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afdfe000 afe2d000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afe33000 afe37000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afe38000 afe44000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afe46000 afe4d000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afe4e000 afe5d000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afe5e000 afe61000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
afe62000 afe73000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
afe74000 afea3000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
afea4000 afeaa000 r-xp /usr/lib/libogg.so.0.7.1
afeab000 afed6000 r-xp /usr/lib/libvorbis.so.0.4.3
afed7000 afedc000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
afedd000 afee1000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
afee2000 afee7000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
afee8000 aff0d000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
aff0e000 aff28000 r-xp /usr/lib/libnetwork.so.0.0.0
aff2a000 aff56000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
aff57000 b1f42000 r-xp /usr/lib/libewebkit2.so.0.11.72
b203c000 b21a7000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b21b3000 b2237000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2239000 b2255000 r-xp /usr/lib/libwifi-direct.so.0.0
b2256000 b2261000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b2262000 b226d000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b226e000 b227c000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b227d000 b231f000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2325000 b2437000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b243d000 b2462000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b2464000 b2491000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b24a3000 b2531000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2536000 b2566000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2567000 b25ba000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b25bb000 b25c1000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b25c2000 b25c7000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b25c8000 b2610000 r-xp /usr/lib/libpulse.so.0.12.4
b2611000 b2615000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b2616000 b2708000 r-xp /usr/lib/libasound.so.2.0.0
b270c000 b2731000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b2732000 b2746000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2747000 b2827000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b282c000 b288b000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b288c000 b2898000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2899000 b28ac000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b28ad000 b28b0000 r-xp /usr/lib/libmm_ta.so.0.0.0
b28b1000 b28c8000 r-xp /usr/lib/libICE.so.6.3.0
b28cb000 b28d2000 r-xp /usr/lib/libSM.so.6.0.1
b28d3000 b28d4000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b28d5000 b28e0000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b28e1000 b28e6000 r-xp /usr/lib/libsysman.so.0.2.0
b28e7000 b28f2000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b28f6000 b28fa000 r-xp /usr/lib/libmmfsession.so.0.0.0
b28fb000 b2958000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b295a000 b2962000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2963000 b2965000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2966000 b29c9000 r-xp /usr/lib/libtiff.so.5.1.0
b29cc000 b2a1e000 r-xp /usr/lib/libturbojpeg.so
b2a2f000 b2a36000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2a37000 b2a40000 r-xp /usr/lib/libgif.so.4.1.6
b2a41000 b2a67000 r-xp /usr/lib/libavutil.so.51.73.101
b2a6e000 b2ab3000 r-xp /usr/lib/libswscale.so.2.1.101
b2ab4000 b2e19000 r-xp /usr/lib/libavcodec.so.54.59.100
b313a000 b3161000 r-xp /usr/lib/libpng12.so.0.50.0
b3162000 b3169000 r-xp /usr/lib/libfeedback.so.0.1.4
b316a000 b3179000 r-xp /usr/lib/libtts.so
b317a000 b3190000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b3191000 b32ab000 r-xp /usr/lib/libcairo.so.2.11200.12
b32ae000 b32d2000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b32d3000 b40b9000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4129000 b412f000 r-xp /usr/lib/libslp_devman_plugin.so
b4130000 b4132000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4133000 b4136000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4137000 b413b000 r-xp /usr/lib/libdevice-node.so.0.1
b413c000 b414a000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b414b000 b4154000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4155000 b415b000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b415c000 b415e000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b415f000 b4163000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4164000 b416b000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b416c000 b416f000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b4170000 b4171000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4172000 b4185000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4187000 b418f000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4190000 b41c0000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b41c1000 b41c5000 r-xp /usr/lib/libuuid.so.1.3.0
b41c6000 b41d7000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b41d8000 b41d9000 r-xp /usr/lib/libpmapi.so.1.2
b41da000 b41e6000 r-xp /usr/lib/libminizip.so.1.0.0
b41e7000 b41f8000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b41f9000 b4221000 r-xp /usr/lib/libpcre.so.0.0.1
b4222000 b4226000 r-xp /usr/lib/libheynoti.so.0.0.2
b4227000 b422c000 r-xp /usr/lib/libhaptic.so.0.1
b422d000 b422e000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b422f000 b4236000 r-xp /usr/lib/libdevman.so.0.1
b4237000 b423d000 r-xp /usr/lib/libchromium.so.1.0
b423e000 b4246000 r-xp /usr/lib/libalarm.so.0.0.0
b4247000 b4250000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b4251000 b4269000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b426a000 b4714000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4736000 b4740000 r-xp /lib/libnss_files-2.13.so
b4742000 b474b000 r-xp /lib/libnss_nis-2.13.so
b474d000 b4760000 r-xp /lib/libnsl-2.13.so
b4764000 b476a000 r-xp /lib/libnss_compat-2.13.so
b496c000 b4986000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4987000 b4ad0000 r-xp /usr/lib/libxml2.so.2.7.8
b4ad6000 b4afc000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4afd000 b4b00000 r-xp /usr/lib/libiniparser.so.0
b4b02000 b4b6b000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4b6d000 b4b89000 r-xp /usr/lib/libcom-core.so.0.0.1
b4b8a000 b4b91000 r-xp /usr/lib/libappsvc.so.0.1.0
b4b92000 b4b95000 r-xp /usr/lib/libdri2.so.0.0.0
b4b96000 b4ba1000 r-xp /usr/lib/libdrm.so.2.4.0
b4ba2000 b4ba7000 r-xp /usr/lib/libtbm.so.1.0.0
b4ba8000 b4bac000 r-xp /usr/lib/libXv.so.1.0.0
b4bad000 b4ccb000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4cda000 b4cef000 r-xp /usr/lib/libnotification.so.0.1.0
b4cf0000 b4cf9000 r-xp /usr/lib/libutilX.so.1.1.0
b4cfa000 b4d2d000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d2f000 b4d40000 r-xp /lib/libresolv-2.13.so
b4d44000 b4d47000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d48000 b4ead000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4eb1000 b5021000 r-xp /usr/lib/libcrypto.so.1.0.0
b5039000 b508f000 r-xp /usr/lib/libssl.so.1.0.0
b5094000 b50c3000 r-xp /usr/lib/libidn.so.11.5.44
b50c4000 b50d3000 r-xp /usr/lib/libcares.so.2.0.0
b50d4000 b50fb000 r-xp /lib/libexpat.so.1.5.2
b50fd000 b5130000 r-xp /usr/lib/libicule.so.48.1
b5131000 b513c000 r-xp /usr/lib/libsf_common.so
b513d000 b5219000 r-xp /usr/lib/libstdc++.so.6.0.14
b5225000 b5228000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5229000 b524e000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b524f000 b5254000 r-xp /usr/lib/libffi.so.5.0.10
b5255000 b5256000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5257000 b5288000 r-xp /usr/lib/libexif.so.12.3.3
b5295000 b52a1000 r-xp /usr/lib/libethumb.so.1.7.99
b52a2000 b5306000 r-xp /usr/lib/libsndfile.so.1.0.25
b530c000 b530f000 r-xp /usr/lib/libctxdata.so.0.0.0
b5310000 b5327000 r-xp /usr/lib/libremix.so.0.0.0
b5328000 b532a000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b532b000 b5358000 r-xp /usr/lib/liblua-5.1.so
b5359000 b5363000 r-xp /usr/lib/libembryo.so.1.7.99
b5364000 b5367000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5368000 b53c9000 r-xp /usr/lib/libcurl.so.4.3.0
b53cb000 b53d1000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b53d2000 b53e3000 r-xp /usr/lib/libXext.so.6.4.0
b53e4000 b53e9000 r-xp /usr/lib/libXtst.so.6.1.0
b53ea000 b53f2000 r-xp /usr/lib/libXrender.so.1.3.0
b53f3000 b53fc000 r-xp /usr/lib/libXrandr.so.2.2.0
b53fd000 b53ff000 r-xp /usr/lib/libXinerama.so.1.0.0
b5400000 b540e000 r-xp /usr/lib/libXi.so.6.1.0
b540f000 b5413000 r-xp /usr/lib/libXfixes.so.3.1.0
b5414000 b5416000 r-xp /usr/lib/libXgesture.so.7.0.0
b5417000 b5419000 r-xp /usr/lib/libXcomposite.so.1.0.0
b541a000 b541c000 r-xp /usr/lib/libXdamage.so.1.1.0
b541d000 b5427000 r-xp /usr/lib/libXcursor.so.1.0.2
b5428000 b54bf000 r-xp /usr/lib/libpixman-1.so.0.28.2
b54c4000 b54f9000 r-xp /usr/lib/libfontconfig.so.1.5.0
b54fb000 b5580000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b558a000 b55a0000 r-xp /usr/lib/libfribidi.so.0.3.1
b55a1000 b5626000 r-xp /usr/lib/libfreetype.so.6.8.1
b562a000 b5671000 r-xp /usr/lib/libjpeg.so.8.0.2
b5682000 b56a1000 r-xp /lib/libz.so.1.2.5
b56a2000 b56ae000 r-xp /usr/lib/libemotion.so.1.7.99
b56af000 b56b5000 r-xp /usr/lib/libecore_fb.so.1.7.99
b56b7000 b56c7000 r-xp /usr/lib/libsensor.so.1.1.0
b56ca000 b56d0000 r-xp /usr/lib/libappcore-common.so.1.1
b67d9000 b6934000 r-xp /usr/lib/libicuuc.so.48.1
b6942000 b6b21000 r-xp /usr/lib/libicui18n.so.48.1
b6b28000 b6b2b000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b2c000 b6b38000 r-xp /usr/lib/libvconf.so.0.2.45
b6b39000 b6b42000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6b43000 b6b54000 r-xp /usr/lib/libail.so.0.1.0
b6b55000 b6b65000 r-xp /usr/lib/libaul.so.0.1.0
b6b66000 b6bb6000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6bb7000 b6bfa000 r-xp /usr/lib/libecore_x.so.1.7.99
b6bfc000 b6c57000 r-xp /usr/lib/libeina.so.1.7.99
b6c59000 b6c78000 r-xp /usr/lib/libecore.so.1.7.99
b6c87000 b6cb2000 r-xp /usr/lib/libecore_con.so.1.7.99
b6cb4000 b6cbf000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6cc0000 b6ccc000 r-xp /usr/lib/libedbus.so.1.7.99
b6ccd000 b6cd0000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6cd1000 b6cd7000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6cd8000 b6cfa000 r-xp /usr/lib/libefreet.so.1.7.99
b6cfc000 b6d93000 r-xp /usr/lib/libedje.so.1.7.99
b6d95000 b6dac000 r-xp /usr/lib/libecore_input.so.1.7.99
b6dc0000 b6dc7000 r-xp /usr/lib/libecore_file.so.1.7.99
b6dc8000 b6df5000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6df7000 b6f01000 r-xp /usr/lib/libevas.so.1.7.99
b6f1c000 b6f39000 r-xp /usr/lib/libeet.so.1.7.99
b6f3a000 b6f5e000 r-xp /lib/libm-2.13.so
b6f60000 b7130000 r-xp /usr/lib/libelementary.so.1.7.99
b713b000 b713c000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b713d000 b7148000 r-xp /usr/lib/libcapi-web-favorites.so
b7149000 b714b000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b714e000 b7152000 r-xp /lib/libattr.so.1.1.0
b7153000 b7155000 r-xp /usr/lib/libXau.so.6.0.0
b7157000 b715e000 r-xp /lib/librt-2.13.so
b7160000 b7168000 r-xp /lib/libcrypt-2.13.so
b7191000 b7194000 r-xp /lib/libcap.so.2.21
b7195000 b7197000 r-xp /usr/lib/libiri.so
b7198000 b71b2000 r-xp /lib/libgcc_s-4.5.3.so.1
b71b3000 b71d3000 r-xp /usr/lib/libxcb.so.1.1.0
b71d5000 b71de000 r-xp /lib/libunwind.so.8.0.1
b71e8000 b733e000 r-xp /lib/libc-2.13.so
b7344000 b7349000 r-xp /usr/lib/libsmack.so.1.0.0
b734a000 b7396000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7397000 b739c000 r-xp /usr/lib/libbundle.so.0.1.22
b739d000 b739f000 r-xp /lib/libdl-2.13.so
b73a2000 b74cb000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b74cc000 b74e1000 r-xp /lib/libpthread-2.13.so
b74e6000 b74e7000 r-xp /usr/lib/libdlog.so.0.0.0
b74e8000 b7592000 r-xp /usr/lib/libsqlite3.so.0.8.6
b7595000 b75a1000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b75a2000 b76d7000 r-xp /usr/lib/libX11.so.6.3.0
b76dc000 b76e4000 r-xp /usr/lib/libecore_imf.so.1.7.99
b76e5000 b76ea000 r-xp /usr/lib/libappcore-efl.so.1.1
b76ec000 b76f0000 r-xp /usr/lib/libsys-assert.so
b76f4000 b76f5000 r-xp [vdso]
b76f5000 b7711000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:12784)
Call Stack Count: 55
 0: MyHondanaMainForm::TraverseFunction(Tizen::Web::Json::IJsonValue*) + 0x36c1 (0xb24f34d1) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x504d1
 1: MyHondanaMainForm::TraverseFunction(Tizen::Web::Json::IJsonValue*) + 0x35d5 (0xb24f33e5) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x503e5
 2: MyHondanaMainForm::TraverseFunction(Tizen::Web::Json::IJsonValue*) + 0x36c1 (0xb24f34d1) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x504d1
 3: MyHondanaMainForm::TraverseFunction(Tizen::Web::Json::IJsonValue*) + 0x35d5 (0xb24f33e5) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x503e5
 4: MyHondanaMainForm::ParseAndDisplay() + 0xda4 (0xb24f43e4) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x513e4
 5: MyHondanaMainForm::StartConect(Tizen::Base::String const&) + 0x38b (0xb24e18eb) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3e8eb
 6: MyHondanaMainForm::OnInitializing() + 0xfd (0xb24e110d) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3e10d
 7: non-virtual thunk to MyHondanaMainForm::OnInitializing() + 0x38 (0xb24e6ef8) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x43ef8
 8: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x3d (0xb35eabbd) [/usr/lib/osp/libosp-uifw.so] + 0x317bbd
 9: Tizen::Ui::Controls::_FormImpl::OnAttachedToMainTree() + 0x3a (0xb391f1fa) [/usr/lib/osp/libosp-uifw.so] + 0x64c1fa
10: Tizen::Ui::_Control::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0x115 (0xb35c3875) [/usr/lib/osp/libosp-uifw.so] + 0x2f0875
11: Tizen::Ui::_Control::EndAttaching(Tizen::Ui::_Control&) + 0x24c (0xb35c93dc) [/usr/lib/osp/libosp-uifw.so] + 0x2f63dc
12: Tizen::Ui::_Control::AttachChild(Tizen::Ui::_Control&) + 0xa5 (0xb35ccb45) [/usr/lib/osp/libosp-uifw.so] + 0x2f9b45
13: Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool) + 0xe6 (0xb35ff0a6) [/usr/lib/osp/libosp-uifw.so] + 0x32c0a6
14: Tizen::Ui::Container::AddControl(Tizen::Ui::Control*) + 0x52 (0xb35b93d2) [/usr/lib/osp/libosp-uifw.so] + 0x2e63d2
15: Tizen::Ui::Container::AddControl(Tizen::Ui::Control const&) + 0x24 (0xb35b94b4) [/usr/lib/osp/libosp-uifw.so] + 0x2e64b4
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
