S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 9810
Date: 2013-08-02 17:16:00(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=9810 tid=9810
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 9810, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x00000000, esi = 0xbff30ba4
ebp = 0xbff30b88, esp = 0xbff30b84
eax = 0x00000000, ebx = 0xb47f4a10
ecx = 0x00000011, edx = 0xbff30ba4
eip = 0xb44b799d

Memory Information
MemTotal:   509368 KB
MemFree:     13040 KB
Buffers:      3448 KB
Cached:     342360 KB
VmPeak:     158756 KB
VmSize:     158692 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       43904 KB
VmRSS:       43904 KB
VmData:      33240 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100684 KB
VmPTE:         140 KB
VmSwap:          8 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
af9d9000 afa4c000 r-xp /usr/lib/host-gl/libGL.so.1.2
afa6f000 afa7d000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afa7e000 afab5000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afc10000 afc12000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afc13000 afc1a000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc1b000 afc28000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc29000 afc37000 r-xp /usr/lib/libudev.so.0.13.1
afc38000 afc7a000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc7b000 afd07000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afd0d000 afd17000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afd18000 afd30000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd31000 afd37000 r-xp /usr/lib/libmmffile.so.0.0.0
afd38000 afd40000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd41000 afd43000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd44000 afd65000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd66000 afd68000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd69000 afd87000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd88000 afd8e000 r-xp /usr/lib/libmemenv.so.1.1.0
afd8f000 afdd8000 r-xp /usr/lib/libleveldb.so.1.1.0
afdda000 afde5000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afde6000 afe22000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe24000 afe39000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe3a000 afe5a000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe5c000 afe92000 r-xp /usr/lib/libxslt.so.1.1.16
afe93000 afe9b000 r-xp /usr/lib/libeeze.so.1.7.99
afe9c000 afea1000 r-xp /usr/lib/libeukit.so.1.7.99
afea2000 afeac000 r-xp /usr/lib/libenchant.so.1.6.1
afead000 afeb7000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afeb8000 afec4000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afec5000 afef4000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afefa000 afefe000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afeff000 aff0b000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
aff0d000 aff14000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
aff15000 aff24000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff25000 aff28000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff29000 aff3a000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff3b000 aff6a000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff6b000 aff71000 r-xp /usr/lib/libogg.so.0.7.1
aff72000 aff9d000 r-xp /usr/lib/libvorbis.so.0.4.3
aff9e000 affa3000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
affa4000 affa8000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
affa9000 affae000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
affaf000 affd4000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affd5000 affef000 r-xp /usr/lib/libnetwork.so.0.0.0
afff1000 b001d000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b001e000 b2009000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2103000 b226e000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b227a000 b22fe000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2300000 b231c000 r-xp /usr/lib/libwifi-direct.so.0.0
b231d000 b2328000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b2329000 b2334000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2335000 b2343000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b2344000 b23e6000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b23ec000 b24fe000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2504000 b2529000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b252b000 b2558000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b256a000 b25f9000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b25fe000 b262e000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b262f000 b2682000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2683000 b2689000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b268a000 b268f000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b2690000 b26d8000 r-xp /usr/lib/libpulse.so.0.12.4
b26d9000 b26dd000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26de000 b27d0000 r-xp /usr/lib/libasound.so.2.0.0
b27d4000 b27f9000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b27fa000 b280e000 r-xp /usr/lib/libmmfsound.so.0.1.0
b280f000 b28ef000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b28f4000 b2953000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b2954000 b2960000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2961000 b2974000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b2975000 b2978000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2979000 b2990000 r-xp /usr/lib/libICE.so.6.3.0
b2993000 b299a000 r-xp /usr/lib/libSM.so.6.0.1
b299b000 b299c000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b299d000 b29a8000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b29a9000 b29ae000 r-xp /usr/lib/libsysman.so.0.2.0
b29af000 b29ba000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b29be000 b29c2000 r-xp /usr/lib/libmmfsession.so.0.0.0
b29c3000 b2a20000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2a22000 b2a2a000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2a2b000 b2a2d000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2a2e000 b2a91000 r-xp /usr/lib/libtiff.so.5.1.0
b2a94000 b2ae6000 r-xp /usr/lib/libturbojpeg.so
b2af7000 b2afe000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2aff000 b2b08000 r-xp /usr/lib/libgif.so.4.1.6
b2b09000 b2b2f000 r-xp /usr/lib/libavutil.so.51.73.101
b2b36000 b2b7b000 r-xp /usr/lib/libswscale.so.2.1.101
b2b7c000 b2ee1000 r-xp /usr/lib/libavcodec.so.54.59.100
b3202000 b3229000 r-xp /usr/lib/libpng12.so.0.50.0
b322a000 b3231000 r-xp /usr/lib/libfeedback.so.0.1.4
b3232000 b3241000 r-xp /usr/lib/libtts.so
b3242000 b3258000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b3259000 b3373000 r-xp /usr/lib/libcairo.so.2.11200.12
b3376000 b339a000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b339b000 b4181000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b41f1000 b41f7000 r-xp /usr/lib/libslp_devman_plugin.so
b41f8000 b41fa000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41fb000 b41fe000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41ff000 b4203000 r-xp /usr/lib/libdevice-node.so.0.1
b4204000 b4212000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4213000 b421c000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b421d000 b4223000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b4224000 b4226000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4227000 b422b000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b422c000 b4233000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4234000 b4237000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b4238000 b4239000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b423a000 b424d000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b424f000 b4257000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4258000 b4288000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4289000 b428d000 r-xp /usr/lib/libuuid.so.1.3.0
b428e000 b429f000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b42a0000 b42a1000 r-xp /usr/lib/libpmapi.so.1.2
b42a2000 b42ae000 r-xp /usr/lib/libminizip.so.1.0.0
b42af000 b42c0000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42c1000 b42e9000 r-xp /usr/lib/libpcre.so.0.0.1
b42ea000 b42ee000 r-xp /usr/lib/libheynoti.so.0.0.2
b42ef000 b42f4000 r-xp /usr/lib/libhaptic.so.0.1
b42f5000 b42f6000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42f7000 b42fe000 r-xp /usr/lib/libdevman.so.0.1
b42ff000 b4305000 r-xp /usr/lib/libchromium.so.1.0
b4306000 b430e000 r-xp /usr/lib/libalarm.so.0.0.0
b430f000 b4318000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b4319000 b4331000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4332000 b47dc000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b47fe000 b4808000 r-xp /lib/libnss_files-2.13.so
b480a000 b4813000 r-xp /lib/libnss_nis-2.13.so
b4815000 b4828000 r-xp /lib/libnsl-2.13.so
b482c000 b4832000 r-xp /lib/libnss_compat-2.13.so
b4a34000 b4a4e000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a4f000 b4b98000 r-xp /usr/lib/libxml2.so.2.7.8
b4b9e000 b4bc4000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4bc5000 b4bc8000 r-xp /usr/lib/libiniparser.so.0
b4bca000 b4c33000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c35000 b4c51000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c52000 b4c59000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c5a000 b4c5d000 r-xp /usr/lib/libdri2.so.0.0.0
b4c5e000 b4c69000 r-xp /usr/lib/libdrm.so.2.4.0
b4c6a000 b4c6f000 r-xp /usr/lib/libtbm.so.1.0.0
b4c70000 b4c74000 r-xp /usr/lib/libXv.so.1.0.0
b4c75000 b4d93000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4da2000 b4db7000 r-xp /usr/lib/libnotification.so.0.1.0
b4db8000 b4dc1000 r-xp /usr/lib/libutilX.so.1.1.0
b4dc2000 b4df5000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4df7000 b4e08000 r-xp /lib/libresolv-2.13.so
b4e0c000 b4e0f000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4e10000 b4f75000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f79000 b50e9000 r-xp /usr/lib/libcrypto.so.1.0.0
b5101000 b5157000 r-xp /usr/lib/libssl.so.1.0.0
b515c000 b518b000 r-xp /usr/lib/libidn.so.11.5.44
b518c000 b519b000 r-xp /usr/lib/libcares.so.2.0.0
b519c000 b51c3000 r-xp /lib/libexpat.so.1.5.2
b51c5000 b51f8000 r-xp /usr/lib/libicule.so.48.1
b51f9000 b5204000 r-xp /usr/lib/libsf_common.so
b5205000 b52e1000 r-xp /usr/lib/libstdc++.so.6.0.14
b52ed000 b52f0000 r-xp /usr/lib/libapp-checker.so.0.1.0
b52f1000 b5316000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5317000 b531c000 r-xp /usr/lib/libffi.so.5.0.10
b531d000 b531e000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b531f000 b5350000 r-xp /usr/lib/libexif.so.12.3.3
b535d000 b5369000 r-xp /usr/lib/libethumb.so.1.7.99
b536a000 b53ce000 r-xp /usr/lib/libsndfile.so.1.0.25
b53d4000 b53d7000 r-xp /usr/lib/libctxdata.so.0.0.0
b53d8000 b53ef000 r-xp /usr/lib/libremix.so.0.0.0
b53f0000 b53f2000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b53f3000 b5420000 r-xp /usr/lib/liblua-5.1.so
b5421000 b542b000 r-xp /usr/lib/libembryo.so.1.7.99
b542c000 b542f000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5430000 b5491000 r-xp /usr/lib/libcurl.so.4.3.0
b5493000 b5499000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b549a000 b54ab000 r-xp /usr/lib/libXext.so.6.4.0
b54ac000 b54b1000 r-xp /usr/lib/libXtst.so.6.1.0
b54b2000 b54ba000 r-xp /usr/lib/libXrender.so.1.3.0
b54bb000 b54c4000 r-xp /usr/lib/libXrandr.so.2.2.0
b54c5000 b54c7000 r-xp /usr/lib/libXinerama.so.1.0.0
b54c8000 b54d6000 r-xp /usr/lib/libXi.so.6.1.0
b54d7000 b54db000 r-xp /usr/lib/libXfixes.so.3.1.0
b54dc000 b54de000 r-xp /usr/lib/libXgesture.so.7.0.0
b54df000 b54e1000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54e2000 b54e4000 r-xp /usr/lib/libXdamage.so.1.1.0
b54e5000 b54ef000 r-xp /usr/lib/libXcursor.so.1.0.2
b54f0000 b5587000 r-xp /usr/lib/libpixman-1.so.0.28.2
b558c000 b55c1000 r-xp /usr/lib/libfontconfig.so.1.5.0
b55c3000 b5648000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5652000 b5668000 r-xp /usr/lib/libfribidi.so.0.3.1
b5669000 b56ee000 r-xp /usr/lib/libfreetype.so.6.8.1
b56f2000 b5739000 r-xp /usr/lib/libjpeg.so.8.0.2
b574a000 b5769000 r-xp /lib/libz.so.1.2.5
b576a000 b5776000 r-xp /usr/lib/libemotion.so.1.7.99
b5777000 b577d000 r-xp /usr/lib/libecore_fb.so.1.7.99
b577f000 b578f000 r-xp /usr/lib/libsensor.so.1.1.0
b5792000 b5798000 r-xp /usr/lib/libappcore-common.so.1.1
b68a1000 b69fc000 r-xp /usr/lib/libicuuc.so.48.1
b6a0a000 b6be9000 r-xp /usr/lib/libicui18n.so.48.1
b6bf0000 b6bf3000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6bf4000 b6c00000 r-xp /usr/lib/libvconf.so.0.2.45
b6c01000 b6c0a000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6c0b000 b6c1c000 r-xp /usr/lib/libail.so.0.1.0
b6c1d000 b6c2d000 r-xp /usr/lib/libaul.so.0.1.0
b6c2e000 b6c7e000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c7f000 b6cc2000 r-xp /usr/lib/libecore_x.so.1.7.99
b6cc4000 b6d1f000 r-xp /usr/lib/libeina.so.1.7.99
b6d21000 b6d40000 r-xp /usr/lib/libecore.so.1.7.99
b6d4f000 b6d7a000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d7c000 b6d87000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d88000 b6d94000 r-xp /usr/lib/libedbus.so.1.7.99
b6d95000 b6d98000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6d99000 b6d9f000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6da0000 b6dc2000 r-xp /usr/lib/libefreet.so.1.7.99
b6dc4000 b6e5b000 r-xp /usr/lib/libedje.so.1.7.99
b6e5d000 b6e74000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e88000 b6e8f000 r-xp /usr/lib/libecore_file.so.1.7.99
b6e90000 b6ebd000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6ebf000 b6fc9000 r-xp /usr/lib/libevas.so.1.7.99
b6fe4000 b7001000 r-xp /usr/lib/libeet.so.1.7.99
b7002000 b7026000 r-xp /lib/libm-2.13.so
b7028000 b71f8000 r-xp /usr/lib/libelementary.so.1.7.99
b7203000 b7204000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b7205000 b7210000 r-xp /usr/lib/libcapi-web-favorites.so
b7211000 b7213000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7216000 b721a000 r-xp /lib/libattr.so.1.1.0
b721b000 b721d000 r-xp /usr/lib/libXau.so.6.0.0
b721f000 b7226000 r-xp /lib/librt-2.13.so
b7228000 b7230000 r-xp /lib/libcrypt-2.13.so
b7259000 b725c000 r-xp /lib/libcap.so.2.21
b725d000 b725f000 r-xp /usr/lib/libiri.so
b7260000 b727a000 r-xp /lib/libgcc_s-4.5.3.so.1
b727b000 b729b000 r-xp /usr/lib/libxcb.so.1.1.0
b729d000 b72a6000 r-xp /lib/libunwind.so.8.0.1
b72b0000 b7406000 r-xp /lib/libc-2.13.so
b740c000 b7411000 r-xp /usr/lib/libsmack.so.1.0.0
b7412000 b745e000 r-xp /usr/lib/libdbus-1.so.3.7.2
b745f000 b7464000 r-xp /usr/lib/libbundle.so.0.1.22
b7465000 b7467000 r-xp /lib/libdl-2.13.so
b746a000 b7593000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b7594000 b75a9000 r-xp /lib/libpthread-2.13.so
b75ae000 b75af000 r-xp /usr/lib/libdlog.so.0.0.0
b75b0000 b765a000 r-xp /usr/lib/libsqlite3.so.0.8.6
b765d000 b7669000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b766a000 b779f000 r-xp /usr/lib/libX11.so.6.3.0
b77a4000 b77ac000 r-xp /usr/lib/libecore_imf.so.1.7.99
b77ad000 b77b2000 r-xp /usr/lib/libappcore-efl.so.1.1
b77b4000 b77b8000 r-xp /usr/lib/libsys-assert.so
b77bc000 b77bd000 r-xp [vdso]
b77bd000 b77d9000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:9810)
Call Stack Count: 52
 0: MyHondanaMainForm::InitContentInfo() + 0x48 (0xb25bc868) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x52868
 1: MyHondanaMainForm::ParseAndDisplay() + 0xd9b (0xb25aa83b) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x4083b
 2: MyHondanaMainForm::StartConect(Tizen::Base::String const&) + 0x383 (0xb25a9953) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3f953
 3: MyHondanaMainForm::OnInitializing() + 0xfd (0xb25a917d) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3f17d
 4: non-virtual thunk to MyHondanaMainForm::OnInitializing() + 0x38 (0xb25afc68) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x45c68
 5: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x3d (0xb36b2bbd) [/usr/lib/osp/libosp-uifw.so] + 0x317bbd
 6: Tizen::Ui::Controls::_FormImpl::OnAttachedToMainTree() + 0x3a (0xb39e71fa) [/usr/lib/osp/libosp-uifw.so] + 0x64c1fa
 7: Tizen::Ui::_Control::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0x115 (0xb368b875) [/usr/lib/osp/libosp-uifw.so] + 0x2f0875
 8: Tizen::Ui::_Control::EndAttaching(Tizen::Ui::_Control&) + 0x24c (0xb36913dc) [/usr/lib/osp/libosp-uifw.so] + 0x2f63dc
 9: Tizen::Ui::_Control::AttachChild(Tizen::Ui::_Control&) + 0xa5 (0xb3694b45) [/usr/lib/osp/libosp-uifw.so] + 0x2f9b45
10: Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool) + 0xe6 (0xb36c70a6) [/usr/lib/osp/libosp-uifw.so] + 0x32c0a6
11: Tizen::Ui::Container::AddControl(Tizen::Ui::Control*) + 0x52 (0xb36813d2) [/usr/lib/osp/libosp-uifw.so] + 0x2e63d2
12: Tizen::Ui::Container::AddControl(Tizen::Ui::Control const&) + 0x24 (0xb36814b4) [/usr/lib/osp/libosp-uifw.so] + 0x2e64b4
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
