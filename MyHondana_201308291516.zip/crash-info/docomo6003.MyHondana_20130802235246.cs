S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG4
Build-Date: 2013.07.22 22:21:22

Crash Information
Process Name: MyHondana
PID: 24982
Date: 2013-08-02 23:52:46(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=24982 tid=24982
Signal: 6
      (SIGABRT)
      si_code: -6
      signal sent by tkill (sent by pid 24982, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0x00006196
r2   = 0x00000006, r3   = 0x00006196
r4   = 0x00000006, r5   = 0xb6c2abe4
r6   = 0xb6c2a000, r7   = 0x0000010c
r8   = 0x00000be4, r9   = 0xb4178090
r10  = 0xb6f66000, fp   = 0xbea5ff10
ip   = 0xb6f664c0, sp   = 0xbea5f8d0
lr   = 0xb6b3155c, pc   = 0xb6b2d760
cpsr = 0x280b0010

Memory Information
MemTotal:  2063780 KB
MemFree:    752340 KB
Buffers:     77972 KB
Cached:     784992 KB
VmPeak:     153288 KB
VmSize:     134000 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       53224 KB
VmRSS:       53224 KB
VmData:      32668 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       66900 KB
VmPTE:         130 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00092000 rw-p [heap]
00092000 00968000 rw-p [heap]
ae608000 ae60a000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
af4e5000 afce4000 rwxp [stack:25000]
b0529000 b052d000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b0536000 b0d35000 rwxp [stack:24984]
b0d35000 b0d3b000 r-xp /usr/lib/libUMP.so
b0d43000 b0e91000 r-xp /usr/lib/r3p2/libMali.so
b0e9d000 b0ec6000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0ed2000 b0ef0000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b11e8000 b1234000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b123d000 b1242000 r-xp /usr/lib/libjson.so.0.0.1
b124a000 b124e000 r-xp /usr/lib/liblocation-pos-log.so
b1256000 b1268000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b1270000 b1272000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b127a000 b127f000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b1287000 b1292000 r-xp /usr/lib/libdrm-trusted.so.0.0.54
b129a000 b129c000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b12a4000 b12b1000 r-xp /usr/lib/libdrm-client.so.0.0.91
b12ba000 b12c2000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b12e4000 b131b000 r-xp /usr/lib/libpulse.so.0.16.2
b1323000 b1387000 r-xp /usr/lib/libasound.so.2.0.0
b1391000 b1394000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b139d000 b13a1000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b13aa000 b13c5000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b13ce000 b13d3000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b13db000 b1408000 r-xp /usr/lib/libSLP-location.so.0.0.0
b1411000 b1419000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b141a000 b141e000 r-xp /usr/lib/libmmffile.so.0.0.0
b1426000 b142e000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b142f000 b1448000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b1451000 b146c000 r-xp /usr/lib/libmedia-service.so.1.0.0
b1474000 b147f000 r-xp /usr/lib/libmdm-common.so.1.0.38
b1487000 b1493000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b149b000 b14a2000 r-xp /usr/lib/libenchant.so.1.6.1
b14aa000 b14ad000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b14b6000 b14bf000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b14c8000 b14cc000 r-xp /usr/lib/libmmfsession.so.0.0.0
b14d5000 b14e4000 r-xp /usr/lib/libmmfsound.so.0.1.0
b14ec000 b14f1000 r-xp /usr/lib/libmemenv.so.1.1.0
b14f9000 b1537000 r-xp /usr/lib/libleveldb.so.1.1.0
b1540000 b156a000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b1573000 b1575000 r-xp /usr/lib/libsecfw.so
b157d000 b1586000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b1591000 b15a0000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b15a8000 b15c0000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b15c2000 b15cf000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b15d8000 b15e1000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b15e9000 b162c000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b1634000 b16d0000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b16dc000 b1701000 r-xp /usr/lib/libxslt.so.1.1.16
b170a000 b170c000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b1714000 b171c000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b1724000 b1730000 r-xp /usr/lib/libcapi-location-manager.so.0.1.14
b1738000 b173b000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b1743000 b1748000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b1750000 b1777000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.71
b177f000 b1798000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.1
b17a0000 b17de000 r-xp /usr/lib/libmdm.so.1.0.67
b17e6000 b17fb000 r-xp /usr/lib/libnetwork.so.0.0.0
b1803000 b180c000 r-xp /usr/lib/libcapi-web-favorites.so
b1814000 b2a74000 r-xp /usr/lib/libewebkit2.so.0.10.154.1
b2b67000 b2bba000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2bc3000 b2bda000 r-xp /usr/lib/libwifi-direct.so.0.0
b2be2000 b2bea000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.10
b2bf2000 b2bfb000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2c04000 b2c0f000 r-xp /usr/lib/libcapi-network-connection.so.0.1.13
b2c17000 b2c83000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2c91000 b2d46000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2d53000 b2d6d000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2d76000 b2d94000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2da3000 b2dad000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b2db5000 b2e20000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2e2d000 b2ea9000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2eb1000 b2f41000 r-xp /usr/lib/libCOREGL.so.3.0
b2f4b000 b2f4e000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2f56000 b2f5d000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2f66000 b2f75000 r-xp /usr/lib/libICE.so.6.3.0
b2f7f000 b2f84000 r-xp /usr/lib/libSM.so.6.0.1
b2f8c000 b2f8d000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2f95000 b2f97000 r-xp /usr/lib/libledplayer.so.0.1
b2f9f000 b2fa5000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2fad000 b2fae000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2fb7000 b2fbe000 r-xp /usr/lib/libGLESv2.so.2.0
b2fc6000 b300d000 r-xp /usr/lib/libtiff.so.5.1.0
b3018000 b3041000 r-xp /usr/lib/libturbojpeg.so
b305a000 b305e000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3067000 b306d000 r-xp /usr/lib/libgif.so.4.1.6
b3075000 b3097000 r-xp /usr/lib/libavutil.so.51.73.101
b30a6000 b30d4000 r-xp /usr/lib/libswscale.so.2.1.101
b30dd000 b33d4000 r-xp /usr/lib/libavcodec.so.54.59.100
b36fb000 b3714000 r-xp /usr/lib/libpng12.so.0.50.0
b371d000 b3724000 r-xp /usr/lib/libfeedback.so.0.1.4
b372d000 b3741000 r-xp /usr/lib/libtts.so
b3749000 b374b000 r-xp /usr/lib/libEGL.so.1.4
b3753000 b380a000 r-xp /usr/lib/libcairo.so.2.11200.12
b3814000 b382d000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3837000 b383b000 r-xp /usr/lib/libss-client.so.1.0.0
b3844000 b3846000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b384e000 b4111000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4182000 b418b000 r-xp /usr/lib/libslp_devman_plugin.so
b4194000 b4196000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b419e000 b41a1000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41a9000 b41af000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41b7000 b41ba000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b41c2000 b41cf000 r-xp /usr/lib/libmodem.so.0.0.0
b41d7000 b41da000 r-xp /usr/lib/libdevice-node.so.0.1
b41e2000 b41f2000 r-xp /usr/lib/libaccounts-svc.so.0.2.71
b41fa000 b41fd000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b4205000 b4209000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b4211000 b4217000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b421f000 b4220000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b4229000 b422c000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b4234000 b4237000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4240000 b4243000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b424b000 b424c000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b4254000 b4262000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b426b000 b4290000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4298000 b429b000 r-xp /usr/lib/libuuid.so.1.3.0
b42a4000 b42b8000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b42c1000 b42c9000 r-xp /usr/lib/libminizip.so.1.0.0
b42d1000 b42dd000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42e6000 b4304000 r-xp /usr/lib/libpcre.so.0.0.1
b430c000 b4310000 r-xp /usr/lib/libheynoti.so.0.0.2
b4318000 b4326000 r-xp /usr/lib/libdeviced.so.0.1.0
b432e000 b4339000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4346000 b434c000 r-xp /usr/lib/libdevman.so.0.1
b4354000 b4358000 r-xp /usr/lib/libchromium.so.1.0
b4360000 b4367000 r-xp /usr/lib/libalarm.so.0.0.0
b436f000 b4379000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b4382000 b4695000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b46be000 b46c8000 r-xp /lib/libnss_files-2.13.so
b46d8000 b46e8000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b46e9000 b46fd000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4705000 b4722000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b472a000 b472d000 r-xp /usr/lib/libiniparser.so.0
b4736000 b4789000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4793000 b47a7000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b47b0000 b47b2000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b47bb000 b47cc000 r-xp /usr/lib/libcom-core.so.0.0.1
b47d4000 b47da000 r-xp /usr/lib/libappsvc.so.0.1.0
b47e2000 b47e4000 r-xp /usr/lib/libdri2.so.0.0.0
b47ec000 b47f4000 r-xp /usr/lib/libdrm.so.2.4.0
b47fc000 b4800000 r-xp /usr/lib/libtbm.so.1.0.0
b4808000 b480b000 r-xp /usr/lib/libXv.so.1.0.0
b4813000 b4827000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b482f000 b48fb000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4911000 b4920000 r-xp /usr/lib/libnotification.so.0.1.0
b4928000 b494c000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4956000 b4966000 r-xp /lib/libresolv-2.13.so
b496a000 b496c000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4974000 b4a4c000 r-xp /usr/lib/libxml2.so.2.7.8
b4a59000 b4b36000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4b41000 b4b46000 r-xp /usr/lib/libcheck.so.0.0.0
b4b4e000 b4b58000 r-xp /usr/lib/libspdy.so.0.0.0
b4b61000 b4cb4000 r-xp /usr/lib/libcrypto.so.1.0.0
b4cd2000 b4d1e000 r-xp /usr/lib/libssl.so.1.0.0
b4d2a000 b4d58000 r-xp /usr/lib/libidn.so.11.5.44
b4d61000 b4d6b000 r-xp /usr/lib/libcares.so.2.1.0
b4d73000 b4d8a000 r-xp /lib/libexpat.so.1.5.2
b4d94000 b4db8000 r-xp /usr/lib/libicule.so.48.1
b4dc1000 b4dd0000 r-xp /usr/lib/libsf_common.so
b4dd8000 b4e73000 r-xp /usr/lib/libstdc++.so.6.0.14
b4e86000 b4e9e000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4e9f000 b4ea2000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4eaa000 b4eae000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4eb7000 b4ebc000 r-xp /usr/lib/libffi.so.5.0.10
b4ec4000 b4ec5000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4ecd000 b4ed7000 r-xp /usr/lib/libXext.so.6.4.0
b4ee0000 b4ee3000 r-xp /usr/lib/libXtst.so.6.1.0
b4eeb000 b4ef1000 r-xp /usr/lib/libXrender.so.1.3.0
b4ef9000 b4eff000 r-xp /usr/lib/libXrandr.so.2.2.0
b4f07000 b4f08000 r-xp /usr/lib/libXinerama.so.1.0.0
b4f11000 b4f1a000 r-xp /usr/lib/libXi.so.6.1.0
b4f22000 b4f25000 r-xp /usr/lib/libXfixes.so.3.1.0
b4f2d000 b4f2f000 r-xp /usr/lib/libXgesture.so.7.0.0
b4f37000 b4f38000 r-xp /usr/lib/libXdamage.so.1.1.0
b4f41000 b4f48000 r-xp /usr/lib/libXcursor.so.1.0.2
b4f50000 b4f73000 r-xp /usr/lib/libexif.so.12.3.3
b4f87000 b4f91000 r-xp /usr/lib/libethumb.so.1.7.99
b4f99000 b4fdd000 r-xp /usr/lib/libsndfile.so.1.0.25
b4feb000 b4fed000 r-xp /usr/lib/libctxdata.so.0.0.0
b4ff5000 b5003000 r-xp /usr/lib/libremix.so.0.0.0
b500b000 b500c000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5014000 b502d000 r-xp /usr/lib/liblua-5.1.so
b5036000 b503d000 r-xp /usr/lib/libembryo.so.1.7.99
b5046000 b5086000 r-xp /usr/lib/libcurl.so.4.3.0
b508f000 b50f9000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5106000 b512a000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5133000 b518f000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b51a1000 b51b5000 r-xp /usr/lib/libfribidi.so.0.3.1
b51bd000 b5215000 r-xp /usr/lib/libfreetype.so.6.8.1
b5220000 b5244000 r-xp /usr/lib/libjpeg.so.8.0.2
b525c000 b5273000 r-xp /lib/libz.so.1.2.5
b527b000 b5283000 r-xp /usr/lib/libemotion.so.1.7.99
b528b000 b5290000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5299000 b52a7000 r-xp /usr/lib/libsensor.so.1.1.0
b52b3000 b52b9000 r-xp /usr/lib/libappcore-common.so.1.1
b52c1000 b52c3000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.80
b52cb000 b52d6000 r-xp /usr/lib/libresourced.so.0.2.80
b52de000 b52e1000 r-xp /usr/lib/libproc-stat.so.0.2.80
b62de000 b63c6000 r-xp /usr/lib/libicuuc.so.48.1
b63d3000 b64f3000 r-xp /usr/lib/libicui18n.so.48.1
b6501000 b6504000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b650c000 b6514000 r-xp /usr/lib/libvconf.so.0.2.45
b6515000 b651b000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6523000 b652f000 r-xp /usr/lib/libail.so.0.1.0
b6537000 b6542000 r-xp /usr/lib/libaul.so.0.1.0
b654a000 b6561000 r-xp /usr/lib/libecore_input.so.1.7.99
b657c000 b6599000 r-xp /usr/lib/libecore_evas.so.1.7.99
b65a2000 b65a4000 r-xp /usr/lib/libXcomposite.so.1.0.0
b65ac000 b65e0000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b65e9000 b6618000 r-xp /usr/lib/libecore_x.so.1.7.99
b6622000 b6661000 r-xp /usr/lib/libeina.so.1.7.99
b666a000 b667f000 r-xp /usr/lib/libecore.so.1.7.99
b6696000 b66b1000 r-xp /usr/lib/libecore_con.so.1.7.99
b66ba000 b66bf000 r-xp /usr/lib/libecore_imf.so.1.7.99
b66c8000 b66d0000 r-xp /usr/lib/libethumb_client.so.1.7.99
b66d8000 b66e1000 r-xp /usr/lib/libedbus.so.1.7.99
b66e9000 b66eb000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b66f3000 b66f7000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6700000 b6716000 r-xp /usr/lib/libefreet.so.1.7.99
b6720000 b677c000 r-xp /usr/lib/libedje.so.1.7.99
b6786000 b678b000 r-xp /usr/lib/libecore_file.so.1.7.99
b6793000 b6843000 r-xp /usr/lib/libevas.so.1.7.99
b685d000 b6870000 r-xp /usr/lib/libeet.so.1.7.99
b6879000 b68e3000 r-xp /lib/libm-2.13.so
b68ec000 b68ed000 r-xp /usr/lib/libpmapi.so.1.2
b68f5000 b68fc000 r-xp /usr/lib/libutilX.so.1.1.0
b6904000 b6a27000 r-xp /usr/lib/libelementary.so.1.7.99
b6a3c000 b6a3f000 r-xp /lib/libattr.so.1.1.0
b6a47000 b6a49000 r-xp /usr/lib/libXau.so.6.0.0
b6a51000 b6a57000 r-xp /lib/librt-2.13.so
b6a60000 b6a68000 r-xp /lib/libcrypt-2.13.so
b6a98000 b6a9b000 r-xp /lib/libcap.so.2.21
b6aa3000 b6aa5000 r-xp /usr/lib/libiri.so
b6aad000 b6ac2000 r-xp /usr/lib/libxcb.so.1.1.0
b6aca000 b6ad5000 r-xp /lib/libunwind.so.8.0.1
b6b03000 b6c20000 r-xp /lib/libc-2.13.so
b6c2e000 b6c37000 r-xp /lib/libgcc_s-4.5.3.so.1
b6c3f000 b6c6b000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6c74000 b6c77000 r-xp /usr/lib/libbundle.so.0.1.22
b6c7f000 b6c81000 r-xp /lib/libdl-2.13.so
b6c8a000 b6c8d000 r-xp /usr/lib/libsmack.so.1.0.0
b6c95000 b6d6f000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6d78000 b6d8c000 r-xp /lib/libpthread-2.13.so
b6d9e000 b6da6000 r-xp /usr/lib/libappcore-efl.so.1.1
b6daf000 b6db0000 r-xp /usr/lib/libdlog.so.0.0.0
b6db9000 b6e26000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6e30000 b6e3a000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e43000 b6f29000 r-xp /usr/lib/libX11.so.6.3.0
b6f34000 b6f35000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6f3d000 b6f41000 r-xp /usr/lib/libsys-assert.so
b6f49000 b6f66000 r-xp /lib/ld-2.13.so
bea41000 bea62000 rwxp [stack]
End of Maps Information

Callstack Information (PID:24982)
Call Stack Count: 31
 0: gsignal + 0x3c (0xb6b2d760) [/lib/libc.so.6] + 0x2a760
 1: abort + 0x1ac (0xb6b3155c) [/lib/libc.so.6] + 0x2e55c
 2: __assert_fail + 0x10c (0xb6b2663c) [/lib/libc.so.6] + 0x2363c
 3: SysAssertfInternal + 0x9e (0xb44c1f3f) [/usr/lib/osp/libosp-appfw.so] + 0x13ff3f
 4: Tizen::Ui::Controls::IconListViewItem::Construct(Tizen::Graphics::Bitmap const&, Tizen::Base::String const*, Tizen::Graphics::Bitmap const*, Tizen::Graphics::Bitmap const*) + 0x70 (0xb3baad9d) [/usr/lib/osp/libosp-uifw.so] + 0x35cd9d
 5: MyHondanaMainForm::CreateItem(int) + 0x154 (0xb2df4df0) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3fdf0
 6: non-virtual thunk to MyHondanaMainForm::CreateItem(int) + 0x2c (0xb2df5434) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x40434
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d ﾌﾞｯｸ ﾏｲ本棚
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
