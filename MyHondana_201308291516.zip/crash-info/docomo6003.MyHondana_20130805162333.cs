S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG4
Build-Date: 2013.07.22 22:21:22

Crash Information
Process Name: MyHondana
PID: 8462
Date: 2013-08-05 16:23:33(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=8462 tid=8462
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 8462, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0x00000000
r2   = 0x8e8e0900, r3   = 0x8e8e0900
r4   = 0xb2e9ced5, r5   = 0xb2e9ce5e
r6   = 0xfffe8215, r7   = 0x00209018
r8   = 0xa00009cb, r9   = 0xbec07974
r10  = 0x00000002, fp   = 0xbec07698
ip   = 0x000033a8, sp   = 0xbec07608
lr   = 0xb2e5d0d0, pc   = 0xb2e5d0d4
cpsr = 0x68000010

Memory Information
MemTotal:  2063780 KB
MemFree:   1278884 KB
Buffers:     48112 KB
Cached:     367336 KB
VmPeak:     123516 KB
VmSize:     119396 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       30192 KB
VmRSS:       30192 KB
VmData:      18360 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       66888 KB
VmPTE:         106 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00071000 rw-p [heap]
00071000 003aa000 rw-p [heap]
b05b3000 b05b7000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b05c0000 b0dbf000 rwxp [stack:8464]
b0dbf000 b0dc5000 r-xp /usr/lib/libUMP.so
b0dcd000 b0f1b000 r-xp /usr/lib/r3p2/libMali.so
b0f27000 b0f50000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0f5c000 b0f7a000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b1272000 b12be000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b12c7000 b12cc000 r-xp /usr/lib/libjson.so.0.0.1
b12d4000 b12d8000 r-xp /usr/lib/liblocation-pos-log.so
b12e0000 b12f2000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b12fa000 b12fc000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b1304000 b1309000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b1311000 b131c000 r-xp /usr/lib/libdrm-trusted.so.0.0.54
b1324000 b1326000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b132e000 b133b000 r-xp /usr/lib/libdrm-client.so.0.0.91
b1344000 b134c000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b136e000 b13a5000 r-xp /usr/lib/libpulse.so.0.16.2
b13ad000 b1411000 r-xp /usr/lib/libasound.so.2.0.0
b141b000 b141e000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b1427000 b142b000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b1434000 b144f000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b1458000 b145d000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b1465000 b1492000 r-xp /usr/lib/libSLP-location.so.0.0.0
b149b000 b14a3000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b14a4000 b14a8000 r-xp /usr/lib/libmmffile.so.0.0.0
b14b0000 b14b8000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b14b9000 b14d2000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b14db000 b14f6000 r-xp /usr/lib/libmedia-service.so.1.0.0
b14fe000 b1509000 r-xp /usr/lib/libmdm-common.so.1.0.38
b1511000 b151d000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b1525000 b152c000 r-xp /usr/lib/libenchant.so.1.6.1
b1534000 b1537000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b1540000 b1549000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b1552000 b1556000 r-xp /usr/lib/libmmfsession.so.0.0.0
b155f000 b156e000 r-xp /usr/lib/libmmfsound.so.0.1.0
b1576000 b157b000 r-xp /usr/lib/libmemenv.so.1.1.0
b1583000 b15c1000 r-xp /usr/lib/libleveldb.so.1.1.0
b15ca000 b15f4000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b15fd000 b15ff000 r-xp /usr/lib/libsecfw.so
b1607000 b1610000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b161b000 b162a000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b1632000 b164a000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b164c000 b1659000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b1662000 b166b000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b1673000 b16b6000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b16be000 b175a000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b1766000 b178b000 r-xp /usr/lib/libxslt.so.1.1.16
b1794000 b1796000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b179e000 b17a6000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b17ae000 b17ba000 r-xp /usr/lib/libcapi-location-manager.so.0.1.14
b17c2000 b17c5000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b17cd000 b17d2000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b17da000 b1801000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.71
b1809000 b1822000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.1
b182a000 b1868000 r-xp /usr/lib/libmdm.so.1.0.67
b1870000 b1885000 r-xp /usr/lib/libnetwork.so.0.0.0
b188d000 b1896000 r-xp /usr/lib/libcapi-web-favorites.so
b189e000 b2afe000 r-xp /usr/lib/libewebkit2.so.0.10.154.1
b2bf1000 b2c44000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2c4d000 b2c64000 r-xp /usr/lib/libwifi-direct.so.0.0
b2c6c000 b2c74000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.10
b2c7c000 b2c85000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2c8e000 b2c99000 r-xp /usr/lib/libcapi-network-connection.so.0.1.13
b2ca1000 b2d0d000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2d1b000 b2dd0000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2ddd000 b2df7000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2e00000 b2e1e000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2e2d000 b2e37000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b2e3f000 b2ea9000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2eb6000 b2f32000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2f3a000 b2fca000 r-xp /usr/lib/libCOREGL.so.3.0
b2fd4000 b2fd7000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2fdf000 b2fe6000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2fef000 b2ffe000 r-xp /usr/lib/libICE.so.6.3.0
b3008000 b300d000 r-xp /usr/lib/libSM.so.6.0.1
b3015000 b3016000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b301e000 b3020000 r-xp /usr/lib/libledplayer.so.0.1
b3028000 b302e000 r-xp /usr/lib/libxcb-render.so.0.0.0
b3036000 b3037000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b3040000 b3047000 r-xp /usr/lib/libGLESv2.so.2.0
b304f000 b3096000 r-xp /usr/lib/libtiff.so.5.1.0
b30a1000 b30ca000 r-xp /usr/lib/libturbojpeg.so
b30e3000 b30e7000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b30f0000 b30f6000 r-xp /usr/lib/libgif.so.4.1.6
b30fe000 b3120000 r-xp /usr/lib/libavutil.so.51.73.101
b312f000 b315d000 r-xp /usr/lib/libswscale.so.2.1.101
b3166000 b345d000 r-xp /usr/lib/libavcodec.so.54.59.100
b3784000 b379d000 r-xp /usr/lib/libpng12.so.0.50.0
b37a6000 b37ad000 r-xp /usr/lib/libfeedback.so.0.1.4
b37b6000 b37ca000 r-xp /usr/lib/libtts.so
b37d2000 b37d4000 r-xp /usr/lib/libEGL.so.1.4
b37dc000 b3893000 r-xp /usr/lib/libcairo.so.2.11200.12
b389d000 b38b6000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b38c0000 b38c4000 r-xp /usr/lib/libss-client.so.1.0.0
b38cd000 b38cf000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b38d7000 b419a000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b420b000 b4214000 r-xp /usr/lib/libslp_devman_plugin.so
b421d000 b421f000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4227000 b422a000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4232000 b4238000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4240000 b4243000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b424b000 b4258000 r-xp /usr/lib/libmodem.so.0.0.0
b4260000 b4263000 r-xp /usr/lib/libdevice-node.so.0.1
b426b000 b427b000 r-xp /usr/lib/libaccounts-svc.so.0.2.71
b4283000 b4286000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b428e000 b4292000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b429a000 b42a0000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b42a8000 b42a9000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b42b2000 b42b5000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b42bd000 b42c0000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b42c9000 b42cc000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b42d4000 b42d5000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b42dd000 b42eb000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b42f4000 b4319000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4321000 b4324000 r-xp /usr/lib/libuuid.so.1.3.0
b432d000 b4341000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b434a000 b4352000 r-xp /usr/lib/libminizip.so.1.0.0
b435a000 b4366000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b436f000 b438d000 r-xp /usr/lib/libpcre.so.0.0.1
b4395000 b4399000 r-xp /usr/lib/libheynoti.so.0.0.2
b43a1000 b43af000 r-xp /usr/lib/libdeviced.so.0.1.0
b43b7000 b43c2000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b43cf000 b43d5000 r-xp /usr/lib/libdevman.so.0.1
b43dd000 b43e1000 r-xp /usr/lib/libchromium.so.1.0
b43e9000 b43f0000 r-xp /usr/lib/libalarm.so.0.0.0
b43f8000 b4402000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b440b000 b471e000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4747000 b4751000 r-xp /lib/libnss_files-2.13.so
b4761000 b4771000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4772000 b4786000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b478e000 b47ab000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b47b3000 b47b6000 r-xp /usr/lib/libiniparser.so.0
b47bf000 b4812000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b481c000 b4830000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b4839000 b483b000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b4844000 b4855000 r-xp /usr/lib/libcom-core.so.0.0.1
b485d000 b4863000 r-xp /usr/lib/libappsvc.so.0.1.0
b486b000 b486d000 r-xp /usr/lib/libdri2.so.0.0.0
b4875000 b487d000 r-xp /usr/lib/libdrm.so.2.4.0
b4885000 b4889000 r-xp /usr/lib/libtbm.so.1.0.0
b4891000 b4894000 r-xp /usr/lib/libXv.so.1.0.0
b489c000 b48b0000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b48b8000 b4984000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b499a000 b49a9000 r-xp /usr/lib/libnotification.so.0.1.0
b49b1000 b49d5000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b49df000 b49ef000 r-xp /lib/libresolv-2.13.so
b49f3000 b49f5000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b49fd000 b4ad5000 r-xp /usr/lib/libxml2.so.2.7.8
b4ae2000 b4bbf000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4bca000 b4bcf000 r-xp /usr/lib/libcheck.so.0.0.0
b4bd7000 b4be1000 r-xp /usr/lib/libspdy.so.0.0.0
b4bea000 b4d3d000 r-xp /usr/lib/libcrypto.so.1.0.0
b4d5b000 b4da7000 r-xp /usr/lib/libssl.so.1.0.0
b4db3000 b4de1000 r-xp /usr/lib/libidn.so.11.5.44
b4dea000 b4df4000 r-xp /usr/lib/libcares.so.2.1.0
b4dfc000 b4e13000 r-xp /lib/libexpat.so.1.5.2
b4e1d000 b4e41000 r-xp /usr/lib/libicule.so.48.1
b4e4a000 b4e59000 r-xp /usr/lib/libsf_common.so
b4e61000 b4efc000 r-xp /usr/lib/libstdc++.so.6.0.14
b4f0f000 b4f27000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4f28000 b4f2b000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4f33000 b4f37000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4f40000 b4f45000 r-xp /usr/lib/libffi.so.5.0.10
b4f4d000 b4f4e000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4f56000 b4f60000 r-xp /usr/lib/libXext.so.6.4.0
b4f69000 b4f6c000 r-xp /usr/lib/libXtst.so.6.1.0
b4f74000 b4f7a000 r-xp /usr/lib/libXrender.so.1.3.0
b4f82000 b4f88000 r-xp /usr/lib/libXrandr.so.2.2.0
b4f90000 b4f91000 r-xp /usr/lib/libXinerama.so.1.0.0
b4f9a000 b4fa3000 r-xp /usr/lib/libXi.so.6.1.0
b4fab000 b4fae000 r-xp /usr/lib/libXfixes.so.3.1.0
b4fb6000 b4fb8000 r-xp /usr/lib/libXgesture.so.7.0.0
b4fc0000 b4fc1000 r-xp /usr/lib/libXdamage.so.1.1.0
b4fca000 b4fd1000 r-xp /usr/lib/libXcursor.so.1.0.2
b4fd9000 b4ffc000 r-xp /usr/lib/libexif.so.12.3.3
b5010000 b501a000 r-xp /usr/lib/libethumb.so.1.7.99
b5022000 b5066000 r-xp /usr/lib/libsndfile.so.1.0.25
b5074000 b5076000 r-xp /usr/lib/libctxdata.so.0.0.0
b507e000 b508c000 r-xp /usr/lib/libremix.so.0.0.0
b5094000 b5095000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b509d000 b50b6000 r-xp /usr/lib/liblua-5.1.so
b50bf000 b50c6000 r-xp /usr/lib/libembryo.so.1.7.99
b50cf000 b510f000 r-xp /usr/lib/libcurl.so.4.3.0
b5118000 b5182000 r-xp /usr/lib/libpixman-1.so.0.28.2
b518f000 b51b3000 r-xp /usr/lib/libfontconfig.so.1.5.0
b51bc000 b5218000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b522a000 b523e000 r-xp /usr/lib/libfribidi.so.0.3.1
b5246000 b529e000 r-xp /usr/lib/libfreetype.so.6.8.1
b52a9000 b52cd000 r-xp /usr/lib/libjpeg.so.8.0.2
b52e5000 b52fc000 r-xp /lib/libz.so.1.2.5
b5304000 b530c000 r-xp /usr/lib/libemotion.so.1.7.99
b5314000 b5319000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5322000 b5330000 r-xp /usr/lib/libsensor.so.1.1.0
b533c000 b5342000 r-xp /usr/lib/libappcore-common.so.1.1
b534a000 b534c000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.80
b5354000 b535f000 r-xp /usr/lib/libresourced.so.0.2.80
b5367000 b536a000 r-xp /usr/lib/libproc-stat.so.0.2.80
b6367000 b644f000 r-xp /usr/lib/libicuuc.so.48.1
b645c000 b657c000 r-xp /usr/lib/libicui18n.so.48.1
b658a000 b658d000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6595000 b659d000 r-xp /usr/lib/libvconf.so.0.2.45
b659e000 b65a4000 r-xp /usr/lib/libxdgmime.so.1.1.0
b65ac000 b65b8000 r-xp /usr/lib/libail.so.0.1.0
b65c0000 b65cb000 r-xp /usr/lib/libaul.so.0.1.0
b65d3000 b65ea000 r-xp /usr/lib/libecore_input.so.1.7.99
b6605000 b6622000 r-xp /usr/lib/libecore_evas.so.1.7.99
b662b000 b662d000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6635000 b6669000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6672000 b66a1000 r-xp /usr/lib/libecore_x.so.1.7.99
b66ab000 b66ea000 r-xp /usr/lib/libeina.so.1.7.99
b66f3000 b6708000 r-xp /usr/lib/libecore.so.1.7.99
b671f000 b673a000 r-xp /usr/lib/libecore_con.so.1.7.99
b6743000 b6748000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6751000 b6759000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6761000 b676a000 r-xp /usr/lib/libedbus.so.1.7.99
b6772000 b6774000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b677c000 b6780000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6789000 b679f000 r-xp /usr/lib/libefreet.so.1.7.99
b67a9000 b6805000 r-xp /usr/lib/libedje.so.1.7.99
b680f000 b6814000 r-xp /usr/lib/libecore_file.so.1.7.99
b681c000 b68cc000 r-xp /usr/lib/libevas.so.1.7.99
b68e6000 b68f9000 r-xp /usr/lib/libeet.so.1.7.99
b6902000 b696c000 r-xp /lib/libm-2.13.so
b6975000 b6976000 r-xp /usr/lib/libpmapi.so.1.2
b697e000 b6985000 r-xp /usr/lib/libutilX.so.1.1.0
b698d000 b6ab0000 r-xp /usr/lib/libelementary.so.1.7.99
b6ac5000 b6ac8000 r-xp /lib/libattr.so.1.1.0
b6ad0000 b6ad2000 r-xp /usr/lib/libXau.so.6.0.0
b6ada000 b6ae0000 r-xp /lib/librt-2.13.so
b6ae9000 b6af1000 r-xp /lib/libcrypt-2.13.so
b6b21000 b6b24000 r-xp /lib/libcap.so.2.21
b6b2c000 b6b2e000 r-xp /usr/lib/libiri.so
b6b36000 b6b4b000 r-xp /usr/lib/libxcb.so.1.1.0
b6b53000 b6b5e000 r-xp /lib/libunwind.so.8.0.1
b6b8c000 b6ca9000 r-xp /lib/libc-2.13.so
b6cb7000 b6cc0000 r-xp /lib/libgcc_s-4.5.3.so.1
b6cc8000 b6cf4000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6cfd000 b6d00000 r-xp /usr/lib/libbundle.so.0.1.22
b6d08000 b6d0a000 r-xp /lib/libdl-2.13.so
b6d13000 b6d16000 r-xp /usr/lib/libsmack.so.1.0.0
b6d1e000 b6df8000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6e01000 b6e15000 r-xp /lib/libpthread-2.13.so
b6e27000 b6e2f000 r-xp /usr/lib/libappcore-efl.so.1.1
b6e38000 b6e39000 r-xp /usr/lib/libdlog.so.0.0.0
b6e42000 b6eaf000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6eb9000 b6ec3000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6ecc000 b6fb2000 r-xp /usr/lib/libX11.so.6.3.0
b6fbd000 b6fbe000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6fc6000 b6fca000 r-xp /usr/lib/libsys-assert.so
b6fd2000 b6fef000 r-xp /lib/ld-2.13.so
bebe9000 bec0a000 rwxp [stack]
End of Maps Information

Callstack Information (PID:8462)
Call Stack Count: 35
 0: HttpCommunicationService::postRequest(Tizen::Base::Collection::HashMap*, Tizen::App::App*, Tizen::Base::String) + 0x60 (0xb2e5d0d4) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x1e0d4
 1: MyHondanaMainForm::StartConect(Tizen::Base::String const&) + 0x2dc (0xb2e79cb4) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3acb4
 2: MyHondanaMainForm::OnInitializing() + 0x68 (0xb2e79904) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3a904
 3: non-virtual thunk to MyHondanaMainForm::OnInitializing() + 0x20 (0xb2e7b71c) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x3c71c
 4: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x22 (0xb3b8ea27) [/usr/lib/osp/libosp-uifw.so] + 0x2b7a27
 5: Tizen::Ui::Controls::_FormImpl::OnAttachedToMainTree() + 0x28 (0xb3d508b5) [/usr/lib/osp/libosp-uifw.so] + 0x4798b5
 6: Tizen::Ui::_Control::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0xb2 (0xb3b770bf) [/usr/lib/osp/libosp-uifw.so] + 0x2a00bf
 7: Tizen::Ui::_Control::EndAttaching(Tizen::Ui::_Control&) + 0xf2 (0xb3b7a247) [/usr/lib/osp/libosp-uifw.so] + 0x2a3247
 8: Tizen::Ui::_Control::AttachChild(Tizen::Ui::_Control&) + 0x5a (0xb3b7cc1f) [/usr/lib/osp/libosp-uifw.so] + 0x2a5c1f
 9: Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool) + 0xa4 (0xb3b99f59) [/usr/lib/osp/libosp-uifw.so] + 0x2c2f59
10: Tizen::Ui::Container::AddControl(Tizen::Ui::Control*) + 0x26 (0xb3b7143f) [/usr/lib/osp/libosp-uifw.so] + 0x29a43f
11: Tizen::Ui::Container::AddControl(Tizen::Ui::Control const&) + 0x6 (0xb3b714cb) [/usr/lib/osp/libosp-uifw.so] + 0x29a4cb
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d ﾌﾞｯｸ ﾏｲ本棚
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
