S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG4
Build-Date: 2013.07.22 22:21:22

Crash Information
Process Name: MyHondana
PID: 9090
Date: 2013-08-05 16:27:40(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=9090 tid=9090
Signal: 11
      (SIGSEGV)
      si_code: 1
      address not mapped to object
      si_addr = 0x4c

Register Information
r0   = 0x00000000, r1   = 0x00000000
r2   = 0x5527ac00, r3   = 0x5527ac00
r4   = 0x2a05ded5, r5   = 0x2a05de5e
r6   = 0xfffe8215, r7   = 0x2a21f3e8
r8   = 0xa00009cb, r9   = 0xbeffd2d4
r10  = 0x00000002, fp   = 0xbeffcff8
ip   = 0x000033a8, sp   = 0xbeffcf68
lr   = 0x2a01e0d0, pc   = 0x2a01e0d4
cpsr = 0x68000010

Memory Information
MemTotal:  2063780 KB
MemFree:   1235628 KB
Buffers:     48672 KB
Cached:     386348 KB
VmPeak:     125252 KB
VmSize:     121132 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       37228 KB
VmRSS:       37228 KB
VmData:      20732 KB
VmStk:         136 KB
VmExe:         424 KB
VmLib:       89748 KB
VmPTE:         106 KB
VmSwap:          0 KB

Maps Information
2a000000 2a06a000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
2a072000 2a077000 rwxp /opt/usr/apps/docomo6003/bin/MyHondana.exe
2a077000 2a3c1000 rwxp [heap]
afe3b000 b0048000 r-xp /usr/share/fonts/UDGothicBold.ttf
b0048000 b026e000 r-xp /usr/share/fonts/UDGothicRegular.ttf
b026e000 b05f2000 rwxs /dev/ump
b0673000 b0e72000 rwxp [stack:9092]
b0e72000 b0e78000 r-xp /usr/lib/libUMP.so
b0e7f000 b0e80000 rwxp /usr/lib/libUMP.so
b0e83000 b0e8c000 r-xs /var/cache/fontconfig/cdc77cde135ce87b641818a103cc9edb-le32d8.cache-3
b0e8c000 b0e90000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b0e97000 b0e98000 rwxp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b0e98000 b0fe6000 r-xp /usr/lib/r3p2/libMali.so
b0fee000 b0ff2000 rwxp /usr/lib/r3p2/libMali.so
b0ff2000 b101b000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b1023000 b1024000 rwxp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b1027000 b1045000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b104d000 b104e000 rwxp /usr/lib/osp/libtestbuddy.so.1.0
b1054000 b105e000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b1065000 b1066000 rwxp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b1066000 b1070000 r-xp /lib/libnss_files-2.13.so
b1077000 b1078000 r-xp /lib/libnss_files-2.13.so
b1078000 b1079000 rwxp /lib/libnss_files-2.13.so
b1079000 b1145000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b114d000 b115b000 rwxp /usr/lib/libscim-1.0.so.8.2.3
b115b000 b117f000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b1187000 b1189000 rwxp /usr/lib/ecore/immodules/libisf-imf-module.so
b1189000 b1278000 r-xp /usr/lib/locale/locale-archive
b1278000 b1478000 r-xp /usr/lib/locale/locale-archive
b1478000 b1508000 r-xp /usr/lib/libCOREGL.so.3.0
b150f000 b1511000 rwxp /usr/lib/libCOREGL.so.3.0
b1516000 b1518000 r-xs /var/cache/fontconfig/a307fb9815d691addd7f142e617ee37c-le32d8.cache-3
b1518000 b151d000 r-xs /var/cache/fontconfig/3830d5c3ddfd5cd38a049b759396e72e-le32d8.cache-3
b151d000 b1523000 r-xs /opt/home/app/.cache/evas_gl_common_caches/ARM::OpenGL
b1523000 b152a000 r-xs /usr/lib/gconv/gconv-modules.cache
b1535000 b1581000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b1589000 b158a000 rwxp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b158a000 b158f000 r-xp /usr/lib/libjson.so.0.0.1
b1596000 b1597000 rwxp /usr/lib/libjson.so.0.0.1
b1598000 b159c000 r-xp /usr/lib/liblocation-pos-log.so
b15a3000 b15a4000 rwxp /usr/lib/liblocation-pos-log.so
b15a4000 b15b6000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b15bd000 b15be000 rwxp /usr/lib/libmmfile_utils.so.0.0.0
b15be000 b15c0000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b15c7000 b15c8000 rwxp /usr/lib/libmedia-hash.so.1.0.0
b15c8000 b15cd000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b15d4000 b15d5000 rwxp /usr/lib/libmmutil_jpeg.so.0.0.0
b15d5000 b15e0000 r-xp /usr/lib/libdrm-trusted.so.0.0.54
b15e7000 b15e8000 rwxp /usr/lib/libdrm-trusted.so.0.0.54
b15e9000 b15eb000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b15f2000 b15f3000 rwxp /usr/lib/libmedia-svc-hash.so.1.0.0
b15f3000 b1600000 r-xp /usr/lib/libdrm-client.so.0.0.91
b1608000 b1609000 rwxp /usr/lib/libdrm-client.so.0.0.91
b1609000 b160c000 r-xp /lib/libattr.so.1.1.0
b1613000 b1614000 rwxp /lib/libattr.so.1.1.0
b1614000 b161c000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b1623000 b1626000 rwxp /usr/lib/lib_SamsungRec_V03010.so
b163f000 b1676000 r-xp /usr/lib/libpulse.so.0.16.2
b167d000 b167e000 rwxp /usr/lib/libpulse.so.0.16.2
b167e000 b16e2000 r-xp /usr/lib/libasound.so.2.0.0
b16e9000 b16ec000 rwxp /usr/lib/libasound.so.2.0.0
b16ec000 b16ef000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b16f7000 b16f8000 rwxp /usr/lib/libpulse-simple.so.0.0.4
b16f8000 b16fc000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b1704000 b1705000 rwxp /usr/lib/libascenario-0.2.so.0.0.0
b1705000 b1720000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b1728000 b1729000 rwxp /usr/lib/libavsysaudio.so.0.0.1
b172a000 b172f000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b1736000 b1737000 rwxp /usr/lib/libmmfsoundcommon.so.0.0.0
b1737000 b1764000 r-xp /usr/lib/libSLP-location.so.0.0.0
b176c000 b176d000 rwxp /usr/lib/libSLP-location.so.0.0.0
b176d000 b1775000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b1775000 b1776000 rwxp /usr/lib/libdownload-provider-interface.so.1.0.7
b1777000 b177b000 r-xp /usr/lib/libmmffile.so.0.0.0
b1782000 b1783000 rwxp /usr/lib/libmmffile.so.0.0.0
b1783000 b178b000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b178b000 b178c000 rwxp /usr/lib/libmedia-utils.so.0.0.0
b178c000 b17a5000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b17ad000 b17ae000 rwxp /usr/lib/libmedia-thumbnail.so.1.0.0
b17ae000 b17c9000 r-xp /usr/lib/libmedia-service.so.1.0.0
b17d0000 b17d1000 rwxp /usr/lib/libmedia-service.so.1.0.0
b17d1000 b17dc000 r-xp /usr/lib/libmdm-common.so.1.0.38
b17e3000 b17e4000 rwxp /usr/lib/libmdm-common.so.1.0.38
b17e5000 b17ed000 r-xp /lib/libcrypt-2.13.so
b17f4000 b17f5000 r-xp /lib/libcrypt-2.13.so
b17f5000 b17f6000 rwxp /lib/libcrypt-2.13.so
b181d000 b1820000 r-xp /lib/libcap.so.2.21
b1827000 b1828000 rwxp /lib/libcap.so.2.21
b1828000 b182a000 r-xp /usr/lib/libiri.so
b1831000 b1832000 rwxp /usr/lib/libiri.so
b1832000 b1842000 r-xp /lib/libresolv-2.13.so
b1842000 b1843000 r-xp /lib/libresolv-2.13.so
b1843000 b1844000 rwxp /lib/libresolv-2.13.so
b1847000 b1849000 r-xp /usr/lib/libXau.so.6.0.0
b1850000 b1851000 rwxp /usr/lib/libXau.so.6.0.0
b1851000 b1856000 r-xp /usr/lib/libffi.so.5.0.10
b185d000 b185e000 rwxp /usr/lib/libffi.so.5.0.10
b185e000 b185f000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b1866000 b1867000 rwxp /usr/lib/libgthread-2.0.so.0.3200.3
b1868000 b1872000 r-xp /usr/lib/libethumb.so.1.7.99
b1879000 b187a000 rwxp /usr/lib/libethumb.so.1.7.99
b187a000 b18be000 r-xp /usr/lib/libsndfile.so.1.0.25
b18c6000 b18c8000 rwxp /usr/lib/libsndfile.so.1.0.25
b18cc000 b18ce000 r-xp /usr/lib/libctxdata.so.0.0.0
b18d5000 b18d6000 rwxp /usr/lib/libctxdata.so.0.0.0
b18d6000 b18e4000 r-xp /usr/lib/libremix.so.0.0.0
b18eb000 b18ec000 rwxp /usr/lib/libremix.so.0.0.0
b18ec000 b18f3000 r-xp /usr/lib/libembryo.so.1.7.99
b18fb000 b18fc000 rwxp /usr/lib/libembryo.so.1.7.99
b18fd000 b18ff000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b1906000 b1907000 rwxp /usr/lib/libgmodule-2.0.so.0.3200.3
b1907000 b190a000 r-xp /usr/lib/libmm_ta.so.0.0.0
b1911000 b1912000 rwxp /usr/lib/libmm_ta.so.0.0.0
b1912000 b1919000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b1921000 b1922000 rwxp /usr/lib/libmmfcommon.so.0.0.0
b1922000 b1931000 r-xp /usr/lib/libICE.so.6.3.0
b1938000 b1939000 rwxp /usr/lib/libICE.so.6.3.0
b193b000 b1940000 r-xp /usr/lib/libSM.so.6.0.1
b1947000 b1948000 rwxp /usr/lib/libSM.so.6.0.1
b1949000 b1955000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b195c000 b195d000 rwxp /usr/lib/libbookmark-adaptor.so.0.2.7
b195d000 b1964000 r-xp /usr/lib/libenchant.so.1.6.1
b196b000 b196c000 rwxp /usr/lib/libenchant.so.1.6.1
b196c000 b196f000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b1977000 b1978000 rwxp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b1978000 b1981000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b1988000 b198a000 rwxp /usr/lib/libcapi-system-sensor.so.0.1.17
b198b000 b19af000 r-xp /usr/lib/libjpeg.so.8.0.2
b19b6000 b19b7000 rwxp /usr/lib/libjpeg.so.8.0.2
b19c7000 b19cb000 r-xp /usr/lib/libmmfsession.so.0.0.0
b19d3000 b19d4000 rwxp /usr/lib/libmmfsession.so.0.0.0
b19d4000 b19e3000 r-xp /usr/lib/libmmfsound.so.0.1.0
b19ea000 b19eb000 rwxp /usr/lib/libmmfsound.so.0.1.0
b19eb000 b19f0000 r-xp /usr/lib/libmemenv.so.1.1.0
b19f7000 b19f8000 rwxp /usr/lib/libmemenv.so.1.1.0
b19f8000 b1a36000 r-xp /usr/lib/libleveldb.so.1.1.0
b1a3e000 b1a3f000 rwxp /usr/lib/libleveldb.so.1.1.0
b1a3f000 b1a69000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b1a70000 b1a72000 rwxp /usr/lib/libgstaudio-0.10.so.0.25.0
b1a73000 b1a75000 r-xp /usr/lib/libsecfw.so
b1a7c000 b1a7d000 rwxp /usr/lib/libsecfw.so
b1a7d000 b1a86000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b1a8d000 b1a8e000 rwxp /usr/lib/libaudio-session-mgr.so.0.0.0
b1a91000 b1aa0000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b1aa7000 b1aa8000 rwxp /usr/lib/libgstvideo-0.10.so.0.25.0
b1aa8000 b1ac0000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b1ac0000 b1ac1000 rwxp /usr/lib/libgstpbutils-0.10.so.0.25.0
b1ac2000 b1acf000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b1ad7000 b1ad8000 rwxp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b1ad9000 b1ae2000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b1ae9000 b1aea000 rwxp /usr/lib/libgstapp-0.10.so.0.25.0
b1aea000 b1b2d000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b1b34000 b1b35000 rwxp /usr/lib/libgstbase-0.10.so.0.30.0
b1b35000 b1bd1000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b1bd9000 b1bdc000 rwxp /usr/lib/libgstreamer-0.10.so.0.30.0
b1bdd000 b1c02000 r-xp /usr/lib/libxslt.so.1.1.16
b1c0a000 b1c0b000 rwxp /usr/lib/libxslt.so.1.1.16
b1c0b000 b1c0d000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b1c14000 b1c15000 rwxp /usr/lib/libewebkit2-ext.so.1.0.2
b1c16000 b1c1e000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b1c25000 b1c26000 rwxp /usr/lib/libui-gadget-1.so.0.1.0
b1c26000 b1c32000 r-xp /usr/lib/libcapi-location-manager.so.0.1.14
b1c39000 b1c3a000 rwxp /usr/lib/libcapi-location-manager.so.0.1.14
b1c3a000 b1c3d000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b1c44000 b1c45000 rwxp /usr/lib/libcapi-web-url-download.so.0.1.0
b1c45000 b1c4a000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b1c51000 b1c52000 rwxp /usr/lib/libcapi-media-metadata-extractor.so
b1c52000 b1c79000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.71
b1c80000 b1c81000 rwxp /usr/lib/libcapi-content-media-content.so.0.2.71
b1c82000 b1c9b000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.1
b1ca2000 b1ca3000 rwxp /usr/lib/osp/libosp-locations.so.1.2.2.1
b1ca3000 b1ca8000 r-xp /usr/lib/libcheck.so.0.0.0
b1caf000 b1cb0000 rwxp /usr/lib/libcheck.so.0.0.0
b1cb0000 b1cba000 r-xp /usr/lib/libspdy.so.0.0.0
b1cc2000 b1cc3000 rwxp /usr/lib/libspdy.so.0.0.0
b1cc3000 b1cf1000 r-xp /usr/lib/libidn.so.11.5.44
b1cf9000 b1cfa000 rwxp /usr/lib/libidn.so.11.5.44
b1cfa000 b1d04000 r-xp /usr/lib/libcares.so.2.1.0
b1d0b000 b1d0c000 rwxp /usr/lib/libcares.so.2.1.0
b1d0d000 b1d4b000 r-xp /usr/lib/libmdm.so.1.0.67
b1d52000 b1d53000 rwxp /usr/lib/libmdm.so.1.0.67
b1d53000 b1d57000 r-xp /usr/lib/libss-client.so.1.0.0
b1d5f000 b1d60000 rwxp /usr/lib/libss-client.so.1.0.0
b1d60000 b1d75000 r-xp /usr/lib/libnetwork.so.0.0.0
b1d7c000 b1d7d000 rwxp /usr/lib/libnetwork.so.0.0.0
b1d7d000 b1d91000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b1d99000 b1d9a000 rwxp /usr/lib/libsecurity-server-commons.so.1.0.0
b1d9a000 b1d9c000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b1da3000 b1da4000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b1da4000 b1da5000 rwxp /usr/lib/libsystemd-daemon.so.0.0.10
b1da6000 b1db0000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b1db8000 b1db9000 rwxp /usr/lib/libprivilege-control.so.0.0.2
b1db9000 b1e96000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b1e9d000 b1ea0000 rwxp /usr/lib/libgio-2.0.so.0.3200.3
b1ea1000 b1eb5000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b1ebc000 b1ebd000 rwxp /usr/lib/libpkgmgr_parser.so.0.1.0
b1ebd000 b1ebf000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b1ec6000 b1ec7000 rwxp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b1ec8000 b1ecb000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b1ed2000 b1ed3000 rwxp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b1ed3000 b1ee4000 r-xp /usr/lib/libcom-core.so.0.0.1
b1eeb000 b1eec000 rwxp /usr/lib/libcom-core.so.0.0.1
b1eec000 b1ef2000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b1ef9000 b1efa000 rwxp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b1efa000 b1efd000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b1f04000 b1f05000 rwxp /usr/lib/libsyspopup_caller.so.0.1.0
b1f05000 b1f12000 r-xp /usr/lib/libmodem.so.0.0.0
b1f19000 b1f1a000 rwxp /usr/lib/libmodem.so.0.0.0
b1f1b000 b1f1e000 r-xp /usr/lib/libdevice-node.so.0.1
b1f25000 b1f26000 rwxp /usr/lib/libdevice-node.so.0.1
b1f26000 b1f36000 r-xp /usr/lib/libaccounts-svc.so.0.2.71
b1f3d000 b1f3e000 rwxp /usr/lib/libaccounts-svc.so.0.2.71
b1f3e000 b1f41000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b1f48000 b1f49000 rwxp /usr/lib/libcsc-feature.so.0.0.0
b1f49000 b1f4c000 r-xp /usr/lib/libsmack.so.1.0.0
b1f53000 b1f54000 rwxp /usr/lib/libsmack.so.1.0.0
b1f55000 b1f56000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b1f5d000 b1f5e000 rwxp /usr/lib/libmmfkeysound.so.0.0.0
b1f5e000 b1f60000 r-xp /usr/lib/libledplayer.so.0.1
b1f67000 b1f68000 rwxp /usr/lib/libledplayer.so.0.1
b1f68000 b1f8c000 r-xp /usr/lib/libicule.so.48.1
b1f94000 b1f95000 rwxp /usr/lib/libicule.so.48.1
b1f95000 b1f9b000 r-xp /usr/lib/libxcb-render.so.0.0.0
b1fa2000 b1fa3000 rwxp /usr/lib/libxcb-render.so.0.0.0
b1fa4000 b1fa5000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b1fad000 b1fae000 rwxp /usr/lib/libxcb-shm.so.0.0.0
b1fae000 b1fb5000 r-xp /usr/lib/libGLESv2.so.2.0
b1fbc000 b1fbd000 rwxp /usr/lib/libGLESv2.so.2.0
b1fbd000 b1fd4000 r-xp /lib/libexpat.so.1.5.2
b1fdc000 b1fde000 rwxp /lib/libexpat.so.1.5.2
b1fde000 b1fe1000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b1fe8000 b1fe9000 rwxp /usr/lib/libecore_input_evas.so.1.7.99
b1fe9000 b1fed000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b1ff5000 b1ff6000 rwxp /usr/lib/libecore_ipc.so.1.7.99
b1ff7000 b1ffd000 r-xp /usr/lib/libXrender.so.1.3.0
b2004000 b2005000 rwxp /usr/lib/libXrender.so.1.3.0
b2005000 b200b000 r-xp /usr/lib/libXrandr.so.2.2.0
b2012000 b2013000 rwxp /usr/lib/libXrandr.so.2.2.0
b2013000 b2014000 r-xp /usr/lib/libXinerama.so.1.0.0
b201c000 b201d000 rwxp /usr/lib/libXinerama.so.1.0.0
b201d000 b2026000 r-xp /usr/lib/libXi.so.6.1.0
b202d000 b202e000 rwxp /usr/lib/libXi.so.6.1.0
b202e000 b2030000 r-xp /usr/lib/libXgesture.so.7.0.0
b2037000 b2038000 rwxp /usr/lib/libXgesture.so.7.0.0
b2039000 b2040000 r-xp /usr/lib/libXcursor.so.1.0.2
b2047000 b2048000 rwxp /usr/lib/libXcursor.so.1.0.2
b2048000 b204b000 r-xp /usr/lib/libXfixes.so.3.1.0
b2052000 b2053000 rwxp /usr/lib/libXfixes.so.3.1.0
b2053000 b2068000 r-xp /usr/lib/libxcb.so.1.1.0
b206f000 b2070000 rwxp /usr/lib/libxcb.so.1.1.0
b2070000 b2078000 r-xp /usr/lib/libemotion.so.1.7.99
b207f000 b2080000 rwxp /usr/lib/libemotion.so.1.7.99
b2080000 b2085000 r-xp /usr/lib/libecore_fb.so.1.7.99
b208c000 b208e000 rwxp /usr/lib/libecore_fb.so.1.7.99
b208f000 b209e000 r-xp /usr/lib/libsf_common.so
b20a5000 b20a6000 rwxp /usr/lib/libsf_common.so
b20a6000 b20a9000 r-xp /usr/lib/libiniparser.so.0
b20b0000 b20b1000 rwxp /usr/lib/libiniparser.so.0
b20b2000 b2105000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b210c000 b210f000 rwxp /usr/lib/libsoup-2.4.so.1.5.0
b210f000 b2111000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.80
b2118000 b2119000 rwxp /usr/lib/libpowertop-wrapper.so.0.2.80
b2119000 b2124000 r-xp /usr/lib/libresourced.so.0.2.80
b212b000 b212c000 rwxp /usr/lib/libresourced.so.0.2.80
b212d000 b2130000 r-xp /usr/lib/libproc-stat.so.0.2.80
b2137000 b2138000 rwxp /usr/lib/libproc-stat.so.0.2.80
b2138000 b213a000 r-xp /usr/lib/libXcomposite.so.1.0.0
b2141000 b2142000 rwxp /usr/lib/libXcomposite.so.1.0.0
b2142000 b2176000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b217d000 b217f000 rwxp /usr/lib/libgobject-2.0.so.0.3200.3
b217f000 b219a000 r-xp /usr/lib/libecore_con.so.1.7.99
b21a1000 b21a2000 rwxp /usr/lib/libecore_con.so.1.7.99
b21a3000 b21ab000 r-xp /usr/lib/libethumb_client.so.1.7.99
b21b2000 b21b3000 rwxp /usr/lib/libethumb_client.so.1.7.99
b21b4000 b21bd000 r-xp /usr/lib/libedbus.so.1.7.99
b21c4000 b21c5000 rwxp /usr/lib/libedbus.so.1.7.99
b21c5000 b21c7000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b21ce000 b21cf000 rwxp /usr/lib/libefreet_trash.so.1.7.99
b21cf000 b21d3000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b21db000 b21dc000 rwxp /usr/lib/libefreet_mime.so.1.7.99
b21dc000 b21f2000 r-xp /usr/lib/libefreet.so.1.7.99
b21fa000 b21fb000 rwxp /usr/lib/libefreet.so.1.7.99
b21fc000 b2258000 r-xp /usr/lib/libedje.so.1.7.99
b2260000 b2262000 rwxp /usr/lib/libedje.so.1.7.99
b2262000 b2267000 r-xp /usr/lib/libecore_file.so.1.7.99
b226e000 b226f000 rwxp /usr/lib/libecore_file.so.1.7.99
b2270000 b2283000 r-xp /usr/lib/libeet.so.1.7.99
b228b000 b228c000 rwxp /usr/lib/libeet.so.1.7.99
b228c000 b3279000 r-xp /usr/lib/libicudata.so.48.1
b3280000 b3281000 rwxp /usr/lib/libicudata.so.48.1
b3281000 b3284000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b328b000 b328c000 rwxp /usr/lib/libSLP-db-util.so.0.1.0
b328c000 b3292000 r-xp /usr/lib/libxdgmime.so.1.1.0
b3299000 b329a000 rwxp /usr/lib/libxdgmime.so.1.1.0
b329a000 b32a6000 r-xp /usr/lib/libail.so.0.1.0
b32ad000 b32ae000 rwxp /usr/lib/libail.so.0.1.0
b32af000 b32d2000 r-xp /usr/lib/libexif.so.12.3.3
b32d9000 b32e6000 rwxp /usr/lib/libexif.so.12.3.3
b32e6000 b332d000 r-xp /usr/lib/libtiff.so.5.1.0
b3335000 b3338000 rwxp /usr/lib/libtiff.so.5.1.0
b3338000 b3361000 r-xp /usr/lib/libturbojpeg.so
b3369000 b336a000 rwxp /usr/lib/libturbojpeg.so
b337a000 b337e000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3386000 b3387000 rwxp /usr/lib/libmmutil_imgp.so.0.0.0
b3387000 b338d000 r-xp /usr/lib/libgif.so.4.1.6
b3394000 b3395000 rwxp /usr/lib/libgif.so.4.1.6
b3396000 b33b8000 r-xp /usr/lib/libavutil.so.51.73.101
b33c0000 b33c3000 rwxp /usr/lib/libavutil.so.51.73.101
b33c7000 b33f5000 r-xp /usr/lib/libswscale.so.2.1.101
b33fd000 b33fe000 rwxp /usr/lib/libswscale.so.2.1.101
b33fe000 b36f5000 r-xp /usr/lib/libavcodec.so.54.59.100
b36fd000 b370d000 rwxp /usr/lib/libavcodec.so.54.59.100
b3a1c000 b3a35000 r-xp /usr/lib/libpng12.so.0.50.0
b3a3d000 b3a3e000 rwxp /usr/lib/libpng12.so.0.50.0
b3a3e000 b3a47000 r-xp /usr/lib/libcapi-web-favorites.so
b3a4e000 b3a4f000 rwxp /usr/lib/libcapi-web-favorites.so
b3a50000 b4cb0000 r-xp /usr/lib/libewebkit2.so.0.10.154.1
b4cb7000 b4d9c000 rwxp /usr/lib/libewebkit2.so.0.10.154.1
b4da3000 b4df6000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b4dfd000 b4dff000 rwxp /usr/lib/osp/libosp-content.so.1.2.2.0
b4dff000 b4e16000 r-xp /usr/lib/libwifi-direct.so.0.0
b4e1d000 b4e1e000 rwxp /usr/lib/libwifi-direct.so.0.0
b4e1e000 b4e5e000 r-xp /usr/lib/libcurl.so.4.3.0
b4e65000 b4e67000 rwxp /usr/lib/libcurl.so.4.3.0
b4e67000 b4eb3000 r-xp /usr/lib/libssl.so.1.0.0
b4eba000 b4ebf000 rwxp /usr/lib/libssl.so.1.0.0
b4ebf000 b4ec7000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.10
b4ece000 b4ecf000 rwxp /usr/lib/libcapi-network-wifi.so.0.1.10
b4ed0000 b4ed9000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b4ee1000 b4ee2000 rwxp /usr/lib/libcapi-network-tethering.so.0.1.0
b4ee2000 b4eed000 r-xp /usr/lib/libcapi-network-connection.so.0.1.13
b4ef4000 b4ef5000 rwxp /usr/lib/libcapi-network-connection.so.0.1.13
b4ef5000 b5048000 r-xp /usr/lib/libcrypto.so.1.0.0
b5050000 b5063000 rwxp /usr/lib/libcrypto.so.1.0.0
b5066000 b507a000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b5081000 b5082000 rwxp /usr/lib/libsecurity-server-client.so.1.0.1
b5083000 b5087000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b508e000 b508f000 rwxp /usr/lib/libcapi-system-info.so.0.2.0
b508f000 b5095000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b509c000 b509d000 rwxp /usr/lib/libcapi-system-system-settings.so.0.0.2
b509d000 b509e000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b50a6000 b50a7000 rwxp /usr/lib/libcapi-system-power.so.0.1.0
b50a7000 b50aa000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b50b1000 b50b2000 rwxp /usr/lib/libcapi-system-device.so.0.1.0
b50b2000 b50b5000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b50bc000 b50bd000 rwxp /usr/lib/libcapi-network-serial.so.0.0.8
b50bd000 b50be000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b50c5000 b50c6000 rwxp /usr/lib/libcapi-content-mime-type.so.0.0.2
b50c7000 b50ec000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b50f3000 b50f4000 rwxp /usr/lib/libSLP-tapi.so.0.0.0
b50f4000 b510b000 r-xp /lib/libz.so.1.2.5
b5112000 b5113000 rwxp /lib/libz.so.1.2.5
b5113000 b5116000 r-xp /usr/lib/libuuid.so.1.3.0
b511e000 b511f000 rwxp /usr/lib/libuuid.so.1.3.0
b511f000 b518c000 r-xp /usr/lib/libsqlite3.so.0.8.6
b5193000 b5195000 rwxp /usr/lib/libsqlite3.so.0.8.6
b5196000 b51b3000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b51ba000 b51bb000 rwxp /usr/lib/libpkgmgr-info.so.0.0.17
b51bc000 b51e8000 r-xp /usr/lib/libdbus-1.so.3.7.2
b51f0000 b51f1000 rwxp /usr/lib/libdbus-1.so.3.7.2
b51f1000 b5209000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5209000 b520a000 rwxp /usr/lib/libdbus-glib-1.so.2.2.2
b520a000 b520b000 r-xp /usr/lib/libdlog.so.0.0.0
b5213000 b5214000 rwxp /usr/lib/libdlog.so.0.0.0
b5214000 b5228000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b5230000 b5231000 rwxp /usr/lib/libpkgmgr-client.so.0.1.68
b5231000 b5232000 r-xp /usr/lib/libpmapi.so.1.2
b5239000 b523a000 rwxp /usr/lib/libpmapi.so.1.2
b523a000 b523d000 r-xp /usr/lib/libbundle.so.0.1.22
b5244000 b5245000 rwxp /usr/lib/libbundle.so.0.1.22
b5246000 b5255000 r-xp /usr/lib/libnotification.so.0.1.0
b525c000 b525d000 rwxp /usr/lib/libnotification.so.0.1.0
b525d000 b5265000 r-xp /usr/lib/libminizip.so.1.0.0
b526c000 b526d000 rwxp /usr/lib/libminizip.so.1.0.0
b526d000 b5279000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b5281000 b5282000 rwxp /usr/lib/libmessage-port.so.1.2.2.0
b5282000 b52a0000 r-xp /usr/lib/libpcre.so.0.0.1
b52a7000 b52a8000 rwxp /usr/lib/libpcre.so.0.0.1
b52a8000 b5390000 r-xp /usr/lib/libicuuc.so.48.1
b5390000 b539b000 rwxp /usr/lib/libicuuc.so.48.1
b539d000 b54bd000 r-xp /usr/lib/libicui18n.so.48.1
b54c4000 b54ca000 rwxp /usr/lib/libicui18n.so.48.1
b54cc000 b54d0000 r-xp /usr/lib/libheynoti.so.0.0.2
b54d7000 b54d8000 rwxp /usr/lib/libheynoti.so.0.0.2
b54d8000 b54e6000 r-xp /usr/lib/libdeviced.so.0.1.0
b54ed000 b54ee000 rwxp /usr/lib/libdeviced.so.0.1.0
b54ee000 b54f9000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b5501000 b5502000 rwxp /usr/lib/libcryptsvc.so.0.0.1
b5506000 b550c000 r-xp /usr/lib/libdevman.so.0.1
b5513000 b5514000 rwxp /usr/lib/libdevman.so.0.1
b5514000 b551f000 r-xp /usr/lib/libaul.so.0.1.0
b5526000 b5527000 rwxp /usr/lib/libaul.so.0.1.0
b5528000 b552f000 r-xp /usr/lib/libalarm.so.0.0.0
b5536000 b5537000 rwxp /usr/lib/libalarm.so.0.0.0
b5537000 b5541000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b5549000 b554a000 rwxp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b554a000 b555a000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b555a000 b555b000 rwxp /usr/lib/libprivacy-manager-client.so.0.0.4
b555b000 b5561000 r-xp /lib/librt-2.13.so
b5568000 b5569000 r-xp /lib/librt-2.13.so
b5569000 b556a000 rwxp /lib/librt-2.13.so
b556a000 b55d4000 r-xp /lib/libm-2.13.so
b55db000 b55dc000 r-xp /lib/libm-2.13.so
b55dc000 b55dd000 rwxp /lib/libm-2.13.so
b55dd000 b55e1000 r-xp /usr/lib/libchromium.so.1.0
b55e8000 b55e9000 rwxp /usr/lib/libchromium.so.1.0
b55ea000 b55ed000 r-xp /usr/lib/libXtst.so.6.1.0
b55f4000 b55f5000 rwxp /usr/lib/libXtst.so.6.1.0
b55f5000 b55fc000 r-xp /usr/lib/libutilX.so.1.1.0
b5603000 b5604000 rwxp /usr/lib/libutilX.so.1.1.0
b5604000 b5607000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b560f000 b5610000 rwxp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b5610000 b5629000 r-xp /usr/lib/liblua-5.1.so
b5631000 b5632000 rwxp /usr/lib/liblua-5.1.so
b5632000 b5636000 r-xp /usr/lib/libtbm.so.1.0.0
b563d000 b563e000 rwxp /usr/lib/libtbm.so.1.0.0
b563f000 b5647000 r-xp /usr/lib/libdrm.so.2.4.0
b564e000 b564f000 rwxp /usr/lib/libdrm.so.2.4.0
b564f000 b5651000 r-xp /usr/lib/libdri2.so.0.0.0
b5658000 b5659000 rwxp /usr/lib/libdri2.so.0.0.0
b5659000 b5660000 r-xp /usr/lib/libfeedback.so.0.1.4
b5668000 b5669000 rwxp /usr/lib/libfeedback.so.0.1.4
b5669000 b567d000 r-xp /usr/lib/libtts.so
b5684000 b5685000 rwxp /usr/lib/libtts.so
b5685000 b5688000 r-xp /usr/lib/libXv.so.1.0.0
b568f000 b5690000 rwxp /usr/lib/libXv.so.1.0.0
b5690000 b5692000 r-xp /usr/lib/libEGL.so.1.4
b5699000 b569a000 rwxp /usr/lib/libEGL.so.1.4
b569b000 b56a5000 r-xp /usr/lib/libXext.so.6.4.0
b56ad000 b56ae000 rwxp /usr/lib/libXext.so.6.4.0
b56ae000 b570a000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5712000 b571c000 rwxp /usr/lib/libharfbuzz.so.0.907.0
b571c000 b5730000 r-xp /usr/lib/libfribidi.so.0.3.1
b5737000 b5738000 rwxp /usr/lib/libfribidi.so.0.3.1
b5738000 b5790000 r-xp /usr/lib/libfreetype.so.6.8.1
b5797000 b579b000 rwxp /usr/lib/libfreetype.so.6.8.1
b579b000 b5875000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b587d000 b587e000 rwxp /usr/lib/libglib-2.0.so.0.3200.3
b587e000 b58e8000 r-xp /usr/lib/libpixman-1.so.0.28.2
b58f0000 b58f5000 rwxp /usr/lib/libpixman-1.so.0.28.2
b58f6000 b59ad000 r-xp /usr/lib/libcairo.so.2.11200.12
b59b4000 b59b7000 rwxp /usr/lib/libcairo.so.2.11200.12
b59b7000 b59db000 r-xp /usr/lib/libfontconfig.so.1.5.0
b59e2000 b59e4000 rwxp /usr/lib/libfontconfig.so.1.5.0
b59e4000 b5abc000 r-xp /usr/lib/libxml2.so.2.7.8
b5ac3000 b5ac9000 rwxp /usr/lib/libxml2.so.2.7.8
b5ac9000 b5ae0000 r-xp /usr/lib/libecore_input.so.1.7.99
b5ae7000 b5afb000 rwxp /usr/lib/libecore_input.so.1.7.99
b5afb000 b5afc000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5b03000 b5b04000 rwxp /usr/lib/libecore_imf_evas.so.1.7.99
b5b04000 b5b09000 r-xp /usr/lib/libecore_imf.so.1.7.99
b5b11000 b5b12000 rwxp /usr/lib/libecore_imf.so.1.7.99
b5b12000 b5b41000 r-xp /usr/lib/libecore_x.so.1.7.99
b5b49000 b5b4b000 rwxp /usr/lib/libecore_x.so.1.7.99
b5b4b000 b5b68000 r-xp /usr/lib/libecore_evas.so.1.7.99
b5b6f000 b5b71000 rwxp /usr/lib/libecore_evas.so.1.7.99
b5b71000 b5bb0000 r-xp /usr/lib/libeina.so.1.7.99
b5bb7000 b5bb9000 rwxp /usr/lib/libeina.so.1.7.99
b5bb9000 b5c69000 r-xp /usr/lib/libevas.so.1.7.99
b5c69000 b5c71000 rwxp /usr/lib/libevas.so.1.7.99
b5c83000 b5c98000 r-xp /usr/lib/libecore.so.1.7.99
b5ca0000 b5ca1000 rwxp /usr/lib/libecore.so.1.7.99
b5caf000 b5cc3000 r-xp /lib/libpthread-2.13.so
b5cca000 b5ccb000 r-xp /lib/libpthread-2.13.so
b5ccb000 b5ccc000 rwxp /lib/libpthread-2.13.so
b5cce000 b5cd6000 r-xp /usr/lib/libvconf.so.0.2.45
b5cd6000 b5cd7000 rwxp /usr/lib/libvconf.so.0.2.45
b5cd7000 b5cd8000 r-xp /usr/lib/libXdamage.so.1.1.0
b5ce0000 b5ce1000 rwxp /usr/lib/libXdamage.so.1.1.0
b5ce1000 b5dc7000 r-xp /usr/lib/libX11.so.6.3.0
b5dce000 b5dd2000 rwxp /usr/lib/libX11.so.6.3.0
b5dd2000 b5ef5000 r-xp /usr/lib/libelementary.so.1.7.99
b5efc000 b5f03000 rwxp /usr/lib/libelementary.so.1.7.99
b5f0a000 b5f18000 r-xp /usr/lib/libsensor.so.1.1.0
b5f20000 b5f21000 rwxp /usr/lib/libsensor.so.1.1.0
b5f24000 b5f2a000 r-xp /usr/lib/libappsvc.so.0.1.0
b5f31000 b5f32000 rwxp /usr/lib/libappsvc.so.0.1.0
b5f32000 b5f3a000 r-xp /usr/lib/libappcore-efl.so.1.1
b5f41000 b5f42000 rwxp /usr/lib/libappcore-efl.so.1.1
b5f42000 b5f48000 r-xp /usr/lib/libappcore-common.so.1.1
b5f4f000 b5f50000 rwxp /usr/lib/libappcore-common.so.1.1
b5f50000 b5f5e000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b5f65000 b5f66000 rwxp /usr/lib/libcapi-appfw-application.so.0.1.0
b5f67000 b5f80000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b5f88000 b5f89000 rwxp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b5f89000 b5f8b000 r-xp /lib/libdl-2.13.so
b5f92000 b5f93000 r-xp /lib/libdl-2.13.so
b5f93000 b5f94000 rwxp /lib/libdl-2.13.so
b5f94000 b5f9f000 r-xp /lib/libunwind.so.8.0.1
b5fa7000 b5fa8000 rwxp /lib/libunwind.so.8.0.1
b5fcd000 b60ea000 r-xp /lib/libc-2.13.so
b60f2000 b60f4000 r-xp /lib/libc-2.13.so
b60f4000 b60f5000 rwxp /lib/libc-2.13.so
b60f8000 b6101000 r-xp /lib/libgcc_s-4.5.3.so.1
b6108000 b6109000 rwxp /lib/libgcc_s-4.5.3.so.1
b6109000 b61a4000 r-xp /usr/lib/libstdc++.so.6.0.14
b61ac000 b61af000 r-xp /usr/lib/libstdc++.so.6.0.14
b61af000 b61b1000 rwxp /usr/lib/libstdc++.so.6.0.14
b61b7000 b6223000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b622b000 b6231000 rwxp /usr/lib/osp/libosp-web.so.1.2.2.0
b6231000 b62e6000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b62ee000 b62f3000 rwxp /usr/lib/osp/libosp-net.so.1.2.2.0
b62f3000 b630d000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b6314000 b6316000 rwxp /usr/lib/osp/libosp-json.so.1.2.2.0
b6316000 b6334000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b633c000 b633d000 rwxp /usr/lib/osp/libosp-image.so.1.2.2.0
b633d000 b6650000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b6658000 b6676000 rwxp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b6679000 b6f3c000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b6f44000 b6fab000 rwxp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b6faf000 b6fb0000 r-xs /opt/home/app/.cache/evas_gl_common_caches/ARM::OpenGL
b6fb0000 b6fb1000 rwxs /dev/ump
b6fb3000 b6fbc000 r-xp /usr/lib/libslp_devman_plugin.so
b6fc4000 b6fc5000 rwxp /usr/lib/libslp_devman_plugin.so
b6fc5000 b6fc6000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6fcd000 b6fce000 rwxp /usr/local/lib/libcortex-strings.so.1.0.0
b6fce000 b6fd2000 r-xp /usr/lib/libsys-assert.so
b6fd9000 b6fda000 rwxp /usr/lib/libsys-assert.so
b6fda000 b6ff7000 r-xp /lib/ld-2.13.so
b6ffe000 b6fff000 r-xp /lib/ld-2.13.so
b6fff000 b7000000 rwxp /lib/ld-2.13.so
befdf000 bf000000 rwxp [stack]
End of Maps Information

Callstack Information (PID:9090)
Call Stack Count: 35
 0: (0x2a01e0d4) [/opt/apps/docomo6003/bin/MyHondana] + 0x1e0d4
 1: (0x2a03acb4) [/opt/apps/docomo6003/bin/MyHondana] + 0x3acb4
 2: (0x2a03a904) [/opt/apps/docomo6003/bin/MyHondana] + 0x3a904
 3: (0x2a03c71c) [/opt/apps/docomo6003/bin/MyHondana] + 0x3c71c
 4: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x22 (0xb6930a27) [/usr/lib/osp/libosp-uifw.so.1] + 0x2b7a27
 5: Tizen::Ui::Controls::_FormImpl::OnAttachedToMainTree() + 0x28 (0xb6af28b5) [/usr/lib/osp/libosp-uifw.so.1] + 0x4798b5
 6: Tizen::Ui::_Control::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0xb2 (0xb69190bf) [/usr/lib/osp/libosp-uifw.so.1] + 0x2a00bf
 7: Tizen::Ui::_Control::EndAttaching(Tizen::Ui::_Control&) + 0xf2 (0xb691c247) [/usr/lib/osp/libosp-uifw.so.1] + 0x2a3247
 8: Tizen::Ui::_Control::AttachChild(Tizen::Ui::_Control&) + 0x5a (0xb691ec1f) [/usr/lib/osp/libosp-uifw.so.1] + 0x2a5c1f
 9: Tizen::Ui::_ContainerImpl::AddChild(Tizen::Ui::_ControlImpl*, bool) + 0xa4 (0xb693bf59) [/usr/lib/osp/libosp-uifw.so.1] + 0x2c2f59
10: Tizen::Ui::Container::AddControl(Tizen::Ui::Control*) + 0x26 (0xb691343f) [/usr/lib/osp/libosp-uifw.so.1] + 0x29a43f
11: Tizen::Ui::Container::AddControl(Tizen::Ui::Control const&) + 0x6 (0xb69134cb) [/usr/lib/osp/libosp-uifw.so.1] + 0x29a4cb
12: (0xb6bbc173) [/usr/lib/osp/libosp-uifw.so.1] + 0x543173
13: (0xb6bbcbc3) [/usr/lib/osp/libosp-uifw.so.1] + 0x543bc3
14: (0xb6bbf691) [/usr/lib/osp/libosp-uifw.so.1] + 0x546691
15: Tizen::Ui::Scenes::SceneManager::GoForward(Tizen::Ui::Scenes::ForwardSceneTransition const&, Tizen::Base::Collection::IList const*) + 0x18 (0xb6bb40d1) [/usr/lib/osp/libosp-uifw.so.1] + 0x53b0d1
16: (0x2a033420) [/opt/apps/docomo6003/bin/MyHondana] + 0x33420
17: Tizen::Ui::_ControlImpl::OnAttachedToMainTree() + 0x22 (0xb6930a27) [/usr/lib/osp/libosp-uifw.so.1] + 0x2b7a27
18: Tizen::Ui::Controls::_FrameImpl::OnAttachedToMainTree() + 0xa (0xb6af580f) [/usr/lib/osp/libosp-uifw.so.1] + 0x47c80f
19: Tizen::Ui::_ControlManager::CallOnAttachedToMainTree(Tizen::Ui::_Control&) + 0x76 (0xb693fec7) [/usr/lib/osp/libosp-uifw.so.1] + 0x2c6ec7
20: Tizen::Ui::_ControlManager::ActivateWindow(Tizen::Ui::_Window&, bool) + 0xca (0xb6940e3f) [/usr/lib/osp/libosp-uifw.so.1] + 0x2c7e3f
21: Tizen::Ui::_ControlManager::OpenWindow(Tizen::Ui::_Window&, bool) + 0x2e (0xb694102f) [/usr/lib/osp/libosp-uifw.so.1] + 0x2c802f
22: Tizen::Ui::_Window::Open(bool) + 0x3c (0xb692daf5) [/usr/lib/osp/libosp-uifw.so.1] + 0x2b4af5
23: Tizen::Ui::_WindowImpl::Open(bool) + 0x12 (0xb693dd83) [/usr/lib/osp/libosp-uifw.so.1] + 0x2c4d83
24: Tizen::App::_UiAppImpl::AddFrame(Tizen::Ui::Controls::Frame const&) + 0x40 (0xb6cf4779) [/usr/lib/osp/libosp-uifw.so.1] + 0x67b779
25: Tizen::App::UiApp::AddFrame(Tizen::Ui::Controls::Frame const&) + 0x14 (0xb6cf39e5) [/usr/lib/osp/libosp-uifw.so.1] + 0x67a9e5
26: (0x2a023d7c) [/opt/apps/docomo6003/bin/MyHondana] + 0x23d7c
27: Tizen::App::_UiAppImpl::OnAppInitialized() + 0x18 (0xb6cf3ec9) [/usr/lib/osp/libosp-uifw.so.1] + 0x67aec9
28: Tizen::App::_AppImpl::OnService(service_s*, void*) + 0x1da (0xb642ed67) [/usr/lib/osp/libosp-appfw.so.1] + 0xf1d67
29: (0xb5f59bdd) [/usr/lib/libcapi-appfw-application.so.0] + 0x9bdd
30: (0xb5f34c3c) [/usr/lib/libappcore-efl.so.1] + 0x2c3c
31: (0xb5f4394c) [/usr/lib/libappcore-common.so.1] + 0x194c
32: (0xb5f44024) [/usr/lib/libappcore-common.so.1] + 0x2024
33: (0xb5517205) [/usr/lib/libaul.so.0] + 0x3205
dladdr failed 34: (0x2a097c30) (null)
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d ﾌﾞｯｸ ﾏｲ本棚
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
