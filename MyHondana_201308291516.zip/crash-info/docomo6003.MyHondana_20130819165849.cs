S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG4
Build-Date: 2013.07.22 22:21:22

Crash Information
Process Name: MyHondana
PID: 24172
Date: 2013-08-19 16:58:49(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=24172 tid=24172
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 24172, uid 5000)

Register Information
r0   = 0x013503e0, r1   = 0x00000001
r2   = 0xbe941150, r3   = 0x00000000
r4   = 0x01455bd8, r5   = 0x00000002
r6   = 0x01455bd8, r7   = 0xb466131c
r8   = 0xbe941150, r9   = 0x00000000
r10  = 0x00000000, fp   = 0xb64b9294
ip   = 0x00232600, sp   = 0xbe941150
lr   = 0xb454127b, pc   = 0xb4541318
cpsr = 0x68010030

Memory Information
MemTotal:  2063780 KB
MemFree:    824176 KB
Buffers:     64720 KB
Cached:     686008 KB
VmPeak:     225820 KB
VmSize:     182740 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      107712 KB
VmRSS:      107712 KB
VmData:      80308 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       67016 KB
VmPTE:         202 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00071000 rw-p [heap]
00071000 0306c000 rw-p [heap]
ae464000 ae466000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
af470000 afc6f000 rwxp [stack:24177]
b00c2000 b00c3000 r-xp /usr/lib/evas/modules/savers/jpeg/linux-gnueabi-armv7l-1.7.99/module.so
b00cb000 b00ce000 r-xp /usr/lib/evas/modules/engines/buffer/linux-gnueabi-armv7l-1.7.99/module.so
b04b4000 b04b8000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b04c1000 b0cc0000 rwxp [stack:24174]
b0cc0000 b0cc6000 r-xp /usr/lib/libUMP.so
b0cce000 b0e1c000 r-xp /usr/lib/r3p2/libMali.so
b0e28000 b0e51000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0e5d000 b0e7b000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b1173000 b11bf000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b11c8000 b11cd000 r-xp /usr/lib/libjson.so.0.0.1
b11d5000 b11d9000 r-xp /usr/lib/liblocation-pos-log.so
b11e1000 b11f3000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b11fb000 b11fd000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b1205000 b120a000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b1212000 b121d000 r-xp /usr/lib/libdrm-trusted.so.0.0.54
b1225000 b1227000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b122f000 b123c000 r-xp /usr/lib/libdrm-client.so.0.0.91
b1245000 b124d000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b126f000 b12a6000 r-xp /usr/lib/libpulse.so.0.16.2
b12ae000 b1312000 r-xp /usr/lib/libasound.so.2.0.0
b131c000 b131f000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b1328000 b132c000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b1335000 b1350000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b1359000 b135e000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b1366000 b1393000 r-xp /usr/lib/libSLP-location.so.0.0.0
b139c000 b13a4000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b13a5000 b13a9000 r-xp /usr/lib/libmmffile.so.0.0.0
b13b1000 b13b9000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b13ba000 b13d3000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b13dc000 b13f7000 r-xp /usr/lib/libmedia-service.so.1.0.0
b13ff000 b140a000 r-xp /usr/lib/libmdm-common.so.1.0.38
b1412000 b141e000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b1426000 b142d000 r-xp /usr/lib/libenchant.so.1.6.1
b1435000 b1438000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b1441000 b144a000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b1453000 b1457000 r-xp /usr/lib/libmmfsession.so.0.0.0
b1460000 b146f000 r-xp /usr/lib/libmmfsound.so.0.1.0
b1477000 b147c000 r-xp /usr/lib/libmemenv.so.1.1.0
b1484000 b14c2000 r-xp /usr/lib/libleveldb.so.1.1.0
b14cb000 b14f5000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b14fe000 b1500000 r-xp /usr/lib/libsecfw.so
b1508000 b1511000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b151c000 b152b000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b1533000 b154b000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b154d000 b155a000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b1563000 b156c000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b1574000 b15b7000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b15bf000 b165b000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b1667000 b168c000 r-xp /usr/lib/libxslt.so.1.1.16
b1695000 b1697000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b169f000 b16a7000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b16af000 b16bb000 r-xp /usr/lib/libcapi-location-manager.so.0.1.14
b16c3000 b16c6000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b16ce000 b16d3000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b16db000 b1702000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.71
b170a000 b1723000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.1
b172b000 b1769000 r-xp /usr/lib/libmdm.so.1.0.67
b1771000 b1786000 r-xp /usr/lib/libnetwork.so.0.0.0
b178e000 b1797000 r-xp /usr/lib/libcapi-web-favorites.so
b179f000 b29ff000 r-xp /usr/lib/libewebkit2.so.0.10.154.1
b2af2000 b2b45000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2b4e000 b2b65000 r-xp /usr/lib/libwifi-direct.so.0.0
b2b6d000 b2b75000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.10
b2b7d000 b2b86000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2b8f000 b2b9a000 r-xp /usr/lib/libcapi-network-connection.so.0.1.13
b2ba2000 b2c0e000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2c1c000 b2cd1000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2cde000 b2cf8000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2d01000 b2d1f000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2d2e000 b2d38000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b2d40000 b2dc4000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2dd2000 b2e4e000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2e56000 b2ee6000 r-xp /usr/lib/libCOREGL.so.3.0
b2ef0000 b2ef3000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2efb000 b2f02000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2f0b000 b2f1a000 r-xp /usr/lib/libICE.so.6.3.0
b2f24000 b2f29000 r-xp /usr/lib/libSM.so.6.0.1
b2f31000 b2f32000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2f3a000 b2f3c000 r-xp /usr/lib/libledplayer.so.0.1
b2f44000 b2f4a000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2f52000 b2f53000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2f5c000 b2f63000 r-xp /usr/lib/libGLESv2.so.2.0
b2f6b000 b2fb2000 r-xp /usr/lib/libtiff.so.5.1.0
b2fbd000 b2fe6000 r-xp /usr/lib/libturbojpeg.so
b2fff000 b3003000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b300c000 b3012000 r-xp /usr/lib/libgif.so.4.1.6
b301a000 b303c000 r-xp /usr/lib/libavutil.so.51.73.101
b304b000 b3079000 r-xp /usr/lib/libswscale.so.2.1.101
b3082000 b3379000 r-xp /usr/lib/libavcodec.so.54.59.100
b36a0000 b36b9000 r-xp /usr/lib/libpng12.so.0.50.0
b36c2000 b36c9000 r-xp /usr/lib/libfeedback.so.0.1.4
b36d2000 b36e6000 r-xp /usr/lib/libtts.so
b36ee000 b36f0000 r-xp /usr/lib/libEGL.so.1.4
b36f8000 b37af000 r-xp /usr/lib/libcairo.so.2.11200.12
b37b9000 b37d2000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b37dc000 b37e0000 r-xp /usr/lib/libss-client.so.1.0.0
b37e9000 b37eb000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b37f3000 b40b6000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4127000 b4130000 r-xp /usr/lib/libslp_devman_plugin.so
b4139000 b413b000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b4143000 b4146000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b414e000 b4154000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b415c000 b415f000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b4167000 b4174000 r-xp /usr/lib/libmodem.so.0.0.0
b417c000 b417f000 r-xp /usr/lib/libdevice-node.so.0.1
b4187000 b4197000 r-xp /usr/lib/libaccounts-svc.so.0.2.71
b419f000 b41a2000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b41aa000 b41ae000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b41b6000 b41bc000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41c4000 b41c5000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b41ce000 b41d1000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b41d9000 b41dc000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b41e5000 b41e8000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b41f0000 b41f1000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41f9000 b4207000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4210000 b4235000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b423d000 b4240000 r-xp /usr/lib/libuuid.so.1.3.0
b4249000 b425d000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4266000 b426e000 r-xp /usr/lib/libminizip.so.1.0.0
b4276000 b4282000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b428b000 b42a9000 r-xp /usr/lib/libpcre.so.0.0.1
b42b1000 b42b5000 r-xp /usr/lib/libheynoti.so.0.0.2
b42bd000 b42cb000 r-xp /usr/lib/libdeviced.so.0.1.0
b42d3000 b42de000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42eb000 b42f1000 r-xp /usr/lib/libdevman.so.0.1
b42f9000 b42fd000 r-xp /usr/lib/libchromium.so.1.0
b4305000 b430c000 r-xp /usr/lib/libalarm.so.0.0.0
b4314000 b431e000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b4327000 b463a000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4663000 b466d000 r-xp /lib/libnss_files-2.13.so
b467d000 b468d000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b468e000 b46a2000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b46aa000 b46c7000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b46cf000 b46d2000 r-xp /usr/lib/libiniparser.so.0
b46db000 b472e000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4738000 b474c000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b4755000 b4757000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b4760000 b4771000 r-xp /usr/lib/libcom-core.so.0.0.1
b4779000 b477f000 r-xp /usr/lib/libappsvc.so.0.1.0
b4787000 b4789000 r-xp /usr/lib/libdri2.so.0.0.0
b4791000 b4799000 r-xp /usr/lib/libdrm.so.2.4.0
b47a1000 b47a5000 r-xp /usr/lib/libtbm.so.1.0.0
b47ad000 b47b0000 r-xp /usr/lib/libXv.so.1.0.0
b47b8000 b47cc000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b47d4000 b48a0000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b48b6000 b48c5000 r-xp /usr/lib/libnotification.so.0.1.0
b48cd000 b48f1000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b48fb000 b490b000 r-xp /lib/libresolv-2.13.so
b490f000 b4911000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4919000 b49f1000 r-xp /usr/lib/libxml2.so.2.7.8
b49fe000 b4adb000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4ae6000 b4aeb000 r-xp /usr/lib/libcheck.so.0.0.0
b4af3000 b4afd000 r-xp /usr/lib/libspdy.so.0.0.0
b4b06000 b4c59000 r-xp /usr/lib/libcrypto.so.1.0.0
b4c77000 b4cc3000 r-xp /usr/lib/libssl.so.1.0.0
b4ccf000 b4cfd000 r-xp /usr/lib/libidn.so.11.5.44
b4d06000 b4d10000 r-xp /usr/lib/libcares.so.2.1.0
b4d18000 b4d2f000 r-xp /lib/libexpat.so.1.5.2
b4d39000 b4d5d000 r-xp /usr/lib/libicule.so.48.1
b4d66000 b4d75000 r-xp /usr/lib/libsf_common.so
b4d7d000 b4e18000 r-xp /usr/lib/libstdc++.so.6.0.14
b4e2b000 b4e43000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4e44000 b4e47000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4e4f000 b4e53000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4e5c000 b4e61000 r-xp /usr/lib/libffi.so.5.0.10
b4e69000 b4e6a000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4e72000 b4e7c000 r-xp /usr/lib/libXext.so.6.4.0
b4e85000 b4e88000 r-xp /usr/lib/libXtst.so.6.1.0
b4e90000 b4e96000 r-xp /usr/lib/libXrender.so.1.3.0
b4e9e000 b4ea4000 r-xp /usr/lib/libXrandr.so.2.2.0
b4eac000 b4ead000 r-xp /usr/lib/libXinerama.so.1.0.0
b4eb6000 b4ebf000 r-xp /usr/lib/libXi.so.6.1.0
b4ec7000 b4eca000 r-xp /usr/lib/libXfixes.so.3.1.0
b4ed2000 b4ed4000 r-xp /usr/lib/libXgesture.so.7.0.0
b4edc000 b4edd000 r-xp /usr/lib/libXdamage.so.1.1.0
b4ee6000 b4eed000 r-xp /usr/lib/libXcursor.so.1.0.2
b4ef5000 b4f18000 r-xp /usr/lib/libexif.so.12.3.3
b4f2c000 b4f36000 r-xp /usr/lib/libethumb.so.1.7.99
b4f3e000 b4f82000 r-xp /usr/lib/libsndfile.so.1.0.25
b4f90000 b4f92000 r-xp /usr/lib/libctxdata.so.0.0.0
b4f9a000 b4fa8000 r-xp /usr/lib/libremix.so.0.0.0
b4fb0000 b4fb1000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b4fb9000 b4fd2000 r-xp /usr/lib/liblua-5.1.so
b4fdb000 b4fe2000 r-xp /usr/lib/libembryo.so.1.7.99
b4feb000 b502b000 r-xp /usr/lib/libcurl.so.4.3.0
b5034000 b509e000 r-xp /usr/lib/libpixman-1.so.0.28.2
b50ab000 b50cf000 r-xp /usr/lib/libfontconfig.so.1.5.0
b50d8000 b5134000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5146000 b515a000 r-xp /usr/lib/libfribidi.so.0.3.1
b5162000 b51ba000 r-xp /usr/lib/libfreetype.so.6.8.1
b51c5000 b51e9000 r-xp /usr/lib/libjpeg.so.8.0.2
b5201000 b5218000 r-xp /lib/libz.so.1.2.5
b5220000 b5228000 r-xp /usr/lib/libemotion.so.1.7.99
b5230000 b5235000 r-xp /usr/lib/libecore_fb.so.1.7.99
b523e000 b524c000 r-xp /usr/lib/libsensor.so.1.1.0
b5258000 b525e000 r-xp /usr/lib/libappcore-common.so.1.1
b5266000 b5268000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.80
b5270000 b527b000 r-xp /usr/lib/libresourced.so.0.2.80
b5283000 b5286000 r-xp /usr/lib/libproc-stat.so.0.2.80
b6283000 b636b000 r-xp /usr/lib/libicuuc.so.48.1
b6378000 b6498000 r-xp /usr/lib/libicui18n.so.48.1
b64a6000 b64a9000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b64b1000 b64b9000 r-xp /usr/lib/libvconf.so.0.2.45
b64ba000 b64c0000 r-xp /usr/lib/libxdgmime.so.1.1.0
b64c8000 b64d4000 r-xp /usr/lib/libail.so.0.1.0
b64dc000 b64e7000 r-xp /usr/lib/libaul.so.0.1.0
b64ef000 b6506000 r-xp /usr/lib/libecore_input.so.1.7.99
b6521000 b653e000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6547000 b6549000 r-xp /usr/lib/libXcomposite.so.1.0.0
b6551000 b6585000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b658e000 b65bd000 r-xp /usr/lib/libecore_x.so.1.7.99
b65c7000 b6606000 r-xp /usr/lib/libeina.so.1.7.99
b660f000 b6624000 r-xp /usr/lib/libecore.so.1.7.99
b663b000 b6656000 r-xp /usr/lib/libecore_con.so.1.7.99
b665f000 b6664000 r-xp /usr/lib/libecore_imf.so.1.7.99
b666d000 b6675000 r-xp /usr/lib/libethumb_client.so.1.7.99
b667d000 b6686000 r-xp /usr/lib/libedbus.so.1.7.99
b668e000 b6690000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6698000 b669c000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b66a5000 b66bb000 r-xp /usr/lib/libefreet.so.1.7.99
b66c5000 b6721000 r-xp /usr/lib/libedje.so.1.7.99
b672b000 b6730000 r-xp /usr/lib/libecore_file.so.1.7.99
b6738000 b67e8000 r-xp /usr/lib/libevas.so.1.7.99
b6802000 b6815000 r-xp /usr/lib/libeet.so.1.7.99
b681e000 b6888000 r-xp /lib/libm-2.13.so
b6891000 b6892000 r-xp /usr/lib/libpmapi.so.1.2
b689a000 b68a1000 r-xp /usr/lib/libutilX.so.1.1.0
b68a9000 b69cc000 r-xp /usr/lib/libelementary.so.1.7.99
b69e1000 b69e4000 r-xp /lib/libattr.so.1.1.0
b69ec000 b69ee000 r-xp /usr/lib/libXau.so.6.0.0
b69f6000 b69fc000 r-xp /lib/librt-2.13.so
b6a05000 b6a0d000 r-xp /lib/libcrypt-2.13.so
b6a3d000 b6a40000 r-xp /lib/libcap.so.2.21
b6a48000 b6a4a000 r-xp /usr/lib/libiri.so
b6a52000 b6a67000 r-xp /usr/lib/libxcb.so.1.1.0
b6a6f000 b6a7a000 r-xp /lib/libunwind.so.8.0.1
b6aa8000 b6bc5000 r-xp /lib/libc-2.13.so
b6bd3000 b6bdc000 r-xp /lib/libgcc_s-4.5.3.so.1
b6be4000 b6c10000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6c19000 b6c1c000 r-xp /usr/lib/libbundle.so.0.1.22
b6c24000 b6c26000 r-xp /lib/libdl-2.13.so
b6c2f000 b6c32000 r-xp /usr/lib/libsmack.so.1.0.0
b6c3a000 b6d14000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6d1d000 b6d31000 r-xp /lib/libpthread-2.13.so
b6d43000 b6d4b000 r-xp /usr/lib/libappcore-efl.so.1.1
b6d54000 b6d55000 r-xp /usr/lib/libdlog.so.0.0.0
b6d5e000 b6dcb000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6dd5000 b6ddf000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6de8000 b6ece000 r-xp /usr/lib/libX11.so.6.3.0
b6ed9000 b6eda000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6ee2000 b6ee6000 r-xp /usr/lib/libsys-assert.so
b6eee000 b6f0b000 r-xp /lib/ld-2.13.so
be922000 be943000 rwxp [stack]
b6eee000 b6f0b000 r-xp /lib/ld-2.13.so
be922000 be943000 rwxp [stack]
End of Maps Information

Callstack Information (PID:24172)
Call Stack Count: 12
 0: (0xb4541318) [/usr/lib/osp/libosp-appfw.so] + 0x21a318
 1: (0xb41c4b4b) [/usr/lib/libcapi-system-power.so.0] + 0xb4b
 2: (0xb64b7505) [/usr/lib/libvconf.so.0] + 0x6505
 3: (0xb6c9e783) [/usr/lib/libglib-2.0.so.0] + 0x64783
 4: g_main_context_dispatch + 0xce (0xb6c72a37) [/usr/lib/libglib-2.0.so.0] + 0x38a37
 5: (0xb661e337) [/usr/lib/libecore.so.1] + 0xf337
 6: (0xb66198b9) [/usr/lib/libecore.so.1] + 0xa8b9
 7: (0xb661a2ab) [/usr/lib/libecore.so.1] + 0xb2ab
 8: ecore_main_loop_begin + 0x30 (0xb661a5cd) [/usr/lib/libecore.so.1] + 0xb5cd
 9: elm_run + 0x6 (0xb6953463) [/usr/lib/libelementary.so.1] + 0xaa463
10: appcore_efl_main + 0x114 (0xb6d48ec8) [/usr/lib/libappcore-efl.so.1] + 0x5ec8
11: app_efl_main + 0xc6 (0xb4202ed3) [/usr/lib/libcapi-appfw-application.so.0] + 0x9ed3
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d ﾌﾞｯｸ ﾏｲ本棚
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
