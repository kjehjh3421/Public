S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG4
Build-Date: 2013.07.22 22:21:22

Crash Information
Process Name: MyHondana
PID: 8536
Date: 2013-08-22 09:40:02(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=8536 tid=8536
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 8536, uid 5000)

Register Information
r0   = 0x3f800000, r1   = 0x0054b278
r2   = 0xb6c36248, r3   = 0xb46be390
r4   = 0x003afe38, r5   = 0x00000000
r6   = 0x00481f90, r7   = 0xb4183090
r8   = 0x00000000, r9   = 0xb3f23cb0
r10  = 0x000e4258, fp   = 0xbeca25a0
ip   = 0xb4e89128, sp   = 0xbeca2538
lr   = 0xb6b7b52c, pc   = 0xb2df2bb4
cpsr = 0x280b0010

Memory Information
MemTotal:  2063780 KB
MemFree:   1200084 KB
Buffers:     51904 KB
Cached:     357112 KB
VmPeak:     255988 KB
VmSize:     192628 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      105884 KB
VmRSS:       85364 KB
VmData:      84744 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       68280 KB
VmPTE:         186 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00091000 rw-p [heap]
00091000 01042000 rw-p [heap]
aa296000 aa2a3000 r-xp /usr/lib/libhogweed.so.2.0
aa2ab000 aa2eb000 r-xp /usr/lib/libgmp.so.10.0.1
aa2f2000 aa316000 r-xp /usr/lib/libnettle.so.4.0
aa31e000 aa39c000 r-xp /usr/lib/libgnutls.so.26.22.4
ab5f4000 abdf3000 rwxp [stack:8547]
accc7000 accd3000 r-xp /usr/lib/gio/modules/libgiognutls.so
acd87000 acd98000 r-xp /usr/lib/scim-1.0/1.4.0/IMEngine/socket.so
acda1000 acda6000 r-xp /usr/lib/scim-1.0/1.4.0/Config/socket.so
ace2d000 ace2e000 r-xp /usr/lib/evas/modules/savers/jpeg/linux-gnueabi-armv7l-1.7.99/module.so
ace36000 ace39000 r-xp /usr/lib/evas/modules/engines/buffer/linux-gnueabi-armv7l-1.7.99/module.so
ace81000 ace83000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
ad39b000 adb9a000 rwxp [stack:8545]
adb9b000 ae39a000 rwxp [stack:8543]
ae39b000 aeb9a000 rwxp [stack:8542]
aeefd000 aef05000 r-xp /usr/lib/libefl-assist.so.0.1.0
aefb5000 aefb6000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnueabi-armv7l-1.7.99/module.so
aefbe000 aefc0000 r-xp /usr/lib/remix/libeet_sndfile_reader.so
aefc9000 aefcb000 r-xp /usr/lib/remix/libtizen_sound_player.so.1.0.0
aefd3000 aefd4000 r-xp /usr/lib/edje/modules/multisense_factory/linux-gnueabi-armv7l-1.0.0/module.so
aefdc000 aeff3000 r-xp /usr/lib/edje/modules/elm/linux-gnueabi-armv7l-1.0.0/module.so
af107000 af906000 rwxp [stack:8541]
af907000 b0106000 rwxp [stack:8540]
b050a000 b050e000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b0517000 b0d16000 rwxp [stack:8538]
b0d16000 b0d1c000 r-xp /usr/lib/libUMP.so
b0d24000 b0e72000 r-xp /usr/lib/r3p2/libMali.so
b0e7e000 b0ea7000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0eb3000 b0ed1000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b11c9000 b1215000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b121e000 b1223000 r-xp /usr/lib/libjson.so.0.0.1
b122b000 b122f000 r-xp /usr/lib/liblocation-pos-log.so
b1237000 b1249000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b1251000 b1253000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b125b000 b1260000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b1268000 b1273000 r-xp /usr/lib/libdrm-trusted.so.0.0.54
b127b000 b127d000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b1285000 b1292000 r-xp /usr/lib/libdrm-client.so.0.0.91
b129b000 b12a3000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b12c5000 b12fc000 r-xp /usr/lib/libpulse.so.0.16.2
b1304000 b1368000 r-xp /usr/lib/libasound.so.2.0.0
b1372000 b1375000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b137e000 b1382000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b138b000 b13a6000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b13af000 b13b4000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b13bc000 b13e9000 r-xp /usr/lib/libSLP-location.so.0.0.0
b13f2000 b13fa000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b13fb000 b13ff000 r-xp /usr/lib/libmmffile.so.0.0.0
b1407000 b140f000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b1410000 b1429000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b1432000 b144d000 r-xp /usr/lib/libmedia-service.so.1.0.0
b1455000 b1460000 r-xp /usr/lib/libmdm-common.so.1.0.38
b1468000 b1474000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b147c000 b1483000 r-xp /usr/lib/libenchant.so.1.6.1
b148b000 b148e000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b1497000 b14a0000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b14a9000 b14ad000 r-xp /usr/lib/libmmfsession.so.0.0.0
b14b6000 b14c5000 r-xp /usr/lib/libmmfsound.so.0.1.0
b14cd000 b14d2000 r-xp /usr/lib/libmemenv.so.1.1.0
b14da000 b1518000 r-xp /usr/lib/libleveldb.so.1.1.0
b1521000 b154b000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b1554000 b1556000 r-xp /usr/lib/libsecfw.so
b155e000 b1567000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b1572000 b1581000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b1589000 b15a1000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b15a3000 b15b0000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b15b9000 b15c2000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b15ca000 b160d000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b1615000 b16b1000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b16bd000 b16e2000 r-xp /usr/lib/libxslt.so.1.1.16
b16eb000 b16ed000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b16f5000 b16fd000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b1705000 b1711000 r-xp /usr/lib/libcapi-location-manager.so.0.1.14
b1719000 b171c000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b1724000 b1729000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b1731000 b1758000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.71
b1760000 b1779000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.1
b1781000 b17bf000 r-xp /usr/lib/libmdm.so.1.0.67
b17c7000 b17cb000 r-xp /usr/lib/libss-client.so.1.0.0
b17d4000 b17e9000 r-xp /usr/lib/libnetwork.so.0.0.0
b17f1000 b17fa000 r-xp /usr/lib/libcapi-web-favorites.so
b1802000 b2a62000 r-xp /usr/lib/libewebkit2.so.0.10.154.1
b2b55000 b2ba8000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2bb1000 b2bc8000 r-xp /usr/lib/libwifi-direct.so.0.0
b2bd0000 b2bd8000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.10
b2be0000 b2be9000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2bf2000 b2bfd000 r-xp /usr/lib/libcapi-network-connection.so.0.1.13
b2c05000 b2c71000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2c7f000 b2d34000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2d41000 b2d5b000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2d64000 b2d82000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2d91000 b2d9b000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b2da3000 b2e29000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2e38000 b2eb4000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2ebc000 b2f4c000 r-xp /usr/lib/libCOREGL.so.3.0
b2f56000 b2f59000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2f61000 b2f68000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2f71000 b2f80000 r-xp /usr/lib/libICE.so.6.3.0
b2f8a000 b2f8f000 r-xp /usr/lib/libSM.so.6.0.1
b2f97000 b2f98000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2fa0000 b2fa2000 r-xp /usr/lib/libledplayer.so.0.1
b2faa000 b2fb0000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2fb8000 b2fb9000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2fc2000 b2fc9000 r-xp /usr/lib/libGLESv2.so.2.0
b2fd1000 b3018000 r-xp /usr/lib/libtiff.so.5.1.0
b3023000 b304c000 r-xp /usr/lib/libturbojpeg.so
b3065000 b3069000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3072000 b3078000 r-xp /usr/lib/libgif.so.4.1.6
b3080000 b30a2000 r-xp /usr/lib/libavutil.so.51.73.101
b30b1000 b30df000 r-xp /usr/lib/libswscale.so.2.1.101
b30e8000 b33df000 r-xp /usr/lib/libavcodec.so.54.59.100
b3706000 b371f000 r-xp /usr/lib/libpng12.so.0.50.0
b3728000 b372f000 r-xp /usr/lib/libfeedback.so.0.1.4
b3738000 b374c000 r-xp /usr/lib/libtts.so
b3754000 b3756000 r-xp /usr/lib/libEGL.so.1.4
b375e000 b3815000 r-xp /usr/lib/libcairo.so.2.11200.12
b381f000 b3838000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b3843000 b3847000 r-xp /opt/usr/apps/docomo6003/lib/libHyBookViewerCore.so
b384f000 b3851000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b3859000 b411c000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b418d000 b4196000 r-xp /usr/lib/libslp_devman_plugin.so
b419f000 b41a1000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b41a9000 b41ac000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b41b4000 b41ba000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41c2000 b41c5000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b41cd000 b41da000 r-xp /usr/lib/libmodem.so.0.0.0
b41e2000 b41e5000 r-xp /usr/lib/libdevice-node.so.0.1
b41ed000 b41fd000 r-xp /usr/lib/libaccounts-svc.so.0.2.71
b4205000 b4208000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b4210000 b4214000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b421c000 b4222000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b422a000 b422b000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b4234000 b4237000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b423f000 b4242000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b424b000 b424e000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b4256000 b4257000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b425f000 b426d000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4276000 b429b000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b42a3000 b42a6000 r-xp /usr/lib/libuuid.so.1.3.0
b42af000 b42c3000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b42cc000 b42d4000 r-xp /usr/lib/libminizip.so.1.0.0
b42dc000 b42e8000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42f1000 b430f000 r-xp /usr/lib/libpcre.so.0.0.1
b4317000 b431b000 r-xp /usr/lib/libheynoti.so.0.0.2
b4323000 b4331000 r-xp /usr/lib/libdeviced.so.0.1.0
b4339000 b4344000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4351000 b4357000 r-xp /usr/lib/libdevman.so.0.1
b435f000 b4363000 r-xp /usr/lib/libchromium.so.1.0
b436b000 b4372000 r-xp /usr/lib/libalarm.so.0.0.0
b437a000 b4384000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b438d000 b46a0000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b46c9000 b46d3000 r-xp /lib/libnss_files-2.13.so
b46e3000 b46f3000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b46f4000 b4708000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4710000 b472d000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4735000 b4738000 r-xp /usr/lib/libiniparser.so.0
b4741000 b4794000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b479e000 b47b2000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b47bb000 b47bd000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b47c6000 b47d7000 r-xp /usr/lib/libcom-core.so.0.0.1
b47df000 b47e5000 r-xp /usr/lib/libappsvc.so.0.1.0
b47ed000 b47ef000 r-xp /usr/lib/libdri2.so.0.0.0
b47f7000 b47ff000 r-xp /usr/lib/libdrm.so.2.4.0
b4807000 b480b000 r-xp /usr/lib/libtbm.so.1.0.0
b4813000 b4816000 r-xp /usr/lib/libXv.so.1.0.0
b481e000 b4832000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b483a000 b4906000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b491c000 b492b000 r-xp /usr/lib/libnotification.so.0.1.0
b4933000 b4957000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4961000 b4971000 r-xp /lib/libresolv-2.13.so
b4975000 b4977000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b497f000 b4a57000 r-xp /usr/lib/libxml2.so.2.7.8
b4a64000 b4b41000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4b4c000 b4b51000 r-xp /usr/lib/libcheck.so.0.0.0
b4b59000 b4b63000 r-xp /usr/lib/libspdy.so.0.0.0
b4b6c000 b4cbf000 r-xp /usr/lib/libcrypto.so.1.0.0
b4cdd000 b4d29000 r-xp /usr/lib/libssl.so.1.0.0
b4d35000 b4d63000 r-xp /usr/lib/libidn.so.11.5.44
b4d6c000 b4d76000 r-xp /usr/lib/libcares.so.2.1.0
b4d7e000 b4d95000 r-xp /lib/libexpat.so.1.5.2
b4d9f000 b4dc3000 r-xp /usr/lib/libicule.so.48.1
b4dcc000 b4ddb000 r-xp /usr/lib/libsf_common.so
b4de3000 b4e7e000 r-xp /usr/lib/libstdc++.so.6.0.14
b4e91000 b4ea9000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4eaa000 b4ead000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4eb5000 b4eb9000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4ec2000 b4ec7000 r-xp /usr/lib/libffi.so.5.0.10
b4ecf000 b4ed0000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4ed8000 b4ee2000 r-xp /usr/lib/libXext.so.6.4.0
b4eeb000 b4eee000 r-xp /usr/lib/libXtst.so.6.1.0
b4ef6000 b4efc000 r-xp /usr/lib/libXrender.so.1.3.0
b4f04000 b4f0a000 r-xp /usr/lib/libXrandr.so.2.2.0
b4f12000 b4f13000 r-xp /usr/lib/libXinerama.so.1.0.0
b4f1c000 b4f25000 r-xp /usr/lib/libXi.so.6.1.0
b4f2d000 b4f30000 r-xp /usr/lib/libXfixes.so.3.1.0
b4f38000 b4f3a000 r-xp /usr/lib/libXgesture.so.7.0.0
b4f42000 b4f43000 r-xp /usr/lib/libXdamage.so.1.1.0
b4f4c000 b4f53000 r-xp /usr/lib/libXcursor.so.1.0.2
b4f5b000 b4f7e000 r-xp /usr/lib/libexif.so.12.3.3
b4f92000 b4f9c000 r-xp /usr/lib/libethumb.so.1.7.99
b4fa4000 b4fe8000 r-xp /usr/lib/libsndfile.so.1.0.25
b4ff6000 b4ff8000 r-xp /usr/lib/libctxdata.so.0.0.0
b5000000 b500e000 r-xp /usr/lib/libremix.so.0.0.0
b5016000 b5017000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b501f000 b5038000 r-xp /usr/lib/liblua-5.1.so
b5041000 b5048000 r-xp /usr/lib/libembryo.so.1.7.99
b5051000 b5091000 r-xp /usr/lib/libcurl.so.4.3.0
b509a000 b5104000 r-xp /usr/lib/libpixman-1.so.0.28.2
b5111000 b5135000 r-xp /usr/lib/libfontconfig.so.1.5.0
b513e000 b519a000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b51ac000 b51c0000 r-xp /usr/lib/libfribidi.so.0.3.1
b51c8000 b5220000 r-xp /usr/lib/libfreetype.so.6.8.1
b522b000 b524f000 r-xp /usr/lib/libjpeg.so.8.0.2
b5267000 b527e000 r-xp /lib/libz.so.1.2.5
b5286000 b528e000 r-xp /usr/lib/libemotion.so.1.7.99
b5296000 b529b000 r-xp /usr/lib/libecore_fb.so.1.7.99
b52a4000 b52b2000 r-xp /usr/lib/libsensor.so.1.1.0
b52be000 b52c4000 r-xp /usr/lib/libappcore-common.so.1.1
b52cc000 b52ce000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.80
b52d6000 b52e1000 r-xp /usr/lib/libresourced.so.0.2.80
b52e9000 b52ec000 r-xp /usr/lib/libproc-stat.so.0.2.80
b62e9000 b63d1000 r-xp /usr/lib/libicuuc.so.48.1
b63de000 b64fe000 r-xp /usr/lib/libicui18n.so.48.1
b650c000 b650f000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6517000 b651f000 r-xp /usr/lib/libvconf.so.0.2.45
b6520000 b6526000 r-xp /usr/lib/libxdgmime.so.1.1.0
b652e000 b653a000 r-xp /usr/lib/libail.so.0.1.0
b6542000 b654d000 r-xp /usr/lib/libaul.so.0.1.0
b6555000 b656c000 r-xp /usr/lib/libecore_input.so.1.7.99
b6587000 b65a4000 r-xp /usr/lib/libecore_evas.so.1.7.99
b65ad000 b65af000 r-xp /usr/lib/libXcomposite.so.1.0.0
b65b7000 b65eb000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b65f4000 b6623000 r-xp /usr/lib/libecore_x.so.1.7.99
b662d000 b666c000 r-xp /usr/lib/libeina.so.1.7.99
b6675000 b668a000 r-xp /usr/lib/libecore.so.1.7.99
b66a1000 b66bc000 r-xp /usr/lib/libecore_con.so.1.7.99
b66c5000 b66ca000 r-xp /usr/lib/libecore_imf.so.1.7.99
b66d3000 b66db000 r-xp /usr/lib/libethumb_client.so.1.7.99
b66e3000 b66ec000 r-xp /usr/lib/libedbus.so.1.7.99
b66f4000 b66f6000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b66fe000 b6702000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b670b000 b6721000 r-xp /usr/lib/libefreet.so.1.7.99
b672b000 b6787000 r-xp /usr/lib/libedje.so.1.7.99
b6791000 b6796000 r-xp /usr/lib/libecore_file.so.1.7.99
b679e000 b684e000 r-xp /usr/lib/libevas.so.1.7.99
b6868000 b687b000 r-xp /usr/lib/libeet.so.1.7.99
b6884000 b68ee000 r-xp /lib/libm-2.13.so
b68f7000 b68f8000 r-xp /usr/lib/libpmapi.so.1.2
b6900000 b6907000 r-xp /usr/lib/libutilX.so.1.1.0
b690f000 b6a32000 r-xp /usr/lib/libelementary.so.1.7.99
b6a47000 b6a4a000 r-xp /lib/libattr.so.1.1.0
b6a52000 b6a54000 r-xp /usr/lib/libXau.so.6.0.0
b6a5c000 b6a62000 r-xp /lib/librt-2.13.so
b6a6b000 b6a73000 r-xp /lib/libcrypt-2.13.so
b6aa3000 b6aa6000 r-xp /lib/libcap.so.2.21
b6aae000 b6ab0000 r-xp /usr/lib/libiri.so
b6ab8000 b6acd000 r-xp /usr/lib/libxcb.so.1.1.0
b6ad5000 b6ae0000 r-xp /lib/libunwind.so.8.0.1
b6b0e000 b6c2b000 r-xp /lib/libc-2.13.so
b6c39000 b6c42000 r-xp /lib/libgcc_s-4.5.3.so.1
b6c4a000 b6c76000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6c7f000 b6c82000 r-xp /usr/lib/libbundle.so.0.1.22
b6c8a000 b6c8c000 r-xp /lib/libdl-2.13.so
b6c95000 b6c98000 r-xp /usr/lib/libsmack.so.1.0.0
b6ca0000 b6d7a000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6d83000 b6d97000 r-xp /lib/libpthread-2.13.so
b6da9000 b6db1000 r-xp /usr/lib/libappcore-efl.so.1.1
b6dba000 b6dbb000 r-xp /usr/lib/libdlog.so.0.0.0
b6dc4000 b6e31000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6e3b000 b6e45000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6e4e000 b6f34000 r-xp /usr/lib/libX11.so.6.3.0
b6f3f000 b6f40000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6f48000 b6f4c000 r-xp /usr/lib/libsys-assert.so
b6f54000 b6f71000 r-xp /lib/ld-2.13.so
bec83000 beca4000 rwxp [stack]
bec83000 beca4000 rwxp [stack]
End of Maps Information

Callstack Information (PID:8536)
Call Stack Count: 18
 0: MyHondanaMainForm::UnLoadBitmapFiles() + 0x58 (0xb2df2bb4) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x4fbb4
 1: MyHondanaMainForm::OnTerminating() + 0x20 (0xb2df2b3c) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x4fb3c
 2: non-virtual thunk to MyHondanaMainForm::OnTerminating() + 0x20 (0xb2df2e04) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x4fe04
 3: Tizen::Ui::_ControlImpl::OnDetachingFromMainTree() + 0x12 (0xb3b0ed9b) [/usr/lib/osp/libosp-uifw.so] + 0x2b5d9b
 4: Tizen::Ui::Controls::_FormImpl::OnDetachingFromMainTree() + 0x14 (0xb3cd17f1) [/usr/lib/osp/libosp-uifw.so] + 0x4787f1
 5: Tizen::Ui::_Control::CallOnDetachingFromMainTree(Tizen::Ui::_Control&) + 0x5e (0xb3af96cf) [/usr/lib/osp/libosp-uifw.so] + 0x2a06cf
 6: Tizen::Ui::_Control::DetachChild(Tizen::Ui::_Control&) + 0x46 (0xb3afd993) [/usr/lib/osp/libosp-uifw.so] + 0x2a4993
 7: Tizen::Ui::_Control::DetachAllChildren(bool, bool) + 0xd0 (0xb3afdc05) [/usr/lib/osp/libosp-uifw.so] + 0x2a4c05
 8: Tizen::Ui::_ContainerImpl::RemoveAllChildren(bool, bool) + 0x1e (0xb3b1c9bf) [/usr/lib/osp/libosp-uifw.so] + 0x2c39bf
 9: Tizen::Ui::_WindowImpl::Destroy() + 0x32 (0xb3b1df3f) [/usr/lib/osp/libosp-uifw.so] + 0x2c4f3f
10: Tizen::App::_UiAppImpl::RemoveAllFrames() + 0x58 (0xb3ed4c05) [/usr/lib/osp/libosp-uifw.so] + 0x67bc05
11: Tizen::App::_UiAppImpl::OnUiAppImplTerminating() + 0x8 (0xb3ed4fe9) [/usr/lib/osp/libosp-uifw.so] + 0x67bfe9
12: Tizen::App::_UiAppImpl::OnTerminate() + 0x3c (0xb3ed5059) [/usr/lib/osp/libosp-uifw.so] + 0x67c059
13: Tizen::App::_AppImpl::OnTerminate(void*) + 0x42 (0xb447e8ff) [/usr/lib/osp/libosp-appfw.so] + 0xf18ff
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d ﾌﾞｯｸ ﾏｲ本棚
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
