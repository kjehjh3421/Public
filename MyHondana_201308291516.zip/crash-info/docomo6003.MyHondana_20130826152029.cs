S/W Version Information
Model: SGH-N055
Tizen-Version: 2.2.0
Build-Number: N055OMEAMG4
Build-Date: 2013.07.22 22:21:22

Crash Information
Process Name: MyHondana
PID: 27467
Date: 2013-08-26 15:20:29(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=27467 tid=27467
Signal: 6
      (SIGABRT)
      si_code: -6
      signal sent by tkill (sent by pid 27467, uid 5000)

Register Information
r0   = 0x00000000, r1   = 0x00006b4b
r2   = 0x00000006, r3   = 0x00006b4b
r4   = 0x00000006, r5   = 0xb6bcabe4
r6   = 0xb6bca000, r7   = 0x0000010c
r8   = 0x00000be4, r9   = 0x00000001
r10  = 0xb6f06000, fp   = 0xbe94aed8
ip   = 0xb6f064c0, sp   = 0xbe94a778
lr   = 0xb6ad155c, pc   = 0xb6acd760
cpsr = 0x280f0010

Memory Information
MemTotal:  2063780 KB
MemFree:    830500 KB
Buffers:     73728 KB
Cached:     593544 KB
VmPeak:     220364 KB
VmSize:     173172 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      102900 KB
VmRSS:      102900 KB
VmData:      70732 KB
VmStk:         136 KB
VmExe:          32 KB
VmLib:       67028 KB
VmPTE:         196 KB
VmSwap:          0 KB

Maps Information
00008000 00010000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
00018000 00071000 rw-p [heap]
00071000 026a7000 rw-p [heap]
ae464000 ae466000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnueabi-armv7l-1.7.99/module.so
af45e000 afc5d000 rwxp [stack:27474]
b049f000 b04a3000 r-xp /usr/lib/bufmgr/libtbm_exynos4412.so.0.0.0
b04ac000 b0cab000 rwxp [stack:27469]
b0cab000 b0cb1000 r-xp /usr/lib/libUMP.so
b0cb9000 b0e07000 r-xp /usr/lib/r3p2/libMali.so
b0e13000 b0e3c000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnueabi-armv7l-1.7.99/module.so
b0e48000 b0e66000 r-xp /usr/lib/osp/libtestbuddy.so.1.0
b115e000 b11aa000 r-xp /usr/lib/pulseaudio/libpulsecommon-4.0.so
b11b3000 b11b8000 r-xp /usr/lib/libjson.so.0.0.1
b11c0000 b11c4000 r-xp /usr/lib/liblocation-pos-log.so
b11cc000 b11de000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
b11e6000 b11e8000 r-xp /usr/lib/libmedia-hash.so.1.0.0
b11f0000 b11f5000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
b11fd000 b1208000 r-xp /usr/lib/libdrm-trusted.so.0.0.54
b1210000 b1212000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
b121a000 b1227000 r-xp /usr/lib/libdrm-client.so.0.0.91
b1230000 b1238000 r-xp /usr/lib/lib_SamsungRec_V03010.so
b125a000 b1291000 r-xp /usr/lib/libpulse.so.0.16.2
b1299000 b12fd000 r-xp /usr/lib/libasound.so.2.0.0
b1307000 b130a000 r-xp /usr/lib/libpulse-simple.so.0.0.4
b1313000 b1317000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b1320000 b133b000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b1344000 b1349000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b1351000 b137e000 r-xp /usr/lib/libSLP-location.so.0.0.0
b1387000 b138f000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
b1390000 b1394000 r-xp /usr/lib/libmmffile.so.0.0.0
b139c000 b13a4000 r-xp /usr/lib/libmedia-utils.so.0.0.0
b13a5000 b13be000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
b13c7000 b13e2000 r-xp /usr/lib/libmedia-service.so.1.0.0
b13ea000 b13f5000 r-xp /usr/lib/libmdm-common.so.1.0.38
b13fd000 b1409000 r-xp /usr/lib/libbookmark-adaptor.so.0.2.7
b1411000 b1418000 r-xp /usr/lib/libenchant.so.1.6.1
b1420000 b1423000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.9
b142c000 b1435000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
b143e000 b1442000 r-xp /usr/lib/libmmfsession.so.0.0.0
b144b000 b145a000 r-xp /usr/lib/libmmfsound.so.0.1.0
b1462000 b1467000 r-xp /usr/lib/libmemenv.so.1.1.0
b146f000 b14ad000 r-xp /usr/lib/libleveldb.so.1.1.0
b14b6000 b14e0000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
b14e9000 b14eb000 r-xp /usr/lib/libsecfw.so
b14f3000 b14fc000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b1507000 b1516000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
b151e000 b1536000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
b1538000 b1545000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b154e000 b1557000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b155f000 b15a2000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b15aa000 b1646000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b1652000 b1677000 r-xp /usr/lib/libxslt.so.1.1.16
b1680000 b1682000 r-xp /usr/lib/libewebkit2-ext.so.1.0.2
b168a000 b1692000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
b169a000 b16a6000 r-xp /usr/lib/libcapi-location-manager.so.0.1.14
b16ae000 b16b1000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
b16b9000 b16be000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
b16c6000 b16ed000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.71
b16f5000 b170e000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.1
b1716000 b1754000 r-xp /usr/lib/libmdm.so.1.0.67
b175c000 b1760000 r-xp /usr/lib/libss-client.so.1.0.0
b1769000 b177e000 r-xp /usr/lib/libnetwork.so.0.0.0
b1786000 b178f000 r-xp /usr/lib/libcapi-web-favorites.so
b1797000 b29f7000 r-xp /usr/lib/libewebkit2.so.0.10.154.1
b2aea000 b2b3d000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2b46000 b2b5d000 r-xp /usr/lib/libwifi-direct.so.0.0
b2b65000 b2b6d000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.10
b2b75000 b2b7e000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2b87000 b2b92000 r-xp /usr/lib/libcapi-network-connection.so.0.1.13
b2b9a000 b2c06000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2c14000 b2cc9000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2cd6000 b2cf0000 r-xp /usr/lib/osp/libosp-json.so.1.2.2.0
b2cf9000 b2d17000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2d26000 b2d30000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnueabi-armv7l-1.7.99/module.so
b2d38000 b2dbf000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2dcd000 b2e49000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2e51000 b2ee1000 r-xp /usr/lib/libCOREGL.so.3.0
b2eeb000 b2eee000 r-xp /usr/lib/libmm_ta.so.0.0.0
b2ef6000 b2efd000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2f06000 b2f15000 r-xp /usr/lib/libICE.so.6.3.0
b2f1f000 b2f24000 r-xp /usr/lib/libSM.so.6.0.1
b2f2c000 b2f2d000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b2f35000 b2f37000 r-xp /usr/lib/libledplayer.so.0.1
b2f3f000 b2f45000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2f4d000 b2f4e000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2f57000 b2f5e000 r-xp /usr/lib/libGLESv2.so.2.0
b2f66000 b2fad000 r-xp /usr/lib/libtiff.so.5.1.0
b2fb8000 b2fe1000 r-xp /usr/lib/libturbojpeg.so
b2ffa000 b2ffe000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b3007000 b300d000 r-xp /usr/lib/libgif.so.4.1.6
b3015000 b3037000 r-xp /usr/lib/libavutil.so.51.73.101
b3046000 b3074000 r-xp /usr/lib/libswscale.so.2.1.101
b307d000 b3374000 r-xp /usr/lib/libavcodec.so.54.59.100
b369b000 b36b4000 r-xp /usr/lib/libpng12.so.0.50.0
b36bd000 b36c4000 r-xp /usr/lib/libfeedback.so.0.1.4
b36cd000 b36e1000 r-xp /usr/lib/libtts.so
b36e9000 b36eb000 r-xp /usr/lib/libEGL.so.1.4
b36f3000 b37aa000 r-xp /usr/lib/libcairo.so.2.11200.12
b37b4000 b37cd000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b37d8000 b37dc000 r-xp /opt/usr/apps/docomo6003/lib/libHyBookViewerCore.so
b37e4000 b37e6000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b37ee000 b40b1000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4122000 b412b000 r-xp /usr/lib/libslp_devman_plugin.so
b4134000 b4136000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b413e000 b4141000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4149000 b414f000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b4157000 b415a000 r-xp /usr/lib/libsyspopup_caller.so.0.1.0
b4162000 b416f000 r-xp /usr/lib/libmodem.so.0.0.0
b4177000 b417a000 r-xp /usr/lib/libdevice-node.so.0.1
b4182000 b4192000 r-xp /usr/lib/libaccounts-svc.so.0.2.71
b419a000 b419d000 r-xp /usr/lib/libcsc-feature.so.0.0.0
b41a5000 b41a9000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b41b1000 b41b7000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b41bf000 b41c0000 r-xp /usr/lib/libcapi-system-power.so.0.1.0
b41c9000 b41cc000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b41d4000 b41d7000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b41e0000 b41e3000 r-xp /usr/lib/libcapi-network-serial.so.0.0.8
b41eb000 b41ec000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b41f4000 b4202000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b420b000 b4230000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b4238000 b423b000 r-xp /usr/lib/libuuid.so.1.3.0
b4244000 b4258000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4261000 b4269000 r-xp /usr/lib/libminizip.so.1.0.0
b4271000 b427d000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4286000 b42a4000 r-xp /usr/lib/libpcre.so.0.0.1
b42ac000 b42b0000 r-xp /usr/lib/libheynoti.so.0.0.2
b42b8000 b42c6000 r-xp /usr/lib/libdeviced.so.0.1.0
b42ce000 b42d9000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b42e6000 b42ec000 r-xp /usr/lib/libdevman.so.0.1
b42f4000 b42f8000 r-xp /usr/lib/libchromium.so.1.0
b4300000 b4307000 r-xp /usr/lib/libalarm.so.0.0.0
b430f000 b4319000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.3
b4322000 b4635000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b465e000 b4668000 r-xp /lib/libnss_files-2.13.so
b4678000 b4688000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4689000 b469d000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b46a5000 b46c2000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b46ca000 b46cd000 r-xp /usr/lib/libiniparser.so.0
b46d6000 b4729000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4733000 b4747000 r-xp /usr/lib/libsecurity-server-commons.so.1.0.0
b4750000 b4752000 r-xp /usr/lib/libsystemd-daemon.so.0.0.10
b475b000 b476c000 r-xp /usr/lib/libcom-core.so.0.0.1
b4774000 b477a000 r-xp /usr/lib/libappsvc.so.0.1.0
b4782000 b4784000 r-xp /usr/lib/libdri2.so.0.0.0
b478c000 b4794000 r-xp /usr/lib/libdrm.so.2.4.0
b479c000 b47a0000 r-xp /usr/lib/libtbm.so.1.0.0
b47a8000 b47ab000 r-xp /usr/lib/libXv.so.1.0.0
b47b3000 b47c7000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b47cf000 b489b000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b48b1000 b48c0000 r-xp /usr/lib/libnotification.so.0.1.0
b48c8000 b48ec000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b48f6000 b4906000 r-xp /lib/libresolv-2.13.so
b490a000 b490c000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4914000 b49ec000 r-xp /usr/lib/libxml2.so.2.7.8
b49f9000 b4ad6000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4ae1000 b4ae6000 r-xp /usr/lib/libcheck.so.0.0.0
b4aee000 b4af8000 r-xp /usr/lib/libspdy.so.0.0.0
b4b01000 b4c54000 r-xp /usr/lib/libcrypto.so.1.0.0
b4c72000 b4cbe000 r-xp /usr/lib/libssl.so.1.0.0
b4cca000 b4cf8000 r-xp /usr/lib/libidn.so.11.5.44
b4d01000 b4d0b000 r-xp /usr/lib/libcares.so.2.1.0
b4d13000 b4d2a000 r-xp /lib/libexpat.so.1.5.2
b4d34000 b4d58000 r-xp /usr/lib/libicule.so.48.1
b4d61000 b4d70000 r-xp /usr/lib/libsf_common.so
b4d78000 b4e13000 r-xp /usr/lib/libstdc++.so.6.0.14
b4e26000 b4e3e000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b4e3f000 b4e42000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b4e4a000 b4e4e000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b4e57000 b4e5c000 r-xp /usr/lib/libffi.so.5.0.10
b4e64000 b4e65000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b4e6d000 b4e77000 r-xp /usr/lib/libXext.so.6.4.0
b4e80000 b4e83000 r-xp /usr/lib/libXtst.so.6.1.0
b4e8b000 b4e91000 r-xp /usr/lib/libXrender.so.1.3.0
b4e99000 b4e9f000 r-xp /usr/lib/libXrandr.so.2.2.0
b4ea7000 b4ea8000 r-xp /usr/lib/libXinerama.so.1.0.0
b4eb1000 b4eba000 r-xp /usr/lib/libXi.so.6.1.0
b4ec2000 b4ec5000 r-xp /usr/lib/libXfixes.so.3.1.0
b4ecd000 b4ecf000 r-xp /usr/lib/libXgesture.so.7.0.0
b4ed7000 b4ed8000 r-xp /usr/lib/libXdamage.so.1.1.0
b4ee1000 b4ee8000 r-xp /usr/lib/libXcursor.so.1.0.2
b4ef0000 b4f13000 r-xp /usr/lib/libexif.so.12.3.3
b4f27000 b4f31000 r-xp /usr/lib/libethumb.so.1.7.99
b4f39000 b4f7d000 r-xp /usr/lib/libsndfile.so.1.0.25
b4f8b000 b4f8d000 r-xp /usr/lib/libctxdata.so.0.0.0
b4f95000 b4fa3000 r-xp /usr/lib/libremix.so.0.0.0
b4fab000 b4fac000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b4fb4000 b4fcd000 r-xp /usr/lib/liblua-5.1.so
b4fd6000 b4fdd000 r-xp /usr/lib/libembryo.so.1.7.99
b4fe6000 b5026000 r-xp /usr/lib/libcurl.so.4.3.0
b502f000 b5099000 r-xp /usr/lib/libpixman-1.so.0.28.2
b50a6000 b50ca000 r-xp /usr/lib/libfontconfig.so.1.5.0
b50d3000 b512f000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5141000 b5155000 r-xp /usr/lib/libfribidi.so.0.3.1
b515d000 b51b5000 r-xp /usr/lib/libfreetype.so.6.8.1
b51c0000 b51e4000 r-xp /usr/lib/libjpeg.so.8.0.2
b51fc000 b5213000 r-xp /lib/libz.so.1.2.5
b521b000 b5223000 r-xp /usr/lib/libemotion.so.1.7.99
b522b000 b5230000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5239000 b5247000 r-xp /usr/lib/libsensor.so.1.1.0
b5253000 b5259000 r-xp /usr/lib/libappcore-common.so.1.1
b5261000 b5263000 r-xp /usr/lib/libpowertop-wrapper.so.0.2.80
b526b000 b5276000 r-xp /usr/lib/libresourced.so.0.2.80
b527e000 b5281000 r-xp /usr/lib/libproc-stat.so.0.2.80
b627e000 b6366000 r-xp /usr/lib/libicuuc.so.48.1
b6373000 b6493000 r-xp /usr/lib/libicui18n.so.48.1
b64a1000 b64a4000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b64ac000 b64b4000 r-xp /usr/lib/libvconf.so.0.2.45
b64b5000 b64bb000 r-xp /usr/lib/libxdgmime.so.1.1.0
b64c3000 b64cf000 r-xp /usr/lib/libail.so.0.1.0
b64d7000 b64e2000 r-xp /usr/lib/libaul.so.0.1.0
b64ea000 b6501000 r-xp /usr/lib/libecore_input.so.1.7.99
b651c000 b6539000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6542000 b6544000 r-xp /usr/lib/libXcomposite.so.1.0.0
b654c000 b6580000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6589000 b65b8000 r-xp /usr/lib/libecore_x.so.1.7.99
b65c2000 b6601000 r-xp /usr/lib/libeina.so.1.7.99
b660a000 b661f000 r-xp /usr/lib/libecore.so.1.7.99
b6636000 b6651000 r-xp /usr/lib/libecore_con.so.1.7.99
b665a000 b665f000 r-xp /usr/lib/libecore_imf.so.1.7.99
b6668000 b6670000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6678000 b6681000 r-xp /usr/lib/libedbus.so.1.7.99
b6689000 b668b000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6693000 b6697000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b66a0000 b66b6000 r-xp /usr/lib/libefreet.so.1.7.99
b66c0000 b671c000 r-xp /usr/lib/libedje.so.1.7.99
b6726000 b672b000 r-xp /usr/lib/libecore_file.so.1.7.99
b6733000 b67e3000 r-xp /usr/lib/libevas.so.1.7.99
b67fd000 b6810000 r-xp /usr/lib/libeet.so.1.7.99
b6819000 b6883000 r-xp /lib/libm-2.13.so
b688c000 b688d000 r-xp /usr/lib/libpmapi.so.1.2
b6895000 b689c000 r-xp /usr/lib/libutilX.so.1.1.0
b68a4000 b69c7000 r-xp /usr/lib/libelementary.so.1.7.99
b69dc000 b69df000 r-xp /lib/libattr.so.1.1.0
b69e7000 b69e9000 r-xp /usr/lib/libXau.so.6.0.0
b69f1000 b69f7000 r-xp /lib/librt-2.13.so
b6a00000 b6a08000 r-xp /lib/libcrypt-2.13.so
b6a38000 b6a3b000 r-xp /lib/libcap.so.2.21
b6a43000 b6a45000 r-xp /usr/lib/libiri.so
b6a4d000 b6a62000 r-xp /usr/lib/libxcb.so.1.1.0
b6a6a000 b6a75000 r-xp /lib/libunwind.so.8.0.1
b6aa3000 b6bc0000 r-xp /lib/libc-2.13.so
b6bce000 b6bd7000 r-xp /lib/libgcc_s-4.5.3.so.1
b6bdf000 b6c0b000 r-xp /usr/lib/libdbus-1.so.3.7.2
b6c14000 b6c17000 r-xp /usr/lib/libbundle.so.0.1.22
b6c1f000 b6c21000 r-xp /lib/libdl-2.13.so
b6c2a000 b6c2d000 r-xp /usr/lib/libsmack.so.1.0.0
b6c35000 b6d0f000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b6d18000 b6d2c000 r-xp /lib/libpthread-2.13.so
b6d3e000 b6d46000 r-xp /usr/lib/libappcore-efl.so.1.1
b6d4f000 b6d50000 r-xp /usr/lib/libdlog.so.0.0.0
b6d59000 b6dc6000 r-xp /usr/lib/libsqlite3.so.0.8.6
b6dd0000 b6dda000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b6de3000 b6ec9000 r-xp /usr/lib/libX11.so.6.3.0
b6ed4000 b6ed5000 r-xp /usr/local/lib/libcortex-strings.so.1.0.0
b6edd000 b6ee1000 r-xp /usr/lib/libsys-assert.so
b6ee9000 b6f06000 r-xp /lib/ld-2.13.so
be92c000 be94d000 rwxp [stack]
b6edd000 b6ee1000 r-xp /usr/lib/libsys-assert.so
b6ee9000 b6f06000 r-xp /lib/ld-2.13.so
be92c000 be94d000 rwxp [stack]
End of Maps Information

Callstack Information (PID:27467)
Call Stack Count: 36
 0: gsignal + 0x3c (0xb6acd760) [/lib/libc.so.6] + 0x2a760
 1: abort + 0x1ac (0xb6ad155c) [/lib/libc.so.6] + 0x2e55c
 2: __assert_fail + 0x10c (0xb6ac663c) [/lib/libc.so.6] + 0x2363c
 3: SysAssertfInternal + 0x9e (0xb4461f3f) [/usr/lib/osp/libosp-appfw.so] + 0x13ff3f
 4: Tizen::Ui::Controls::CustomItem::AddElement(Tizen::Graphics::Rectangle const&, int, Tizen::Graphics::Bitmap const&, Tizen::Graphics::Bitmap const*, Tizen::Graphics::Bitmap const*) + 0x9e (0xb3cde99b) [/usr/lib/osp/libosp-uifw.so] + 0x4f099b
 5: MyHondanaDownloadForm::OnListViewItemStateChanged(Tizen::Ui::Controls::ListView&, int, int, Tizen::Ui::Controls::ListItemStatus) + 0x234 (0xb2d7a390) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x42390
 6: non-virtual thunk to MyHondanaDownloadForm::OnListViewItemStateChanged(Tizen::Ui::Controls::ListView&, int, int, Tizen::Ui::Controls::ListItemStatus) + 0x64 (0xb2d7a6ac) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x426ac
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d ﾌﾞｯｸ ﾏｲ本棚
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
