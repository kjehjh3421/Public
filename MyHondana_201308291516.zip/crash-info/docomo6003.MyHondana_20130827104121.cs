S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 2598
Date: 2013-08-27 10:41:21(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=2598 tid=2598
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 2598, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x093da508, esi = 0x095262f0
ebp = 0xbfc50548, esp = 0xbfc50500
eax = 0x094e25f0, ebx = 0xb255cd80
ecx = 0x015a0000, edx = 0x00000000
eip = 0xb24feec3

Memory Information
MemTotal:   509368 KB
MemFree:      7264 KB
Buffers:     15172 KB
Cached:     297384 KB
VmPeak:     215880 KB
VmSize:     214772 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:       88912 KB
VmRSS:       88912 KB
VmData:      70620 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      101004 KB
VmPTE:         208 KB
VmSwap:          0 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
ab930000 ab931000 r-xp /usr/lib/evas/modules/loaders/eet/linux-gnu-i686-1.7.99/module.so
ab932000 ab956000 r-xp /usr/lib/edje/modules/elm/linux-gnu-i686-1.0.0/module.so
afa64000 afad7000 r-xp /usr/lib/host-gl/libGL.so.1.2
afafa000 afb08000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afb09000 afb40000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afb44000 afb46000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afb47000 afb4e000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afb4f000 afb5c000 r-xp /usr/lib/libdrm-client.so.0.0.1
afb5d000 afb6b000 r-xp /usr/lib/libudev.so.0.13.1
afb6c000 afbae000 r-xp /usr/lib/libSLP-location.so.0.0.0
afbaf000 afc3b000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afc41000 afc4b000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afc4c000 afc64000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afc65000 afc6b000 r-xp /usr/lib/libmmffile.so.0.0.0
afc6c000 afc74000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afc75000 afc77000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afc78000 afc99000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afc9a000 afc9c000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afc9d000 afcbb000 r-xp /usr/lib/libmedia-service.so.1.0.0
afcbc000 afcc2000 r-xp /usr/lib/libmemenv.so.1.1.0
afcc3000 afd0c000 r-xp /usr/lib/libleveldb.so.1.1.0
afd0e000 afd19000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afd1a000 afd56000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afd58000 afd6d000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afd6e000 afd8e000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afd90000 afdc6000 r-xp /usr/lib/libxslt.so.1.1.16
afdc7000 afdcf000 r-xp /usr/lib/libeeze.so.1.7.99
afdd0000 afdd5000 r-xp /usr/lib/libeukit.so.1.7.99
afdd6000 afde0000 r-xp /usr/lib/libenchant.so.1.6.1
afde1000 afdeb000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afdec000 afdf8000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afdf9000 afe28000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afe2e000 afe32000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afe33000 afe3f000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afe41000 afe48000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afe49000 afe58000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
afe59000 afe5c000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
afe5d000 afe6e000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
afe6f000 afe9e000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
afe9f000 afea5000 r-xp /usr/lib/libogg.so.0.7.1
afea6000 afed1000 r-xp /usr/lib/libvorbis.so.0.4.3
afed2000 afed7000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
afed8000 afedc000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
afedd000 afee2000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
afee3000 aff08000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
aff09000 aff23000 r-xp /usr/lib/libnetwork.so.0.0.0
aff25000 aff51000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
aff52000 b1f3d000 r-xp /usr/lib/libewebkit2.so.0.11.72
b2037000 b21a2000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b21ae000 b2232000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b2234000 b2250000 r-xp /usr/lib/libwifi-direct.so.0.0
b2251000 b225c000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b225d000 b2268000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b2269000 b2277000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b2278000 b231a000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b2320000 b2432000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b2438000 b245d000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b245f000 b248c000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b248f000 b2491000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
b2494000 b2495000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b249e000 b24a3000 r-xp /opt/usr/apps/docomo6003/lib/libHyBookViewerCore.so
b24a4000 b2557000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b255e000 b258e000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b258f000 b25e2000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b25e3000 b25e9000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b25ea000 b25ef000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b25f0000 b2638000 r-xp /usr/lib/libpulse.so.0.12.4
b2639000 b263d000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b263e000 b2730000 r-xp /usr/lib/libasound.so.2.0.0
b2734000 b2759000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b275a000 b276e000 r-xp /usr/lib/libmmfsound.so.0.1.0
b276f000 b284f000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b2854000 b28b3000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b28b4000 b28c0000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b28c1000 b28d4000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b28d5000 b28d8000 r-xp /usr/lib/libmm_ta.so.0.0.0
b28d9000 b28f0000 r-xp /usr/lib/libICE.so.6.3.0
b28f3000 b28fa000 r-xp /usr/lib/libSM.so.6.0.1
b28fb000 b28fc000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b28fd000 b2908000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b2909000 b290e000 r-xp /usr/lib/libsysman.so.0.2.0
b290f000 b291a000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b291e000 b2922000 r-xp /usr/lib/libmmfsession.so.0.0.0
b2923000 b2980000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2982000 b298a000 r-xp /usr/lib/libxcb-render.so.0.0.0
b298b000 b298d000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b298e000 b29f1000 r-xp /usr/lib/libtiff.so.5.1.0
b29f4000 b2a46000 r-xp /usr/lib/libturbojpeg.so
b2a57000 b2a5e000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2a5f000 b2a68000 r-xp /usr/lib/libgif.so.4.1.6
b2a69000 b2a8f000 r-xp /usr/lib/libavutil.so.51.73.101
b2a96000 b2adb000 r-xp /usr/lib/libswscale.so.2.1.101
b2adc000 b2e41000 r-xp /usr/lib/libavcodec.so.54.59.100
b3162000 b3189000 r-xp /usr/lib/libpng12.so.0.50.0
b318a000 b3191000 r-xp /usr/lib/libfeedback.so.0.1.4
b3192000 b31a1000 r-xp /usr/lib/libtts.so
b31a2000 b31b8000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b31b9000 b32d3000 r-xp /usr/lib/libcairo.so.2.11200.12
b32d6000 b32fa000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b32fb000 b40e1000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4151000 b4157000 r-xp /usr/lib/libslp_devman_plugin.so
b4158000 b415a000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b415b000 b415e000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b415f000 b4163000 r-xp /usr/lib/libdevice-node.so.0.1
b4164000 b4172000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4173000 b417c000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b417d000 b4183000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b4184000 b4186000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4187000 b418b000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b418c000 b4193000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4194000 b4197000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b4198000 b4199000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b419a000 b41ad000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b41af000 b41b7000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b41b8000 b41e8000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b41e9000 b41ed000 r-xp /usr/lib/libuuid.so.1.3.0
b41ee000 b41ff000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b4200000 b4201000 r-xp /usr/lib/libpmapi.so.1.2
b4202000 b420e000 r-xp /usr/lib/libminizip.so.1.0.0
b420f000 b4220000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b4221000 b4249000 r-xp /usr/lib/libpcre.so.0.0.1
b424a000 b424e000 r-xp /usr/lib/libheynoti.so.0.0.2
b424f000 b4254000 r-xp /usr/lib/libhaptic.so.0.1
b4255000 b4256000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4257000 b425e000 r-xp /usr/lib/libdevman.so.0.1
b425f000 b4265000 r-xp /usr/lib/libchromium.so.1.0
b4266000 b426e000 r-xp /usr/lib/libalarm.so.0.0.0
b426f000 b4278000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b4279000 b4291000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4292000 b473c000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b475e000 b4768000 r-xp /lib/libnss_files-2.13.so
b476a000 b4773000 r-xp /lib/libnss_nis-2.13.so
b4775000 b4788000 r-xp /lib/libnsl-2.13.so
b478c000 b4792000 r-xp /lib/libnss_compat-2.13.so
b4994000 b49ae000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b49af000 b4af8000 r-xp /usr/lib/libxml2.so.2.7.8
b4afe000 b4b24000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4b25000 b4b28000 r-xp /usr/lib/libiniparser.so.0
b4b2a000 b4b93000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4b95000 b4bb1000 r-xp /usr/lib/libcom-core.so.0.0.1
b4bb2000 b4bb9000 r-xp /usr/lib/libappsvc.so.0.1.0
b4bba000 b4bbd000 r-xp /usr/lib/libdri2.so.0.0.0
b4bbe000 b4bc9000 r-xp /usr/lib/libdrm.so.2.4.0
b4bca000 b4bcf000 r-xp /usr/lib/libtbm.so.1.0.0
b4bd0000 b4bd4000 r-xp /usr/lib/libXv.so.1.0.0
b4bd5000 b4cf3000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4d02000 b4d17000 r-xp /usr/lib/libnotification.so.0.1.0
b4d18000 b4d21000 r-xp /usr/lib/libutilX.so.1.1.0
b4d22000 b4d55000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4d57000 b4d68000 r-xp /lib/libresolv-2.13.so
b4d6c000 b4d6f000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4d70000 b4ed5000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4ed9000 b5049000 r-xp /usr/lib/libcrypto.so.1.0.0
b5061000 b50b7000 r-xp /usr/lib/libssl.so.1.0.0
b50bc000 b50eb000 r-xp /usr/lib/libidn.so.11.5.44
b50ec000 b50fb000 r-xp /usr/lib/libcares.so.2.0.0
b50fc000 b5123000 r-xp /lib/libexpat.so.1.5.2
b5125000 b5158000 r-xp /usr/lib/libicule.so.48.1
b5159000 b5164000 r-xp /usr/lib/libsf_common.so
b5165000 b5241000 r-xp /usr/lib/libstdc++.so.6.0.14
b524d000 b5250000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5251000 b5276000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5277000 b527c000 r-xp /usr/lib/libffi.so.5.0.10
b527d000 b527e000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b527f000 b52b0000 r-xp /usr/lib/libexif.so.12.3.3
b52bd000 b52c9000 r-xp /usr/lib/libethumb.so.1.7.99
b52ca000 b532e000 r-xp /usr/lib/libsndfile.so.1.0.25
b5334000 b5337000 r-xp /usr/lib/libctxdata.so.0.0.0
b5338000 b534f000 r-xp /usr/lib/libremix.so.0.0.0
b5350000 b5352000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5353000 b5380000 r-xp /usr/lib/liblua-5.1.so
b5381000 b538b000 r-xp /usr/lib/libembryo.so.1.7.99
b538c000 b538f000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5390000 b53f1000 r-xp /usr/lib/libcurl.so.4.3.0
b53f3000 b53f9000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b53fa000 b540b000 r-xp /usr/lib/libXext.so.6.4.0
b540c000 b5411000 r-xp /usr/lib/libXtst.so.6.1.0
b5412000 b541a000 r-xp /usr/lib/libXrender.so.1.3.0
b541b000 b5424000 r-xp /usr/lib/libXrandr.so.2.2.0
b5425000 b5427000 r-xp /usr/lib/libXinerama.so.1.0.0
b5428000 b5436000 r-xp /usr/lib/libXi.so.6.1.0
b5437000 b543b000 r-xp /usr/lib/libXfixes.so.3.1.0
b543c000 b543e000 r-xp /usr/lib/libXgesture.so.7.0.0
b543f000 b5441000 r-xp /usr/lib/libXcomposite.so.1.0.0
b5442000 b5444000 r-xp /usr/lib/libXdamage.so.1.1.0
b5445000 b544f000 r-xp /usr/lib/libXcursor.so.1.0.2
b5450000 b54e7000 r-xp /usr/lib/libpixman-1.so.0.28.2
b54ec000 b5521000 r-xp /usr/lib/libfontconfig.so.1.5.0
b5523000 b55a8000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b55b2000 b55c8000 r-xp /usr/lib/libfribidi.so.0.3.1
b55c9000 b564e000 r-xp /usr/lib/libfreetype.so.6.8.1
b5652000 b5699000 r-xp /usr/lib/libjpeg.so.8.0.2
b56aa000 b56c9000 r-xp /lib/libz.so.1.2.5
b56ca000 b56d6000 r-xp /usr/lib/libemotion.so.1.7.99
b56d7000 b56dd000 r-xp /usr/lib/libecore_fb.so.1.7.99
b56df000 b56ef000 r-xp /usr/lib/libsensor.so.1.1.0
b56f2000 b56f8000 r-xp /usr/lib/libappcore-common.so.1.1
b6801000 b695c000 r-xp /usr/lib/libicuuc.so.48.1
b696a000 b6b49000 r-xp /usr/lib/libicui18n.so.48.1
b6b50000 b6b53000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6b54000 b6b60000 r-xp /usr/lib/libvconf.so.0.2.45
b6b61000 b6b6a000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6b6b000 b6b7c000 r-xp /usr/lib/libail.so.0.1.0
b6b7d000 b6b8d000 r-xp /usr/lib/libaul.so.0.1.0
b6b8e000 b6bde000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6bdf000 b6c22000 r-xp /usr/lib/libecore_x.so.1.7.99
b6c24000 b6c7f000 r-xp /usr/lib/libeina.so.1.7.99
b6c81000 b6ca0000 r-xp /usr/lib/libecore.so.1.7.99
b6caf000 b6cda000 r-xp /usr/lib/libecore_con.so.1.7.99
b6cdc000 b6ce7000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6ce8000 b6cf4000 r-xp /usr/lib/libedbus.so.1.7.99
b6cf5000 b6cf8000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6cf9000 b6cff000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6d00000 b6d22000 r-xp /usr/lib/libefreet.so.1.7.99
b6d24000 b6dbb000 r-xp /usr/lib/libedje.so.1.7.99
b6dbd000 b6dd4000 r-xp /usr/lib/libecore_input.so.1.7.99
b6de8000 b6def000 r-xp /usr/lib/libecore_file.so.1.7.99
b6df0000 b6e1d000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6e1f000 b6f29000 r-xp /usr/lib/libevas.so.1.7.99
b6f44000 b6f61000 r-xp /usr/lib/libeet.so.1.7.99
b6f62000 b6f86000 r-xp /lib/libm-2.13.so
b6f88000 b7158000 r-xp /usr/lib/libelementary.so.1.7.99
b7165000 b7170000 r-xp /usr/lib/libcapi-web-favorites.so
b7171000 b7173000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7176000 b717a000 r-xp /lib/libattr.so.1.1.0
b717b000 b717d000 r-xp /usr/lib/libXau.so.6.0.0
b717f000 b7186000 r-xp /lib/librt-2.13.so
b7188000 b7190000 r-xp /lib/libcrypt-2.13.so
b71b9000 b71bc000 r-xp /lib/libcap.so.2.21
b71bd000 b71bf000 r-xp /usr/lib/libiri.so
b71c0000 b71da000 r-xp /lib/libgcc_s-4.5.3.so.1
b71db000 b71fb000 r-xp /usr/lib/libxcb.so.1.1.0
b71fd000 b7206000 r-xp /lib/libunwind.so.8.0.1
b7210000 b7366000 r-xp /lib/libc-2.13.so
b736c000 b7371000 r-xp /usr/lib/libsmack.so.1.0.0
b7372000 b73be000 r-xp /usr/lib/libdbus-1.so.3.7.2
b73bf000 b73c4000 r-xp /usr/lib/libbundle.so.0.1.22
b73c5000 b73c7000 r-xp /lib/libdl-2.13.so
b73ca000 b74f3000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b74f4000 b7509000 r-xp /lib/libpthread-2.13.so
b750e000 b750f000 r-xp /usr/lib/libdlog.so.0.0.0
b7510000 b75ba000 r-xp /usr/lib/libsqlite3.so.0.8.6
b75bd000 b75c9000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b75ca000 b76ff000 r-xp /usr/lib/libX11.so.6.3.0
b7704000 b770c000 r-xp /usr/lib/libecore_imf.so.1.7.99
b770d000 b7712000 r-xp /usr/lib/libappcore-efl.so.1.1
b7714000 b7718000 r-xp /usr/lib/libsys-assert.so
b771c000 b771d000 r-xp [vdso]
b771d000 b7739000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:2598)
Call Stack Count: 23
 0: non-virtual thunk to MyHondanaMainForm::OnTerminating() + 0x38 (0xb24ff0b8) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x5b0b8
 1: Tizen::Ui::_ControlImpl::OnDetachingFromMainTree() + 0x1a (0xb360f9fa) [/usr/lib/osp/libosp-uifw.so] + 0x3149fa
 2: Tizen::Ui::Controls::_FormImpl::OnDetachingFromMainTree() + 0x32 (0xb3944ef2) [/usr/lib/osp/libosp-uifw.so] + 0x649ef2
 3: Tizen::Ui::_Control::CallOnDetachingFromMainTree(Tizen::Ui::_Control&) + 0x8f (0xb35ec2bf) [/usr/lib/osp/libosp-uifw.so] + 0x2f12bf
 4: Tizen::Ui::_Control::DetachChild(Tizen::Ui::_Control&) + 0x12c (0xb35f3a3c) [/usr/lib/osp/libosp-uifw.so] + 0x2f8a3c
 5: Tizen::Ui::_Control::DetachAllChildren(bool, bool) + 0x177 (0xb35f3d77) [/usr/lib/osp/libosp-uifw.so] + 0x2f8d77
 6: Tizen::Ui::_ContainerImpl::RemoveAllChildren(bool, bool) + 0x4e (0xb362801e) [/usr/lib/osp/libosp-uifw.so] + 0x32d01e
 7: Tizen::Ui::_WindowImpl::Destroy() + 0x6f (0xb362a51f) [/usr/lib/osp/libosp-uifw.so] + 0x32f51f
 8: Tizen::App::_UiAppImpl::RemoveAllFrames() + 0x8a (0xb3cb39ca) [/usr/lib/osp/libosp-uifw.so] + 0x9b89ca
 9: Tizen::App::_UiAppImpl::OnUiAppImplTerminating() + 0x27 (0xb3cb3ff7) [/usr/lib/osp/libosp-uifw.so] + 0x9b8ff7
10: Tizen::App::_UiAppImpl::OnTerminate() + 0x66 (0xb3cb40c6) [/usr/lib/osp/libosp-uifw.so] + 0x9b90c6
11: Tizen::App::_AppImpl::OnTerminate(void*) + 0x65 (0xb4395065) [/usr/lib/osp/libosp-appfw.so] + 0x103065
12: app_appcore_terminate + 0x2f (0xb419e94f) [/usr/lib/libcapi-appfw-application.so.0] + 0x494f
13: appcore_efl_main + 0x45c (0xb771031c) [/usr/lib/libappcore-efl.so.1] + 0x331c
14: app_efl_main + 0xe8 (0xb419ed98) [/usr/lib/libcapi-appfw-application.so.0] + 0x4d98
15: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x122 (0xb4395612) [/usr/lib/osp/libosp-appfw.so] + 0x103612
16: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3cb1ea1) [/usr/lib/osp/libosp-uifw.so] + 0x9b6ea1
17: OspMain + 0x19f (0xb24f25df) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x4e5df
18: main + 0x503 (0xb71720c3) [/opt/apps/docomo6003/bin/MyHondana] + 0x10c3
19: __launchpad_main_loop + 0x1c17 (0x804bf97) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bf97
20: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
21: __libc_start_main + 0xe6 (0xb7226da6) [/lib/libc.so.6] + 0x16da6
22: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d book MyShelf
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
