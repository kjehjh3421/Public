S/W Version Information
Model: Emulator
Tizen-Version: 2.2.0
Build-Number: Tizen_EMULATOR_20130702.0205
Build-Date: 2013.07.02 02:05:29

Crash Information
Process Name: MyHondana
PID: 5315
Date: 2013-08-28 11:30:16(GMT+0900)
Executable File Path: /opt/apps/docomo6003/bin/MyHondana
This process is multi-thread process
pid=5315 tid=5315
Signal: 11
      (SIGSEGV)
      si_code: -6
      signal sent by tkill (sent by pid 5315, uid 5000)

Register Information
gs  = 0x00000033, fs  = 0x00000000
es  = 0x0000007b, ds  = 0x0000007b
edi = 0x00000001, esi = 0x0c9cd6f8
ebp = 0xbfc07ca8, esp = 0xbfc07c60
eax = 0x0ac66030, ebx = 0xb4806a10
ecx = 0xbfc07c88, edx = 0x00000000
eip = 0xb4644c61

Memory Information
MemTotal:   509368 KB
MemFree:     35680 KB
Buffers:      3200 KB
Cached:     162548 KB
VmPeak:     346320 KB
VmSize:     339676 KB
VmLck:           0 KB
VmPin:           0 KB
VmHWM:      216760 KB
VmRSS:      213852 KB
VmData:     195692 KB
VmStk:         136 KB
VmExe:          40 KB
VmLib:      100868 KB
VmPTE:         328 KB
VmSwap:         12 KB

Maps Information
08048000 08052000 r-xp /usr/bin/launchpad_preloading_preinitializing_daemon
ab7bf000 ab7c1000 r-xp /usr/lib/libhaptic-module.so
afa03000 afa76000 r-xp /usr/lib/host-gl/libGL.so.1.2
afa99000 afaa7000 r-xp /usr/lib/evas/modules/engines/software_generic/linux-gnu-i686-1.7.99/module.so
afaa8000 afadf000 r-xp /usr/lib/evas/modules/engines/gl_x11/linux-gnu-i686-1.7.99/module.so
afbf5000 afbf7000 r-xp /usr/lib/libcamsrcjpegenc.so.0.0.0
afbf8000 afbff000 r-xp /usr/lib/libmmutil_jpeg.so.0.0.0
afc00000 afc0d000 r-xp /usr/lib/libdrm-client.so.0.0.1
afc0e000 afc1c000 r-xp /usr/lib/libudev.so.0.13.1
afc1d000 afc5f000 r-xp /usr/lib/libSLP-location.so.0.0.0
afc60000 afcec000 r-xp /usr/lib/libmmfcamcorder.so.0.0.0
afcf2000 afcfc000 r-xp /usr/lib/libdownload-provider-interface.so.1.0.7
afcfd000 afd15000 r-xp /usr/lib/libmmfile_utils.so.0.0.0
afd16000 afd1c000 r-xp /usr/lib/libmmffile.so.0.0.0
afd1d000 afd25000 r-xp /usr/lib/libmedia-utils.so.0.0.0
afd26000 afd28000 r-xp /usr/lib/libmedia-hash.so.1.0.0
afd29000 afd4a000 r-xp /usr/lib/libmedia-thumbnail.so.1.0.0
afd4b000 afd4d000 r-xp /usr/lib/libmedia-svc-hash.so.1.0.0
afd4e000 afd6c000 r-xp /usr/lib/libmedia-service.so.1.0.0
afd6d000 afd73000 r-xp /usr/lib/libmemenv.so.1.1.0
afd74000 afdbd000 r-xp /usr/lib/libleveldb.so.1.1.0
afdbf000 afdca000 r-xp /usr/lib/libgstfft-0.10.so.0.25.0
afdcb000 afe07000 r-xp /usr/lib/libgstaudio-0.10.so.0.25.0
afe09000 afe1e000 r-xp /usr/lib/libgstvideo-0.10.so.0.25.0
afe1f000 afe3f000 r-xp /usr/lib/libgstpbutils-0.10.so.0.25.0
afe41000 afe77000 r-xp /usr/lib/libxslt.so.1.1.16
afe78000 afe80000 r-xp /usr/lib/libeeze.so.1.7.99
afe81000 afe86000 r-xp /usr/lib/libeukit.so.1.7.99
afe87000 afe91000 r-xp /usr/lib/libenchant.so.1.6.1
afe92000 afe9c000 r-xp /usr/lib/libui-gadget-1.so.0.1.0
afe9d000 afea9000 r-xp /usr/lib/libcapi-location-manager.so.0.1.11
afeaa000 afed9000 r-xp /usr/lib/host-gl/libGLESv2.so.1.0
afedf000 afee3000 r-xp /usr/lib/libcapi-telephony-network-info.so.0.1.0
afee4000 afef0000 r-xp /usr/lib/libcapi-system-sensor.so.0.1.17
afef2000 afef9000 r-xp /usr/lib/libcapi-media-recorder.so.0.1.2
afefa000 aff09000 r-xp /usr/lib/libcapi-media-camera.so.0.1.3
aff0a000 aff0d000 r-xp /usr/lib/libcapi-media-sound-manager.so.0.1.1
aff0e000 aff1f000 r-xp /usr/lib/libcapi-media-player.so.0.1.0
aff20000 aff4f000 r-xp /usr/lib/libopencore-amrnb.so.0.0.2
aff50000 aff56000 r-xp /usr/lib/libogg.so.0.7.1
aff57000 aff82000 r-xp /usr/lib/libvorbis.so.0.4.3
aff83000 aff88000 r-xp /usr/lib/libcapi-media-audio-io.so.0.2.0
aff89000 aff8d000 r-xp /usr/lib/libcapi-web-url-download.so.0.1.0
aff8e000 aff93000 r-xp /usr/lib/libcapi-media-metadata-extractor.so
aff94000 affb9000 r-xp /usr/lib/osp/libosp-locations.so.1.2.2.0
affba000 affd4000 r-xp /usr/lib/libnetwork.so.0.0.0
affd6000 b0002000 r-xp /usr/lib/libcapi-content-media-content.so.0.2.58
b0003000 b1fee000 r-xp /usr/lib/libewebkit2.so.0.11.72
b20e8000 b2253000 r-xp /usr/lib/osp/libosp-media.so.1.2.2.0
b225f000 b22e3000 r-xp /usr/lib/osp/libosp-content.so.1.2.2.0
b22e5000 b2301000 r-xp /usr/lib/libwifi-direct.so.0.0
b2302000 b230d000 r-xp /usr/lib/libcapi-network-wifi.so.0.1.2_24
b230e000 b2319000 r-xp /usr/lib/libcapi-network-tethering.so.0.1.0
b231a000 b2328000 r-xp /usr/lib/libcapi-network-connection.so.0.1.3_16
b2329000 b23cb000 r-xp /usr/lib/osp/libosp-web.so.1.2.2.0
b23d1000 b24e3000 r-xp /usr/lib/osp/libosp-net.so.1.2.2.0
b24e9000 b250e000 r-xp /usr/lib/osp/libosp-json.so.1.2.1.0
b2510000 b253d000 r-xp /usr/lib/osp/libosp-image.so.1.2.2.0
b2541000 b2543000 r-xp /usr/lib/evas/modules/loaders/png/linux-gnu-i686-1.7.99/module.so
b2546000 b2547000 r-xp /usr/lib/libX11-xcb.so.1.0.0
b254f000 b2554000 r-xp /opt/usr/apps/docomo6003/lib/libHyBookViewerCore.so
b2555000 b2609000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana.exe
b2610000 b2640000 r-xp /usr/lib/libosp-env-config.so.SOVERSION
b2641000 b2694000 r-xp /usr/lib/libpulsecommon-0.9.23.so
b2695000 b269b000 r-xp /usr/lib/libascenario-0.2.so.0.0.0
b269c000 b26a1000 r-xp /usr/lib/libmmfsoundcommon.so.0.0.0
b26a2000 b26ea000 r-xp /usr/lib/libpulse.so.0.12.4
b26eb000 b26ef000 r-xp /usr/lib/libpulse-simple.so.0.0.3
b26f0000 b27e2000 r-xp /usr/lib/libasound.so.2.0.0
b27e6000 b280b000 r-xp /usr/lib/libavsysaudio.so.0.0.1
b280c000 b2820000 r-xp /usr/lib/libmmfsound.so.0.1.0
b2821000 b2901000 r-xp /usr/lib/libgstreamer-0.10.so.0.30.0
b2906000 b2965000 r-xp /usr/lib/libgstbase-0.10.so.0.30.0
b2966000 b2972000 r-xp /usr/lib/libgstapp-0.10.so.0.25.0
b2973000 b2986000 r-xp /usr/lib/libgstinterfaces-0.10.so.0.25.0
b2987000 b298a000 r-xp /usr/lib/libmm_ta.so.0.0.0
b298b000 b29a2000 r-xp /usr/lib/libICE.so.6.3.0
b29a5000 b29ac000 r-xp /usr/lib/libSM.so.6.0.1
b29ad000 b29ae000 r-xp /usr/lib/libmmfkeysound.so.0.0.0
b29af000 b29ba000 r-xp /usr/lib/libmmfcommon.so.0.0.0
b29bb000 b29c0000 r-xp /usr/lib/libsysman.so.0.2.0
b29c1000 b29cc000 r-xp /usr/lib/libaudio-session-mgr.so.0.0.0
b29d0000 b29d4000 r-xp /usr/lib/libmmfsession.so.0.0.0
b29d5000 b2a32000 r-xp /usr/lib/libmmfplayer.so.0.0.0
b2a34000 b2a3c000 r-xp /usr/lib/libxcb-render.so.0.0.0
b2a3d000 b2a3f000 r-xp /usr/lib/libxcb-shm.so.0.0.0
b2a40000 b2aa3000 r-xp /usr/lib/libtiff.so.5.1.0
b2aa6000 b2af8000 r-xp /usr/lib/libturbojpeg.so
b2b09000 b2b10000 r-xp /usr/lib/libmmutil_imgp.so.0.0.0
b2b11000 b2b1a000 r-xp /usr/lib/libgif.so.4.1.6
b2b1b000 b2b41000 r-xp /usr/lib/libavutil.so.51.73.101
b2b48000 b2b8d000 r-xp /usr/lib/libswscale.so.2.1.101
b2b8e000 b2ef3000 r-xp /usr/lib/libavcodec.so.54.59.100
b3214000 b323b000 r-xp /usr/lib/libpng12.so.0.50.0
b323c000 b3243000 r-xp /usr/lib/libfeedback.so.0.1.4
b3244000 b3253000 r-xp /usr/lib/libtts.so
b3254000 b326a000 r-xp /usr/lib/host-gl/libEGL.so.1.0
b326b000 b3385000 r-xp /usr/lib/libcairo.so.2.11200.12
b3388000 b33ac000 r-xp /usr/lib/osp/libosp-image-core.so.1.2.2.0
b33ad000 b4193000 r-xp /usr/lib/osp/libosp-uifw.so.1.2.2.0
b4203000 b4209000 r-xp /usr/lib/libslp_devman_plugin.so
b420a000 b420c000 r-xp /usr/lib/libpkgmgr_installer_status_broadcast_server.so.0.1.0
b420d000 b4210000 r-xp /usr/lib/libpkgmgr_installer_client.so.0.1.0
b4211000 b4215000 r-xp /usr/lib/libdevice-node.so.0.1
b4216000 b4224000 r-xp /usr/lib/libsecurity-server-client.so.1.0.1
b4225000 b422e000 r-xp /usr/lib/libcapi-system-info.so.0.2.0
b422f000 b4235000 r-xp /usr/lib/libcapi-system-system-settings.so.0.0.2
b4236000 b4238000 r-xp /usr/lib/libcapi-system-power.so.0.1.1
b4239000 b423d000 r-xp /usr/lib/libcapi-system-device.so.0.1.0
b423e000 b4245000 r-xp /usr/lib/libcapi-system-runtime-info.so.0.0.3
b4246000 b4249000 r-xp /usr/lib/libcapi-network-serial.so.0.0.7
b424a000 b424b000 r-xp /usr/lib/libcapi-content-mime-type.so.0.0.2
b424c000 b425f000 r-xp /usr/lib/libcapi-appfw-application.so.0.1.0
b4261000 b4269000 r-xp /usr/lib/libcapi-appfw-app-manager.so.0.1.0
b426a000 b429a000 r-xp /usr/lib/libSLP-tapi.so.0.0.0
b429b000 b429f000 r-xp /usr/lib/libuuid.so.1.3.0
b42a0000 b42b1000 r-xp /usr/lib/libpkgmgr-client.so.0.1.68
b42b2000 b42b3000 r-xp /usr/lib/libpmapi.so.1.2
b42b4000 b42c0000 r-xp /usr/lib/libminizip.so.1.0.0
b42c1000 b42d2000 r-xp /usr/lib/libmessage-port.so.1.2.2.0
b42d3000 b42fb000 r-xp /usr/lib/libpcre.so.0.0.1
b42fc000 b4300000 r-xp /usr/lib/libheynoti.so.0.0.2
b4301000 b4306000 r-xp /usr/lib/libhaptic.so.0.1
b4307000 b4308000 r-xp /usr/lib/libcryptsvc.so.0.0.1
b4309000 b4310000 r-xp /usr/lib/libdevman.so.0.1
b4311000 b4317000 r-xp /usr/lib/libchromium.so.1.0
b4318000 b4320000 r-xp /usr/lib/libalarm.so.0.0.0
b4321000 b432a000 r-xp /usr/lib/libcapi-security-privilege-manager.so.0.0.2
b432b000 b4343000 r-xp /usr/lib/libprivacy-manager-client.so.0.0.4
b4344000 b47ee000 r-xp /usr/lib/osp/libosp-appfw.so.1.2.2.0
b4810000 b481a000 r-xp /lib/libnss_files-2.13.so
b481c000 b4825000 r-xp /lib/libnss_nis-2.13.so
b4827000 b483a000 r-xp /lib/libnsl-2.13.so
b483e000 b4844000 r-xp /lib/libnss_compat-2.13.so
b4a46000 b4a60000 r-xp /usr/lib/libpkgmgr_parser.so.0.1.0
b4a61000 b4baa000 r-xp /usr/lib/libxml2.so.2.7.8
b4bb0000 b4bd6000 r-xp /usr/lib/libpkgmgr-info.so.0.0.17
b4bd7000 b4bda000 r-xp /usr/lib/libiniparser.so.0
b4bdc000 b4c45000 r-xp /usr/lib/libsoup-2.4.so.1.5.0
b4c47000 b4c63000 r-xp /usr/lib/libcom-core.so.0.0.1
b4c64000 b4c6b000 r-xp /usr/lib/libappsvc.so.0.1.0
b4c6c000 b4c6f000 r-xp /usr/lib/libdri2.so.0.0.0
b4c70000 b4c7b000 r-xp /usr/lib/libdrm.so.2.4.0
b4c7c000 b4c81000 r-xp /usr/lib/libtbm.so.1.0.0
b4c82000 b4c86000 r-xp /usr/lib/libXv.so.1.0.0
b4c87000 b4da5000 r-xp /usr/lib/libscim-1.0.so.8.2.3
b4db4000 b4dc9000 r-xp /usr/lib/libnotification.so.0.1.0
b4dca000 b4dd3000 r-xp /usr/lib/libutilX.so.1.1.0
b4dd4000 b4e07000 r-xp /usr/lib/ecore/immodules/libisf-imf-module.so
b4e09000 b4e1a000 r-xp /lib/libresolv-2.13.so
b4e1e000 b4e21000 r-xp /usr/lib/libgmodule-2.0.so.0.3200.3
b4e22000 b4f87000 r-xp /usr/lib/libgio-2.0.so.0.3200.3
b4f8b000 b50fb000 r-xp /usr/lib/libcrypto.so.1.0.0
b5113000 b5169000 r-xp /usr/lib/libssl.so.1.0.0
b516e000 b519d000 r-xp /usr/lib/libidn.so.11.5.44
b519e000 b51ad000 r-xp /usr/lib/libcares.so.2.0.0
b51ae000 b51d5000 r-xp /lib/libexpat.so.1.5.2
b51d7000 b520a000 r-xp /usr/lib/libicule.so.48.1
b520b000 b5216000 r-xp /usr/lib/libsf_common.so
b5217000 b52f3000 r-xp /usr/lib/libstdc++.so.6.0.14
b52ff000 b5302000 r-xp /usr/lib/libapp-checker.so.0.1.0
b5303000 b5328000 r-xp /usr/lib/libdbus-glib-1.so.2.2.2
b5329000 b532e000 r-xp /usr/lib/libffi.so.5.0.10
b532f000 b5330000 r-xp /usr/lib/libgthread-2.0.so.0.3200.3
b5331000 b5362000 r-xp /usr/lib/libexif.so.12.3.3
b536f000 b537b000 r-xp /usr/lib/libethumb.so.1.7.99
b537c000 b53e0000 r-xp /usr/lib/libsndfile.so.1.0.25
b53e6000 b53e9000 r-xp /usr/lib/libctxdata.so.0.0.0
b53ea000 b5401000 r-xp /usr/lib/libremix.so.0.0.0
b5402000 b5404000 r-xp /usr/lib/libecore_imf_evas.so.1.7.99
b5405000 b5432000 r-xp /usr/lib/liblua-5.1.so
b5433000 b543d000 r-xp /usr/lib/libembryo.so.1.7.99
b543e000 b5441000 r-xp /usr/lib/libecore_input_evas.so.1.7.99
b5442000 b54a3000 r-xp /usr/lib/libcurl.so.4.3.0
b54a5000 b54ab000 r-xp /usr/lib/libecore_ipc.so.1.7.99
b54ac000 b54bd000 r-xp /usr/lib/libXext.so.6.4.0
b54be000 b54c3000 r-xp /usr/lib/libXtst.so.6.1.0
b54c4000 b54cc000 r-xp /usr/lib/libXrender.so.1.3.0
b54cd000 b54d6000 r-xp /usr/lib/libXrandr.so.2.2.0
b54d7000 b54d9000 r-xp /usr/lib/libXinerama.so.1.0.0
b54da000 b54e8000 r-xp /usr/lib/libXi.so.6.1.0
b54e9000 b54ed000 r-xp /usr/lib/libXfixes.so.3.1.0
b54ee000 b54f0000 r-xp /usr/lib/libXgesture.so.7.0.0
b54f1000 b54f3000 r-xp /usr/lib/libXcomposite.so.1.0.0
b54f4000 b54f6000 r-xp /usr/lib/libXdamage.so.1.1.0
b54f7000 b5501000 r-xp /usr/lib/libXcursor.so.1.0.2
b5502000 b5599000 r-xp /usr/lib/libpixman-1.so.0.28.2
b559e000 b55d3000 r-xp /usr/lib/libfontconfig.so.1.5.0
b55d5000 b565a000 r-xp /usr/lib/libharfbuzz.so.0.907.0
b5664000 b567a000 r-xp /usr/lib/libfribidi.so.0.3.1
b567b000 b5700000 r-xp /usr/lib/libfreetype.so.6.8.1
b5704000 b574b000 r-xp /usr/lib/libjpeg.so.8.0.2
b575c000 b577b000 r-xp /lib/libz.so.1.2.5
b577c000 b5788000 r-xp /usr/lib/libemotion.so.1.7.99
b5789000 b578f000 r-xp /usr/lib/libecore_fb.so.1.7.99
b5791000 b57a1000 r-xp /usr/lib/libsensor.so.1.1.0
b57a4000 b57aa000 r-xp /usr/lib/libappcore-common.so.1.1
b68b3000 b6a0e000 r-xp /usr/lib/libicuuc.so.48.1
b6a1c000 b6bfb000 r-xp /usr/lib/libicui18n.so.48.1
b6c02000 b6c05000 r-xp /usr/lib/libSLP-db-util.so.0.1.0
b6c06000 b6c12000 r-xp /usr/lib/libvconf.so.0.2.45
b6c13000 b6c1c000 r-xp /usr/lib/libxdgmime.so.1.1.0
b6c1d000 b6c2e000 r-xp /usr/lib/libail.so.0.1.0
b6c2f000 b6c3f000 r-xp /usr/lib/libaul.so.0.1.0
b6c40000 b6c90000 r-xp /usr/lib/libgobject-2.0.so.0.3200.3
b6c91000 b6cd4000 r-xp /usr/lib/libecore_x.so.1.7.99
b6cd6000 b6d31000 r-xp /usr/lib/libeina.so.1.7.99
b6d33000 b6d52000 r-xp /usr/lib/libecore.so.1.7.99
b6d61000 b6d8c000 r-xp /usr/lib/libecore_con.so.1.7.99
b6d8e000 b6d99000 r-xp /usr/lib/libethumb_client.so.1.7.99
b6d9a000 b6da6000 r-xp /usr/lib/libedbus.so.1.7.99
b6da7000 b6daa000 r-xp /usr/lib/libefreet_trash.so.1.7.99
b6dab000 b6db1000 r-xp /usr/lib/libefreet_mime.so.1.7.99
b6db2000 b6dd4000 r-xp /usr/lib/libefreet.so.1.7.99
b6dd6000 b6e6d000 r-xp /usr/lib/libedje.so.1.7.99
b6e6f000 b6e86000 r-xp /usr/lib/libecore_input.so.1.7.99
b6e9a000 b6ea1000 r-xp /usr/lib/libecore_file.so.1.7.99
b6ea2000 b6ecf000 r-xp /usr/lib/libecore_evas.so.1.7.99
b6ed1000 b6fdb000 r-xp /usr/lib/libevas.so.1.7.99
b6ff6000 b7013000 r-xp /usr/lib/libeet.so.1.7.99
b7014000 b7038000 r-xp /lib/libm-2.13.so
b703a000 b720a000 r-xp /usr/lib/libelementary.so.1.7.99
b7217000 b7222000 r-xp /usr/lib/libcapi-web-favorites.so
b7223000 b7225000 r-xp /opt/usr/apps/docomo6003/bin/MyHondana
b7228000 b722c000 r-xp /lib/libattr.so.1.1.0
b722d000 b722f000 r-xp /usr/lib/libXau.so.6.0.0
b7231000 b7238000 r-xp /lib/librt-2.13.so
b723a000 b7242000 r-xp /lib/libcrypt-2.13.so
b726b000 b726e000 r-xp /lib/libcap.so.2.21
b726f000 b7271000 r-xp /usr/lib/libiri.so
b7272000 b728c000 r-xp /lib/libgcc_s-4.5.3.so.1
b728d000 b72ad000 r-xp /usr/lib/libxcb.so.1.1.0
b72af000 b72b8000 r-xp /lib/libunwind.so.8.0.1
b72c2000 b7418000 r-xp /lib/libc-2.13.so
b741e000 b7423000 r-xp /usr/lib/libsmack.so.1.0.0
b7424000 b7470000 r-xp /usr/lib/libdbus-1.so.3.7.2
b7471000 b7476000 r-xp /usr/lib/libbundle.so.0.1.22
b7477000 b7479000 r-xp /lib/libdl-2.13.so
b747c000 b75a5000 r-xp /usr/lib/libglib-2.0.so.0.3200.3
b75a6000 b75bb000 r-xp /lib/libpthread-2.13.so
b75c0000 b75c1000 r-xp /usr/lib/libdlog.so.0.0.0
b75c2000 b766c000 r-xp /usr/lib/libsqlite3.so.0.8.6
b766f000 b767b000 r-xp /usr/lib/libprivilege-control.so.0.0.2
b767c000 b77b1000 r-xp /usr/lib/libX11.so.6.3.0
b77b6000 b77be000 r-xp /usr/lib/libecore_imf.so.1.7.99
b77bf000 b77c4000 r-xp /usr/lib/libappcore-efl.so.1.1
b77c6000 b77ca000 r-xp /usr/lib/libsys-assert.so
b77ce000 b77cf000 r-xp [vdso]
b77cf000 b77eb000 r-xp /lib/ld-2.13.so
End of Maps Information

Callstack Information (PID:5315)
Call Stack Count: 18
 0: _vconf_kdb_gio_cb + 0x353 (0xb6c0f373) [/usr/lib/libvconf.so.0] + 0x9373
 1: g_io_unix_dispatch + 0x4b (0xb750750b) [/usr/lib/libglib-2.0.so.0] + 0x8b50b
 2: g_main_context_dispatch + 0x133 (0xb74c4a13) [/usr/lib/libglib-2.0.so.0] + 0x48a13
 3: _ecore_glib_select + 0x3fb (0xb6d46d5b) [/usr/lib/libecore.so.1] + 0x13d5b
 4: _ecore_main_select + 0x3a5 (0xb6d40595) [/usr/lib/libecore.so.1] + 0xd595
 5: _ecore_main_loop_iterate_internal + 0x2e9 (0xb6d41019) [/usr/lib/libecore.so.1] + 0xe019
 6: ecore_main_loop_begin + 0x3f (0xb6d4145f) [/usr/lib/libecore.so.1] + 0xe45f
 7: elm_run + 0x17 (0xb712aee7) [/usr/lib/libelementary.so.1] + 0xf0ee7
 8: appcore_efl_main + 0x42e (0xb77c22ee) [/usr/lib/libappcore-efl.so.1] + 0x32ee
 9: app_efl_main + 0xe8 (0xb4250d98) [/usr/lib/libcapi-appfw-application.so.0] + 0x4d98
10: Tizen::App::_AppImpl::Execute(Tizen::App::_IAppImpl*) + 0x122 (0xb4447612) [/usr/lib/osp/libosp-appfw.so] + 0x103612
11: Tizen::App::UiApp::Execute(Tizen::App::UiApp* (*)(), Tizen::Base::Collection::IList const*) + 0xa1 (0xb3d63ea1) [/usr/lib/osp/libosp-uifw.so] + 0x9b6ea1
12: OspMain + 0x19f (0xb25a3def) [/opt/apps/docomo6003/bin/MyHondana.exe] + 0x4edef
13: main + 0x503 (0xb72240c3) [/opt/apps/docomo6003/bin/MyHondana] + 0x10c3
14: __launchpad_main_loop + 0x1c17 (0x804bf97) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804bf97
15: main + 0x685 (0x804ce85) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x804ce85
16: __libc_start_main + 0xe6 (0xb72d8da6) [/lib/libc.so.6] + 0x16da6
17: (0x8049e81) [/usr/bin/launchpad_preloading_preinitializing_daemon] + 0x8049e81
End of Call Stack

Package Information
Package Name: docomo6003.MyHondana
Package ID : docomo6003
Version: 1.0.0
Package Type: tpk
App Name: d ﾌﾞｯｸ ﾏｲ本棚
App ID: docomo6003.MyHondana
Type: Application
Categories: (NULL)
