#ifndef _BACKLIGHTPOPUP_H_
#define _BACKLIGHTPOPUP_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FSystem.h>

using namespace Tizen::Graphics;

const int ID_SCREEN_BACKLIGHTTIME_VALUE_15 = 500;
const int ID_SCREEN_BACKLIGHTTIME_VALUE_30 = 501;
const int ID_SCREEN_BACKLIGHTTIME_VALUE_60 = 502;
const int ID_SCREEN_BACKLIGHTTIME_VALUE_120 = 503;
const int ID_SCREEN_BACKLIGHTTIME_VALUE_300 = 504;
const int ID_SCREEN_BACKLIGHTTIME_VALUE_600 = 505;

class IBacklightPopupListener
{
public:
	virtual ~IBacklightPopupListener() {}

	virtual void OnBacklightPopupSelected(int selectIdx) = 0;
};

class BacklightPopup
	: public Tizen::Ui::Controls::Popup
	, public Tizen::Ui::IPropagatedKeyEventListener
	, public Tizen::Ui::IActionEventListener
	, public Tizen::System::IScreenEventListener
	, public Tizen::System::ISettingEventListener
	, public Tizen::System::ISettingInfoSetValueAsyncResultListener
{
private:
	IBacklightPopupListener* __pListener;

public:
	BacklightPopup(void);
	BacklightPopup(IBacklightPopupListener * pListener);
	virtual ~BacklightPopup(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	void ShowPopup(void);
	void HidePopup(void);
	void SetControl(void);
	void ControlSetting(void);
	void InitializeValue(void);

	void FirstStart(void);
	virtual bool OnKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool TranslateKeyEventInfo(Tizen::Ui::Control& source, Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);

	// IScreenEventListener
	virtual void OnScreenOn(void);
	virtual void OnScreenOff(void);
	virtual void OnScreenBacklightChanged(int brightness);

	//ISettingEventLisetener
	virtual void OnSettingChanged(Tizen::Base::String& key);

	virtual void OnResultReceivedForSetValueAsync(const Tizen::Base::String& key, result r);


	Tizen::Ui::Controls::Label* __pBacklight_Description_Label;

	Tizen::Ui::Controls::CheckButton* __pBacklight_CheckButton_15Sec;
	Tizen::Ui::Controls::CheckButton* __pBacklight_CheckButton_30Sec;
	Tizen::Ui::Controls::CheckButton* __pBacklight_CheckButton_60Sec;
	Tizen::Ui::Controls::CheckButton* __pBacklight_CheckButton_120Sec;
	Tizen::Ui::Controls::CheckButton* __pBacklight_CheckButton_300Sec;
	Tizen::Ui::Controls::CheckButton* __pBacklight_CheckButton_600Sec;

	Tizen::Ui::Controls::Button* __pBacklight_Cancel_Button;
	Tizen::Ui::Controls::Button* __pBacklight_Ok_Button;;

	static const int ID_BACKLIGHT_CANCEL_BUTTON = 1000;
	static const int ID_BACKLIGHT_SET_BUTTON = 1001;
};

#endif // _BACKLIGHTPOPUP_H_
