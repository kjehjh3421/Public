#ifndef _BOOKMARKSHAREDPOPUP_H_
#define _BOOKMARKSHAREDPOPUP_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FSystem.h>

using namespace Tizen::Graphics;

class IBookmarkSharedPopupListener
{
public:
	virtual ~IBookmarkSharedPopupListener() {}

	virtual void OnBookmarkSharedPopupSelected(int selectIdx) = 0;
};

class BookmarkSharedPopup
	: public Tizen::Ui::Controls::Popup
	, public Tizen::Ui::IPropagatedKeyEventListener
	, public Tizen::Ui::IActionEventListener
{
private:
	IBookmarkSharedPopupListener* __pListener;

public:
	BookmarkSharedPopup(void);
	BookmarkSharedPopup(IBookmarkSharedPopupListener * pListener);
	virtual ~BookmarkSharedPopup(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	void ShowPopup(void);
	void HidePopup(void);
	void SetControl(void);
	void AddControl(void);

	virtual bool OnKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool TranslateKeyEventInfo(Tizen::Ui::Control& source, Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);

	Tizen::Ui::Controls::Button* __pBookmarkShared_Button_Link;
	Tizen::Ui::Controls::Button* __pBookmarkShared_Button_Send;;
	Tizen::Ui::Controls::Button* __pBookmarkShared_Button_Reception;;
	Tizen::Ui::Controls::Button* __pBookmarkShared_Button_Delete;;
	Tizen::Ui::Controls::Button* __pBookmarkShared_Cancel_Button;

	static const int ID_BOOKMARKSHARED_CANCEL_BUTTON = 1000;
	static const int ID_BOOKMARKSHARED_BUTTON_LINK = 1001;
	static const int ID_BOOKMARKSHARED_BUTTON_SEND = 1002;
	static const int ID_BOOKMARKSHARED_BUTTON_RECEPTION = 1003;
	static const int ID_BOOKMARKSHARED_BUTTON_DELETE = 1004;
};

#endif // _BOOKMARKSHAREDPOPUP_H_
