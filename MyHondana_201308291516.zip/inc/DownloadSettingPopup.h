#ifndef _DOWNLOADSETTINGPOPUP_H_
#define _DOWNLOADSETTINGPOPUP_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FSystem.h>

using namespace Tizen::Graphics;

class IDownloadSettingPopupListener
{
public:
	virtual ~IDownloadSettingPopupListener() {}

	virtual void OnDownloadSettingPopupSelected(int selectIdx) = 0;
};

class DownloadSettingPopup
	: public Tizen::Ui::Controls::Popup
	, public Tizen::Ui::IPropagatedKeyEventListener
	, public Tizen::Ui::IActionEventListener
{
private:
	IDownloadSettingPopupListener* __pListener;

public:
	DownloadSettingPopup(void);
	DownloadSettingPopup(IDownloadSettingPopupListener * pListener);
	virtual ~DownloadSettingPopup(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	void ShowPopup(void);
	void HidePopup(void);
	void SetControl(void);
	void AddControl(void);

	virtual bool OnKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool TranslateKeyEventInfo(Tizen::Ui::Control& source, Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);

	Tizen::Ui::Controls::Button* __pDownloadSetting_Button_Link;
	Tizen::Ui::Controls::CheckButton* __pDownloadSetting_CheckButton_Select;
	Tizen::Ui::Controls::CheckButton* __pDownloadSetting_CheckButton_Inmemory;
	Tizen::Ui::Controls::CheckButton* __pDownloadSetting_CheckButton_Outmemory;
	Tizen::Ui::Controls::CheckButton* __pDownloadSetting_CheckButton_Notmemory;
	Tizen::Ui::Controls::Button* __pDownloadSetting_Button_Ok;
	Tizen::Ui::Controls::Button* __pDownloadSetting_Button_Cancel;

	static const int ID_DOWNLOADSETTING_BUTTON_LINK = 1001;
	static const int ID_DOWNLOADSETTING_BUTTON_SELECT = 1002;
	static const int ID_DOWNLOADSETTING_BUTTON_INMEMORY = 1003;
	static const int ID_DOWNLOADSETTING_BUTTON_OUTMEMORY = 1004;
	static const int ID_DOWNLOADSETTING_BUTTON_NOTMEMORY = 1005;
	static const int ID_DOWNLOADSETTING_BUTTON_OK = 1006;
	static const int ID_DOWNLOADSETTING_BUTTON_CANCEL = 1007;
};

#endif // _DOWNLOADSETTINGPOPUP_H_
