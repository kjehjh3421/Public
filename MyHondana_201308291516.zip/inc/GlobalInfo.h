/*
 * GlobalInfo.h
 *
 *  Created on: Aug 13, 2013
 *      Author: Administrator
 */

#ifndef GLOBALINFO_H_
#define GLOBALINFO_H_




#endif /* GLOBALINFO_H_ */
