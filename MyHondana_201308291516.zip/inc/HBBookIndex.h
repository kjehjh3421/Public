/*
 * HBBookIndex.h
 *
 *  Created on: Jul 30, 2013
 *      Author: ochi
 */

#ifndef HBBOOKINDEX_H_
#define HBBOOKINDEX_H_

#include <stdint.h>
#include <vector>
#include <tr1/memory>

namespace HyBook {

/*!
 * 目次項目を取り扱うクラス
 *
 * @attention 文字サイズ、ページレイアウト、組み方向等の変更によりリフローが発生するとページインデックスが変動するため
 * リフロー以前に取得した目次は破棄すること。
 */
class HBBookIndex {
public:
	virtual ~HBBookIndex()
	{
	}

	/*!
	 *  目次項目の文字インデックス値
	 *  return 文字インデックス
	 */
	virtual int64_t charactorIndex(void) = 0;

	/*!
	 *  目次項目の表題
	 *  return 目次項目名
	 */
	virtual std::string title(void) = 0;

	/*!
	 *  目次項目のページインデックス値
	 *  return ページインデックス
	 */
	virtual int pageIndex(void) = 0;
};

/*!
 * 目次リスト
 */
typedef std::vector<std::tr1::shared_ptr<HBBookIndex> > HBBookIndexList;

} /* namespace HyBook */
#endif /* HBBOOKINDEX_H_ */
