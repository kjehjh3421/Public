/*
 * HBPageLayout.h
 *
 *  Created on: Jul 30, 2013
 *      Author: ochi
 */

#ifndef HBPAGELAYOUT_H_
#define HBPAGELAYOUT_H_

#include "HBParam.h"

namespace HyBook {

/*!
 @struct HBPageLayout
 レンダラーに設定するレイアウト情報
*/
typedef struct {
	HBPageBindingType binding;		/*!< 綴じ方向 */
	HBPageLayoutType layputType;	/*!< ビューレイアウト */
	float fontScale;				/*!< オリジナルサイズからのフォント倍率 */
} HBPageLayout;

} /* namespace HyBook */
#endif /* HBPAGELAYOUT_H_ */
