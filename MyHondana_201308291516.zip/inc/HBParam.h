/*
 * HBParam.h
 *
 *  Created on: Jul 30, 2013
 *      Author: Hideki OCHI
 */

#ifndef HBPARAM_H_
#define HBPARAM_H_

#include <stdint.h>

namespace HyBook {

/*!
 綴じ方向
*/
typedef enum
{
    HBPageBindingTypeAuto = 0,	/*!< 自動 */
    HBPageBindingTypeLeft,		/*!< 左綴じ */
    HBPageBindingTypeRight		/*!< 右綴じ */
} HBPageBindingType;

/*!
 ページ送り効果
*/
typedef enum
{
    HBTransitionTypeNone = 0,	/*!< なし */
    HBTransitionTypePageCurl,	/*!< カール（非対応） */
    HBTransitionTypePageSlide	/*!< スライド */
} HBTransitionType;

/*!
 影のタイプ
 */
typedef enum
{
    HBShadowTypeNone = 0,	/*!< 陰影なし */
    HBShadowTypeInner,		/*!< ノドに陰影を描画 */
    HBShadowTypeDrop		/*!< ページ外に影を描画 */
} HBShadowType;

/*!
 ビューモード
 */
typedef enum
{
    HBPageViewModePageView = 0,	/*!< ページビュー：標準状態 */
    HBPageViewModeFreeScroll,	/*!< フリースクロール：拡大・縮小時のスクロール状態 */
    HBPageViewModeViewPort		/*!< ビューポート拡大表示 */
} HBPageViewMode;

/*!
 ページのレイアウト
 */
typedef enum
{
    HBPageLayoutTypeSinglePageFullscreen = 0,	/*!< 単ページ表示 + フルスクリーン　（上下左右余白なしでいっぱいまで広げる） */
    HBPageLayoutTypeSinglePagePaper,			/*!< 単ページ表示 + ページ全体を表示 */
    HBPageLayoutTypeSinglePageScroll,			/*!< 単ページ表示 + 縦スクロール (OMFの縦スクロール) */
    HBPageLayoutTypeDoublePageFullScreen,		/*!< 見開き表示 + フルスクリーン　（上下左右余白なしでいっぱいまで広げる） */
    HBPageLayoutTypeDoublePagePaper,			/*!< 見開き表示 + ページ全体を表示 */
    HBPageLayoutTypeDoublePageScroll			/*!< 見開き表示 + 横スクロール　(OMFの横スクロール)  */
} HBPageLayoutType;

/*!
 ビューアクション
 */
typedef enum
{
    HBViewTouchActionNone = 0,			/*!< 何もしない */
    HBViewTouchActionSelectLink,		/*!< リンクのタップ */
    HBViewTouchActionSelectAnnotation,	/*!< アノテーションのタップ */
    HBViewTouchActionSelectText,		/*!< テキスト選択 */
    HBViewTouchActionCancelSelectText,	/*!< テキスト選択の解除 */
    HBViewTouchActionNextPage,			/*!< 次のページに移動する */
    HBViewTouchActionNextViewport,		/*!< 次のビューポートに移動する */
    HBViewTouchActionPrevPage,			/*!< 前のページに移動する */
    HBViewTouchActionPrevViewport,		/*!< 前のビューポートに移動する */
    HBViewTouchActionZoomViewport,		/*!< ビューポートへ拡大 */
    HBViewTouchActionZoomFreeScroll,	/*!< フリースクロールへ拡大 */
    HBViewTouchActionZoomCancel,		/*!< ビューポート,フリースクロールをキャンセル */
    HBViewTouchActionScroll,			/*!< スクロール */
    HBViewTouchActionLayoutDouble,		/*!< レイアウト変更 単ページから見開きへ (OMFのみ) */
    HBViewTouchActionLayoutSingle		/*!< レイアウト変更 見開きから単ページ表示へ (OMFのみ) */
} HBViewTouchAction;

/*!
 書籍の読み込み状況
 */
typedef enum
{
    HBProgressTypeReflow = 0,	/*!< 非同期リフロー処理中 */
    HBProgressTypeProgressive	/*!< プログレッシブ再生ダウンロード継続中 */
} HBProgressType;

/*!
 左右上下の情報
 */
typedef enum
{
    HBDirectionCenter = 0,	/*!< 中心 */
    HBDirectionLeft,		/*!< 左 */
    HBDirectionRight,		/*!< 右 */
    HBDirectionTop,			/*!< 上 */
    HBDirectionBottom		/*!< 下 */
} HBDirection;

/*!
 HBPageViewFomeインスタンスがサポート可能な機能に関する情報
*/
typedef enum
{
	HBSupportedFunctionNone	= 0,										/*!< 設定値なし */
    HBSupportedFunctionHBLayoutTypeSinglepagePaper         = 1 << 0,	/*!< ページレイアウトとしてHBLayoutTypeSinglepagePaperが選択できるか否か */
    HBSupportedFunctionHBLayoutTypeSinglepageFullscreen    = 1 << 1,	/*!< ページレイアウトとしてHBLayoutTypeSinglepageFullscreenが選択できるか否か */
    HBSupportedFunctionHBLayoutTypeDoublepagePaper         = 1 << 2,	/*!< ページレイアウトとしてHBLayoutTypeDoublepagePaperが選択できるか否か */
    HBSupportedFunctionHBLayoutTypeDoublepageFullscreen    = 1 << 3,	/*!< ページレイアウトとしてHBLayoutTypeDoublepageFullscreenが選択できるか否か */
    HBSupportedFunctionHBLayoutTypeSinglepageScroll        = 1 << 4,	/*!< ページレイアウトとしてHBLayoutTypeSinglepageScrollが選択できるか否か */
    HBSupportedFunctionHBLayoutTypeDoublepageScroll        = 1 << 5,	/*!< ページレイアウトとしてHBLayoutTypeDoublepageScrollが選択できるか否か */
    HBSupportedFunctionHBShadowModeNone                    = 1 << 6,	/*!< 影のタイプとしてHBShadowTypeNoneが選択できるか否か */
    HBSupportedFunctionHBShadowModeInner                   = 1 << 7,	/*!< 影のタイプとしてHBShadowTypeInnerが選択できるか否か */
    HBSupportedFunctionHBShadowModeDrop                    = 1 << 8,	/*!< 影のタイプとしてHBShadowTypeDropが選択できるか否か */
    HBSupportedFunctionSearch                            = 1 << 9,		/*!< 検索機能が機能するか否か */
    HBSupportedFunctionTracezoom                         = 1 << 10,		/*!< トレースズームが利用出来るか否か */
    HBSupportedFunctionReflow                            = 1 << 11,		/*!< フォントスケール設定が機能するか否か */
    HBSupportedFunctionBinding                           = 1 << 12,		/*!< 綴じ方向変更機能が機能するか否か */
    HBSupportedFunctionBookIndex                         = 1 << 13,		/*!< 目次が利用出来るか否か */
    HBSupportedFunctionHBTransitionTypeNone             = 1 << 14,		/*!< ページ送り効果HBTransitionTypePageNoneが機能するか否か */
    HBSupportedFunctionHBTransitionTypeCurl             = 1 << 15,		/*!< ページ送り効果HBTransitionTypePageCurlが機能するか否か */
    HBSupportedFunctionHBTransitionTypeSlide            = 1 << 16		/*!< ページ送り効果HBTransitionTypePageSlideが選択出来るか否か */
} HBSupportedFunction;

/*!
 書籍オープン時のアニメーションの形式
*/
typedef enum
{
    HBCoverAnimationNone = 0,	/*!< 表示無し */
    HBCoverAnimationCover,		/*!< カバー表示のみ */
    HBCoverAnimationCoverFlip	/*!< カバー表示し読み込み完了後にはカバーをフリップでオープン */
} HBCoverAnimationType;

/*!
 書籍の形式
 */
typedef enum
{
    HBBookTypeFixed = 0,	/*!< コミック、写真集などの固定レイアウト */
    HBBookTypeReflow		/*!< 小説、文字ものなどのリフロー型レイアウト */
} HBBookType;

}

#endif /* HBPARAM_H_ */
