#ifndef _MYHONDANA_DOWNLOAD_FORM_H_
#define _MYHONDANA_DOWNLOAD_FORM_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include "GlobalDefine.h"
#include "DownloadPopup.h"

class MyHondanaDownloadForm
	: public Tizen::Ui::Controls::Form
	, public Tizen::Ui::IActionEventListener
	, public Tizen::Ui::IOrientationEventListener
	, public Tizen::Ui::Controls::IFormBackEventListener
	, public Tizen::Ui::Controls::IFormMenuEventListener
	, public Tizen::Ui::Scenes::ISceneEventListener
	// List View
	, public Tizen::Ui::Controls::IListViewItemEventListener
	, public Tizen::Ui::Controls::IListViewItemProvider
	// Download Popup Listener
	, public IDownloadPopupListener

{
public:
	MyHondanaDownloadForm(void);
	virtual ~MyHondanaDownloadForm(void);
	bool Initialize(void);
	void LoadBitmapFiles(void);

	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);
	virtual void OnFormBackRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnFormMenuRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnOrientationChanged(const Tizen::Ui::Control &source, Tizen::Ui::OrientationStatus orientationStatus);

	virtual void OnSceneDeactivated(const Tizen::Ui::Scenes::SceneId& currentSceneId, const Tizen::Ui::Scenes::SceneId& nextSceneId);
	virtual void OnSceneActivatedN(const Tizen::Ui::Scenes::SceneId& previousSceneId, const Tizen::Ui::Scenes::SceneId& currentSceneId, Tizen::Base::Collection::IList* pArgs);

	//IListViewItemEventListener
	virtual void OnListViewContextItemStateChanged(Tizen::Ui::Controls::ListView &listView, int index, int elementId, Tizen::Ui::Controls::ListContextItemStatus state);
	virtual void OnListViewItemStateChanged(Tizen::Ui::Controls::ListView &listView, int index, int elementId, Tizen::Ui::Controls::ListItemStatus status);
	virtual void OnListViewItemSwept(Tizen::Ui::Controls::ListView &listView, int index, Tizen::Ui::Controls::SweepDirection direction);
	virtual void OnListViewItemLongPressed(Tizen::Ui::Controls::ListView &listView, int index, int elementId, bool& invokeListViewItemCallback);

	//IListViewItemProvider
	virtual Tizen::Ui::Controls::ListItemBase* CreateItem (int index, int itemWidth);
	virtual bool  DeleteItem (int index, Tizen::Ui::Controls::ListItemBase *pItem, int itemWidth);

	virtual void OnDownloadPopupSelected(int selectIdx);
	virtual int GetItemCount(void);

private:
	void InitHeader(void);
	void SetFooter(void);
	void SetSplitPanel(void);
	void ShowListView(void);
	void SetButton(void);
	void DownloadPopupShow(void);

private:
	Tizen::Ui::Controls::ScrollPanel* __pDownloadBackgroundPanel;
	Tizen::Ui::Controls::Panel* __pDownloadBackgroundPanel_Bottom;
	Tizen::Ui::Controls::ScrollPanel* __pDownloadBackgroundPanel_Landscape;
	Tizen::Ui::Controls::Panel* __pDownloadBackgroundPanel_Bottom_Landscape;

	Tizen::Ui::Controls::ListView* __pListView;
	Tizen::Ui::Controls::Label* __pFileSizeLabel;
	Tizen::Ui::Controls::Label* __pFileSizeLabel2;
	Tizen::Ui::Controls::Button* __pCancelButton;
	Tizen::Ui::Controls::Button* __pDownloadButton;
	Tizen::Ui::Controls::ListView* __pListView_Landscape;
	Tizen::Ui::Controls::Label* __pFileSizeLabel_Landscape;
	Tizen::Ui::Controls::Button* __pCancelButton_Landscape;
	Tizen::Ui::Controls::Button* __pDownloadButton_Landscape;

//	Rectangle checkImageRect;

	Tizen::Graphics::Bitmap* __pCover;
	Tizen::Graphics::Bitmap* __pBook;
	Tizen::Graphics::Bitmap* __pListNewBook;
	Tizen::Graphics::Bitmap* __pGridNewBook;
	Tizen::Graphics::Bitmap* __pListBottomText;
	Tizen::Graphics::Bitmap* __pGridBottomText;
	Tizen::Graphics::Bitmap* __pHeaderBackground;

	Tizen::Graphics::Bitmap* __pCheckImage[2];
	Tizen::Graphics::Bitmap* __pUncheckImage[2];

	const int LIST_VIEW_MAIN_MENU_COUNT = 20;
	Tizen::Ui::Controls::ListItemBase* __pItem[20];

	static const int ID_FORMAT_NULL = -1;
	static const int ID_FORMAT_STRING = 500;
	static const int ID_FORMAT_STRING2 = ID_FORMAT_STRING + 0x01;
	static const int ID_FORMAT_STRING3 = ID_FORMAT_STRING + 0x02;
	static const int ID_FORMAT_STRING4 = ID_FORMAT_STRING + 0x03;
	static const int ID_FORMAT_STRING5 = ID_FORMAT_STRING + 0x04;
	static const int ID_FORMAT_BITMAP = ID_FORMAT_STRING + 3;
	static const int ID_FORMAT_BITMAP2 = ID_FORMAT_STRING + 4;
	static const int ID_FORMAT_BITMAP3 = ID_FORMAT_STRING + 5;
	static const int ID_FORMAT_CHECKIMAGE = ID_FORMAT_STRING + 6;

public:
	static const RequestId REQUEST_ID_SEND = 0;
	void DownloadCheckPopupHide(void);
	Tizen::Ui::Controls::Popup* __pDownloadCheckPopup;

	DownloadPopup* __pDownloadPopup;
};

#endif	//_MYHONDANA_DOWNLOAD_FORM_H_
