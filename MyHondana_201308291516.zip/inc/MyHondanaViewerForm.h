
#ifndef _MYHONDANAVIEWERFORM_H_
#define _MYHONDANAVIEWERFORM_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include "AnimationBaseForm.h"
//#include "HBAnnotation.h"
//#include "HBBookIndex.h"
//#include "HBPageLayout.h"
//#include "HBParam.h"
//#include "HBReader.h"
//#include "HyBookViewerCore.h"

using namespace Tizen::Graphics;

class MyHondanaViewerForm
	: public Tizen::Ui::IOrientationEventListener
	, public Tizen::Ui::Controls::IFormMenuEventListener
	, public Tizen::Ui::Scenes::ISceneEventListener
	, public Tizen::Ui::IAdjustmentEventListener
	, public Tizen::Ui::Controls::ISliderEventListener
	, public AnimationBaseForm
    , public Tizen::Ui::Controls::IGalleryItemProvider
    , public Tizen::Ui::Controls::IGalleryEventListener
//    , public HyBook::HBPageViewForm

{
public:
	MyHondanaViewerForm(void);
	virtual ~MyHondanaViewerForm(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);
	virtual result Play(void);
	void GetBitmap(void);

	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);
	virtual void OnFormBackRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnFormMenuRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnOrientationChanged(const Tizen::Ui::Control &source, Tizen::Ui::OrientationStatus orientationStatus);
	virtual void OnSceneDeactivated(const Tizen::Ui::Scenes::SceneId& currentSceneId, const Tizen::Ui::Scenes::SceneId& nextSceneId);
	virtual void OnSceneActivatedN(const Tizen::Ui::Scenes::SceneId& previousSceneId, const Tizen::Ui::Scenes::SceneId& currentSceneId, Tizen::Base::Collection::IList* pArgs);
	virtual void OnSliderBarMoved(Tizen::Ui::Controls::Slider& source, int value);
	virtual void OnAdjustmentValueChanged(const Tizen::Ui::Control& source, int adjustment);
	virtual void OnUserEventReceivedN(RequestId requestId, Tizen::Base::Collection::IList *pArgs);

	virtual Tizen::Ui::Controls::GalleryItem* CreateItem(int index);
	virtual bool DeleteItem(int index, Tizen::Ui::Controls::GalleryItem* pItem);
	virtual int GetItemCount(void);

	virtual void OnGallerySlideShowStarted(Tizen::Ui::Controls::Gallery& gallery);
	virtual void OnGallerySlideShowStopped(Tizen::Ui::Controls::Gallery& gallery);
	virtual void OnGalleryItemClicked(Tizen::Ui::Controls::Gallery& gallery, int itemIndex);
	virtual void OnGalleryCurrentItemChanged(Tizen::Ui::Controls::Gallery& gallery, int currentItemIndex);

//	//HBPageView
//	virtual HyBook::HBBookType BookType();
//	virtual HyBook::HBSupportedFunction SupportedFunction();
//	virtual bool maskTransparency(void);
//	virtual HyBook::HBTransitionType TransitionType();
//	virtual int searchPrev(void);
//	virtual void maskTransparency(bool flag);
//	virtual void cancelSearch(void);
//	virtual void TransitionType(HyBook::HBTransitionType transittionType);
//	virtual int searchNext(void);
//	virtual int searchText(std::string text);
//	virtual void ShadowType(HyBook::HBShadowType shadowType);
//	virtual HyBook::HBShadowType ShadowType();
//	virtual void cancelTextSelection(void);
//	virtual void AnnotationList(HyBook::HBAnnotationList annotationList);
//	virtual HyBook::HBPageLayout PageLayout();
//	virtual void setListner(HyBook::IHBPageViewFormListner* listner);
//	virtual HyBook::HBAnnotationList AnnotationList(void);
//	virtual void PageLayout(HyBook::HBPageLayout layout);
//	virtual HyBook::HBBookIndexList BookIndexList(void);
//	virtual bool navigationPageWithAnnotation(HyBook::HBAnnotation* bookmark);
//	virtual bool navigationPageWithBookIndex(HyBook::HBBookIndex* bookIndex);
//	virtual bool navigationPage(int pageIndex);
//	virtual bool prevPage(void);
//	virtual bool nextPage(void);

private:
	void SetHeader(void);

	void SetBackgroundPanel(void);
	void SetControl(void);
	void SetButton(void);
	void ShowMessageBox(void);

	Tizen::Ui::Controls::OverlayPanel* __pOverlayPanel_Menu;
	Tizen::Ui::Controls::OverlayPanel* __pOverlayPanel_Title;
	Tizen::Ui::Controls::Gallery* __pGallery;

	// OverlayPanel Control
	Tizen::Ui::Controls::Button* __pButton_Market;
	Tizen::Ui::Controls::Label* __pLabel_Title_Background;

	Tizen::Ui::Controls::Label* __pLabel_Slider_Background;
	Tizen::Ui::Controls::Label* __pLabel_CurrentPage;
	Tizen::Ui::Controls::Label* __pLabel_Divider;
	Tizen::Ui::Controls::Label* __pLabel_TotalPage;
	Tizen::Ui::Controls::Slider* __pSlider;
	Tizen::Ui::Controls::Button* __pButton_Move;
	Tizen::Ui::Controls::Button* __pButton_Next;
	Tizen::Ui::Controls::Button* __pButton_Setting;
	Tizen::Ui::Controls::Button* __pButton_Help;
	Tizen::Ui::Controls::Button* __pButton_Bookmark;

	Bitmap* __pBookmark[2];

	// Toast Popup
	Tizen::Ui::Controls::Label* __pLabel_Toast_CurrentPage;
	Tizen::Ui::Controls::Label* __pLabel_Toast_Divider;
	Tizen::Ui::Controls::Label* __pLabel_Toast_TotalPage;

	bool __isVisible;
	int bookTotalPage = 10;
	int bookmarkPage[10];
	bool isFirstStart = true;
	bool chkBookmark = false;

private:
	static const int ID_BUTTON_MARKET = 1000;
	static const int ID_BUTTON_MOVE = 1001;
	static const int ID_BUTTON_NEXT = 1002;
	static const int ID_BUTTON_SETTING = 1003;
	static const int ID_BUTTON_HELP = 1004;
	static const int ID_BUTTON_BOOKMARK = 1005;


public:
	void BookmarkPage(void);
	int __transactionId;
};

#endif
