/*
 * MyBookShelfBookData.h
 *
 *  Created on: Aug 9, 2013
 *      Author: Administrator
 */

#ifndef RESMETAINFO_H_
#define RESMETAINFO_H_
#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FWebJson.h>
#include <vector>
#include "GlobalDefine.h"
using namespace std;
using namespace Tizen::Base;

typedef struct _meta_info_detail_info : public Object
{
	String item_id; 				   // 1 	
	String purchase_target_device_type;// 2
	String item_no; 				   // 3
	String item_nm; 				   // 4
	String file_name;				   // 5
	String file_size;				   // 6
	String book_format_id;			   // 7
	String dl_limit_dt; 			   // 8
	String item_type;				   // 9
	String settlement_dt;			   // 10
	String del_flag;				   // 11
}meta_info_detail_info_t; 
	
typedef struct _meta_info_datalist : public Object
{
	String title_id;                  // 1
	String last_target_device_type;   // 2
	String title_nm;                  // 3
	String title_kana;                // 4
	String v_cnt;                     // 5
	String c_cnt;                     // 6
	String book_type;                 // 7
	String new_item_id;               // 8
	String release_dt;                // 9
	String buy_check_flg;             // 10
	String author_nm;                 // 11
	String author_kana;               // 12 
	vector<meta_info_detail_info_t *> detail_info;
}meta_info_datalist_t; 

class cres_meta_info
{
private:
public:
	String Result;
	String access_dt;
	String table_flg;
	String total_count;
	String offset;
	vector<meta_info_datalist_t *> datalist;
private:
public:
	meta_info_datalist_t * getDatalist(String * title_id);	
	meta_info_datalist_t * getDatalist(int index);
	meta_info_datalist_t * getNewDatalist();	
	inline void clearDatalist(){datalist.clear();}

	meta_info_detail_info_t * getDetailInfo(meta_info_datalist_t * datalist, String * item_id);
	meta_info_detail_info_t * getDetailInfo(meta_info_datalist_t * datalist, int index);
	meta_info_detail_info_t * getNewDetailInfo(meta_info_datalist_t * datalist);
	inline void clearDetailInfo(meta_info_datalist_t * datalist){datalist->detail_info.clear();}
};

#endif /* MYBOOKSHELFMETAINFO_H_ */
