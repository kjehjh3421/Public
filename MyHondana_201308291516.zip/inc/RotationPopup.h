#ifndef _ROTATIONPOPUP_H_
#define _ROTATIONPOPUP_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FSystem.h>

using namespace Tizen::Graphics;

const int ID_SCREEN_ROTATION_AUTO_ENABLED = 139;
const int ID_SCREEN_ROTATION_AUTO_DISABLED = 239;

class IRotationPopupListener
{
public:
	virtual ~IRotationPopupListener() {}

	virtual void OnRotationPopupSelected(int selectIdx) = 0;
};

class RotationPopup
	: public Tizen::Ui::Controls::Popup
	, public Tizen::Ui::IPropagatedKeyEventListener
	, public Tizen::Ui::IActionEventListener
	, public Tizen::System::IScreenEventListener
	, public Tizen::System::ISettingEventListener
	, public Tizen::System::ISettingInfoSetValueAsyncResultListener
{
private:
	IRotationPopupListener* __pListener;

public:
	RotationPopup(void);
	RotationPopup(IRotationPopupListener * pListener);
	virtual ~RotationPopup(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	void ShowPopup(void);
	void HidePopup(void);
	void SetControl(void);
	void ControlSetting(void);
	void InitializeValue(void);

	void FirstStart(void);
	virtual bool OnKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool TranslateKeyEventInfo(Tizen::Ui::Control& source, Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);

	// IScreenEventListener
	virtual void OnScreenOn(void);
	virtual void OnScreenOff(void);
	virtual void OnScreenBacklightChanged(int brightness);

	//ISettingEventLisetener
	virtual void OnSettingChanged(Tizen::Base::String& key);

	virtual void OnResultReceivedForSetValueAsync(const Tizen::Base::String& key, result r);


	Tizen::Ui::Controls::Label* __pRotation_Description_Label;

	Tizen::Ui::Controls::CheckButton* __pRotation_CheckButton_Enabled;
	Tizen::Ui::Controls::CheckButton* __pRotation_CheckButton_Disabled;

	Tizen::Ui::Controls::Button* __pRotation_Cancel_Button;
	Tizen::Ui::Controls::Button* __pRotation_Ok_Button;;

	static const int ID_ROTATION_CANCEL_BUTTON = 1000;
	static const int ID_ROTATION_SET_BUTTON = 1001;
};

#endif // _ROTATIONPOPUP_H_
