/*
 * HBPageVoewForm.h
 *
 *  Created on: Jul 29, 2013
 *      Author: Hideki OCHI
 */

#ifndef HBPAGEVIEWFORM_H_
#define HBPAGEVIEWFORM_H_

#include <FUiCtrlForm.h>
#include "HBAnnotation.h"
#include "HBBookIndex.h"
#include "HBPageLayout.h"
#include <vector>

namespace HyBook {
/*!
 * HBPageViewFormからのイベントを受けるリスナー
 *
 * HBPageViewForm::setListerに本インスタンスを登録することにより
 * イベント発生時に該当メソッドが呼び出される。
 * @note イベントを受信したいクラスは本クラスを継承すること。
 */
class IHBPageViewFormListner
{
public:
	virtual ~IHBPageViewFormListner()
	{
	}

	/*! @name ビューアの状態遷移により発生するイベント */

	/*!
	 ビューアがページ移動を完了した時に呼び出されます。
	  @param pageIndexes 表示中のページ番号が含まれたvector
	  見開き表示時は左右両ページ分格納される
	 */
	virtual void onPageViewChangePage(std::vector<int> pageIndexes) = 0;

	/*!
	 回転時など、ビューのサイズが変更された時に呼び出される。
	 @param width 変更後の幅
	 @param height 変更後の高さ
	*/
	virtual void onPageViewChangeSize(float width, float height) = 0;

	/*!
	 ビューモードが変化した時に呼び出される
	 @param mode ビューモード
	 */
	virtual void onPageViewChangeViewMode(HBPageViewMode mode) = 0;


	/*! @name ゼスチャイベント（falseを返す事で規定動作をキャンセルできます） */

	/*! タップ操作による動作を行う前に呼び出します。
	 @param action 操作による規定の動作アクション
	 @param pointX タッチ位置のX座標
	 @param pointY タッチ位置のY座標
	 @return true：デフォルト動作を継続　false:デフォルト動作を殺す
	 */
		virtual bool onPageViewTap(HBViewTouchAction action, float pointX, float pointY) = 0;

	/*! ダブルタップ操作による動作を行う前に呼び出します。
	 @param action 操作による規定の動作アクション
	 @param pointX タッチ位置のX座標
	 @param pointY タッチ位置のY座標
	 @return true：デフォルト動作を継続　false:デフォルト動作を殺す
	 */
	virtual bool onPageViewDoubleTap(HBViewTouchAction action, float pointX, float pointY) = 0;

	/*! ドラッグ操作による動作を行う前に呼び出します。
	 @param action 操作による規定の動作アクション
	 @param direction ドラッグの方向
	 @param pointX タッチ位置のX座標
	 @param pointY タッチ位置のY座標
	 @return true：デフォルト動作を継続　false:デフォルト動作を殺す
	 */
	virtual bool onPageViewDrag(HBViewTouchAction action, int direction, float pointX, float pointY) = 0;

	/*! ピンチ操作による動作を行う前に呼び出します。
	 @param action 操作による規定の動作アクション
	 @param pointX タッチ位置のX座標
 	 @param pointY タッチ位置のY座標
	 @return true：デフォルト動作を継続　false:デフォルト動作を殺す
	 */
	virtual bool onPageViewPinch(HBViewTouchAction action, float pointX, float pointY) = 0;

	/*! ロングタップ操作による動作を行う前に呼び出します。
	 @param action 操作による規定の動作アクション
	 @param pointX タッチ位置のX座標
	 @param pointY タッチ位置のY座標
	 @return true：デフォルト動作を継続　false:デフォルト動作を殺す
	 */
	virtual bool onPageViewLongTap(HBViewTouchAction action, float pointX, float pointY) = 0;

	/*! @name 表示位置の変更時に発生するイベント */

	/*! ビューアがビューポート移動を完了した時に呼び出されます。
	 @param pageIndex ページインデックス
	 @param viewportIndex ビューポートインデックス
	 */
	virtual void onPageViewChangeViewportWithPageIndex(int pageIndex, int viewportIndex) = 0;


	/*! ビューアが最後のページより後に移動しようとしたときに呼び出されます。*/
	virtual void onPageViewForwardOver() = 0;
	/*! ビューアが最初のページより前に移動しようとしたときに呼び出されます。*/
	virtual void onPageViewRewindOver() = 0;

	/*! @name リフロー関連のイベント */

	/*! ビューアがリフローを開始した時に呼び出されます。
	 */
	virtual void onPageViewReflowStart() = 0;

	/*! ビューアが非同期処理中のページに移動しようとしたときに呼び出されます。*/
	virtual void onPageViewLoadingOver() = 0;

	/*! ビューアが書籍のリフローを完了、もしくはダウンロードを完了した時に呼び出されます。
	 @param supportedFunction このビューアインスタンスとコンテンツの組み合わせでサポートされる機能情報
	 @param totalPage 合計ページ
	 */
	virtual void onPageViewReflowComplete(HBSupportedFunction supportedFunction, int totalPage) = 0;

	/*! ビューアがページ表示に必要な段階までリフローを完了した時に呼び出されます。
	 @param supportedFunction このビューアインスタンスとコンテンツの組み合わせでサポートされる機能情報
	 @param progressType 継続中の非同期オペレーションタイプ
	 @param totalPage 合計ページ
	 */
	virtual void onPageViewReflowProvisional(HBSupportedFunction supportedFunction, HBProgressType progressType, int totalPage) = 0;

	/*!
	 プログレッシブダウンロードの進捗状況を通知する
	 @param progress ダウンロード進捗状況
	 @warning このメソッドは準備中です。
	 */
	virtual void onPageViewReflowUpdate(float progress) = 0;

	/*! @name フリークロール中に発生するイベント */

	/*! フリースクロール操作でページの端が表示されているか否かを HBCommonDefine.Directionで通知する。
	 @param edge 方向
	 */
	virtual void onPageViewScrollEdge(HBDirection edge) = 0;

	/*! @name ビューア機能実行時に発行されるイベント */

	/*! ビューア内でアノテーションをタップした時に呼び出されます。
	 @param index ページ内でタップされて位置のアノテーションの配列のインデックス
	 */
	virtual void onPageViewSelectAnnotation(int index) = 0;

	/*! ビューア内で外部リンクをタップした時に呼び出されます。
	 @param url ページ内でタップされた位置がクリッカブルだった場合のURL文字列
	 */
	virtual void onPageViewSelectLink(std::string url) = 0;

	/*! ビューア内で文字を選択した時に呼び出されます。
	 @param text 選択中の文字列
	 @param startCharIndex 選択文字列の先頭の文字インデックス
	 @param endCharIndex 選択文字列の最後の文字インデックス
	 @param pointX タッチ位置のX座標
	 @param pointY タッチ位置のY座標
	 */
	virtual void onPageViewSelectText(std::string text, int64_t startCharIndex, int64_t endCharIndex,  float pointX, float pointY) = 0;

	/*! ピンチ操作により拡大率が変わった場合に呼び出される。
	 @param scale 現在のスケール
	 */
	virtual void onPageViewZoom(float scale) = 0;

	/*! @name エラーイベント */

	/*! 例外が発生した場合に呼び出されます。
	 @param errorCode エラーの内容
	 */
	virtual void onPageViewError(int errorCode) = 0;
};

/*!
 * ページ版面を表示するUIコントロール
 *
 * このクラスは仮想クラスであり、OMF用、テキスト用等、コンテンツの種類により実装が別れる。
 * HBFactory::instanceHBPageViewFormでコンテンツに適合したインスタンスを生成する。
 */
class HBPageViewForm: public Tizen::Ui::Controls::Form {
public:
	virtual ~HBPageViewForm()
	{
	}

	/// @name リスナーの登録
	/*! リスナーインスタンスを登録する
	 * @param listner IHBPageViewFormListnerを継承したクラスへのポインタ。NULLの場合は登録を解除する
	 * @attention 登録したクラスはHBPageViewForm内では解放されない。また、登録したクラスを解放する際には、先に本メソッドにNULLを渡して登録を解除しておくこと。
	 */
	virtual void setListner(IHBPageViewFormListner* listner) = 0;

	/// @name レンダリングレイアウトの設定・取得
	/*! レンダリングレイアウトを設定する
	 * @param layout パラメートをセットしたHBPageLayout構造体
	 */
	virtual void PageLayout(HBPageLayout layout) = 0;
	/*! 現在のレンダリングレイアウトを取得する
	 * @return 現在設定されているHBPageLayout構造体
	 */
	virtual HBPageLayout PageLayout() = 0;

	/// @name ページ陰影表現の設定・取得
	/*! ページ陰影表現を設定する
	 * @param shadowType 設定する陰影表現のスタイル
	 */
	virtual void ShadowType(HBShadowType shadowType) = 0;
	/*! 現在のページ陰影表現を取得する
	 * @return 現在設定されている陰影表現のスタイル
	 */
	virtual HBShadowType ShadowType() = 0;

	/// @name ページ送りエフェクトの設定・取得
	/*! ページ送りエフェクトを設定する
	 * @param transittionType 設定するページ送りエフェクト
	 */
	virtual void TransitionType(HBTransitionType transittionType) = 0;
	/*! 現在のページ送りエフェクトを取得する
	 * @return 現在設定されているページ送りエフェクト
	 */
	virtual HBTransitionType TransitionType() = 0;

	/// @name トレースズームスタイルの設定・取得（HyCでのみ動作）
	/*! トレースズームのコマ外のマスク部分を透過にするか設定する
	 * @param flag trueで透過。falseで非透過（黒）。
	 */
	virtual void maskTransparency(bool flag) = 0;
	/*! 現在のトレースズームのコマ外の透過設定を取得する
     * @return trueが返った場合は透過。falseが返った場合は非透過（黒）。
	 */
	virtual bool maskTransparency(void) = 0;

	/// @name インスタンスの状態取得
	/*! ビューワがサポートする機能を取得する
	 * @return サポートする機能がビットマスクされたHBSupportedFunction
	 */
	virtual HBSupportedFunction SupportedFunction() = 0;

	/*! 書籍の形式（リフロー/固定レイアウト
	 * @return HBBookTypeReflowが返った場合はリフロー型。HBBookTypeFixedが返った場合は固定レイアウト。
	 */
	virtual HBBookType BookType() = 0;

	/// @name ページ移動に関する項目
	/*!
	 * 次のページを表示する。
	 *
	 * @return 次のページがないときはfalse
	 */
	virtual bool nextPage(void) = 0;

	/*!
	 * 前のページを表示する。
	 *
	 * @return 前のページがないときはfalse
	 */
	virtual bool prevPage(void) = 0;

	/*!
	 * 指定したページを表示する。
	 *
	 * @param pageIndex ページ番号
	 * @return 遷移できない番号を指定した場合NO
	 *
	 */
	virtual bool navigationPage(int pageIndex) = 0;

	/*!
	 * 指定したページを表示する。
	 *
	 * @param bookIndex 目次データそのもの
	 *
	 */
	virtual bool navigationPageWithBookIndex(HBBookIndex* bookIndex) = 0;

	/*!
	 * 指定したページを表示する。
	 *
	 * @param bookmark ブックマークデータそのもの
	 *
	 */
	virtual bool navigationPageWithAnnotation(HBAnnotation* bookmark) = 0;

	/// @name 目次とアノテーション
	/*!
	 * 目次リストを取得する
	 * @return HBBookIndexが格納されたvector(HBBookIndexList型)
	 */
	virtual HBBookIndexList BookIndexList(void) = 0;

	/*!
	 * アノテーションのリストを取得する
	 * @return  HBAnnotationが格納されたvector(HBAnnotationList型)
	 */
	virtual HBAnnotationList AnnotationList(void) = 0;

	/*!
	 * アノテーションのリストを設定する
	 *
	 * アノテーションを設定すると、該当文字列がマークされるようになる。
	 * 設定後、直ぐに版面が書き直される。
	 * @param annotationList HBAnnotationが格納されたvector(HBAnnotationList型)
	 */
	virtual void AnnotationList(HBAnnotationList annotationList) = 0;

	/// @name テキスト関連の操作項目
	/*!
	 テキスト選択ハイライトを消去する
	 */
	virtual void cancelTextSelection(void) = 0;

	/*!
	 現在表示中のページを起点に検索を開始する
	 @param text 検索する文字列
	 @return pageIndex：検索がヒットした直近のページ。見つからない場合は-1
	 */
	virtual int searchText(std::string text) = 0;

	/*!
	 現在表示中のページを起点に次の検索文字列を探す
	 コンテンツの終端まで検索し見つからない場合は、先頭から検索される
	 @return pageIndex：検索がヒットした直近のページ
	 */
	virtual int searchNext(void) = 0;

	/*!
	 現在表示中のページを起点に前の検索文字列を探す
	 コンテンツの先頭まで検索し見つからない場合は、終端から検索される
	 @return pageIndex：検索がヒットした直近のページ
	 */
	virtual int searchPrev(void) = 0;

	/*!
	 検索をキャンセルする
	 */
	virtual void cancelSearch(void) = 0;
};

} /* namespace HyBook */
#endif /* HBPAGEVIEWFORM_H_ */
