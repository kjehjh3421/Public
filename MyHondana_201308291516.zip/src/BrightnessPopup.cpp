
#include "BrightnessPopup.h"
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "SceneRegister.h"
#include "MyHondanaSettingForm.h"
#include "AppResourceId.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::System;

BrightnessPopup::BrightnessPopup(void)
{
}

BrightnessPopup::BrightnessPopup(IBrightnessPopupListener * pListener)
{
	__pListener = pListener;
}

BrightnessPopup::~BrightnessPopup(void)
{
}

bool
BrightnessPopup::Initialize(void)
{
	Construct(L"IDP_SETTING_BRIGHTNESS_POPUP");
	return true;
}

result
BrightnessPopup::OnInitializing(void)
{
	result r = E_SUCCESS;

	PowerManager::AddScreenEventListener(*((IScreenEventListener*) this));
	SetPropagatedKeyEventListener(this);

	if(isFirstStart==true)
	{
		SetControl();
		isFirstStart=false;
//		InitializeValue();
	}
	ControlSetting();
	return r;
}

result
BrightnessPopup::OnTerminating(void)
{
	result r = E_SUCCESS;

	return r;
}

void
BrightnessPopup::SetControl(void)
{
	__pBrightness_CheckButton = static_cast <CheckButton *>(GetControl(IDC_BRIGHTNESS_CHECKBUTTON, true));
	__pBrightness_Slider = static_cast <Slider *>(GetControl(IDC_BRIGHTNESS_SLIDER, true));

	__pBrightness_Ok_Button = static_cast <Button *>(GetControl(IDC_BRIGHTNESS_BUTTON_OK, true));
	__pBrightness_Cancel_Button = static_cast <Button *>(GetControl(IDC_BRIGHTNESS_BUTTON_CANCEL, true));
}

void
BrightnessPopup::ControlSetting(void)
{

	int appBrightness = -1;
	appBrightness = PowerManager::GetScreenBrightness();

	__pBrightness_CheckButton->SetActionId(ID_BRIGHTNESS_AUTOSET, ID_BRIGHTNESS_AUTOSET, ID_BRIGHTNESS_AUTOSET);
	__pBrightness_CheckButton->AddActionEventListener(*this);

	__pBrightness_Slider->SetValue(appBrightness);
	__pBrightness_Slider->AddAdjustmentEventListener(*this);
	__pBrightness_Slider->AddSliderEventListener(*this);

	__pBrightness_Cancel_Button->SetActionId(ID_BRIGHTNESS_CANCEL_BUTTON);
	__pBrightness_Cancel_Button->AddActionEventListener(*this);

	__pBrightness_Ok_Button->SetActionId(ID_BRIGHTNESS_OK_BUTTON);
	__pBrightness_Ok_Button->AddActionEventListener(*this);
}

void
BrightnessPopup::ShowPopup(void)
{
	SetShowState(true);
	Show();
}

void
BrightnessPopup::HidePopup(void)
{
	SetShowState(false);
	Invalidate(true);
}

void
BrightnessPopup::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	static int previousSliderValue=-1;
	switch (actionId)
	{
	case ID_BRIGHTNESS_AUTOSET:
		if (__pBrightness_CheckButton->IsSelected()==true)
		{
			PowerManager::RestoreScreenBrightness();
			__pBrightness_Slider->SetEnabled(false);
			previousSliderValue = __pBrightness_Slider->GetValue();
			int autoSetValue = 5;
			__pBrightness_Slider->SetValue(autoSetValue);
			PowerManager::SetScreenBrightness(autoSetValue);
		}
		else if (__pBrightness_CheckButton->IsSelected()==false)
		{
			__pBrightness_Slider->SetValue(previousSliderValue);
			PowerManager::SetScreenBrightness(__pBrightness_Slider->GetValue());
			__pBrightness_Slider->SetEnabled(true);
		}
		RequestRedraw(true);
		break;
	case ID_BRIGHTNESS_OK_BUTTON:
	{
		PowerManager::SetScreenBrightness(__pBrightness_Slider->GetValue());

		HidePopup();
	}
		break;
	case ID_BRIGHTNESS_CANCEL_BUTTON:
	{
		PowerManager::RestoreScreenBrightness();
		if (__pBrightness_CheckButton->IsSelected()==true)
		{
			__pBrightness_CheckButton->SetSelected(false);
			PowerManager::RestoreScreenBrightness();
			__pBrightness_Slider->SetEnabled(false);
			previousSliderValue = __pBrightness_Slider->GetValue();
			int autoSetValue = 5;
			__pBrightness_Slider->SetValue(autoSetValue);
			PowerManager::SetScreenBrightness(autoSetValue);
		}
		else if (__pBrightness_CheckButton->IsSelected()==false)
		{
			__pBrightness_Slider->SetValue(previousSliderValue);
			PowerManager::SetScreenBrightness(__pBrightness_Slider->GetValue());
			__pBrightness_Slider->SetEnabled(true);
		}
		HidePopup();
	}
		break;
	default:
		break;
	}
}

bool
BrightnessPopup::OnKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BrightnessPopup::OnKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	if ((keyEventInfo.GetKeyCode() == KEY_ESC ||keyEventInfo.GetKeyCode() == KEY_BACK) && source.GetShowState() == true)
	{
		source.SetShowState(false);
	}
	return false;
}

bool
BrightnessPopup::OnPreviewKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BrightnessPopup::OnPreviewKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BrightnessPopup::TranslateKeyEventInfo(Control& source, KeyEventInfo& keyEventInfo)
{
	return false;
}

void
BrightnessPopup::OnSliderBarMoved(Tizen::Ui::Controls::Slider& source, int value)
{
	PowerManager::SetScreenBrightness(value);
	Invalidate(true);
}

void
BrightnessPopup::OnAdjustmentValueChanged(const Tizen::Ui::Control& source, int adjustment)
{
	PowerManager::SetScreenBrightness(adjustment);
	Invalidate(true);
}

// IScreenEventListener
void
BrightnessPopup::OnScreenOn(void)
{

}
void
BrightnessPopup::OnScreenOff(void)
{
}

void
BrightnessPopup::OnScreenBrightnessChanged(int brightness)
{
}


