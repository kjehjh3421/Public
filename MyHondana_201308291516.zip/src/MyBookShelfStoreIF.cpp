/*
 * MyBookShelfStoreIF.cpp
 *
 *  Created on: Aug 13, 2013
 *      Author: Administrator
 */
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include <FSystem.h>
	 
#include "MyBookShelfStoreIF.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Graphics;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Media;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::Ui::Animations;
using namespace Tizen::Base::Collection;
using namespace Tizen::System;
using namespace Tizen::Io;

enum{
	status_usr_login,
	status_imei2_regist,
	status_imei2_update,
	status_imei2_check,
	status_bookshelf_sync,
	status_bookshelf_onesync,
	status_bookshelf_deleteitem,
	status_bookshelf_coverimage,
	status_bookshelf_firstitem,
	status_bookshelf_nextitem,
	status_purchase_status,
	status_item2_coverflow,
	status_item2_nobuylist,
	status_item2_itemname,
	status_download2_contents2,
	status_download2_rangedownload,
	status_download_complete,
	status_download_bsurl,
	status_download_share,
	status_download_delete,
	status_bookmark_share,
	status_bookmark_delete,
	status_bookmark_sync,
	status_advert_dispadvert,
	status_appstore2_url,
	status_appstore2_appver,
	status_item_detailurl,
	status_appstore_url,
	status_appstore_appver,
	status_idle,
	status_no_connection
};
#define site_count status_appstore_appver+1

String test_server_address[site_count]={
	L"http://stg.book.dmkt-sp.jp/api/usr/login",
	L"http://stg.book.dmkt-sp.jp/api/imei2/regist",
	L"http://stg.book.dmkt-sp.jp/api/imei2/update",
	L"http://stg.book.dmkt-sp.jp/api/imei2/check",
	L"http://stg.book.dmkt-sp.jp/api/bookshelf/sync",
	L"http://stg.book.dmkt-sp.jp/api/bookshelf/onesync",
	L"http://stg.book.dmkt-sp.jp/api/bookshelf/deleteitem",
	L"http://stg.book.dmkt-sp.jp/api/bookshelf/coverimage",
	L"http://stg.book.dmkt-sp.jp/api/bookshelf/firstitem",
	L"http://stg.book.dmkt-sp.jp/api/bookshelf/nextitem",
	L"http://stg.book.dmkt-sp.jp/api/purchase/status",
	L"http://stg.book.dmkt-sp.jp/api/item2/coverflow",
	L"http://stg.book.dmkt-sp.jp/api/item2/nobuylist",
	L"http://stg.book.dmkt-sp.jp/api/item2/itemname",
	L"http://stg.book.dmkt-sp.jp/api/download2/contents2",
	L"http://stg.book.dmkt-sp.jp/api/download2/rangedownload",
	L"http://stg.book.dmkt-sp.jp/api/download/complete",
	L"http://stg.book.dmkt-sp.jp/api/download/bsurl",
	L"http://stg.book.dmkt-sp.jp/api/download/share",
	L"http://stg.book.dmkt-sp.jp/api/download/delete",
	L"http://stg.book.dmkt-sp.jp/api/bookmark/share",
	L"http://stg.book.dmkt-sp.jp/api/bookmark/delete",
	L"http://stg.book.dmkt-sp.jp/api/bookmark/sync",
	L"http://stg.book.dmkt-sp.jp/api/advert/dispadvert",
	L"http://stg.book.dmkt-sp.jp/api/appstore2/url",
	L"http://stg.book.dmkt-sp.jp/api/appstore2/appver",
	L"http://stg.book.dmkt-sp.jp/api/item/detailurl",
	L"http://stg.book.dmkt-sp.jp/api/appstore/url",
	L"http://stg.book.dmkt-sp.jp/api/appstore/appver"
};

String real_server_address[site_count]={
	L"https://book.dmkt-sp.jp/api/usr/login",
	L"https://book.dmkt-sp.jp/api/imei2/regist",
	L"https://book.dmkt-sp.jp/api/imei2/update",
	L"https://book.dmkt-sp.jp/api/imei2/check",
	L"https://book.dmkt-sp.jp/api/bookshelf/sync",
	L"https://book.dmkt-sp.jp/api/bookshelf/onesync",
	L"https://book.dmkt-sp.jp/api/bookshelf/deleteitem",
	L"https://book.dmkt-sp.jp/api/bookshelf/coverimage",
	L"https://book.dmkt-sp.jp/api/bookshelf/firstitem",
	L"https://book.dmkt-sp.jp/api/bookshelf/nextitem",
	L"https://book.dmkt-sp.jp/api/purchase/status",
	L"https://book.dmkt-sp.jp/api/item2/coverflow",
	L"https://book.dmkt-sp.jp/api/item2/nobuylist",
	L"https://book.dmkt-sp.jp/api/item2/itemname",
	L"https://book.dmkt-sp.jp/api/download2/contents2",
	L"https://book.dmkt-sp.jp/api/download2/rangedownload",
	L"https://book.dmkt-sp.jp/api/download/complete",
	L"https://book.dmkt-sp.jp/api/download/bsurl",
	L"https://book.dmkt-sp.jp/api/download/share",
	L"https://book.dmkt-sp.jp/api/download/delete",
	L"https://book.dmkt-sp.jp/api/bookmark/share",
	L"https://book.dmkt-sp.jp/api/bookmark/delete",
	L"https://book.dmkt-sp.jp/api/bookmark/sync",
	L"https://book.dmkt-sp.jp/api/advert/dispadvert",
	L"https://book.dmkt-sp.jp/api/appstore2/url",
	L"https://book.dmkt-sp.jp/api/appstore2/appver",
	L"https://book.dmkt-sp.jp/api/item/detailurl",
	L"https://book.dmkt-sp.jp/api/appstore/url",
	L"https://book.dmkt-sp.jp/api/appstore/appver"
};

CMyBookShelfStoreIF::CMyBookShelfStoreIF()
{
	net_status         = status_no_connection;
	p_http_com_service = 0;
}

CMyBookShelfStoreIF::~CMyBookShelfStoreIF()
{
}

void CMyBookShelfStoreIF::OnResponseReceived(const String &responseStr)
{
	bool result;
	switch(net_status)
	{
		case status_usr_login:
			break;
		case status_imei2_regist:
			break;
		case status_imei2_update:
			break;
		case status_imei2_check:
			imei2_check_res(result);
			if(result)
				pctrl_caller->SendUserEvent(IMEI_CHECK_OK, NULL);
			else
				pctrl_caller->SendUserEvent(IMEI_CHECK_FAIL, NULL);
			break;		
		case status_bookshelf_sync:
			if(bookshelf_sync_res())
				pctrl_caller->SendUserEvent(RES_RECEIVE_OK, NULL);
			else
				pctrl_caller->SendUserEvent(RES_RECEIVE_FAIL, NULL);
			break;
		case status_bookshelf_onesync:
			break;
		case status_bookshelf_deleteitem:
			break;
		case status_bookshelf_coverimage:
			break;
		case status_bookshelf_firstitem:
			break;
		case status_bookshelf_nextitem:
			break;
		case status_purchase_status:
			break;
		case status_item2_coverflow:
			break;
		case status_item2_nobuylist:
			break;
		case status_item2_itemname:
			break;
		case status_download2_contents2:
			break;
		case status_download2_rangedownload:
			break;
		case status_download_complete:
			break;
		case status_download_bsurl:
			break;
		case status_download_share:
			break;
		case status_download_delete:
			break;
		case status_bookmark_share:
			break;
		case status_bookmark_delete:
			break;
		case status_bookmark_sync:
			break;
		case status_advert_dispadvert:
			break;
		case status_appstore2_url:
			break;
		case status_appstore2_appver:
			break;
		case status_item_detailurl:
			break;
		case status_appstore_url:
			break;
		case status_appstore_appver:
			break;

	}
}

bool CMyBookShelfStoreIF::initialize()
{
	bool ret = true;
	p_http_com_service =  new HttpCommunicationService(this);
	if(!p_http_com_service)
	{
		net_status = status_no_connection;
		ret = false;
	}
	
	MyHondanaApp * app = static_cast<MyHondanaApp *>(Tizen::App::UiApp::GetInstance());
	p_meta_info     = static_cast<cres_meta_info *>(&app->meta_info);
	p_one_meta_info = static_cast<cres_meta_info *>(&app->one_meta_info);
	net_status = status_idle;
	return ret;
}

void CMyBookShelfStoreIF::read_json_data(ByteBuffer &buf)
{
	File file;
	File file_datalist;
	String filePath 	 = App::GetInstance()->GetAppRootPath() + L"shared/data/JsonBookList.txt";

	//Read File Content into buffer
	result r;
	r = file.Construct(filePath, "r");
	TryReturnVoid(r == E_SUCCESS, "file construction failure with [%s]", GetErrorMessage(r));

	FileAttributes att;
	r = File::GetAttributes(filePath, att);
	TryReturnVoid(r == E_SUCCESS, "file GetAttributes failure with [%s]", GetErrorMessage(r));

	long long size = att.GetFileSize();
	TryReturnVoid(size > 0, "file does not contain valid data, size of file [%ld]", size);

	//ByteBuffer buf;
	r = buf.Construct(size + 1);
	TryReturnVoid(r == E_SUCCESS, "bytebuffer construct failure with [%s]", GetErrorMessage(r));

	r = file.Read(buf);
	TryReturnVoid(r == E_SUCCESS, "file read failure with [%s]", GetErrorMessage(r));

}

bool CMyBookShelfStoreIF::remove_json(IJsonValue* pJson)
{
	if (pJson->GetType() == JSON_TYPE_OBJECT)
	{
		JsonObject* pObject = static_cast< JsonObject* >(pJson);
		AppLog("pObject  = %d", pObject->GetCount());
		pObject->RemoveAll(true);
	}
	else if (pJson->GetType() == JSON_TYPE_ARRAY)
	{
		JsonArray* pArray = static_cast< JsonArray* >(pJson);
		pArray->RemoveAll(true);
	}
	delete pJson;
}
//String * imei, String * dev_nm
bool CMyBookShelfStoreIF::imei2_regist_req()
{
	String key(L"http://tizen.org/system/duid");
	String dev_nm;
	result r = E_SUCCESS;


	r = SystemInfo::GetValue(key, dev_nm);
	TryReturn(r == E_SUCCESS, r, "MySystemInfo: To get a value is failed");

	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")  , new String(IMEI));
	map->Add(new String(L"dev_nm"), new String(dev_nm));
	map->Add(new String(URI)      , new String(test_server_address[status_imei2_regist]));
	String mUserAgent = USER_AGENT;
	net_status = status_imei2_regist;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	bool ret = true;
	return ret;

}
bool CMyBookShelfStoreIF::imei2_regist_res(res_imei2_regist_t * p_res_imei2_regist)
{
	bool ret = true;
	String str(p_http_com_service->__responseStr );
	ret = meta_info_parser.imei2_regist_parser(p_res_imei2_regist, str);

	// ----------------------------------------------------------------------------------------
	AppLog("After traverse");
	//clean up allocated jsonValues
	net_status = status_idle;
	return ret;

}
bool CMyBookShelfStoreIF::imei2_update_req(req_imei2_update_t * p_imei2_update)
{
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"reg_imei")  , new String(p_imei2_update->reg_imei));
	map->Add(new String(L"reg_dev_nm"), new String(p_imei2_update->reg_dev_nm));
	// to be ..
	map->Add(new String(URI)      , new String(test_server_address[status_imei2_update]));
	String mUserAgent = USER_AGENT;
	net_status = status_bookshelf_sync;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	bool ret = true;
	return ret;
}
bool CMyBookShelfStoreIF::imei2_update_res()
{
	ByteBuffer buf;
	read_json_data(buf);
	bool result;
	//Call Json Parser
	bool ret = true;
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.imei2_update_parser(&result, pJson);

	// ----------------------------------------------------------------------------------------
	AppLog("After traverse");
	//clean up allocated jsonValues
	remove_json(pJson);
	net_status = status_idle;
	return ret;

}
bool CMyBookShelfStoreIF::imei2_check_req()
{
	// Not set last_ups_dt(last update date), if last_upd_dt not set, All meta data will be downloaded.
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")  , new String(IMEI));
	map->Add(new String(URI)      , new String(test_server_address[status_imei2_check]));
	String mUserAgent = USER_AGENT;
	net_status = status_imei2_check;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;
}
bool CMyBookShelfStoreIF::imei2_check_res(bool & b_result)
{
	bool ret;
	String str(p_http_com_service->__responseStr );
	//IJsonValue* pJson = JsonParser::ParseN(*pBuf);
	//TryCatch(pJson, , "ParseN failed with [%s]", GetErrorMessage(GetLastResult()));
	ret = meta_info_parser.imei2_check_parser(b_result, str);

	// ----------------------------------------------------------------------------------------
	AppLog("imei2_check_res"); // ??
	net_status = status_idle;

	return ret;

}


bool CMyBookShelfStoreIF::bookshelf_sync_req(String * last_upd_dt, String * Offset)
{
	// Not set last_ups_dt(last update date), if last_upd_dt not set, All meta data will be downloaded.
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"offset"), new String(L"0"));
	map->Add(new String(L"IMEI")  , new String(IMEI));
	map->Add(new String(URI)      , new String(test_server_address[status_bookshelf_sync]));
	String mUserAgent = USER_AGENT;
	net_status = status_bookshelf_sync;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	bool ret = true;
	return ret;
}

bool CMyBookShelfStoreIF::bookshelf_sync_res()
{
	bool ret;
	ByteBuffer *pBuf = Tizen::Base::Utility::StringUtil::StringToUtf8N( p_http_com_service->__responseStr );
	IJsonValue* pJson = JsonParser::ParseN(*pBuf);
	TryCatch(pJson, , "ParseN failed with [%s]", GetErrorMessage(GetLastResult()));
	meta_info_parser.MetaInfoParser(p_meta_info, pJson);	

	// ----------------------------------------------------------------------------------------
	AppLog("After traverse"); // ??
	if(pJson)
	{
		remove_json(pJson);
		ret = true;
		net_status = status_idle;
	}
	else
	{	
		ret = false;
		net_status = status_no_connection;
	}

	return ret;

CATCH:
	return false;
}
bool CMyBookShelfStoreIF::bookshelf_onesync_req(String * title_id, String * item_id)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")    , new String(IMEI)); // be confused to me.
	map->Add(new String(L"item_id") , new String(*item_id));
	map->Add(new String(L"title_id"), new String(*title_id));
	map->Add(new String(URI)        , new String(test_server_address[status_bookshelf_onesync]));
	String mUserAgent = USER_AGENT;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	
	net_status = status_bookshelf_onesync;
	return ret;	
}
bool CMyBookShelfStoreIF::bookshelf_onesync_res()
{
	ByteBuffer buf;
	read_json_data(buf);

	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.MetaInfoParser(p_one_meta_info, pJson);	

	// ----------------------------------------------------------------------------------------
	AppLog("After traverse");
	//clean up allocated jsonValues
	remove_json(pJson);
	net_status = status_idle;
	bool ret = true;
	return ret;
}
bool CMyBookShelfStoreIF::bookshelf_deleteitem_req(String * title_id, String * item_id)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")    , new String(IMEI)); // be confused to me.
	map->Add(new String(L"item_id") , new String(*item_id));
	map->Add(new String(L"title_id"), new String(*title_id));
	map->Add(new String(URI)        , new String(test_server_address[status_bookshelf_deleteitem]));
	String mUserAgent = USER_AGENT;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;	
}
bool CMyBookShelfStoreIF::bookshelf_deleteitem_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);

	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.deleteitem_parser(&ret, pJson);	
	remove_json(pJson);
	net_status = status_idle;
	return ret;
}
bool CMyBookShelfStoreIF::bookshelf_coverimage_req(String * title_id, String * item_id)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")    , new String(IMEI)); // be confused to me.
	map->Add(new String(L"item_id") , new String(*item_id));
	map->Add(new String(L"title_id"), new String(*title_id));
	map->Add(new String(URI)        , new String(test_server_address[status_bookshelf_coverimage]));
	String mUserAgent = USER_AGENT;
	
	net_status = status_bookshelf_coverimage;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;
}
bool CMyBookShelfStoreIF::bookshelf_coverimage_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	cres_coverimage  result;
	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.coverimage_parser(&result, pJson);
	remove_json(pJson);
	
	net_status = status_idle;
	return ret;
}

bool CMyBookShelfStoreIF::bookshelf_firstitem_req(String * title_id)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")    , new String(IMEI)); // be confused to me.
	map->Add(new String(L"title_id") , new String(* title_id));
	map->Add(new String(URI)        , new String(test_server_address[status_bookshelf_firstitem]));
	String mUserAgent = USER_AGENT;
	
	net_status = status_bookshelf_firstitem;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;
	return ret;
}
bool CMyBookShelfStoreIF::bookshelf_firstitem_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	res_firstitem_t res_first_item; //

	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.firstitem_parser(&res_first_item, pJson);

	remove_json(pJson);
	net_status = status_idle;
	return ret;
}
bool CMyBookShelfStoreIF::bookshelf_nextitem_req(String * title_id, String * item_id)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")    , new String(IMEI)); // be confused to me.
	map->Add(new String(L"item_id") , new String(*item_id));
	map->Add(new String(L"title_id"), new String(*title_id));
	map->Add(new String(URI)        , new String(test_server_address[status_bookshelf_nextitem]));
	String mUserAgent = USER_AGENT;
	
	net_status = status_bookshelf_nextitem;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::bookshelf_nextitem_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	res_nextitem_t res_nextitem; //

	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.firstitem_parser(&res_nextitem, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;
}
bool CMyBookShelfStoreIF::purchase_status_req(String * title_id, String * item_id)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")    , new String(IMEI)); // be confused to me.
	map->Add(new String(L"title_id"), new String(*title_id));
	map->Add(new String(L"item_id") , new String(*item_id));
	map->Add(new String(URI)        , new String(test_server_address[status_purchase_status]));
	String mUserAgent = USER_AGENT;
	
	net_status = status_purchase_status;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;
}
bool CMyBookShelfStoreIF::purchase_status_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	res_purchase_status_t res_nextitem; //

	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.purchase_status_parser(&res_nextitem, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;
}

bool CMyBookShelfStoreIF::item2_coverflow_req(String * rec_cnt)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")    , new String(IMEI)); // be confused to me.
	map->Add(new String(L"rec_cnt") , new String(*rec_cnt));
	map->Add(new String(URI)        , new String(test_server_address[status_item2_coverflow]));
	String mUserAgent = USER_AGENT;
	
	net_status = status_item2_coverflow;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;
}

bool CMyBookShelfStoreIF::item2_coverflow_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	res_item2coverflow_t res_item2coverflow; //
	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.item2_coverflow_parser(&res_item2coverflow, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;
}

bool CMyBookShelfStoreIF::item2_nobuylist_req(String * title_id)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")    , new String(IMEI)); // be confused to me.
	map->Add(new String(L"title_id") , new String(*title_id));
	map->Add(new String(URI)        , new String(test_server_address[status_item2_nobuylist]));
	String mUserAgent = USER_AGENT;
	
	net_status = status_item2_nobuylist;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;
}
bool CMyBookShelfStoreIF::item2_nobuylist_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	res_item2nobuylist_t res_item2nobuylist; //
	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.item2nobuylist_parser(&res_item2nobuylist, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;

}
bool CMyBookShelfStoreIF::item2_itemname_req(String * title_id, String * item_id)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"title_id") , new String(*title_id));
	map->Add(new String(L"item_id")  , new String(*item_id));
	map->Add(new String(URI)         , new String(test_server_address[status_item2_itemname]));
	String mUserAgent = USER_AGENT;
	
	net_status = status_item2_itemname;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::item2_itemname_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	res_item2itemname_t res_item2itemname; //
	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.item2itemname_parser(&res_item2itemname, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;
}
bool CMyBookShelfStoreIF::download2_contents2_req(String * title_id, 
                                                         String * item_id, 
                                                         String * sample_flg,
                                                         String * imei)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"title_id") , new String(*title_id));
	map->Add(new String(L"item_id")  , new String(*item_id));
	map->Add(new String(L"sample_flg")  , new String(*sample_flg));
	map->Add(new String(URI)         , new String(test_server_address[status_download2_contents2]));
	String mUserAgent = USER_AGENT;
	net_status = status_download2_contents2;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::download2_contents2_res()
{
	bool ret = true;
	// file or text
	net_status = status_idle;
	return ret;
}
bool CMyBookShelfStoreIF::download2_rangedownload_req(String * Range,// http header,
                                                                String * title_id,
                                                                String * item_id,
                                                                String * sample_flg,
                                                                String * imei)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"Range")     , new String(*Range)); // be confused to me.
	map->Add(new String(L"title_id") , new String(*title_id));
	map->Add(new String(L"item_id")  , new String(*item_id));
	map->Add(new String(L"sample_flg")  , new String(*sample_flg));
	map->Add(new String(L"imei")     , new String(*imei)); // be confused to me.
	map->Add(new String(URI)         , new String(test_server_address[status_download2_rangedownload]));
	String mUserAgent = USER_AGENT;
	net_status = status_download2_rangedownload;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::download2_rangedownload_res()
{
	// text or file
	bool ret = true;
	
	net_status = status_idle;
	return ret;
}

bool CMyBookShelfStoreIF::download_complete_req(String * title_id,
                                                       String * item_id,
                                                       String * book_format_id,
                                                       String * sample_flg)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"title_id") , new String(*title_id));
	map->Add(new String(L"item_id")  , new String(*item_id));
	map->Add(new String(L"book_format_id")  , new String(*book_format_id));
	map->Add(new String(L"sample_flg")  , new String(*sample_flg));
	map->Add(new String(URI)         , new String(test_server_address[status_download_complete]));
	String mUserAgent = USER_AGENT;
	net_status = status_download_complete;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::download_complete_res()
{
	
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	bool result;
	//Call Json Parser
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.download_complete_parser(&result, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;
}
bool CMyBookShelfStoreIF::download_bsurl_req(String * title_id, 
                                                   String * item_id, 
                                                   String * sample_flg,
                                                   String * imei)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(*imei)); // be confused to me.
	map->Add(new String(L"title_id") , new String(*title_id));
	map->Add(new String(L"item_id")  , new String(*item_id));
	map->Add(new String(L"sample_flg")  , new String(*sample_flg));
	map->Add(new String(URI)         , new String(test_server_address[status_download_bsurl]));
	String mUserAgent = USER_AGENT;
	net_status = status_download_bsurl;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::download_bsurl_res()
{
	bool ret = true;
	ByteBuffer buf;
	read_json_data(buf);
	res_download_bsurl_t download_bsurl;
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.download_bsurl_parser(&download_bsurl, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;

}
bool CMyBookShelfStoreIF::bookmark_share_req(req_bookmark_share_t * p_bookmark_share)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"user_no")  , new String(p_bookmark_share->user_no));

	// must make json array. to be continue;
//	map->Add(new String(L"item_id")  , new String(p_bookmark_share->item_id));
//	map->Add(new String(L"sample_flg")  , new String(p_bookmark_share->sample_flg));
	map->Add(new String(URI)         , new String(test_server_address[status_bookmark_share]));
	String mUserAgent = USER_AGENT;
	net_status = status_bookmark_share;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::bookmark_share_res()
{
	bool ret = true;
	bool result = true;
	ByteBuffer buf;
	read_json_data(buf);

	IJsonValue* pJson = JsonParser::ParseN(buf);
	//meta_info_parser.Result_parser(&result, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;
}
bool CMyBookShelfStoreIF::bookmark_delete_req(String * user_no)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"user_no") , new String(*user_no));
	map->Add(new String(URI)         , new String(test_server_address[status_bookmark_delete]));
	String mUserAgent = USER_AGENT;
	net_status = status_bookmark_delete;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;
}
bool CMyBookShelfStoreIF::bookmark_delete_res()
{
	bool ret = true;
	res_bookmark_delete_t bookmark_delete;
	ByteBuffer buf;
	read_json_data(buf);
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.bookmark_delete_parser(&bookmark_delete, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;
}

bool CMyBookShelfStoreIF::bookmark_sync_req(String * user_no)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"user_no") , new String(*user_no));
	map->Add(new String(URI)         , new String(test_server_address[status_bookmark_sync]));
	String mUserAgent = USER_AGENT;
	net_status = status_bookmark_sync;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::bookmark_sync_res()
{
	bool ret = true;
	res_bookmark_sync_t bookmark_sync;
	ByteBuffer buf;
	read_json_data(buf);
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.bookmark_sync_parser(&bookmark_sync, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;

}
bool CMyBookShelfStoreIF::advert_disadvert_req(String *count)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"count") , new String(*count));
	map->Add(new String(URI)         , new String(test_server_address[status_advert_dispadvert]));
	String mUserAgent = USER_AGENT;
	net_status = status_advert_dispadvert;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::advert_disadvert_res()
{
	//file or text
	bool ret = true;
	
	net_status = status_idle;
	return ret;
}
bool CMyBookShelfStoreIF::appstore2_url_req(String * Launchflg, String * pkg_nm)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"Launchflg") , new String(*Launchflg));
	map->Add(new String(L"pkg_nm")   , new String(*pkg_nm));
	map->Add(new String(URI)         , new String(test_server_address[status_appstore2_url]));
	String mUserAgent = USER_AGENT;
	net_status = status_appstore2_url;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::appstore2_url_res()
{
	bool ret = true;
	res_appstore2_url_t res_appstore2_url;
	ByteBuffer buf;
	read_json_data(buf);
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.appstore2_url_parser(&res_appstore2_url, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;

}
bool CMyBookShelfStoreIF::appstore2_appver_req(String * pkg_nm)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"pkg_nm")   , new String(*pkg_nm));
	map->Add(new String(URI)         , new String(test_server_address[status_appstore2_appver]));
	String mUserAgent = USER_AGENT;
	net_status = status_appstore2_appver;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::appstore2_appver_res()
{
	// to be determine
	bool ret = true;
	
	net_status = status_idle;
	return ret;
}
bool CMyBookShelfStoreIF::item_detailurl_req(String * mail_title,//64 encoding. -->:
                                                String * url)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")         , new String(IMEI)); // be confused to me.
	map->Add(new String(L"mail_title")   , new String(*mail_title));
	map->Add(new String(L"url")          , new String(*url));
	map->Add(new String(URI)             , new String(test_server_address[status_item_detailurl]));
	String mUserAgent = USER_AGENT;
	net_status = status_item_detailurl;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}

bool CMyBookShelfStoreIF::item_detailurl_res()
{
	bool ret = true;
	bool result;
	ByteBuffer buf;
	read_json_data(buf);
	IJsonValue* pJson = JsonParser::ParseN(buf);
	//meta_info_parser.Result_parser(&result, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;

}
bool CMyBookShelfStoreIF::appstore_url_req(String * Launchflg)
{
	bool ret = true;
	HashMap* map = new HashMap();
	map-> Construct();
	map->Add(new String(L"IMEI")     , new String(IMEI)); // be confused to me.
	map->Add(new String(L"Launchflg") , new String(*Launchflg));
	map->Add(new String(URI)         , new String(test_server_address[status_appstore_url]));
	String mUserAgent = USER_AGENT;
	net_status = status_appstore_url;
	p_http_com_service->postRequest(map, App::GetInstance(), mUserAgent);
	return ret;

}
bool CMyBookShelfStoreIF::appstore_url_res()
{
	bool ret = true;
	res_appstore_url_t res_appstore_url;
	ByteBuffer buf;
	read_json_data(buf);
	IJsonValue* pJson = JsonParser::ParseN(buf);
	meta_info_parser.appstore2_url_parser(&res_appstore_url, pJson);
	remove_json(pJson);
	net_status = status_idle;
	return ret;;

}

bool CMyBookShelfStoreIF::appstore_appver_req()
{
	bool ret = true;
	
	net_status = status_idle;
	return ret;
}
bool CMyBookShelfStoreIF::appstore_appver_res()
{
	bool ret = true;
	
	net_status = status_idle;
	return ret;
}
