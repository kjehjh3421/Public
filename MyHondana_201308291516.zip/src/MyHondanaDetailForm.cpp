#include <new>
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include <FSystem.h>
#include "MyHondanaMainForm.h"
#include "MyHondanaDetailForm.h"
#include "MyHondanaDeleteForm.h"
#include "SceneRegister.h"
#include "AppResourceId.h"
#include "FMedia.h"

#include "GlobalDefine.h"
#include "ResMetaInfo.h"
#include "MyHondana.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Graphics;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Media;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::Ui::Animations;
using namespace Tizen::Base::Collection;
using namespace Tizen::Base::Utility;
using namespace Tizen::System;
using namespace Tizen::Io;


struct book_list_t {
 //const Tizen::Graphics::Bitmap* bookbitmap;
 const Tizen::Base::String		 itemTitleText;
 const Tizen::Base::String		 itemAuthorText;
 bool recommend;
 bool readbook;
 } Temp_BOOK_LIST_ITEM[]= {
	  { L"しんじゅくすわんかぶきちょうすかうとさばいばる", L"いわさきなつみしんじゅくすわんかぶきちょうすかうとさばいばる", false, true }
	 ,{ L"しんじゅくすわんかぶきちょうすかうとさばいばる", L"いわさきなつみしんじゅくすわんかぶきちょうすかうとさばいばる", false, false }
	 ,{ L"わんかぶきちょうすかう", L"わさきみ", false, false }
	 ,{ L"くすわんかぶきちょうすかうとさば", L"わさきみ", false, false }
	 ,{ L"しんじゅく", L"わさきみ", false, false }
	 ,{ L"すわんかぶきちょうすかうとさばいばる", L"わきみ", false, true }
	 ,{ L"うとさばいばる", L"わきみ", false, true }
	 ,{ L"しんじょうすかうとさばいばる", L"わさみ", false, true }
	 ,{ L"ばいばる", L"さきみ", false, false }
	 ,{ L"しいばる", L"わさみ", false, true }
	 ,{ L"くすわんかぶきちょうすかうとさばいばる", L"わさ", false, true }
	 ,{ L"しんじゅくすうとさばいばる", L"わみ", false, true }
	 ,{ L"かうとさばいばる", L"わさきみ", false, true }
	 ,{ L"しばる", L"わさ", false, true }
	 ,{ L"ぶきちょうすかうといばる", L"わ", false, true }
	 ,{ L"ゅくすわんかちょうすかばいばる", L"わさきみ", false, false }
	 ,{ L"くすわんかぶきちすかうといばる", L"み", false, true }
	 ,{ L"しくすわんかうすかうとさばる", L"わさきみ", false, true }
	 ,{ L"しじゅくとさばいばる", L"わさみ", true, true }
	 ,{ L"ゅくすわんかぶきちょうすかうとさばいばる", L"み", true, false }
	 ,{ L"ばいばる", L"わさきみ", true, false }
 };


MyHondanaDetailForm::MyHondanaDetailForm(void)
{
	__dIndex = 0;
	currentUiStatus = 0;
	list_item_count = 0;
}

MyHondanaDetailForm::~MyHondanaDetailForm(void)
{
}

bool
MyHondanaDetailForm::Initialize(void)
{
	Construct(L"IDF_MY_HONDANA_DETAIL_FORM");
	LoadBitmapFiles();
	Control::OnInitializing();
	MyHondanaApp * app = static_cast<MyHondanaApp *>(Tizen::App::UiApp::GetInstance());
	p_meta_info = static_cast<cres_meta_info *>(&app->meta_info);
	SetOrientation(ORIENTATION_AUTOMATIC);
	AddOrientationEventListener(*this);
	SetFormBackEventListener(this);
	SetFormMenuEventListener(this);

	return true;
}

result
MyHondanaDetailForm::OnInitializing(void)
{
	result r = E_SUCCESS;
	InitHeader();
	InitControlPointer();
	InitMainContainerPanel();
	CreateOptionMenu();
	if(GetOrientationStatus()==ORIENTATION_STATUS_PORTRAIT)
		SetPortraitMode();
	else
		SetLandscapeMode();
		
	DrawForm();
	return r;
}

void MyHondanaDetailForm::DrawForm(void)
{
	bool isPort = IsPortraitMode();

	SwitchMainContainerPanel(isPort);
	DrawMainContainerPanel(isPort);
	this->RequestRedraw(true);
}

result
MyHondanaDetailForm::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
MyHondanaDetailForm::LoadBitmapFiles(void)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	//**Option Menu / Context Menu
	__pOptionmenu_thumbnail[0] = pAppResource->GetBitmapN("optionmenu_icon_gridview.png");
	__pOptionmenu_thumbnail[1] = pAppResource->GetBitmapN("optionmenu_icon_gridview.png");
	__pOptionmenu_list[0]      = pAppResource->GetBitmapN("optionmenu_icon_listview.png");
	__pOptionmenu_list[1]      = pAppResource->GetBitmapN("optionmenu_icon_listview.png");
	__pOptionmenu_update[0]    = pAppResource->GetBitmapN("optionmenu_icon_refresh.png");
	__pOptionmenu_update[1]    = pAppResource->GetBitmapN("optionmenu_icon_refresh.png");
	__pOptionmenu_delete[0]    = pAppResource->GetBitmapN("optionmenu_icon_delete.png");
	__pOptionmenu_delete[1]    = pAppResource->GetBitmapN("optionmenu_icon_delete.png");
	__pOptionmenu_download[0]  = pAppResource->GetBitmapN("optionmenu_icon_download.png");
	__pOptionmenu_download[1]  = pAppResource->GetBitmapN("optionmenu_icon_download.png");
	__pOptionmenu_setting[0]   = pAppResource->GetBitmapN("optionmenu_icon_setting.png");
	__pOptionmenu_setting[1]   = pAppResource->GetBitmapN("optionmenu_icon_setting.png");
	__pOptionmenu_help[0]      = pAppResource->GetBitmapN("optionmenu_icon_help.png");
	__pOptionmenu_help[1]      = pAppResource->GetBitmapN("optionmenu_icon_help.png");

	//**Book List
	__pNoImage = pAppResource->GetBitmapN(L"thumbnail_thumbnail_default.png");
	__pBookCover[0] = pAppResource->GetBitmapN(L"book20.png");
	__pBookCover[1] = pAppResource->GetBitmapN(L"book19.png");
	__pBookCover[2] = pAppResource->GetBitmapN(L"book18.png");
	__pBookCover[3] = pAppResource->GetBitmapN(L"book17.png");
	__pBookCover[4] = pAppResource->GetBitmapN(L"book16.png");
	__pBookCover[5] = pAppResource->GetBitmapN(L"book15.png");
	__pBookCover[6] = pAppResource->GetBitmapN(L"book14.png");
	__pBookCover[7] = pAppResource->GetBitmapN(L"book13.png");
	__pBookCover[8] = pAppResource->GetBitmapN(L"book12.png");
	__pBookCover[9] = pAppResource->GetBitmapN(L"book11.png");
	__pBookCover[10] = pAppResource->GetBitmapN(L"book10.png");
	__pBookCover[11] = pAppResource->GetBitmapN(L"book09.png");
	__pBookCover[12] = pAppResource->GetBitmapN(L"book08.png");
	__pBookCover[13] = pAppResource->GetBitmapN(L"book07.png");
	__pBookCover[14] = pAppResource->GetBitmapN(L"book06.png");
	__pBookCover[15] = pAppResource->GetBitmapN(L"book05.png");
	__pBookCover[16] = pAppResource->GetBitmapN(L"book04.png");
	__pBookCover[17] = pAppResource->GetBitmapN(L"book03.png");
	__pBookCover[18] = pAppResource->GetBitmapN(L"book02.png");
	__pBookCover[19] = pAppResource->GetBitmapN(L"book01.png");

	__pTranslate = pAppResource->GetBitmapN(L"translate.png");
}

void
MyHondanaDetailForm::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);

	switch(actionId)
	{
	case ID_BUTTON_MARKET:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_MARKET));
		break;
	case ID_BUTTON_LINK:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_MARKET));
		break;
	case ID_OPTIONMENU_UPDATE:
		__pUpdatePopup->SetShowState(true);
		__pUpdatePopup->Show();
		break;
	case ID_OPTIONMENU_DELETE:
		__pDeletePopup->SetShowState(true);
		__pDeletePopup->Show();
		break;
	case ID_OPTIONMENU_DOWNLOAD:
//		pSceneManager->GoForward(ForwardSceneTransition(SCENE_DOWNLOAD));
		break;
	case ID_OPTIONMENU_SETTING:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_SETTING));
		break;
	case ID_OPTIONMENU_HELP:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_HELP));
		break;
	default:
		break;
	}
}

void
MyHondanaDetailForm::OnOrientationChanged(const Control &source, OrientationStatus orientationStatus)
{
	if(orientationStatus == ORIENTATION_STATUS_PORTRAIT)
		SetPortraitMode();
	else
		SetLandscapeMode();
	DrawForm();
}	

void
MyHondanaDetailForm::InitHeader(void)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	// Create header
	Header * pHeader = GetHeader();
	String title;
	pAppResource->GetString("IDS_HEADER_TITLE", title);
	pHeader->SetTitleText(title);
	pHeader->AddActionEventListener(*this);
}

void
MyHondanaDetailForm::OnFormMenuRequested(Tizen::Ui::Controls::Form& source)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	String update, del, download, setting, help;
	pAppResource->GetString("IDS_OPTIONMENU_UPDATE", update);
	pAppResource->GetString("IDS_OPTIONMENU_DELETE", del);
	pAppResource->GetString("IDS_OPTIONMENU_DOWNLOAD", download);
	pAppResource->GetString("IDS_OPTIONMENU_SETTING", setting);
	pAppResource->GetString("IDS_OPTIONMENU_HELP", help);

	__pOptionMenu->AddItem(update, ID_OPTIONMENU_UPDATE, *__pOptionmenu_update[0], __pOptionmenu_update[1]);
	__pOptionMenu->AddItem(del, ID_OPTIONMENU_DELETE, *__pOptionmenu_delete[0], __pOptionmenu_delete[1]);
	__pOptionMenu->AddItem(download, ID_OPTIONMENU_DOWNLOAD, *__pOptionmenu_download[0], __pOptionmenu_download[1]);
	__pOptionMenu->AddItem(setting, ID_OPTIONMENU_SETTING, *__pOptionmenu_setting[0], __pOptionmenu_setting[1]);
	__pOptionMenu->AddItem(help, ID_OPTIONMENU_HELP, *__pOptionmenu_help[0], __pOptionmenu_help[1]);
	__pOptionMenu->SetMaxVisibleItemsCount(DETAIL_OPTIONMENU_MAX_VISIBLE_ITEM_COUNT);
	__pOptionMenu->SetColor(OPTIONMENU_COLOR);
	__pOptionMenu->AddActionEventListener(*this);

	__pOptionMenu->SetShowState(true);
	__pOptionMenu->Show();
}

void
MyHondanaDetailForm::OnFormBackRequested(Tizen::Ui::Controls::Form& source)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);
	pSceneManager->GoBackward(BackwardSceneTransition());
}

void
MyHondanaDetailForm::InitControlPointer(void)
{
	__pMainContainerPanel[PORTRAIT] = static_cast <Panel *>   (GetControl(IDC_DETAIL_PANEL, true));
	__pTextBoxTitle[PORTRAIT]  = static_cast <TextBox *> (GetControl(IDC_DETAIL_TEXTBOX_TITLE, true));
	__pButtonLink[PORTRAIT]    = static_cast <Button*>   (GetControl(IDC_DETAIL_BUTTON_LINK, true));
	__pLabelAuthor[PORTRAIT]   = static_cast <Label *>   (GetControl(IDC_DETAIL_LABEL_AUTHOR, true));
	__pListView[PORTRAIT]      = static_cast <ListView*> (GetControl(IDC_DETAIL_LISTVIEW, true));

	__pMainContainerPanel[LANDSCAPE] = static_cast <ScrollPanel *>(GetControl(IDC_DETAIL_SCROLLPANEL, true));
	__pTextBoxTitle[LANDSCAPE] = static_cast <TextBox *> (GetControl(IDC_DETAIL_TEXTBOX_TITLE_LANDSCAPE, true));
	__pButtonLink[LANDSCAPE]   = static_cast <Button*>   (GetControl(IDC_DETAIL_BUTTON_LINK_LANDSCAPE, true));
	__pLabelAuthor[LANDSCAPE]  = static_cast <Label *>   (GetControl(IDC_DETAIL_LABEL_AUTHOR_LANDSCAPE, true));
	__pListView[LANDSCAPE]     = static_cast <ListView*> (GetControl(IDC_DETAIL_LISTVIEW_LANDSCAPE, true));
}

void
MyHondanaDetailForm::SwitchMainContainerPanel(bool isPort)
{
	__pMainContainerPanel[PORTRAIT]->SetShowState(isPort);
	__pMainContainerPanel[LANDSCAPE]->SetShowState(!isPort);
}

void
MyHondanaDetailForm::InitMainContainerPanel(void)
{
	__pMainContainerPanel[PORTRAIT]->SetBounds(0, 0, this->GetWidth(), 1124);
	__pMainContainerPanel[LANDSCAPE]->SetBounds(0, 0, this->GetWidth(), 629);
}

int
MyHondanaDetailForm::GetItemCount(void)
{
	list_item_count = p_meta_info->datalist[__dIndex]->detail_info.size();
	return list_item_count;
}

void
MyHondanaDetailForm::DrawMainContainerPanel(bool isPort)
{
	AppResource *pAppResource = App::GetInstance()->GetAppResource();

	String str_title="しんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばるしんじゅくすわんかぶきちょうすかうとさばいばる";
	String str_author = "岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海 岩崎夏海";

	int title_length  = str_title.GetLength();
	int author_length = str_author.GetLength();

	int tb_title_height;
	int lb_author_height; 
	int row_count;
	int direction;

	Rectangle tb_title_rect;
	Rectangle lb_author_rect;
	Rectangle lv_series_rect;

	direction = !isPort;
	
	if(isPort)
	{
		row_count = title_length/TB_TITLE_MAX_STR_LEN_PORT + !!(title_length%TB_TITLE_MAX_STR_LEN_PORT);
		if(row_count > 10) row_count = 10;
		tb_title_height = row_count * TB_TITLE_FONT_HEIGHT;
		row_count = title_length/LB_AUTHOR_MAX_STR_LEN_PORT + !!(title_length%LB_AUTHOR_MAX_STR_LEN_PORT);
		lb_author_height = row_count * LB_AUTHOR_FONT_HEIGHT;
	}
	else
	{
		row_count = title_length/TB_TITLE_MAX_STR_LEN_LAND + !!(title_length%TB_TITLE_MAX_STR_LEN_LAND);
		if(row_count > 10) row_count = 10;
		tb_title_height = row_count * TB_TITLE_FONT_HEIGHT;
		row_count = title_length/LB_AUTHOR_MAX_STR_LEN_LAND + !!(title_length%LB_AUTHOR_MAX_STR_LEN_LAND);
		lb_author_height = row_count * LB_AUTHOR_FONT_HEIGHT;
	}
	
	tb_title_rect.x = 0;
	tb_title_rect.y = 0;
	tb_title_rect.width = WINDOW_WIDTH;
	tb_title_rect.height = tb_title_height + TB_TITLE_V_MARGIN;
	
	lb_author_rect.x = 0;
	lb_author_rect.y = tb_title_rect.height;
	lb_author_rect.width = WINDOW_WIDTH;
	lb_author_rect.height = lb_author_height + LB_AUTHOR_V_MARGIN;
	
	lv_series_rect.x = 0;
	lv_series_rect.y = tb_title_rect.height + lb_author_rect.height;
	lv_series_rect.width = WINDOW_WIDTH;
	lv_series_rect.height = GetClientAreaBounds().height-lv_series_rect.y;

	__pTextBoxTitle[direction]->SetBounds(tb_title_rect);
	__pTextBoxTitle[direction]->SetText(p_meta_info->datalist[__dIndex]->title_kana);
	__pTextBoxTitle[direction]->SetTextStyle(TEXT_BOX_TEXT_STYLE_UNDERLINE);
		
	__pButtonLink[direction]->SetBounds(tb_title_rect);
	__pButtonLink[direction]->SetNormalBackgroundBitmap(*__pTranslate);
	__pButtonLink[direction]->SetPressedBackgroundBitmap(*__pTranslate);
	__pButtonLink[direction]->SetActionId(ID_BUTTON_LINK);
	__pButtonLink[direction]->AddActionEventListener(*this);

	__pLabelAuthor[direction]->SetBounds(lb_author_rect);
	__pLabelAuthor[direction]->SetText(p_meta_info->datalist[__dIndex]->author_kana);
	__pLabelAuthor[direction]->SetBackgroundColor(LB_AUTHOR_BG_COLOR);
	__pLabelAuthor[direction]->SetTextColor(Color::GetColor(COLOR_ID_GREY));
	__pLabelAuthor[direction]->SetTextConfig(LB_AUTHOR_FONT_SIZE, LABEL_TEXT_STYLE_NORMAL);
	__pLabelAuthor[direction]->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
	__pLabelAuthor[direction]->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);

	__pListView[direction]->SetBounds(lv_series_rect);
	__pListView[direction]->SetItemProvider(*this);
	__pListView[direction]->AddListViewItemEventListener(*this);

}

Tizen::Ui::Controls::ListItemBase*
MyHondanaDetailForm::CreateItem(int index, int itemWidth)
{
	ListAnnexStyle style = LIST_ANNEX_STYLE_NORMAL;


	CustomItem* pItem = new (std::nothrow) CustomItem();
	Rectangle coverImageRect(LIST_ITEM_COVERIMAGE_X, 
	                         LIST_ITEM_COVERIMAGE_Y, 
	                         LIST_ITEM_COVERIMAGE_W, 
	                         LIST_ITEM_COVERIMAGE_H);//96, 150);
	Rectangle bookImageRect (LIST_ITEM_COVER_BELOW_IMAGE_X, 
	                         LIST_ITEM_COVER_BELOW_IMAGE_Y, 
	                         LIST_ITEM_COVER_BELOW_IMAGE_W, 
	                         LIST_ITEM_COVER_BELOW_IMAGE_H);
	Rectangle titlekanaRect (LIST_ITEM_TITLE_KANA_X,
	                         LIST_ITEM_TITLE_KANA_Y, 
	                         LIST_ITEM_TITLE_KANA_W, 
	                         LIST_ITEM_TITLE_KANA_H);
	Rectangle authornamekanaRect(LIST_ITEM_AUTH_NAME_KANA_X,
	                         LIST_ITEM_AUTH_NAME_KANA_Y, 
	                         LIST_ITEM_AUTH_NAME_KANA_W, 
	                         LIST_ITEM_AUTH_NAME_KANA_H);
	Rectangle releasedateRect(LIST_ITEM_RELEASE_DATE_X, 
							 LIST_ITEM_RELEASE_DATE_Y, 
							 LIST_ITEM_RELEASE_DATE_W, 
							 LIST_ITEM_RELEASE_DATE_H);
	Rectangle gotonewbookImageRect(LIST_ITEM_NEWBOOK_IMAGE_X, 
	                         LIST_ITEM_NEWBOOK_IMAGE_Y, 
	                         LIST_ITEM_NEWBOOK_IMAGE_W, 
	                         LIST_ITEM_NEWBOOK_IMAGE_H);//70, 153, 50
	Dimension itemDimension(itemWidth, LIST_ITEM_HEIGHT);//160

	pItem->Construct(itemDimension, style);

	if(!LoadBitmap(p_meta_info->datalist[index]->title_id))
		pItem->AddElement(coverImageRect, ID_BITMAP_BOOKCOVER, *__pNoImage, null, null);
	else
		pItem->AddElement(coverImageRect, ID_BITMAP_BOOKCOVER, 
		*LoadBitmap(p_meta_info->datalist[__dIndex]->detail_info[index]->item_id), null, null);

	
	pItem->AddElement(coverImageRect, ID_BITMAP_BOOKCOVER, 
	                                 * __pBookCover[index], null, null);
	                                 
	pItem->AddElement(titlekanaRect,  ID_STRING_TITLE, 
	                                 p_meta_info->datalist[__dIndex]->detail_info[index]->item_nm,
	                                 LIST_ITEM_TITLE_KANA_TEXT_SIZE, 
	                                 Color::GetColor(COLOR_ID_WHITE), 
	                                 Color::GetColor(COLOR_ID_WHITE), 
	                                 Color::GetColor(COLOR_ID_WHITE), true);
	pItem->AddElement(authornamekanaRect, ID_STRING_AUTHOR, 
	                                 L"保存済み"  ,
	                                 LIST_ITEM_AUTH_NAME_KANA_TEXT_SIZE, 
	                                 Color::GetColor(COLOR_ID_GREY), 
	                                 Color::GetColor(COLOR_ID_GREY), 
	                                 Color::GetColor(COLOR_ID_GREY), true);
	return pItem;
}

void
MyHondanaDetailForm::OnListViewItemStateChanged(ListView& listView, int index, int elementId, ListItemStatus status)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);
	pSceneManager->GoForward(ForwardSceneTransition(SCENE_VIEWER));
}

bool
MyHondanaDetailForm::DeleteItem(int index, Tizen::Ui::Controls::ListItemBase* pItem, int itemWidth)
{
	delete pItem;
	pItem = null;
	return true;
}

void
MyHondanaDetailForm::OnListViewItemSwept(ListView& listView, int index, SweepDirection direction)
{
}

void
MyHondanaDetailForm::OnListViewContextItemStateChanged(ListView& listView, int index, int elementId, ListContextItemStatus state)
{
}

void
MyHondanaDetailForm::OnListViewItemLongPressed(ListView& listView, int index, int elementId, bool& invokeListViewItemCallback)
{
}

void
MyHondanaDetailForm::OnUserEventReceivedN(RequestId requestId, Tizen::Base::Collection::IList* pArgs)
{
	AppLogDebug("Detail_OnUserEventReceivedN = %d", __dIndex);
	__Indexlist = new Tizen::Base::Collection::ArrayList;
	Integer* pInt = static_cast< Integer* >(pArgs->GetAt(0));
	__dIndex = pInt->ToInt();
	delete pInt;
	AppLogDebug("Received = %d", __dIndex);
}

void
MyHondanaDetailForm::CreateOptionMenu()
{
	__pOptionMenu = new (std::nothrow) OptionMenu();
	__pOptionMenu->Construct();
	CreateDeletePopup();
	CreateUpdatePopup();
}

void
MyHondanaDetailForm::CreateDeletePopup(void)
{
	Rectangle clientRect= GetClientAreaBounds();
	Rectangle rect(0, 0, clientRect.width, clientRect.height);

	__pDeletePopup = new (std::nothrow) Popup();
	__pDeletePopup->Construct(true, Dimension(DELETEPOPUP_WIDTH, DELETEPOPUP_HEIGHT));
	__pDeletePopup->SetTitleText(L"削除");
	__pDeletePopup->SetTitleTextColor(Color::GetColor(COLOR_ID_WHITE));
	__pDeletePopup->SetColor(DELETEPOPUP_COLOR);

	__pDeletePopupPanel = new (std::nothrow) DeletePopupPanel(this);
	__pDeletePopupPanel->Construct(Rectangle(0, 0, clientRect.width, clientRect.height));
	__pDeletePopup->AddControl(__pDeletePopupPanel);
}

void
MyHondanaDetailForm::OnDeletePanelItemSelected(int selectIdx)
{
	switch (selectIdx) {
	case 1:
		break;
	default:
		break;
	}
	HideDeletePopup();
}

void
MyHondanaDetailForm::HideDeletePopup(void)
{
	__pDeletePopup->SetShowState(false);
}

void
MyHondanaDetailForm::CreateUpdatePopup(void)
{
	__pUpdatePopup = new (std::nothrow) ProgressPopup();
	__pUpdatePopup->Construct(true,false);

	__pUpdatePopup->SetTitleText(L"更新中");
	switch(GetOrientationStatus())
	{
		case ORIENTATION_STATUS_PORTRAIT:
			__pUpdatePopup->SetText(L"更新しています");
			break;
		case ORIENTATION_STATUS_LANDSCAPE:
			__pUpdatePopup->SetText(L"更新しています");
			break;
		case ORIENTATION_STATUS_LANDSCAPE_REVERSE:
			__pUpdatePopup->SetText(L"更新しています");
			break;
	}
	__pUpdatePopup->AddProgressPopupEventListener(*this);
}

void
MyHondanaDetailForm::OnProgressPopupCanceled(void)
{
	__pUpdatePopup->SetShowState(false);
	Invalidate(true);
}

void
MyHondanaDetailForm::OnSceneDeactivated(const Tizen::Ui::Scenes::SceneId& currentSceneId, const Tizen::Ui::Scenes::SceneId& nextSceneId)
{
}

void
MyHondanaDetailForm::OnSceneActivatedN(const Tizen::Ui::Scenes::SceneId& previousSceneId, const Tizen::Ui::Scenes::SceneId& currentSceneId, Tizen::Base::Collection::IList* pArgs)
{
}

void MyHondanaDetailForm::OnLinkClicked(Tizen::Ui::Control &source, const Tizen::Base::String &text, Tizen::Base::Utility::LinkType linkType, const Tizen::Base::String &link)
{
}

void MyHondanaDetailForm::OnTextBlockSelected(Tizen::Ui::Control &source, int start, int end)
{
}
Tizen::Graphics::Bitmap*
MyHondanaDetailForm::LoadBitmap(const String& fullname)
{
	result r = E_SUCCESS;
	Bitmap* pBitmap = null;
	Image* pImage = new (std::nothrow) Image();

	String mFullPath = App::GetInstance()->GetAppDataPath();
	String mFilesPath = L"files/files/thumbnail/";

	/* remove prefix 0 series */
	int i_file_name;
	Integer::Parse(fullname, i_file_name);
	String str_file_name;
	str_file_name.Append(i_file_name);
	
	mFullPath.Append(mFilesPath);
	mFullPath.Append(str_file_name);
	mFullPath.Append(L".jpg");

	TryReturn((pImage != null), null, "Failed instantiate Image object");

	r = pImage->Construct();

	if (mFullPath.EndsWith(L"jpg"))
	{
		pBitmap = pImage->DecodeN(mFullPath, BITMAP_PIXEL_FORMAT_RGB565);
	}
	else if (mFullPath.EndsWith(L"bmp"))
	{
		pBitmap = pImage->DecodeN(mFullPath, BITMAP_PIXEL_FORMAT_RGB565);
	}
	else if (mFullPath.EndsWith(L"png"))
	{
		pBitmap = pImage->DecodeN(mFullPath, BITMAP_PIXEL_FORMAT_ARGB8888);
	}
	else if (mFullPath.EndsWith(L"gif"))
	{
		pBitmap = pImage->DecodeN(mFullPath, BITMAP_PIXEL_FORMAT_RGB565);
	}
	delete pImage;

	return pBitmap;
}

