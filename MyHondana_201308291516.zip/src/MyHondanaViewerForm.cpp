#include <new>
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "MyHondanaViewerForm.h"
#include "SceneRegister.h"
#include "AppResourceId.h"
#include "FMedia.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Graphics;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Media;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::Ui::Animations;
using namespace Tizen::Base::Collection;

MyHondanaViewerForm::MyHondanaViewerForm(void)
: __isVisible(true)
, __pGallery(null)
{
}

MyHondanaViewerForm::~MyHondanaViewerForm(void)
{
}

bool
MyHondanaViewerForm::Initialize(void)
{
	Construct(L"IDF_MY_HONDANA_VIEWER_FORM");
	return true;
}

result
MyHondanaViewerForm::OnInitializing(void)
{
	result r = E_SUCCESS;
	Control::OnInitializing();

	SetOrientation(ORIENTATION_AUTOMATIC);
	AddOrientationEventListener(*this);

	SetFormBackEventListener(this);
	SetFormMenuEventListener(this);

	GetBitmap();
	SetHeader();
	SetControl();
	SetBackgroundPanel();
	SetButton();
	bookmarkPage[bookTotalPage]=0;
	__pGallery->SetCurrentItemIndex(bookTotalPage-1);

	isFirstStart=false;

	return r;
}

result
MyHondanaViewerForm::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
MyHondanaViewerForm::GetBitmap(void)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();

	__pBookmark[0] = pAppResource->GetBitmapN(L"viewer_bookmark_icon_normal.png");
	__pBookmark[1] = pAppResource->GetBitmapN(L"viewer_bookmark_icon_selected.png");
}

void
MyHondanaViewerForm::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);

    switch(actionId)
    {
    case ID_BUTTON_MARKET :
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_MARKET));
    	break;
    case ID_BUTTON_MOVE:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_VIEWERMOVE));
    	break;
    case ID_BUTTON_NEXT :
    	break;
    case ID_BUTTON_SETTING :
    	break;
    case ID_BUTTON_HELP :
    	break;
    case ID_BUTTON_BOOKMARK :
    	BookmarkPage();
    	break;
    default:
        break;
    }
}

void
MyHondanaViewerForm::OnOrientationChanged(const Control &source, OrientationStatus orientationStatus)
{
	SetBackgroundPanel();
	SetButton();
	if(bookmarkPage[__pSlider->GetValue()] == 1)
	{
		__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[1]);
		__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[1]);
		Invalidate(true);
	}
	else
	{
		__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[0]);
		__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[0]);
		Invalidate(true);
	}
}

void
MyHondanaViewerForm::OnFormMenuRequested(Tizen::Ui::Controls::Form& source)
{
	switch(__isVisible)
	{
	case true:
		__pOverlayPanel_Menu->SetShowState(false);
		__pOverlayPanel_Title->SetShowState(false);
		__isVisible = false;
		break;
	case false:
		Invalidate(true);
		__pOverlayPanel_Menu->SetShowState(true);
		__pOverlayPanel_Title->SetShowState(true);
		__pSlider->SetValue(__pSlider->GetValue());
		__isVisible = true;
		Invalidate(true);
		break;
	default:
		break;
	}
}

void
MyHondanaViewerForm::OnFormBackRequested(Tizen::Ui::Controls::Form& source)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);
	pSceneManager->GoBackward(BackwardSceneTransition());
}

void
MyHondanaViewerForm::SetHeader(void)
{
//	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
//	// Create header
//	Header * pHeader = GetHeader();
//
//	String title;
//	pAppResource->GetString("IDS_HEADER_TITLE", title);
//	pHeader->SetTitleText(title);
//	pHeader->AddActionEventListener(*this);
}

void
MyHondanaViewerForm::SetControl(void)
{
	__pGallery = static_cast <Gallery *>(GetControl(IDC_VIEWER_GALLERY, true));

	__pOverlayPanel_Menu = static_cast <OverlayPanel *>(GetControl(IDC_VIEWER_OVERLAYPANEL_MENU, true));
	__pOverlayPanel_Title = static_cast <OverlayPanel *>(GetControl(IDC_VIEWER_OVERLAYPANEL_TITLE, true));
	__pLabel_Title_Background = static_cast <Label *>(GetControl(IDC_VIEWER_LABEL_TITLE_BACKGROUND, true));
	__pButton_Market = static_cast <Button *> (GetControl(IDC_VIEWER_BUTTON_MARKET, true));

	__pLabel_Slider_Background = static_cast <Label *> (GetControl(IDC_VIEWER_LABEL_SLIDEBAR_BACKGROUND, true));

	__pLabel_CurrentPage = static_cast <Label *> (GetControl(IDC_VIEWER_LABEL_CURRENTPAGE, true));
	__pLabel_Divider = static_cast <Label *> (GetControl(IDC_VIEWER_LABEL_DIVIDER, true));
	__pLabel_TotalPage = static_cast <Label *> (GetControl(IDC_VIEWER_LABEL_TOTALPAGE, true));

	__pSlider = static_cast <Slider *> (GetControl(IDC_VIEWER_SLIDER, true));
	__pButton_Move = static_cast <Button *> (GetControl(IDC_VIEWER_BUTTON_MOVE, true));
	__pButton_Next = static_cast <Button *> (GetControl(IDC_VIEWER_BUTTON_NEXT, true));
	__pButton_Setting = static_cast <Button *> (GetControl(IDC_VIEWER_BUTTON_SETTING, true));
	__pButton_Help = static_cast <Button *> (GetControl(IDC_VIEWER_BUTTON_HELP, true));
	__pButton_Bookmark = static_cast <Button *> (GetControl(IDC_VIEWER_BUTTON_BOOKMARK, true));

	__pLabel_Toast_CurrentPage = static_cast <Label *> (GetControl(IDC_VIEWER_LABEL_TOAST_CURRENTPAGE, true));
	__pLabel_Toast_Divider = static_cast <Label *> (GetControl(IDC_VIEWER_LABEL_TOAST_DIVIDER, true));
	__pLabel_Toast_TotalPage = static_cast <Label *> (GetControl(IDC_VIEWER_LABEL_TOAST_TOTALPAGE, true));
}

void
MyHondanaViewerForm::SetBackgroundPanel(void)
{
	if(GetOrientationStatus()==ORIENTATION_STATUS_PORTRAIT)
	{
		__pOverlayPanel_Menu->SetBounds(0, this->GetHeight()-230-60, this->GetWidth(), this->GetHeight());
		__pOverlayPanel_Title->SetBounds(0, 0, this->GetWidth(), 96);
		__pGallery->SetBounds(0, 0, this->GetWidth(), this->GetHeight());
	}
	else
	{
		__pOverlayPanel_Menu->SetBounds(0, this->GetHeight()-195, this->GetWidth(), this->GetHeight());
		__pOverlayPanel_Title->SetBounds(0, 0, this->GetWidth(), 91);
		__pGallery->SetBounds(0, 0, this->GetWidth(), this->GetHeight());
	}

	__pGallery->SetBackgroundColor(0xff393939);
	__pGallery->SetItemProvider(*this);
	__pGallery->AddGalleryEventListener(*this);
}

void
MyHondanaViewerForm::SetButton(void)
{
	AppResource *pAppResource = App::GetInstance()->GetAppResource();

	if(GetOrientationStatus()==ORIENTATION_STATUS_PORTRAIT)
	{
		__pLabel_Title_Background->SetBounds(0, 0, this->GetWidth(), 96);
		__pButton_Market->SetBounds(this->GetWidth()-124, 14, 124, 70);

		__pButton_Move->SetBounds(0, 0, 180, 112);
		__pButton_Move->SetNormalBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_move.png"));
		__pButton_Move->SetPressedBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_move_pressed.png"));

		__pButton_Next->SetBounds(180, 0, 180, 112);
		__pButton_Next->SetNormalBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_next.png"));
		__pButton_Next->SetPressedBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_next_pressed.png"));

		__pButton_Setting->SetBounds(360, 0, 180, 112);
		__pButton_Setting->SetNormalBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_setting.png"));
		__pButton_Setting->SetPressedBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_setting_pressed.png"));

		__pButton_Help->SetBounds(540, 0, 180, 112);
		__pButton_Help->SetNormalBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_help.png"));
		__pButton_Help->SetPressedBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_help_pressed.png"));

		__pLabel_Slider_Background->SetBounds(0, 112, this->GetWidth(), 118);
		__pLabel_CurrentPage->SetBounds(106, 112, (this->GetWidth()-146)/2-1, 52);
		__pLabel_Divider->SetBounds(106+(this->GetWidth()-146)/2-19, 112, 50, 52);
		__pLabel_TotalPage->SetBounds(106+(this->GetWidth()-146+80)/2, 112, (this->GetWidth()-146)/2, 52);
		__pSlider->SetBounds(66, 112, this->GetWidth()-66, 118);
		__pButton_Bookmark->SetBounds(0, 149, 86, 44);

		__pLabel_Toast_CurrentPage->SetBounds(this->GetWidth()/2-180, this->GetHeight()/2-50-156, 150, 100);

		__pLabel_Toast_Divider->SetBounds(this->GetWidth()/2-30, this->GetHeight()/2-50-156, 60, 100);
		__pLabel_Toast_TotalPage->SetBounds(this->GetWidth()/2+30, this->GetHeight()/2-50-156, 150, 100);
	}
	else
	{
		__pLabel_Title_Background->SetBounds(0, 0, this->GetWidth(), 91);
		__pButton_Market->SetBounds(this->GetWidth()-124, 12, 124, 70);

		__pButton_Move->SetBounds(0, 0, 320, 77);
		__pButton_Move->SetNormalBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_move_landscape.png"));
		__pButton_Move->SetPressedBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_move_landscape_pressed.png"));

		__pButton_Next->SetBounds(320, 0, 320, 77);
		__pButton_Next->SetNormalBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_next_landscape.png"));
		__pButton_Next->SetPressedBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_next_landscape_pressed.png"));

		__pButton_Setting->SetBounds(640, 0, 320, 77);
		__pButton_Setting->SetNormalBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_setting_landscape.png"));
		__pButton_Setting->SetPressedBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_setting_landscape_pressed.png"));

		__pButton_Help->SetBounds(960, 0, 320, 77);
		__pButton_Help->SetNormalBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_help_landscape.png"));
		__pButton_Help->SetPressedBackgroundBitmap(*pAppResource->GetBitmapN(L"view_btn_help_landscape_pressed.png"));

		__pLabel_Slider_Background->SetBounds(0, 77, this->GetWidth(), 118);
		__pLabel_CurrentPage->SetBounds(106, 77, (this->GetWidth()-146)/2-1, 52);
		__pLabel_Divider->SetBounds(106+(this->GetWidth()-146)/2-19, 77, 50, 52);
		__pLabel_TotalPage->SetBounds(106+(this->GetWidth()-146+80)/2, 77, (this->GetWidth()-146)/2, 52);
		__pSlider->SetBounds(66, 77, this->GetWidth()-66, 118);
		__pButton_Bookmark->SetBounds(0, 114, 86, 44);

		__pLabel_Toast_CurrentPage->SetBounds(this->GetWidth()/2-180, this->GetHeight()/2-50-91, 150, 100);
		__pLabel_Toast_Divider->SetBounds(this->GetWidth()/2-30, this->GetHeight()/2-50-91, 60, 100);
		__pLabel_Toast_TotalPage->SetBounds(this->GetWidth()/2+30, this->GetHeight()/2-50-91, 150, 100);
	}
//	String title;
//	pAppResource->GetString("IDS_HEADER_TITLE", title);
	__pLabel_Title_Background->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
	__pLabel_Title_Background->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
//	__pLabel_Title_Background->SetText(title);
	__pLabel_Title_Background->SetText(L"  マイ本棚         NARUTO NARUTO NARUTO NARUTO NARUTO 1권");


	__pButton_Market->SetActionId(ID_BUTTON_MARKET);
	__pButton_Market->AddActionEventListener(*this);

	__pButton_Move->SetActionId(ID_BUTTON_MOVE);
	__pButton_Move->AddActionEventListener(*this);

	__pButton_Next->SetActionId(ID_BUTTON_NEXT);
	__pButton_Next->AddActionEventListener(*this);

	__pButton_Setting->SetActionId(ID_BUTTON_SETTING);
	__pButton_Setting->AddActionEventListener(*this);

	__pButton_Help->SetActionId(ID_BUTTON_HELP);
	__pButton_Help->AddActionEventListener(*this);

	String str_current_page = Tizen::Base::Integer::ToString(bookTotalPage-__pSlider->GetValue()+1);
	__pLabel_CurrentPage->SetText(str_current_page);
	__pLabel_CurrentPage->SetTextHorizontalAlignment(ALIGNMENT_RIGHT);
	__pLabel_CurrentPage->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pLabel_CurrentPage->SetTextConfig(22, LABEL_TEXT_STYLE_NORMAL);
	__pLabel_CurrentPage->SetTextColor(0xffffffff);

	__pLabel_Divider->SetTextHorizontalAlignment(ALIGNMENT_RIGHT);
	__pLabel_Divider->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pLabel_Divider->SetTextConfig(22, LABEL_TEXT_STYLE_NORMAL);
	__pLabel_Divider->SetTextColor(0xff555555);
	__pLabel_Divider->SetBackgroundColor(0x1111ff);

	String str_total_page = Tizen::Base::Integer::ToString(bookTotalPage);
	__pLabel_TotalPage->SetText(str_total_page);
	__pLabel_TotalPage->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
	__pLabel_TotalPage->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pLabel_TotalPage->SetTextConfig(22, LABEL_TEXT_STYLE_NORMAL);
	__pLabel_TotalPage->SetTextColor(0xff555555);
	__pLabel_TotalPage->SetBackgroundColor(0x001111ff);

	__pSlider->SetRange(1, bookTotalPage);
	if(isFirstStart==true)
		__pSlider->SetValue(bookTotalPage);
	else
		__pSlider->SetValue(__pSlider->GetValue());
	__pSlider->SetThumbBitmap(SLIDER_THUMB_STATUS_NORMAL,*pAppResource->GetBitmapN(L"viewer_bar_control_normal.png"));
	__pSlider->SetThumbBitmap(SLIDER_THUMB_STATUS_PRESSED,*pAppResource->GetBitmapN(L"viewer_bar_control_pressed.png"));
	__pSlider->SetThumbTextColor(SLIDER_THUMB_STATUS_NORMAL, 0x00ffffff);
	__pSlider->SetThumbTextColor(SLIDER_THUMB_STATUS_PRESSED, 0x00ffffff);
	__pSlider->AddSliderEventListener(*this);
	__pSlider->AddAdjustmentEventListener(*this);

	__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[0]);
	__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[0]);
	__pButton_Bookmark->SetActionId(ID_BUTTON_BOOKMARK);
	__pButton_Bookmark->AddActionEventListener(*this);

	__pLabel_Toast_CurrentPage->SetTextHorizontalAlignment(ALIGNMENT_RIGHT);
	__pLabel_Toast_CurrentPage->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);

	__pLabel_Toast_Divider->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
	__pLabel_Toast_Divider->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);

	__pLabel_Toast_TotalPage->SetText(str_total_page);
	__pLabel_Toast_TotalPage->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
	__pLabel_Toast_TotalPage->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);

	__pLabel_Toast_CurrentPage->SetShowState(false);
	__pLabel_Toast_Divider->SetShowState(false);
	__pLabel_Toast_TotalPage->SetShowState(false);
}

result
MyHondanaViewerForm::Play(void)
{
	result r = E_SUCCESS;

	AnimationTransaction::Begin(__transactionId);
	int start = 1;
	int end = 0;
	IntegerAnimation animRightBottom(start, end, AnimationPropertyInfo2::DEFAULT_DURATION2, ANIMATION_INTERPOLATOR_EASE_IN_OUT);
	_animationPropertyInfo2.ApplyGlobalSettings(animRightBottom);
	(__pLabel_Toast_CurrentPage->GetControlAnimator())->StartUserAnimation(ANIMATION_TARGET_ALPHA, animRightBottom);
	(__pLabel_Toast_Divider->GetControlAnimator())->StartUserAnimation(ANIMATION_TARGET_ALPHA, animRightBottom);
	(__pLabel_Toast_TotalPage->GetControlAnimator())->StartUserAnimation(ANIMATION_TARGET_ALPHA, animRightBottom);
	AnimationTransaction::Commit();

	return r;
}

void
MyHondanaViewerForm::ShowMessageBox(void)
{
	MessageBox* pMessageBox = new (std::nothrow) MessageBox();
	pMessageBox->Construct(null, L"\n\n", MSGBOX_STYLE_NONE, 2000);
	pMessageBox->SetColor(0xff262626);

	Label* __pLabel_MsgBox = new(std::nothrow) Label;
	if(GetOrientationStatus()==ORIENTATION_STATUS_PORTRAIT)
		__pLabel_MsgBox->Construct(Rectangle(35, 45, 250, 77), L"");
	else
		__pLabel_MsgBox->Construct(Rectangle(35, 45, 340, 77), L"");

	String str_current_page = Tizen::Base::Integer::ToString(bookTotalPage-__pSlider->GetValue()+1);
	__pLabel_MsgBox->SetText(str_current_page);
	__pLabel_MsgBox->SetTextHorizontalAlignment(ALIGNMENT_RIGHT);
	__pLabel_MsgBox->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pLabel_MsgBox->SetTextConfig(40, LABEL_TEXT_STYLE_NORMAL);
	__pLabel_MsgBox->SetBackgroundColor(0x00ff0000);
	pMessageBox->AddControl(__pLabel_MsgBox);

	Label* __pLabel_MsgBox2 = new(std::nothrow) Label;
	if(GetOrientationStatus()==ORIENTATION_STATUS_PORTRAIT)
		__pLabel_MsgBox2->Construct(Rectangle(325-40, 45, 290+40, 77), L"");
	else
		__pLabel_MsgBox2->Construct(Rectangle(415-40, 45, 380+40, 77), L"");
	__pLabel_MsgBox2->SetText(L"ページ");
	__pLabel_MsgBox2->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
	__pLabel_MsgBox2->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pLabel_MsgBox2->SetTextConfig(40, LABEL_TEXT_STYLE_NORMAL);
	__pLabel_MsgBox2->SetBackgroundColor(0x0000ff00);
	pMessageBox->AddControl(__pLabel_MsgBox2);

	Label* __pLabel_MsgBox3 = new(std::nothrow) Label;
	if(GetOrientationStatus()==ORIENTATION_STATUS_PORTRAIT)
	{
		__pLabel_MsgBox3->Construct(Rectangle(35, 112, 580, 78), L"");
		if(chkBookmark==true)
			__pLabel_MsgBox3->SetText(L"ブックマークが削除されました。");
		else
			__pLabel_MsgBox3->SetText(L"ブックマークが追加されました。");
	}
	else
	{
		__pLabel_MsgBox3->Construct(Rectangle(35, 112, 760, 78), L"");
		if(chkBookmark==true)
			__pLabel_MsgBox3->SetText(L"ブックマークが削除されました。");
		else
			__pLabel_MsgBox3->SetText(L"ブックマークが追加されました。");
	}
	__pLabel_MsgBox3->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
	__pLabel_MsgBox3->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pLabel_MsgBox3->SetTextConfig(38, LABEL_TEXT_STYLE_NORMAL);
	__pLabel_MsgBox3->SetBackgroundColor(0x000000ff);
	pMessageBox->AddControl(__pLabel_MsgBox3);

	int ModalResult;
	pMessageBox->ShowAndWait(ModalResult);

	delete pMessageBox;
}

void
MyHondanaViewerForm::OnUserEventReceivedN(RequestId requestId, Tizen::Base::Collection::IList* pArgs)
{
//	AppLogDebug("Detail_OnUserEventReceivedN = %d", __dIndex);
//	__Indexlist = new Tizen::Base::Collection::ArrayList;
//	Integer* pInt = static_cast< Integer* >(pArgs->GetAt(0));
//	__dIndex = pInt->ToInt();
//	delete pInt;
//	AppLogDebug("Received = %d", __dIndex);
}


void
MyHondanaViewerForm::OnSceneDeactivated(const Tizen::Ui::Scenes::SceneId& currentSceneId, const Tizen::Ui::Scenes::SceneId& nextSceneId)
{
}

void
MyHondanaViewerForm::OnSceneActivatedN(const Tizen::Ui::Scenes::SceneId& previousSceneId, const Tizen::Ui::Scenes::SceneId& currentSceneId, Tizen::Base::Collection::IList* pArgs)
{
}

void
MyHondanaViewerForm::OnSliderBarMoved(Tizen::Ui::Controls::Slider& source, int value)
{
	String str_current_page = Tizen::Base::Integer::ToString(bookTotalPage-value+1);
	__pLabel_Toast_TotalPage->SetShowState(true);
	__pLabel_Toast_Divider->SetShowState(true);
	__pLabel_Toast_CurrentPage->SetShowState(true);
	__pLabel_Toast_CurrentPage->SetText(str_current_page);
	__pLabel_CurrentPage->SetText(str_current_page);

	Invalidate(true);
}

void
MyHondanaViewerForm::OnAdjustmentValueChanged(const Tizen::Ui::Control& source, int adjustment)
{
	Play();
	__pGallery->SetCurrentItemIndex(adjustment-1);
	if(bookmarkPage[__pSlider->GetValue()] == 1)
	{
		__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[1]);
		__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[1]);

		Invalidate(true);
	}
	else
	{
		__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[0]);
		__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[0]);
		Invalidate(true);
	}
}

Tizen::Ui::Controls::GalleryItem*
MyHondanaViewerForm::CreateItem(int index)
{
    AppResource* pAppResource = Application::GetInstance()->GetAppResource();
//	struct BOOK_LIST {
//		const Tizen::Graphics::Bitmap* bookbitmap;
//	} BOOK_LIST_ITEM[]= {
//		 { pAppResource->GetBitmapN(L"naruto016.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto015.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto014.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto013.jpg")}
////		,{ pAppResource->GetBitmapN(L"naruto012.jpg")}
////		,{ pAppResource->GetBitmapN(L"naruto011.jpg")}
////		,{ pAppResource->GetBitmapN(L"naruto010.jpg")}
////		,{ pAppResource->GetBitmapN(L"naruto009.jpg")}
////		,{ pAppResource->GetBitmapN(L"naruto008.jpg")}
////		,{ pAppResource->GetBitmapN(L"naruto007.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto006.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto005.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto004.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto003.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto002.jpg")}
//		,{ pAppResource->GetBitmapN(L"naruto001.jpg")}
//	};


    Tizen::Graphics::Bitmap* bookbitmap;
//    bookbitmap[0][0] = pAppResource->GetBitmapN(L"naruto016.jpg");
//    bookbitmap[0][1] = pAppResource->GetBitmapN(L"naruto015.jpg");
//    bookbitmap[0][2] = pAppResource->GetBitmapN(L"naruto014.jpg");
//    bookbitmap[0][3] = pAppResource->GetBitmapN(L"naruto013.jpg");
//    bookbitmap[0][4] = pAppResource->GetBitmapN(L"naruto012.jpg");
//    bookbitmap[0][5] = pAppResource->GetBitmapN(L"naruto011.jpg");
//    bookbitmap[0][6] = pAppResource->GetBitmapN(L"naruto010.jpg");
//    bookbitmap[0][7] = pAppResource->GetBitmapN(L"naruto009.jpg");
//    bookbitmap[0][8] = pAppResource->GetBitmapN(L"naruto008.jpg");
//    bookbitmap[0][9] = pAppResource->GetBitmapN(L"naruto007.jpg");
//    bookbitmap[0][10] = pAppResource->GetBitmapN(L"naruto006.jpg");
//    bookbitmap[0][11] = pAppResource->GetBitmapN(L"naruto005.jpg");
//    bookbitmap[0][12] = pAppResource->GetBitmapN(L"naruto004.jpg");
//    bookbitmap[0][13] = pAppResource->GetBitmapN(L"naruto003.jpg");
//    bookbitmap[0][14] = pAppResource->GetBitmapN(L"naruto002.jpg");
    bookbitmap = pAppResource->GetBitmapN(L"naruto001.jpg");


//	Bitmap* pImageTemp1 = pAppResource->GetBitmapN(L"naruto003.jpg");

    GalleryItem* pGallery = new GalleryItem();
    pGallery->Construct(*bookbitmap);

		bookbitmap->Scale(Dimension(1280,2275));
    // Deallocates the bitmap
    delete bookbitmap;

    return pGallery;
}

bool
MyHondanaViewerForm::DeleteItem(int index, Tizen::Ui::Controls::GalleryItem* pItem)
{
    delete pItem;
    return true;
}

int
MyHondanaViewerForm::GetItemCount(void)
{
    return bookTotalPage;
}

void
MyHondanaViewerForm::OnGallerySlideShowStarted(Tizen::Ui::Controls::Gallery& gallery)
{

}

void
MyHondanaViewerForm::OnGallerySlideShowStopped(Tizen::Ui::Controls::Gallery& gallery)
{

}

void
MyHondanaViewerForm::OnGalleryItemClicked(Tizen::Ui::Controls::Gallery& gallery, int itemIndex)
{
//	switch(__isVisible)
//	{
//	case true:
//		__pOverlayPanel_Menu->SetShowState(false);
//		__pOverlayPanel_Title->SetShowState(false);
//		__isVisible = false;
//		break;
////	case false:
////		__pOverlayPanel_Menu->SetShowState(true);
////		__pOverlayPanel_Title->SetShowState(true);
////		__isVisible = true;
////		break;
//	default:
//		break;
//	}
//	nextPage();

}

void
MyHondanaViewerForm::OnGalleryCurrentItemChanged(Tizen::Ui::Controls::Gallery& gallery, int currentItemIndex)
{
	__pSlider->SetValue(currentItemIndex+1);
	String str_current_page = Tizen::Base::Integer::ToString(bookTotalPage-currentItemIndex);
	__pLabel_Toast_TotalPage->SetShowState(true);
	__pLabel_Toast_Divider->SetShowState(true);
	__pLabel_Toast_CurrentPage->SetShowState(true);
	__pLabel_Toast_CurrentPage->SetText(str_current_page);
	__pLabel_CurrentPage->SetText(str_current_page);

	if(bookmarkPage[__pSlider->GetValue()] == 1)
	{
		__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[1]);
		__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[1]);
		Invalidate(true);
	}
	else
	{
		__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[0]);
		__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[0]);
		Invalidate(true);
	}

	Invalidate(true);
	Play();
}

void
MyHondanaViewerForm::BookmarkPage(void)
{
	if(bookmarkPage[__pSlider->GetValue()] == 1)
	{
		__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[0]);
		__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[0]);
		Invalidate(true);
		ShowMessageBox();
		bookmarkPage[__pSlider->GetValue()] = 0;
	}
	else
	{
		__pButton_Bookmark->SetNormalBackgroundBitmap(*__pBookmark[1]);
		__pButton_Bookmark->SetPressedBackgroundBitmap(*__pBookmark[1]);
		Invalidate(true);
		ShowMessageBox();
		bookmarkPage[__pSlider->GetValue()] = 1;
	}
}

////HBPageView
//HyBook::HBBookType
//MyHondanaViewerForm::BookType()
//{
//
//}
//
//HyBook::HBSupportedFunction
//MyHondanaViewerForm::SupportedFunction()
//{
//}
//
//bool
//MyHondanaViewerForm::maskTransparency(void)
//{
//}
//
//HyBook::HBTransitionType
//MyHondanaViewerForm::TransitionType()
//{
//}
//
//int
//MyHondanaViewerForm::searchPrev(void)
//{
//
//}
//
//void
//MyHondanaViewerForm::maskTransparency(bool flag)
//{
//}
//
//void
//MyHondanaViewerForm::cancelSearch(void)
//{
//}
//
//void
//MyHondanaViewerForm::TransitionType(HyBook::HBTransitionType transittionType)
//{
//}
//
//int
//MyHondanaViewerForm::searchNext(void)
//{
//}
//
//int
//MyHondanaViewerForm::searchText(std::string text)
//{
//}
//
//void
//MyHondanaViewerForm::ShadowType(HyBook::HBShadowType shadowType)
//{
//}
//
//HyBook::HBShadowType
//MyHondanaViewerForm::ShadowType()
//{
//}
//
//void
//MyHondanaViewerForm::cancelTextSelection(void)
//{
//}
//
//void
//MyHondanaViewerForm::AnnotationList(HyBook::HBAnnotationList annotationList)
//{
//}
//
//HyBook::HBPageLayout
//MyHondanaViewerForm::PageLayout()
//{
//}
//
//void
//MyHondanaViewerForm::setListner(HyBook::IHBPageViewFormListner* listner)
//{
//}
//
//HyBook::HBAnnotationList
//MyHondanaViewerForm::AnnotationList(void)
//{
//}
//
//void
//MyHondanaViewerForm::PageLayout(HyBook::HBPageLayout layout)
//{
//}
//
//HyBook::HBBookIndexList
//MyHondanaViewerForm::BookIndexList(void)
//{
//}
//
//bool
//MyHondanaViewerForm::navigationPageWithAnnotation(HyBook::HBAnnotation* bookmark)
//{
//}
//
//bool
//MyHondanaViewerForm::navigationPageWithBookIndex(HyBook::HBBookIndex* bookIndex)
//{
//}
//
//bool
//MyHondanaViewerForm::navigationPage(int pageIndex)
//{
//}
//
//bool
//MyHondanaViewerForm::prevPage(void)
//{
//
//}
//
//bool
//MyHondanaViewerForm::nextPage(void)
//{
//	switch(__isVisible)
//	{
//	case true:
//		__pOverlayPanel_Menu->SetShowState(false);
//		__pOverlayPanel_Title->SetShowState(false);
//		__isVisible = false;
//		break;
////	case false:
////		__pOverlayPanel_Menu->SetShowState(true);
////		__pOverlayPanel_Title->SetShowState(true);
////		__isVisible = true;
////		break;
//	default:
//		break;
//	}
//}
//
