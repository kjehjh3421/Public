/*
 * ParameterUtil.cpp
 *
 *  Created on: Aug 28, 2013
 *      Author: Administrator
 */

#include "ParameterUtil.h"

using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Base::Utility;

result
ParameterUtil::DecodeBase64(const String &iInput, ByteBuffer &oOutput)
{
	result	r = E_SUCCESS;
	ByteBuffer	*pTemp = null;

	TryCatch(iInput.GetLength() != 0, r = E_INVALID_ARG, "Invalid parameter.");
	pTemp = StringUtil::DecodeBase64StringN(iInput);
	TryCatch(pTemp != null, r = GetLastResult(), GetErrorMessage(r));
	oOutput.Reset();
	r = oOutput.Construct(*pTemp);
	TryCatch(r == E_SUCCESS, , GetErrorMessage(r));

CATCH:
	if (pTemp != null) {
		delete pTemp;
	}
	return r;
}

result
ParameterUtil::EncodeBase64(const ByteBuffer &iInput, String &oOutput)
{
	result	r = E_SUCCESS;

	TryCatch(iInput.GetCapacity() != 0, r = E_INVALID_ARG, GetErrorMessage(r));
	r = StringUtil::EncodeToBase64String(iInput, oOutput);
	TryCatch(r == E_SUCCESS, , GetErrorMessage(r));

CATCH:
	return r;
}

result
ParameterUtil::StringToHashMap(const Tizen::Base::String &iStr, Tizen::Base::Collection::HashMap &oMap)
{
	result	r = E_SUCCESS;
	String	delimAmp(L"\\r\\n");
	String	delimEql(L"=");
	String	key;
	String	val;
	String	token;
	int		count;
	StringTokenizer	paramTok(iStr, delimAmp);

	if (oMap.GetCount()) {
		oMap.RemoveAll();
	}
	r = oMap.Construct();
	TryCatch(r == E_SUCCESS, , GetErrorMessage(r));

	while (paramTok.HasMoreTokens()) {
		paramTok.GetNextToken(token);
		StringTokenizer valueTok(token, delimEql);
		key = "";
		val = "";
		count = valueTok.GetTokenCount();
		valueTok.GetNextToken(key);
		if (count == 2) {
			valueTok.GetNextToken(val);
		}
		oMap.Add(new String(key), new String(val));
	}

CATCH:
	return r;
}

result
ParameterUtil::HashMapToString(const Tizen::Base::Collection::HashMap &iMap, Tizen::Base::String &oStr)
{
	result	r = E_SUCCESS;
	String	*pKey = null;
	String	*pValue = null;
	String	delimAmp(L"\\r\\n");
	String	delimEql(L"=");
	IMapEnumerator	*pMapEnum = null;

	TryCatch(iMap.GetCount() != 0, r = E_INVALID_ARG, "Invalid argument.");
	pMapEnum = iMap.GetMapEnumeratorN();
	TryCatch(pMapEnum != null, r = GetLastResult(), GetErrorMessage(r));
	oStr = L"";
	while (pMapEnum->MoveNext() == E_SUCCESS) {
		pKey = static_cast<String*>(pMapEnum->GetKey());
		pValue = static_cast<String*>(pMapEnum->GetValue());
		if (oStr.GetLength() != 0) oStr.Append(delimAmp);
		oStr.Append(*pKey);
		oStr.Append(delimEql);
		oStr.Append(*pValue);
	}

CATCH:
	if (pMapEnum != null) {
		delete pMapEnum;
	}
	return r;
}
