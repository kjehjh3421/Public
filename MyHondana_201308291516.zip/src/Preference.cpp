/*
 * Preference.cpp
 *
 *  Created on: Aug 23, 2013
 *      Author: JEONGHUN
 */

#include "Preference.h"

Preference::Preference() {
	// TODO Auto-generated constructor stub

}

Preference::~Preference() {
	// TODO Auto-generated destructor stub
}

