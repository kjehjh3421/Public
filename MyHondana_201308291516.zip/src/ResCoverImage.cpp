/*
 * ResCoverImage.cpp
 *
 *  Created on: Aug 19, 2013
 *      Author: Administrator
 */

 #include "ResCoverImage.h"
//#include "NetResStructure.h"

cres_coverimage::cres_coverimage()
{
}

cres_coverimage::~cres_coverimage()
{
}
coverimage_info_datalist_t * 
cres_coverimage::getNewDatalist()
{
	coverimage_info_datalist_t * p_datalist = new (std::nothrow) coverimage_info_datalist_t();
 	datalist.push_back(p_datalist);
 	return p_datalist;
}

