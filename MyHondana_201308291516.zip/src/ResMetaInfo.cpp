/*
 * MyBookShelfMetaInfo.cpp
 *
 *  Created on: Aug 9, 2013
 *      Author: Administrator
 */

 #include "ResMetaInfo.h"
 
meta_info_datalist_t * cres_meta_info::getNewDatalist()
{
 	meta_info_datalist_t * p_datalist = new (std::nothrow) meta_info_datalist_t();
 	datalist.push_back(p_datalist);
 	return p_datalist;
}

meta_info_datalist_t * cres_meta_info::getDatalist(String * title_id)
{
 	int len = datalist.size();

 	meta_info_datalist_t * p_datalist = NULL;
 	for(int i=0; i < len; i++)
 	{
 		p_datalist = datalist[i];
 		if(p_datalist->title_id == *(title_id))
 			break;
 	}
 	if(p_datalist == NULL)
 		p_datalist = getNewDatalist();
 		
	return p_datalist;
}

meta_info_datalist_t * cres_meta_info::getDatalist(int index)
{
	int len = datalist.size();
	if(index < 0 || index >= len ) return NULL;
	return datalist[index];
}

meta_info_detail_info_t * cres_meta_info::getDetailInfo(meta_info_datalist_t * p_datalist, String * item_id)
{
 	int len = p_datalist->detail_info.size();

 	meta_info_detail_info_t * p_detail_info = NULL;
 	for(int i=0; i < len; i++)
 	{
 		p_detail_info = p_datalist->detail_info[i];
 		if(p_detail_info->item_id == *item_id)
 			break;
 	}
 	if(p_detail_info == NULL)
 		p_detail_info = getNewDetailInfo(p_datalist);
	return p_detail_info;

}
meta_info_detail_info_t * cres_meta_info::getDetailInfo(meta_info_datalist_t * p_datalist, int index)
{
	int len = p_datalist->detail_info.size();
	if(index < 0 || index >= len ) return NULL;
 	return p_datalist->detail_info[index];
}
meta_info_detail_info_t * cres_meta_info::getNewDetailInfo(meta_info_datalist_t * p_datalist)
{
 	meta_info_detail_info_t * detail_info = new (std::nothrow) meta_info_detail_info_t;
 	p_datalist->detail_info.push_back(detail_info);
 	return detail_info;
}


