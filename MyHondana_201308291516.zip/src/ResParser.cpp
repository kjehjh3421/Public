/*
 * MyBookShelfParser.cpp
 *
 *  Created on: Aug 9, 2013
 *      Author: Administrator
 */
#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FWebJson.h>

#include "GlobalDefine.h"
#include "ResMetaInfo.h"
#include "ResParser.h"
#include "ParameterUtil.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Graphics;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Media;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::Ui::Animations;
using namespace Tizen::Base::Collection;
using namespace Tizen::System;
using namespace Tizen::Io;
cres_parser::cres_parser(void)
{

}
cres_parser::~cres_parser(void)
{

}

bool cres_parser::imei2_regist_imeilist(imeilist_t* p_imeilist, IJsonValue * pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	bool ret = true;
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"imei")
		{
			p_imeilist->imei = * (static_cast< JsonString* >(value));
			AppLog("imei2_regist_imeilist() Result = %s", p_imeilist->imei.GetPointer());
		}
		else if(*key == L"dev_nm")
		{
			p_imeilist->dev_nm = * (static_cast< JsonString* >(value));
			AppLog("imei2_regist_imeilist() Result = %s", p_imeilist->dev_nm.GetPointer());
		}
		else if(*key == L"ins_dt")
		{
			p_imeilist->imei = * (static_cast< JsonString* >(value));
			AppLog("imei2_regist_imeilist() Result = %s", p_imeilist->imei.GetPointer());
		}
	}
	
	delete pMapEnum;
	return ret;
}

bool cres_parser::imei2_regist_parser(res_imei2_regist_t * p_res_imei2_regist, String & value)
{
	TryReturn(value.GetLength() > 0, false, "input String is null");
	
	bool ret = true;

	Tizen::Base::Collection::HashMap map;
	ParameterUtil::StringToHashMap(value, map);

	String *pstr_result = static_cast<String *>(map.GetValue(String(L"Result")));
	String *preg_no     = static_cast<String *>(map.GetValue(String(L"reg_no")));

	p_res_imei2_regist->Result = *pstr_result;
	p_res_imei2_regist->reg_no = *preg_no;

	if(*pstr_result == L"SW")
	{
		String    * pstr = static_cast<String *>(map.GetValue(String(L"imeilist")));
        IJsonValue* pValue = JsonParser::ParseN(pstr->GetPointer(), pstr->GetLength());
		JsonObject* pObject = static_cast< JsonObject* >(pValue);
		IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
		
		while (pMapEnum->MoveNext() == E_SUCCESS)
		{
			const String* key = null;
			IJsonValue* value = null;
			
			pMapEnum->GetKey(key);
			pMapEnum->GetValue(value);
			
			if(*key == L"Result")
			{
				p_res_imei2_regist->Result = * (static_cast< JsonString* >(value));
				AppLog("MetaInfoParser() Result = %s", p_res_imei2_regist->Result.GetPointer());
			}
			
			if(*key == L"reg_no")
			{
				p_res_imei2_regist->reg_no = * (static_cast< JsonString* >(value));
				AppLog("MetaInfoParser() access_dt = %S", p_res_imei2_regist->reg_no.GetPointer());
			}
		
			if(*key == L"imeilist")
			{
				JsonArray* pJsonArray = static_cast< JsonArray* >(value);
				int count = pJsonArray->GetCount();
				IEnumeratorT< IJsonValue* >* pEnum = pJsonArray->GetEnumeratorN();
				while (pEnum->MoveNext() == E_SUCCESS)
				{
					IJsonValue* pValue = null;
					pEnum->GetCurrent(pValue);
					imeilist_t* p_datalist = p_res_imei2_regist->get_new_imeilist();
		
					imei2_regist_imeilist(p_datalist, pValue);
				}
				delete pEnum;
				AppLog("MetaInfoParser() datalist count = %d");
			}
		}
		delete pMapEnum;
	}
	return ret;
}

bool cres_parser::imei2_update_parser(bool * result, IJsonValue* pValue)
{
	//return Result_parser(result, pValue);
	return true;
}

bool cres_parser::imei2_check_parser(bool & result, String & str)
{
	Tizen::Base::Collection::HashMap map;
	map.Construct();
	ParameterUtil::StringToHashMap(str, map);
	String *pstr_result = static_cast<String *>(map.GetValue(String(L"Result")));
	//Integer*    pValue = static_cast< Integer* > (map.GetValue(String(L"Zero")));

	if(*pstr_result == L"OK")
		result = true;
	else
		result = false;
	
	bool ret = true;
	return ret;
}

String cres_parser::TypeToString(IJsonValue * pValue, JsonType type)
{
	String* pStr = null;
	if(type == JSON_TYPE_STRING)
	{
		JsonString* pVal = reinterpret_cast< JsonString* >(pValue);
		pStr = new String(*pVal);
	}
	else if(type == JSON_TYPE_NUMBER)
	{
		JsonNumber* pVal = reinterpret_cast< JsonNumber* >(pValue);
		pStr = new String((pVal->ToString()));
	}
	else if(type == JSON_TYPE_BOOL)
	{
		JsonBool* pVal = reinterpret_cast< JsonBool* >(pValue);
		if (*pVal == true)
		   pStr = new String(L"true");
		else
		   pStr = new String(L"false");
	}
	else 
	{
		pStr = new String(L"null");
	}
	return *pStr;
}

bool cres_parser::MetaInfoParser(cres_meta_info * p_meta_info, IJsonValue* pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");

	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();

	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
	  const String* key = null;
	  IJsonValue* value = null;
	  
	  pMapEnum->GetKey(key);
	  pMapEnum->GetValue(value);
	  JsonType type = value->GetType();
	  String str_value = TypeToString(value, type);
	  
	  if(*key == L"Result")
	  {
		  p_meta_info->Result =str_value;
		  //Integer::Parse(*totalCount, itotalCount);
		  AppLog("MetaInfoParser() Result = %S", p_meta_info->Result.GetPointer());
	  }
	  
	  if(*key == L"access_dt")
	  {
		  p_meta_info->access_dt = str_value;
		  AppLog("MetaInfoParser() access_dt = %S", p_meta_info->access_dt.GetPointer());
	  }

	  if(*key == L"tablet_flg")
	  {
		  AppLog("MetaInfoParser() before tablet_flg");
		  p_meta_info->table_flg=str_value;
		  AppLog("MetaInfoParser() tablet_flg = %S", p_meta_info->table_flg.GetPointer());
	  }

	  if(*key == L"offset")
	  {
		  p_meta_info->offset= str_value;
		  AppLog("MetaInfoParser() offset = %S", p_meta_info->offset.GetPointer());
	  }

	  if(*key == L"total_count")
	  {
		  p_meta_info->total_count = str_value;
		  AppLog("MetaInfoParser() total_count = %s", p_meta_info->total_count.GetPointer());
	  }
	  if(*key == L"datalist")
	  {
	  
		  JsonArray* pJsonArray = static_cast< JsonArray* >(value);
		  int count = pJsonArray->GetCount();
		  IEnumeratorT< IJsonValue* >* pEnum = pJsonArray->GetEnumeratorN();

		  while (pEnum->MoveNext() == E_SUCCESS)
		  {
			  IJsonValue* pValue = null;
			  pEnum->GetCurrent(pValue);
			  meta_info_datalist_t * p_datalist = p_meta_info->getNewDatalist();

			  MetaInfoDataListParser(p_meta_info, p_datalist, pValue);
		  }
		  delete pEnum;
		  AppLog("MetaInfoParser() datalist count = %d");
		  
	  }
	}
	delete pMapEnum;
	return ret;

}
  
bool cres_parser::MetaInfoDataListParser(cres_meta_info * p_meta_info, meta_info_datalist_t * p_datalist, IJsonValue* pValue)
{
  TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
  AppLog("MetaInfoBookListParser() ...");
  
  bool ret = true;
  if(pValue->GetType() != JSON_TYPE_OBJECT)
  {
	AppLog("MetaInfoBookListParser() must be json_type_array...");
  	return false;
  }

  JsonObject* pObject = static_cast< JsonObject* >(pValue);
  IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
  
  while (pMapEnum->MoveNext() == E_SUCCESS)
  {
	  String* pStr        = null;
	  const String* key   = null;
	  IJsonValue*   value = null;
	  
	  pMapEnum->GetKey(key);
	  pMapEnum->GetValue(value);
	  
	  JsonType type = value->GetType();
	  String str_value = TypeToString(value, type);
	  if(*key == L"title_id") // 1
	  {
		  p_datalist->title_id = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() title_id = %S",  p_datalist->title_id.GetPointer());
	  } 		  

	  if(*key == L"last_target_device_type")  // 2
	  {
		  p_datalist->last_target_device_type = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = last_target_device_type = %S", 
		  p_datalist->last_target_device_type.GetPointer());
	  }
	  
	  if(*key == L"title_nm") // 3
	  {
		  p_datalist->title_nm = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = title_nm = %S", 
		  p_datalist->title_nm.GetPointer());
	  }
	  
	  if(*key == L"title_kana")  // 4
	  {
		  p_datalist->title_kana = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = title_kana = %S", p_datalist->title_kana.GetPointer());
	  }
	  
	  if(*key == L"c_cnt")	  // 5
	  {
		  p_datalist->v_cnt = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = c_cnt = %S", p_datalist->v_cnt.GetPointer());
	  }
	  
	  if(*key == L"v_cnt")	  //6
	  {
		  p_datalist->c_cnt = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = v_cnt = %S", p_datalist->c_cnt.GetPointer());
	  }
	  
	  if(*key == L"book_type")	  // 7
	  {
		  p_datalist->book_type = str_value;

		  AppLog("[sihong] MetaInfoBookListParser() key = book_type = %S", p_datalist->book_type.GetPointer());
	  }

	  if(*key == L"new_item_id")  // 8
	  {
		  p_datalist->new_item_id = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = new_item_id = %S", p_datalist->new_item_id.GetPointer());
	  }

	  if(*key == L"release_dt")   // 9
	  {
		  p_datalist->release_dt = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = release_dt = %S", p_datalist->release_dt.GetPointer());
	  }
	  
	  if(*key == L"buy_check_flg")	// 10	  // Recheck~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
	  {
		 p_datalist->buy_check_flg = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = buy_check_flg = %S", 
				  str_value.GetPointer());
	  }
	  
	  if(*key == L"author_nm")	  // 11
	  {
		  p_datalist->author_nm = str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = author_nm = %S", p_datalist->author_nm.GetPointer());
	  }

	  if(*key == L"author_kana")  // 12
	  {
		  p_datalist->author_kana =  str_value;
		  AppLog("[sihong] MetaInfoBookListParser() key = author_kana = %S", p_datalist->author_kana.GetPointer());
	  }

	  if(*key == L"detail_info") //13
	  {
		  AppLog("MetaInfoParser() detail_info");
		  JsonArray* pJsonArray = static_cast< JsonArray* >(value);
		  int count = pJsonArray->GetCount();
		  IEnumeratorT< IJsonValue* >* pEnum = pJsonArray->GetEnumeratorN();

		  while (pEnum->MoveNext() == E_SUCCESS)
		  {
			  IJsonValue* pValue = null;
			  pEnum->GetCurrent(pValue);
			  meta_info_detail_info_t * p_detail_info =  p_meta_info->getNewDetailInfo(p_datalist);
			  MetaInfoDetailInfoParser(p_detail_info, pValue);
		  }
		  delete pEnum;
			  
		  AppLog("[sihong] MetaInfoBookListParser() key = detail_info, count = %d", 
		         count);
	  }
  }
  delete pMapEnum;
  return ret;
 
}

bool cres_parser::MetaInfoDetailInfoParser(meta_info_detail_info_t * p_detail_info, IJsonValue* pValue)
{
	TryReturnResult(pValue, false, false,"input jsonvalue pointer is null");
  AppLog("TraverseFunction() ...");
  
  bool ret = true;
  if(pValue->GetType() != JSON_TYPE_OBJECT)
  {
	AppLog("MetaInfoBookListParser() must be json_type_array...");
  	return false;
  }
  
  JsonObject* pObject = static_cast< JsonObject* >(pValue);
  IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
  
  while (pMapEnum->MoveNext() == E_SUCCESS)
  {
	  String* pStr        = null;
	  const String* key   = null;
	  IJsonValue*   value = null;
	  
	  pMapEnum->GetKey(key);
	  pMapEnum->GetValue(value);
	  JsonType type = value->GetType();
	  
	  String str_value = TypeToString(value, type);
	  
	  //---------------- Detail info -------------------------------------------------------/
	  if(*key == L"item_id")  // 1
	  {
		  p_detail_info->item_id = str_value;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-item_id  = %S", 
		  		str_value.GetPointer());
	  }
	  
	  if(*key == L"purchase_target_device_type")  // 2
	  {
		  p_detail_info->purchase_target_device_type = str_value;;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-purchase_target_device_type = %S", 
			  str_value.GetPointer());
	  }
	  
	  if(*key == L"item_no")  // 3
	  {
		  p_detail_info->item_no = str_value;;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-item_no = %S", 
			  str_value.GetPointer());
	  }
	  
	  if(*key == L"item_nm")  // 4
	  {
		  p_detail_info->item_nm = str_value;;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-item_nm = %S", 
			  str_value.GetPointer());
	  }
	  
	  if(*key == L"file_name")	  // 5
	  {
		  p_detail_info->file_name = str_value;;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-file_name = %S", 
			  str_value.GetPointer());
	  }
	  
	  if(*key == L"file_size")	  //6
	  {
		  p_detail_info->file_size = str_value;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-file_size = %s", 
		  	str_value.GetPointer());
	  }
	  
	  if(*key == L"book_format_id")   // 7
	  {
		  p_detail_info->book_format_id = str_value;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-book_format_id = %S", 
		  	str_value.GetPointer());
	  }

	  if(*key == L"dl_limit_dt")  // 8
	  {
		  p_detail_info->dl_limit_dt = str_value;
		  

		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-dl_limit_dt = %S", 
		  	str_value.GetPointer());
	  }

	  if(*key == L"item_type")	  // 9
	  {
		  p_detail_info->item_type =str_value;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-item_type = %S", 
		  	str_value.GetPointer());

	  }
	  if(*key == L"settlement_dt")	  // 10
	  {
		  p_detail_info->settlement_dt = str_value;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-settlement_dt = %S", 
		  str_value.GetPointer());
	  }

	  if(*key == L"del_flg")  // 11
	  {
		  p_detail_info->del_flag =str_value;
		  AppLog("[sihong] MetaInfoDetailInfoParser() key = Detail-del_flg = %S", 
		  str_value.GetPointer());
	  }
  }
  delete pMapEnum;
  return ret;
}

bool cres_parser::deleteitem_parser(bool * result, IJsonValue * pValue)
{
	return true;
}

bool cres_parser::coverimage_parser(cres_coverimage * p_coverimage_info, IJsonValue* pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	
	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"Result")
		{
			p_coverimage_info->Result = *(static_cast< JsonString* >(value));
			//Integer::Parse(*totalCount, itotalCount);
			AppLog("coverimage_parser() Result = %s", p_coverimage_info->Result.GetPointer());
		}
		
		if(*key == L"datalist")
		{
			JsonArray* pJsonArray = static_cast< JsonArray* >(value);
			int count = pJsonArray->GetCount();
			IEnumeratorT< IJsonValue* >* pEnum = pJsonArray->GetEnumeratorN();
	
			while (pEnum->MoveNext() == E_SUCCESS)
			{
				IJsonValue* pValue = null;
				pEnum->GetCurrent(pValue);
				coverimage_info_datalist_t * p_datalist = p_coverimage_info->getNewDatalist();
				coverimage_datalist_parser(p_datalist, pValue);
			}
			delete pEnum;
			AppLog("coverimage_parser() datalist count = %d");
		}
	}
	delete pMapEnum;
	return ret;

}

bool cres_parser::coverimage_datalist_parser(coverimage_info_datalist_t * p_coverimage_datalist_item, IJsonValue* pValue)
{
  TryReturnResult(pValue,false, false, "input jsonvalue pointer is null");
  AppLog("MetaInfoBookListParser() ...");
  
  bool ret = true;
  if(pValue->GetType() != JSON_TYPE_OBJECT)
  {
	AppLog("coverimage_datalist_parser() must be json_type_array...");
  	return false;
  }

  JsonObject* pObject = static_cast< JsonObject* >(pValue);
  IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
  
  while (pMapEnum->MoveNext() == E_SUCCESS)
  {
	  String* pStr        = null;
	  const String* key   = null;
	  IJsonValue*   value = null;
	  
	  pMapEnum->GetKey(key);
	  pMapEnum->GetValue(value);
	  
	  if(*key == L"title_id") // 1
	  {
		  p_coverimage_datalist_item->title_id = *(static_cast< JsonString* >(value));
		  AppLog("[sihong] coverimage_datalist_parser() title_id = %S", 
		         p_coverimage_datalist_item->title_id.GetPointer());
	  } 		  

	  if(*key == L"item_id")  // 2
	  {
		  p_coverimage_datalist_item->item_id = *(static_cast< JsonString* >(value));
		  AppLog("[sihong] coverimage_datalist_parser() key = item_id = %S", 
		         p_coverimage_datalist_item->item_id.GetPointer());
	  }

	  if(*key == L"thumbnail")  // 3
	  {
		  String pstr_thumbnail;
		  JsonString* pjstr_thumbnail64 = static_cast< JsonString* >(value);
		  String* pstr_thumbnail64 = new (std::nothrow) String(*pjstr_thumbnail64);
		  ByteBuffer* pDecodedBuffer = Tizen::Base::Utility::StringUtil::DecodeBase64StringN(*pstr_thumbnail64);
		  p_coverimage_datalist_item->thumbnail = * pstr_thumbnail64;
		  
		  //p_datalist->author_kana = *pStrauthorNameKana;
		  AppLog("[sihong] coverimage_datalist_parser() key = thumbnail64 = %S", pstr_thumbnail64->GetPointer());
		  AppLog("[sihong] coverimage_datalist_parser() key = thumbnail = %S", pDecodedBuffer);
	  }

	  //MetaInfoTraverseFunction(value);
  }
  delete pMapEnum;
  return ret;
}

bool cres_parser::firstitem_parser(res_firstitem_t * firstitem, IJsonValue* pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	
	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"Result")
		{
			firstitem->Result = *(static_cast< JsonString* >(value));
			AppLog("firstitem_parser() Result = %s", firstitem->Result.GetPointer());
		}
		if(*key == L"item_id")
		{
			firstitem->item_id =*(static_cast< JsonString* >(value));
			AppLog("firstitem_parser() Result = %s", firstitem->item_id.GetPointer());
		}
	}
	delete pMapEnum;
	return ret;
}

bool cres_parser::purchase_status_parser(res_purchase_status_t * p_purchase_status, IJsonValue* pValue)
{
		TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
		
		bool ret = true;
		JsonObject* pObject = static_cast< JsonObject* >(pValue);
		IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
		
		while (pMapEnum->MoveNext() == E_SUCCESS)
		{
			const String* key = null;
			IJsonValue* value = null;
			
			pMapEnum->GetKey(key);
			pMapEnum->GetValue(value);
			
			if(*key == L"Result")
			{
				p_purchase_status->Result = *(static_cast< JsonString* >(value));
				AppLog("purchase_status_parser() Result = %s", p_purchase_status->Result.GetPointer());
			}
			
			if(*key == L"purchase_flg")
			{
				p_purchase_status->purchase_flg = *(static_cast< JsonString* >(value));
				AppLog("purchase_status_parser() Result = %s", p_purchase_status->purchase_flg.GetPointer());
			}
		}
		delete pMapEnum;
		return ret;
}
bool cres_parser::item2_coverflow_parser(res_item2coverflow_t* p_item2coverflow, IJsonValue * pValue)
{
		TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
		
		bool ret = true;
		JsonObject* pObject = static_cast< JsonObject* >(pValue);
		IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
		
		while (pMapEnum->MoveNext() == E_SUCCESS)
		{
			const String* key = null;
			IJsonValue* value = null;
			
			pMapEnum->GetKey(key);
			pMapEnum->GetValue(value);
			
			if(*key == L"Result")
			{
				JsonString* pjstr_result = static_cast< JsonString* >(value);
				String * pstr_result = new (std::nothrow) String(*pjstr_result);
				p_item2coverflow->Result = *pstr_result;
				//Integer::Parse(*totalCount, itotalCount);
				AppLog("purchase_status_parser() Result = %s", pstr_result->GetPointer());
			}
			
			if(*key == L"titlelist")
			{
				JsonArray* pJsonArray = static_cast< JsonArray* >(value);
				int count = pJsonArray->GetCount();
				IEnumeratorT< IJsonValue* >* pEnum = pJsonArray->GetEnumeratorN();
			
				while (pEnum->MoveNext() == E_SUCCESS)
				{
					IJsonValue* pValue = null;
					pEnum->GetCurrent(pValue);
					titlelist_t * p_datalist = p_item2coverflow->get_new_imeilist();
			
					item2coverflow_titlelist_parser(p_datalist, pValue);
				}
				delete pEnum;
				AppLog("coverimage_parser() datalist count = %d");
			}
		}
		delete pMapEnum;
		return ret;


}
bool cres_parser::item2coverflow_titlelist_parser(titlelist_t * titlelist, IJsonValue *pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	
	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"title_id")
		{
			titlelist->title_id= *(static_cast< JsonString* >(value));
			AppLog("purchase_status_parser() Result = %s", titlelist->title_id.GetPointer());
		}
		
		if(*key == L"title_nm")
		{
			titlelist->title_nm= *(static_cast< JsonString* >(value));
			AppLog("purchase_status_parser() Result = %s", titlelist->title_nm.GetPointer());
		}
	}
	delete pMapEnum;
	return ret;

}
bool cres_parser::item2nobuylist_parser(res_item2nobuylist_t * p_item2nobuylist, IJsonValue *pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");

	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"Result")
		{
			p_item2nobuylist->Result= *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_item2nobuylist->Result.GetPointer());
		}
		
		if(*key == L"latest_item_id")
		{
			p_item2nobuylist->latest_item_id = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_item2nobuylist->latest_item_id.GetPointer());
		}

		if(*key == L"latest_item_nm")
		{
			p_item2nobuylist->latest_item_nm = *(static_cast< JsonString* >(value));
			//Integer::Parse(*totalCount, itotalCount);
			AppLog("item2nobuylist_parser() Result = %s", p_item2nobuylist->latest_item_nm.GetPointer());
		}
	}
	delete pMapEnum;
	return ret;
}

bool cres_parser::item2itemname_parser(res_item2itemname_t * p_item2itemname, IJsonValue *pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"Result")
		{
			p_item2itemname->Result = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_item2itemname->Result.GetPointer());
		}
		
		if(*key == L"item_nm")
		{
			p_item2itemname->item_nm = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_item2itemname->item_nm.GetPointer());
		}
	}
	delete pMapEnum;
	return ret;
}

bool cres_parser::download_complete_parser(bool * result, IJsonValue* pValue)
{
	return true;
}

bool cres_parser::download_bsurl_parser(res_download_bsurl_t * p_download_bsurl, IJsonValue *pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"Result")
		{
			p_download_bsurl->Result = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_download_bsurl->Result.GetPointer());
		}
		
		if(*key == L"dl_url")
		{
			p_download_bsurl->dl_url = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() dl_url = %s", p_download_bsurl->dl_url.GetPointer());
		}
	}
	delete pMapEnum;
	return ret;
}

bool cres_parser::bookmark_delete_parser(res_bookmark_delete_t* p_bookmark_delete, IJsonValue *pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"Result")
		{
			p_bookmark_delete->Result = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_bookmark_delete->Result.GetPointer());
		}
		
		if(*key == L"count")
		{
			p_bookmark_delete->count = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_bookmark_delete->count.GetPointer());
		}
	}
	delete pMapEnum;
	return ret;
}
bool cres_parser::bookmark_sync_parser(res_bookmark_sync_t* p_bookmark_sync, IJsonValue *pValue)

{
		TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
		
		bool ret = true;
		JsonObject* pObject = static_cast< JsonObject* >(pValue);
		IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
		
		while (pMapEnum->MoveNext() == E_SUCCESS)
		{
			const String* key = null;
			IJsonValue* value = null;
			
			pMapEnum->GetKey(key);
			pMapEnum->GetValue(value);
			
			if(*key == L"datalist")
			{
				JsonArray* pJsonArray = static_cast< JsonArray* >(value);
				int count = pJsonArray->GetCount();
				IEnumeratorT< IJsonValue* >* pEnum = pJsonArray->GetEnumeratorN();
			
				while (pEnum->MoveNext() == E_SUCCESS)
				{
					IJsonValue* pValue = null;
					pEnum->GetCurrent(pValue);
					bookmarkList_t * p_datalist = p_bookmark_sync->get_new_imeilist();
			
					bookmark_sync_datalist_parser(p_datalist, pValue);
				}
				delete pEnum;
				AppLog("coverimage_parser() datalist count = %d");
			}
		}
		delete pMapEnum;
		return ret;


}
bool cres_parser::bookmark_sync_datalist_parser(bookmarkList_t* p_bookmarkList, IJsonValue *pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"item_id")
		{
			p_bookmarkList->item_id = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_bookmarkList->item_id.GetPointer());
		}
		if(*key == L"book_format_id")
		{
			p_bookmarkList->book_format_id = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() book_format_id = %s", p_bookmarkList->book_format_id.GetPointer());
		}
		if(*key == L"bookmark")
		{
			p_bookmarkList->bookmark = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() bookmark = %s", p_bookmarkList->bookmark.GetPointer());
		}
	}
	delete pMapEnum;
	return ret;
}

bool cres_parser::appstore2_url_parser(res_appstore2_url_t* p_appstore2_ur, IJsonValue *pValue)
{
	TryReturnResult(pValue, false, false, "input jsonvalue pointer is null");
	bool ret = true;
	JsonObject* pObject = static_cast< JsonObject* >(pValue);
	IMapEnumeratorT< const String*, IJsonValue* >* pMapEnum = pObject->GetMapEnumeratorN();
	
	while (pMapEnum->MoveNext() == E_SUCCESS)
	{
		const String* key = null;
		IJsonValue* value = null;
		
		pMapEnum->GetKey(key);
		pMapEnum->GetValue(value);
		
		if(*key == L"Result")
		{
			p_appstore2_ur->Result = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() Result = %s", p_appstore2_ur->Result.GetPointer());
		}
		if(*key == L"URL")
		{
			p_appstore2_ur->URL = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() URL = %s", p_appstore2_ur->URL.GetPointer());
		}
		if(*key == L"URL2")
		{
			p_appstore2_ur->URL2 = *(static_cast< JsonString* >(value));
			AppLog("item2nobuylist_parser() URL2 = %s", p_appstore2_ur->URL2.GetPointer());
		}
	}
	delete pMapEnum;
	return ret;
}

