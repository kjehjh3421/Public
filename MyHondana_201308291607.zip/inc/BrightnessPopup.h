#ifndef _BRIGHTNESSPOPUP_H_
#define _BRIGHTNESSPOPUP_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FSystem.h>

using namespace Tizen::Graphics;

class IBrightnessPopupListener
{
public:
	virtual ~IBrightnessPopupListener() {}

	virtual void OnBrightnessPopupSelected(int selectIdx) = 0;
};

class BrightnessPopup
	: public Tizen::Ui::Controls::Popup
	, public Tizen::Ui::IPropagatedKeyEventListener
	, public Tizen::Ui::IActionEventListener
	, public Tizen::Ui::IAdjustmentEventListener
	, public Tizen::Ui::Controls::ISliderEventListener
	, public Tizen::System::IScreenEventListener
{
private:
	IBrightnessPopupListener* __pListener;

public:
	bool chkFirst = true;

	BrightnessPopup(void);
	BrightnessPopup(IBrightnessPopupListener * pListener);
	virtual ~BrightnessPopup(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	void ShowPopup(void);
	void HidePopup(void);
	void SetControl(void);
	void ControlSetting(void);

	virtual bool OnKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool TranslateKeyEventInfo(Tizen::Ui::Control& source, Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);

	//ISliderEventListener
	virtual void OnSliderBarMoved(Tizen::Ui::Controls::Slider& source, int value);
	virtual void OnAdjustmentValueChanged(const Tizen::Ui::Control& source, int adjustment);

	// IScreenEventListener
	virtual void OnScreenOn(void);
	virtual void OnScreenOff(void);
	virtual void OnScreenBrightnessChanged(int brightness);

	Tizen::Ui::Controls::Label* __pBrightness_Description_Label;
	Tizen::Ui::Controls::CheckButton* __pBrightness_CheckButton;
	Tizen::Ui::Controls::Slider* __pBrightness_Slider;
	Tizen::Ui::Controls::Button* __pBrightness_Ok_Button;;
	Tizen::Ui::Controls::Button* __pBrightness_Cancel_Button;

	bool isFirstStart=true;

	static const int ID_BRIGHTNESS_CANCEL_BUTTON = 900;
	static const int ID_BRIGHTNESS_OK_BUTTON = 901;
	static const int ID_BRIGHTNESS_AUTOSET = 902;
	static const int ID_BRIGHTNESS_SLIDER = 903;
};

#endif // _BRIGHTNESSPOPUP_H_
