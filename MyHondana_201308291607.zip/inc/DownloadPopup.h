#ifndef _DOWNLOADPOPUP_H_
#define _DOWNLOADPOPUP_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FSystem.h>

using namespace Tizen::Graphics;

class IDownloadPopupListener
{
public:
	virtual ~IDownloadPopupListener() {}

	virtual void OnDownloadPopupSelected(int selectIdx) = 0;
};

class DownloadPopup
	: public Tizen::Ui::Controls::Popup
	, public Tizen::Ui::IPropagatedKeyEventListener
	, public Tizen::Ui::IActionEventListener
{
private:
	IDownloadPopupListener* __pListener;

public:
	DownloadPopup(void);
	DownloadPopup(IDownloadPopupListener * pListener);
	virtual ~DownloadPopup(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	void ShowPopup(void);
	void HidePopup(void);
	void SetControl(void);
	void ControlSetting(void);

	void FirstStart(void);
	virtual bool OnKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool TranslateKeyEventInfo(Tizen::Ui::Control& source, Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);

	Tizen::Ui::Controls::Label* __pDownload_Label_Description;
	Tizen::Ui::Controls::Label*__pDownload_Label_Destination;

	Tizen::Ui::Controls::Button* __pDownload_Button_External;
	Tizen::Ui::Controls::Button* __pDownload_Button_Internal;
	Tizen::Ui::Controls::Button* __pDownload_Button_Notsave;

	Tizen::Ui::Controls::CheckButton* __pDownload_CheckButton_Nextshow;

	Tizen::Ui::Controls::Button* __pDownload_Button_Cancel;
	Tizen::Ui::Controls::Button* __pDownload_Button_Download;
};

#endif // _DOWNLOADPOPUP_H_
