/*
 * HBAnnotation.h
 *
 *  Created on: Jul 30, 2013
 *      Author: Hideki OCHI
 */

#ifndef HBANNOTATION_H_
#define HBANNOTATION_H_

#include <stdint.h>
#include <vector>
#include <tr1/memory>

namespace HyBook {
/*!
 * アノテーション（ブックマークも兼用）項目を取り扱うクラス
 *
 * インスタンスの生成はHBFactory::instanceAnottationを使用すること。
 */
class HBAnnotation {
public:
	virtual ~HBAnnotation()
	{
	}

	/*! @name 文字インデックスの設定取得 */

	/*!
	 *  アノテーション開始位置の文字インデックス値を取得する
	 *  @return 文字インデクス
	 */
	virtual int64_t startIndex() = 0;
	/*!
	 *  アノテーション開始位置の文字インデックス値を設定する
	 *  @param startIndex 文字インデクス
	 */
	virtual void startIndex(int64_t startIndex) = 0;

	/*!
	 *  アノテーション終端の文字インデックス値を取得する
	 *  @return 文字インデクス
	 */
	virtual int64_t endIndex() = 0;
	/*!
	 *  アノテーション終端の文字インデックス値を設定する
	 *  @param endIndex 文字インデクス
	 */
	virtual void endIndex(int64_t endIndex) = 0;

	/*! @name ページインデックスの設定取得
	 * @attention HBAnnotationは内部では文字インデクスを保持しており、ページインデックスは変換して返している。
	 * 変換はエンジンが稼働しているスレッドで行われるため、状況によっては実行スレッドが暫く待機状態になる可能性がある。
	 */

	/*!
	 *  アノテーションの先頭が含まれるページインデックスを取得する
	 *  @return ページインデックス
	 */
	virtual int startPageIndex(void) = 0;

	/*!
	 *  アノテーションの終端が含まれるページインデックスを取得する
	 *  @return ページインデックス
	 */
	virtual int endPageIndex(void) = 0;
};

/*!
 * アノテーションリスト
 */
typedef std::vector<std::tr1::shared_ptr<HBAnnotation> > HBAnnotationList;

} /* namespace HyBook */
#endif /* HBANNOTATION_H_ */
