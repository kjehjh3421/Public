/*
 * HBReader.h
 *
 *  Created on: Jul 30, 2013
 *      Author: ochi
 */

#ifndef HBREADER_H_
#define HBREADER_H_

namespace HyBook {

/*!
 * ファイルIOを抽象化したクラス
 * 独自DRM実装を施す場合は、派生クラスを作成して対応すること
 * @attention 今回はDRM実装を行わない為、α版では未定義とする
 */
class HBReader {
public:
	HBReader();
	virtual ~HBReader();
};

} /* namespace HyBook */
#endif /* HBREADER_H_ */
