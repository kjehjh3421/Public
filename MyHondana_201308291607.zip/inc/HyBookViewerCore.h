#ifndef _HYBOOKVIEWERCORE_H_
#define _HYBOOKVIEWERCORE_H_

/*! \mainpage 概要
 *
 * \section about このSDKについて
 * 本SDKは電子書籍総合ソリューション『HyBookSystem』のビューア機能をTizenに組み込むための開発キットです。
 * 提供するモジュールはTizen Native Applicationに組み込まれる事を前提としています。
 * 組み込み側が使用する言語環境はC++を想定しています。
 * <BR>
 *
 * \subsection spec 動作環境
 * 本SDKは以下の環境で開発・評価を行っています。
 *  - Mac OS X 10.8.4
 *  - Tizen SDK Version:2.2.0 Build id:20130708-1956
 *  - 評価機：SAMSUNG TIZEN REDWOOD
 * <BR>
 * \subsection elements ファイル構成
 *  - Documents
 *   - SDKリファレンス（本ドキュメント）
 *  - include
 *   - ヘッダファイル
 *  - lib/x86
 *   - シミュレータ用動的リンクライブラリ
 *  - lib/arm
 *   - 実機用動的リンクライブラリ
 *
 */

#include <FApp.h>
#include <FBase.h>
#include <FGraphics.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <gl.h>
#include <stdint.h>

#include "HBParam.h"
#include "HBPageViewForm.h"
#include "HBReader.h"
#include "HBAnnotation.h"

namespace HyBook {

#ifdef __cplusplus
extern "C"
{
#endif // __cplusplus

/*!
 * 各種インスタンスを生成するファクトリークラス
 */
class _EXPORT_ HBFactory {
public:
	HBFactory();
	virtual ~HBFactory();

	/// @name インスタンスの生成

	/*!
	 * HBreaderインスタンスの生成
	 * @param filePath 読み込み対象となるコンテンツファイルへのフルパス
	 * @return HBReaderインスタンス
	 */
	static HBReader* instanceHBReader(std::string filePath);

	/*!
	 * HBPageViewFormインスタンスの生成
	 * @param reader HBReaderインスタンス
	 * @param safeMode セーフモードのON/OFF
	 *
	 * @par セーフモード
	 *  HBPageViewFormはOpenGL上で動作するが、OpenGLの不安定な環境用にOpenGLを使用しないモードを指定できる。
	 *  ただし、OpneGL非使用時は版面表示のみに特化し、ページエフェクトや文字選択など機能が大幅に制限される。
	 * @return HBPageViewFormインスタンス
	*/
	static HBPageViewForm* instanceHBPageViewForm(HBReader* reader, bool safeMode);

	/*!
	 * HBAnnotationインスタンスの生成
	 *
	 * ブックマークとして運用する場合は、startIndexとendIndexに同じ値を指定する
	 * @param startIndex アノテーションの開始文字インデックス
	 * @param endIndex アノテーションの終端文字インデックス
	 * @return HBAnnotationインスタンス
	*/
	static HBAnnotation* instanceHBAnnotation(int64_t startIndex, int64_t endIndex);
};

#ifdef __cplusplus
}
#endif // __cplusplus

}
#endif // _HYBOOKVIEWERCORE_H_

