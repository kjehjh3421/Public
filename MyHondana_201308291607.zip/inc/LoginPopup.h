#ifndef _LOGINPOPUP_H_
#define _LOGINPOPUP_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FSystem.h>

using namespace Tizen::Graphics;

class ILoginPopupListener
{
public:
	virtual ~ILoginPopupListener() {}

	virtual void OnLoginPopupSelected(int selectIdx) = 0;
};

class LoginPopup
	: public Tizen::Ui::Controls::Popup
	, public Tizen::Ui::IPropagatedKeyEventListener
	, public Tizen::Ui::IActionEventListener
{
private:
	ILoginPopupListener* __pListener;

public:
	LoginPopup(void);
	LoginPopup(ILoginPopupListener * pListener);
	virtual ~LoginPopup(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	void ShowPopup(void);
	void HidePopup(void);
	void SetControl(void);
	void ControlSetting(void);

	void FirstStart(void);
	virtual bool OnKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool TranslateKeyEventInfo(Tizen::Ui::Control& source, Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);

	Tizen::Ui::Controls::Label* __pLogin_Description_Label;

	Tizen::Ui::Controls::Button* __pLogin_Cancel_Button;
	Tizen::Ui::Controls::Button* __pLogin_DocomoLogin_Button;;

	static const int ID_LOGIN_CANCEL_BUTTON = 1000;
	static const int ID_LOGIN_DOCOMOLOGIN_BUTTON = 1001;
};

#endif // _LOGINPOPUP_H_
