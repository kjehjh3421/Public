/*
 * MyBookShelfStoreIF.h
 *
 *  Created on: Aug 13, 2013
 *      Author: Administrator
 */

#ifndef MYBOOKSHELFSTOREIF_H_
#define MYBOOKSHELFSTOREIF_H_

#include "MyHondanaMainForm.h"
#include "MyHondanaDetailForm.h"
#include "SceneRegister.h"
#include "AppResourceId.h"
	 
#include "GlobalDefine.h"
#include "NetResStructure.h"
#include "ResMetaInfo.h"
#include "ResParser.h"
#include "MyHondana.h"


class CMyBookShelfStoreIF : public IHttpResponseEventListener
{
private:
	int net_status;
	HttpCommunicationService * p_http_com_service;
	cres_parser     meta_info_parser;
	cres_meta_info * p_meta_info;
	cres_meta_info * p_one_meta_info;
	Tizen::Ui::Control * pctrl_caller;
public:
private:
	void read_json_data(ByteBuffer &buf);
public:
	CMyBookShelfStoreIF();
	virtual ~CMyBookShelfStoreIF();
	bool initialize();
	inline void set_caller_for_response(Tizen::Ui::Control * p_caller){ pctrl_caller = p_caller;}
	void OnResponseReceived(const String &responseStr);
	bool remove_json(IJsonValue* pJson);
	bool imei2_regist_req();
	bool imei2_regist_res(res_imei2_regist_t * p_res_imei2_regist);
	bool imei2_update_req(req_imei2_update_t * p_imei2_update);
	bool imei2_update_res();
	bool imei2_check_req();
	bool imei2_check_res(bool & b_result);
	bool bookshelf_sync_req(String * last_upd_dt, String * Offset);
	bool bookshelf_sync_res();
	bool bookshelf_onesync_req(String * title_id, String * item_id);
	bool bookshelf_onesync_res();
	bool bookshelf_deleteitem_req(String * title_id, String * item_id);
	bool bookshelf_deleteitem_res();
	bool bookshelf_coverimage_req(String * title_id, String * item_id);
	bool bookshelf_coverimage_res();
	bool bookshelf_firstitem_req(String * title_id);
	bool bookshelf_firstitem_res();
	bool bookshelf_nextitem_req(String * title_id, String * item_id);
	bool bookshelf_nextitem_res();
	bool purchase_status_req(String * title_id, String * item_id);
	bool purchase_status_res();
	bool item2_coverflow_req(String * rec_cnt);
	bool item2_coverflow_res();
	bool item2_nobuylist_req(String * title_id);
	bool item2_nobuylist_res();
	bool item2_itemname_req(String * title_id, String * item_id);
	bool item2_itemname_res();
	bool download2_contents2_req(String * title_id, 
															 String * item_id, 
															 String * sample_flg,
															 String * imei);
	bool download2_contents2_res();
	bool download2_rangedownload_req(String * Range,// http header,
																	String * title_id,
																	String * item_id,
																	String * sample_flg,
																	String * imei);
	bool download2_rangedownload_res();
	bool download_complete_req(String * title_id,
														   String * item_id,
														   String * book_format_id,
														   String * sample_flg);
	bool download_complete_res();
	bool download_bsurl_req(String * title_id, 
													   String * item_id, 
													   String * sample_flg,
													   String * imei);
	bool download_bsurl_res();
	bool bookmark_share_req(req_bookmark_share_t * p_bookmark_share);
	bool bookmark_share_res();
	bool bookmark_delete_req(String * user_no);
	bool bookmark_delete_res();
	bool bookmark_sync_req(String * user_no);
	bool bookmark_sync_res();
	bool advert_disadvert_req(String *count);
	bool advert_disadvert_res();
	bool appstore2_url_req(String * Launchflg, String * pkg_nm);
	bool appstore2_url_res();
	bool appstore2_appver_req(String * pkg_nm);
	bool appstore2_appver_res();
	bool item_detailurl_req(String * mail_title,//64 encoding. -->:
													String * url);	
	bool item_detailurl_res();
	bool appstore_url_req(String * Launchflg);
	bool appstore_url_res();
	bool appstore_appver_req();
	bool appstore_appver_res();
};
#endif /* MYBOOKSHELFSTOREIF_H_ */
