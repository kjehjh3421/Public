
#ifndef _MYHONDANADETAILFORM_H_
#define _MYHONDANADETAILFORM_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include "DeletePopupPanel.h"
#include "GlobalDefine.h"
#include "ResMetaInfo.h"

using namespace Tizen::Base;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;

class MyHondanaDetailForm
	: public Tizen::Ui::Controls::Form
	, public Tizen::Ui::Scenes::ISceneEventListener
	, public Tizen::Ui::IActionEventListener
	, public Tizen::Ui::IOrientationEventListener
	, public Tizen::Ui::Controls::IFormBackEventListener
	, public Tizen::Ui::Controls::IFormMenuEventListener
	// List View
	, public Tizen::Ui::Controls::IListViewItemEventListener
	, public Tizen::Ui::Controls::IListViewItemProvider

	// Delete Popup Listener
	, public IDeletePopupPanelListener
	// Progress Popup Listener
	, public Tizen::Ui::IProgressPopupEventListener

	, public Tizen::Ui::IUiLinkEventListener
	, public Tizen::Ui::ITextBlockEventListener
{

private:

	DeletePopupPanel* __pDeletePopupPanel;

	ProgressPopup*    __pUpdatePopup;
	Popup*            __pDeletePopup;

	Panel*            __pMainContainerPanel[D_MODE_NUM];
	ScrollPanel*      __pMainContainerPanel_Land;
	Tizen::Ui::Controls::OptionMenu* __pOptionMenu;
	
	TextBox*          __pTextBoxTitle[D_MODE_NUM];
	Button*           __pButtonLink[D_MODE_NUM];
	Label*            __pLabelAuthor[D_MODE_NUM];
	ListView*         __pListView[D_MODE_NUM];

	Tizen::Base::Collection::ArrayList* __Indexlist;

	//**Option Menu / Context Menu
	Bitmap* __pOptionmenu_thumbnail[2];
	Bitmap* __pOptionmenu_list[2];
	Bitmap* __pOptionmenu_update[2];
	Bitmap* __pOptionmenu_delete[2];
	Bitmap* __pOptionmenu_download[2];
	Bitmap* __pOptionmenu_setting[2];
	Bitmap* __pOptionmenu_help[2];

	// related to list.
	Bitmap* __pBookCover[20];
	Bitmap* __pNoImage;
	Bitmap* __pTranslate;

	int list_item_count; // series's count for the book.
	int currentUiStatus;
	cres_meta_info * p_meta_info;
public:
	MyHondanaDetailForm(void);
	virtual ~MyHondanaDetailForm(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);
	virtual void OnFormBackRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnFormMenuRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnOrientationChanged(const Tizen::Ui::Control &source, Tizen::Ui::OrientationStatus orientationStatus);
	virtual void OnSceneDeactivated(const Tizen::Ui::Scenes::SceneId& currentSceneId,
										const Tizen::Ui::Scenes::SceneId& nextSceneId);
	virtual void OnSceneActivatedN(const Tizen::Ui::Scenes::SceneId& previousSceneId, const Tizen::Ui::Scenes::SceneId& currentSceneId, Tizen::Base::Collection::IList* pArgs);

	//IListViewItemEventListener
	virtual void OnListViewContextItemStateChanged(Tizen::Ui::Controls::ListView &listView, int index, int elementId, Tizen::Ui::Controls::ListContextItemStatus state);
	virtual void OnListViewItemStateChanged(Tizen::Ui::Controls::ListView &listView, int index, int elementId, Tizen::Ui::Controls::ListItemStatus status);
	virtual void OnListViewItemSwept(Tizen::Ui::Controls::ListView &listView, int index, Tizen::Ui::Controls::SweepDirection direction);
	virtual void OnListViewItemLongPressed(Tizen::Ui::Controls::ListView &listView, int index, int elementId, bool& invokeListViewItemCallback);

	//IListViewItemProvider
	virtual Tizen::Ui::Controls::ListItemBase* CreateItem (int index, int itemWidth);
	virtual bool DeleteItem (int index, Tizen::Ui::Controls::ListItemBase *pItem, int itemWidth);
	virtual int GetItemCount(void);

	virtual void OnUserEventReceivedN(RequestId requestId, Tizen::Base::Collection::IList *pArgs);

	virtual void OnLinkClicked(Tizen::Ui::Control &source, const Tizen::Base::String &text, Tizen::Base::Utility::LinkType linkType, const Tizen::Base::String &link);
	virtual void OnTextBlockSelected(Tizen::Ui::Control &source, int start, int end);
	// IDeletePopupPanelListener
	virtual void OnDeletePanelItemSelected(int selectIdx);
	// ProgressPopup
	virtual void OnProgressPopupCanceled(void);
	

private:
	void LoadBitmapFiles(void);
	void InitHeader(void);
	void InitControlPointer(void);
	
	void InitMainContainerPanel();
	void SwitchMainContainerPanel(bool isPort);
	void DrawMainContainerPanel(bool isPort);
	
	void CreateOptionMenu(void);
	void CreateDeletePopup(void);
	void CreateUpdatePopup(void);

	inline bool IsPortraitMode()	{return currentUiStatus & PORT_MODE;}
	inline void SetPortraitMode()	 {currentUiStatus |= PORT_MODE;}
	inline void SetLandscapeMode(){currentUiStatus &= ~PORT_MODE;}
	Tizen::Graphics::Bitmap*
	MyHondanaDetailForm::LoadBitmap(const String& fullname);


public:
	void HideDeletePopup();
	void DrawForm(void);
	
	int __dIndex;
};

#endif
