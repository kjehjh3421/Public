#ifndef _MYHONDANA_MAIN_FORM_H_
#define _MYHONDANA_MAIN_FORM_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FWebJson.h>

#include "CoverFlowPanel.h"
#include "SortPopup.h"
#include "DeletePopupPanel.h"
#include "HttpCommunicationService.h"
#include "AnimationBaseForm.h"
#include "GlobalDefine.h"
#include "ResMetaInfo.h"
#include "ResParser.h"
#include "MyBookShelfStoreIF.h"

using namespace Tizen::Web::Json;
using namespace Tizen::Base;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;

class CMyBookShelfStoreIF;

class MyHondanaMainForm
	: public Tizen::Ui::IOrientationEventListener
	, public Tizen::System::IScreenEventListener
	// Option Menu
	, public Tizen::Ui::Controls::IFormMenuEventListener
	// List View
	, public Tizen::Ui::Controls::IListViewItemEventListener
	, public Tizen::Ui::Controls::IListViewItemProvider
	// Thumbnail View
	, public Tizen::Ui::Controls::IIconListViewItemProvider
	, public Tizen::Ui::Controls::IIconListViewItemEventListener
	// Sort Popup Listener
	, public ISortPopupListener
	// Delete Popup Listener
	, public IDeletePopupPanelListener
	// Progress Popup Listener
	, public Tizen::Ui::IProgressPopupEventListener
	// Animation Listener
	, public Tizen::Ui::IAnimationEventListener
	, public AnimationBaseForm

{
	private:

		struct BOOK_LIST {
			const Tizen::Graphics::Bitmap* bookbitmap;
			const Tizen::Base::String		itemTitleText;
			const Tizen::Base::String		itemAuthorText;
			bool recommend;
			bool readbook;
		};

		
		Tizen::Ui::Orientation __status;

		int   currentUiStatus;

		//Header            __pHeader;

		CoverFlowPanel*   __pCoverflowPanel;
		Panel*            __pCoverflowCotainerPanel;

		OptionMenu*       __pOptionMenu;
		ScrollPanel*      __pMainContainerPanel;
		// menubar
		Label*            __pMenuBarContainerLabel;
		Button*           __pSortButton;
		Button*           __pNewBookButton;
		Button*           __pNewBookButtonEmpty;
		Button*           __pCoverflowOnOffButton;

		// listview
		int list_item_count;
		ListView*         __pListView;
		IconListView*     __pThumbnailView;
		IconListViewItem* pIconListview;

		DeletePopupPanel* __pDeletePopupPanel;
		ProgressPopup*    __pUpdatePopup;
	
		//**************************************BITMAP***************************************
		//**Thumbnail View / List View
		Bitmap* __pListNewBook;
		Bitmap* __pGridNewBook;
		Bitmap* __pListBottomText;
		Bitmap* __pGridBottomText;
	
		//**Book
		Bitmap* __pBookCover[20];
		Bitmap* __pNoImage;
	
		//**Header
		Bitmap* __pHeader_background;
		Bitmap* __pButton_market[2];
		Bitmap* __pButton_contextmenu[2];
	
		//**Option Menu / Context Menu
		Bitmap* __pOptionmenu_thumbnail[2];
		Bitmap* __pOptionmenu_list[2];
		Bitmap* __pOptionmenu_update[2];
		Bitmap* __pOptionmenu_delete[2];
		Bitmap* __pOptionmenu_download[2];
		Bitmap* __pOptionmenu_setting[2];
		Bitmap* __pOptionmenu_help[2];
	
		//**Divider Bar
		Bitmap* __pThumbnail_background_greyblack;
		Bitmap* __pThumbnail_background[2];
		Bitmap* __pDivider_background;
		Bitmap* __pDivider_sortbutton[2];
		Bitmap* __pDivider_newbookbutton[2];
		Bitmap* __pDivider_coverflow_on_button[2];
		Bitmap* __pDivider_coverflow_off_button[2];
	
		//************************************************************************************
		bool chkNewBook;
public:
	MyHondanaMainForm(void);
	virtual ~MyHondanaMainForm(void);
	bool Initialize(void);

	
	void DrawForm(void);
	
	virtual result Play(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);
	virtual void OnFormBackRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnFormMenuRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnOrientationChanged(const Tizen::Ui::Control &source, Tizen::Ui::OrientationStatus orientationStatus);

	virtual void OnScreenOn(void);
	virtual void OnScreenOff(void);
	virtual void OnAnimationStopped(const Tizen::Ui::Control& source);

	virtual int  GetItemCount(void);

	//IListViewItemEventListener
	virtual void OnListViewContextItemStateChanged(Tizen::Ui::Controls::ListView &listView, int index, int elementId, Tizen::Ui::Controls::ListContextItemStatus state);
	virtual void OnListViewItemStateChanged(Tizen::Ui::Controls::ListView &listView, int index, int elementId, Tizen::Ui::Controls::ListItemStatus status);
	virtual void OnListViewItemSwept(Tizen::Ui::Controls::ListView &listView, int index, Tizen::Ui::Controls::SweepDirection direction);
	virtual void OnListViewItemLongPressed(Tizen::Ui::Controls::ListView &listView, int index, int elementId, bool& invokeListViewItemCallback);

	//IListViewItemProvider
	virtual Tizen::Ui::Controls::ListItemBase* CreateItem (int index, int itemWidth);
	virtual bool  DeleteItem (int index, Tizen::Ui::Controls::ListItemBase *pItem, int itemWidth);

	// IIconListViewItemEventListener
	virtual void OnIconListViewItemStateChanged (Tizen::Ui::Controls::IconListView &view, int index, Tizen::Ui::Controls::IconListViewItemStatus status);
	virtual void OnIconListViewOverlayBitmapSelected (Tizen::Ui::Controls::IconListView &iconListView, int index, int overlayBitmapId);

	// IIconListViewItemProvider
	virtual Tizen::Ui::Controls::IconListViewItem* CreateItem(int index);
	virtual bool DeleteItem(int index, Tizen::Ui::Controls::IconListViewItem* pItem);

	// ISortPopupListener
	virtual void OnSortPopupSelected(int selectIdx);

	// IDeletePopupPanelListener
	virtual void OnDeletePanelItemSelected(int selectIdx);

	// ProgressPopup
	virtual void OnProgressPopupCanceled(void);

	// IHttpResponseEventListener
	virtual void OnResponseReceived(const Tizen::Base::String &responseStr);
	virtual void OnUserEventReceivedN(RequestId requestId, Tizen::Base::Collection::IList *pArgs);

private:
	inline bool IsFullScreenMode(){return currentUiStatus & FULL_MODE;}
	inline bool IsThumbnailMode(){return currentUiStatus & THUM_MODE;}
	inline bool IsPortraitMode()    {return currentUiStatus & PORT_MODE;}

	inline void SetFullScreenMode(){currentUiStatus |= FULL_MODE;}
	inline void SetThumbnailMode(){currentUiStatus |= THUM_MODE;}
	inline void SetPortraitMode()    {currentUiStatus |= PORT_MODE;}
	inline void SetHalfScreenMode(){currentUiStatus &= ~FULL_MODE;}
	inline void SetListMode()        {currentUiStatus &= ~THUM_MODE;}
	inline void SetLandscapeMode(){currentUiStatus &= ~PORT_MODE;}
	
	void LoadBitmapFiles(void);
	void UnLoadBitmapFiles(void);

	void SetCurrentUIStatus(int newStatus);
	
	void InitHeader(void);
	void InitMenuBar(void);
	void InitControlPointer(void);
	
	void ResizeMainContainerPanel();
	
	void SetThumbnailBackground(void);

	void CreateOptionMenu(void);
	void CreateSortPopup(void);
	void CreateDeletePopup(void);
	void CreateUpdatePopup(void);

	Bitmap* LoadBitmap(const String& fullname);

	inline void ShowCoverFlow()
	{
		__pCoverflowCotainerPanel->SetShowState(true);
	}

	inline void HideCoverFlow()
	{
		__pCoverflowCotainerPanel->SetShowState(false);
	}

	void ResizeMenuBar(bool isFull);

	// below function is operated mutually.
	void ShowListView(bool isFull, bool isPort);
	void ShowThumbnailView(bool isFull, bool isPort);


public:
	void HideDeletePopup();
	SortPopup* __pSortPopup;
	Tizen::Ui::Controls::Popup* __pDeletePopup;

	static const RequestId REQUEST_ID_SEND = 0;

	// -----------------------------------------------

	cres_meta_info * p_meta_info;
	CMyBookShelfStoreIF * p_store_intf;

	int iIndex;
	int itotalCount;

	void StartConect(const String& pUri);
	// -----------------------------------------------

};

#endif	//_MYHONDANA_MAIN_FORM_H_
