
#ifndef _MYHONDANASETTINGFORM_H_
#define _MYHONDANASETTINGFORM_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>

#include "GlobalDefine.h"
#include "RotationPopup.h"
#include "BrightnessPopup.h"
#include "BacklightPopup.h"
#include "LoginPopup.h"
#include "BookmarkSharedPopup.h"
#include "DownloadSettingPopup.h"

class MyHondanaSettingForm
	: public Tizen::Ui::Controls::Form
	, public Tizen::Ui::IOrientationEventListener
	, public Tizen::Ui::Controls::IFormBackEventListener
	, public Tizen::Ui::Scenes::ISceneEventListener
	, public Tizen::Ui::Controls::ISectionTableViewItemEventListener
	, public Tizen::Ui::Controls::ISectionTableViewItemProviderF
	, public Tizen::System::ISettingEventListener


	// Rotation Popup Listener
	, public IRotationPopupListener
	// Brightness Popup Listener
	, public IBrightnessPopupListener
	// Backlight Popup Listener
	, public IBacklightPopupListener
	// Login Popup Listener
	, public ILoginPopupListener
	// BookmarkShared Popup Listener
	, public IBookmarkSharedPopupListener
	// Download Setting Popup Listener
	, public IDownloadSettingPopupListener
{
public:
	MyHondanaSettingForm(void);
	virtual ~MyHondanaSettingForm(void);
	bool Initialize(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	virtual void OnFormBackRequested(Tizen::Ui::Controls::Form& source);
	virtual void OnOrientationChanged(const Tizen::Ui::Control &source, Tizen::Ui::OrientationStatus orientationStatus);
	virtual void OnSceneDeactivated(const Tizen::Ui::Scenes::SceneId& currentSceneId, const Tizen::Ui::Scenes::SceneId& nextSceneId);
	virtual void OnSceneActivatedN(const Tizen::Ui::Scenes::SceneId& previousSceneId, const Tizen::Ui::Scenes::SceneId& currentSceneId, Tizen::Base::Collection::IList* pArgs);
	virtual void OnUserEventReceivedN(RequestId requestId, Tizen::Base::Collection::IList *pArgs);

	//ISettingEventLisetener
	virtual void OnSettingChanged(Tizen::Base::String& key);

	//ISectionTableViewItemProviderF
	virtual int GetSectionCount(void);
	virtual int GetItemCount(int sectionIndex);
	virtual Tizen::Ui::Controls::TableViewItem* CreateItem(int sectionIndex, int itemIndex, float itemWidth);
	virtual bool DeleteItem(int sectionIndex, int itemIndex, Tizen::Ui::Controls::TableViewItem* pItem);
	virtual void UpdateItem(int sectionIndex, int itemIndex, Tizen::Ui::Controls::TableViewItem* pItem);
	virtual Tizen::Base::String GetSectionHeader(int sectionIndex);
	virtual bool HasSectionHeader(int sectionIndex);
	virtual Tizen::Base::String GetSectionFooter(int sectionIndex);
	virtual bool HasSectionFooter(int sectionIndex);
	virtual float GetDefaultItemHeight(void);

	//ISectionTableViewItemEventListener
	virtual void OnSectionTableViewItemStateChanged(Tizen::Ui::Controls::SectionTableView& tableView, int sectionIndex, int itemIndex, Tizen::Ui::Controls::TableViewItem* pItem, Tizen::Ui::Controls::TableViewItemStatus status);
	virtual void OnSectionTableViewContextItemActivationStateChanged(Tizen::Ui::Controls::SectionTableView& tableView, int sectionIndex, int itemIndex, Tizen::Ui::Controls::TableViewContextItem* pContextItem, bool activated);

	// IRotationPopupListener
	virtual void OnRotationPopupSelected(int selectIdx);
	// IBrightnessPopupListener
	virtual void OnBrightnessPopupSelected(int selectIdx);
	// IBacklightPopupListener
	virtual void OnBacklightPopupSelected(int selectIdx);
	// ILoginPopupListener
	virtual void OnLoginPopupSelected(int selectIdx);
	// IBookmarkSharedPopupListener
	virtual void OnBookmarkSharedPopupSelected(int selectIdx);
	// IDownloadSettingPopupListener
	virtual void OnDownloadSettingPopupSelected(int selectIdx);

private:
	void InitHeader(void);
	void InitControlPointer(void);
	void ResizeControl(void);
	void RotationMenu(void);
	void BrightnessMenu(void);
	void BacklightMenu(void);
	void LoginMenu(void);
	void BookmarkSharedMenu(void);
	void DownloadSettingMenu(void);

	Tizen::Ui::Controls::Label* pTitleLabel;
	Tizen::Ui::Controls::Label* pDescriptionLabel;
	Tizen::Ui::Controls::Label* pCurrentSetTextLabel;
	Tizen::Ui::Controls::Label* pCurrentValueLabel;
	Tizen::Ui::Controls::Label* pCurrentStatusLabel;

	Tizen::Ui::Controls::SectionTableView* __pSectionTableView;

public:
	RotationPopup* __pRotationMenu;
	BrightnessPopup* __pBrightnessMenu;
	BacklightPopup* __pBacklightMenu;
	LoginPopup* __pLoginMenu;
	BookmarkSharedPopup* __pBookmarkSharedMenu;
	DownloadSettingPopup* __pDownloadSettingMenu;
};

#endif
