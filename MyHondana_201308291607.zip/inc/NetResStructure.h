/*
 * NetResStructure.h
 *
 *  Created on: Aug 14, 2013
 *      Author: Administrator
 */

#ifndef NETRESSTRUCTURE_H_
#define NETRESSTRUCTURE_H_
#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FWebJson.h>
#include <vector>
#include "GlobalDefine.h"
using namespace std;
using namespace Tizen::Base;

#define RES_RECEIVE_OK   100000
#define RES_RECEIVE_FAIL 100001

#define IMEI_CHECK_OK    110000
#define IMEI_CHECK_FAIL  110001

typedef struct _imeilist
{
	String imei;
	String dev_nm;
	String ins_dt;
}imeilist_t;

typedef struct _imei2_regist
{
	String Result;
	String reg_no;
	vector<imeilist_t *> imeilist;
	imeilist_t * get_new_imeilist()
	{
		imeilist_t * p_datalist = new (std::nothrow) imeilist_t();
		imeilist.push_back(p_datalist);
		return p_datalist;
	}
}res_imei2_regist_t;

typedef struct _imei2_update
{
	String reg_imei;
	String reg_dev_nm;
	vector<String *> del_imeilist;
}req_imei2_update_t;

typedef struct _firstitem
{
	String Result;
	String item_id;
	
}res_firstitem_t;

typedef res_firstitem_t res_nextitem_t;

typedef struct _purchase_status
{
	String Result;
	String purchase_flg;// 1:yes 2: no 3: expire
	
}res_purchase_status_t;

typedef struct _titlelist
{
	String title_id;
	String title_nm;
}titlelist_t;

typedef struct _item2coverflow
{
	String Result;
	vector<titlelist_t *> titlelist;
	titlelist_t * get_new_imeilist()
	{
		titlelist_t * p_datalist = new (std::nothrow) titlelist_t();
		titlelist.push_back(p_datalist);
		return p_datalist;
	}
}res_item2coverflow_t;

typedef struct _item2nobuylist
{
	String Result;
	String latest_item_id;
	String latest_item_nm;
	String first_item_id;
	String first_item_nm;
}res_item2nobuylist_t;

typedef struct _item2itemname
{
	String Result;
	String item_nm;
}res_item2itemname_t;

typedef struct _downloadcomplete
{
	String title_id;
	String item_id;
	String book_format_id;
	String sample_flg;
}req_downloadcomplete_t;

typedef struct _download_bsurl
{
	String Result;
	String dl_url;
}res_download_bsurl_t;

typedef struct _bookmarkList
{
	String item_id;
	String book_format_id;
	String bookmark;
}bookmarkList_t;

typedef struct _bookmark_share
{
	String user_no;
	vector<bookmarkList_t *> bookmarkList;
	bookmarkList_t * get_new_imeilist()
	{
		bookmarkList_t * p_datalist = new (std::nothrow) bookmarkList_t();
		bookmarkList.push_back(p_datalist);
		return p_datalist;
	}
}req_bookmark_share_t;

typedef struct _bookmark_delete
{
	String Result;
	String count;
}res_bookmark_delete_t;


typedef struct _bookmark_sync
{
	vector<bookmarkList_t *> datalist;
	bookmarkList_t * get_new_imeilist()
	{
		bookmarkList_t * p_datalist = new (std::nothrow) bookmarkList_t();
		datalist.push_back(p_datalist);
		return p_datalist;
	}
}res_bookmark_sync_t;

typedef struct _appstore2_url
{
	String Result;
	String URL;
	String URL2;
}res_appstore2_url_t;

typedef res_appstore2_url_t res_appstore_url_t;

#endif /* NETRESSTRUCTURE_H_ */
