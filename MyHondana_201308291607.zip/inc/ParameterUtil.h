/*
 * ParameterUtil.h
 *
 *  Created on: Aug 28, 2013
 *      Author: Administrator
 */

#ifndef PARAMETERUTIL_H_
#define PARAMETERUTIL_H_

#include <FBase.h>

class ParameterUtil {
public:
	static result DecodeBase64(const Tizen::Base::String &iInput, Tizen::Base::ByteBuffer &oOutput);
	static result EncodeBase64(const Tizen::Base::ByteBuffer &iInput, Tizen::Base::String &oOutput);
	static result StringToHashMap(const Tizen::Base::String &iStr, Tizen::Base::Collection::HashMap &oMap);
	static result HashMapToString(const Tizen::Base::Collection::HashMap &iMap, Tizen::Base::String &oStr);
};

#endif /* PARAMETERUTIL_H_ */
