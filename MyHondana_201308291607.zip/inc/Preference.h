/*
 * Preference.h
 *
 *  Created on: Aug 23, 2013
 *      Author: JEONGHUN
 */

#ifndef PREFERENCE_H_
#define PREFERENCE_H_

class Preference {
public:
	Preference();
	virtual ~Preference();
};

#endif /* PREFERENCE_H_ */
