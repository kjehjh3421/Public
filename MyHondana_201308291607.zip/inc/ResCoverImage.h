/*
 * res_coverimage.h
 *
 *  Created on: Aug 19, 2013
 *      Author: Administrator
 */

#ifndef RESCOVERIMAGE_H_
#define RESCOVERIMAGE_H_

#include <FApp.h>
#include <FBase.h>
#include <FSystem.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>
#include <FWebJson.h>
#include <vector>
#include "GlobalDefine.h"
using namespace std;
using namespace Tizen::Base;

typedef struct _data_list
{
	String title_id;
	String item_id;
	String thumbnail;
}coverimage_info_datalist_t;

class cres_coverimage
{
private:
public:
	String Result;
	vector<coverimage_info_datalist_t *> datalist;
private:
public:
	cres_coverimage();
	virtual ~cres_coverimage();
	coverimage_info_datalist_t * getNewDatalist();
};

#endif /* RES_COVERIMAGE_H_ */
