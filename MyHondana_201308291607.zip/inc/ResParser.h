/*
 * MyBookShelfParser.h
 *
 *  Created on: Aug 9, 2013
 *      Author: Administrator
 */

#ifndef RESPARSER_H_
#define RESPARSER_H_

#include "NetResStructure.h"
#include "ResCoverImage.h"
#include "ResMetaInfo.h"

using namespace Tizen::Web::Json;
using namespace Tizen::Base;

class cres_parser{
private:
	
public:

private:
	
public:
	cres_parser(void);
	virtual ~cres_parser(void);
	
	bool   string_parser(String * str);
	String TypeToString(IJsonValue * pValue, JsonType type);

	bool imei2_regist_imeilist(imeilist_t* p_imeilist, IJsonValue * pValue);
	bool imei2_regist_parser(res_imei2_regist_t * p_res_imei2_regist, String & value);
	bool Result_parser(bool * result, IJsonValue* pValue);	
	bool imei2_update_parser(bool * result, IJsonValue* pValue);
	bool imei2_check_parser(bool & result, String & str);
	bool MetaInfoParser(cres_meta_info * p_meta_info, IJsonValue* pValue);
	bool MetaInfoDataListParser(cres_meta_info * p_meta_info, meta_info_datalist_t * p_datalist, IJsonValue* pValue);
	bool MetaInfoDetailInfoParser(meta_info_detail_info_t * p_detail_info, IJsonValue* pValue);
	bool deleteitem_parser(bool * result, IJsonValue * pValue);
	bool coverimage_parser(cres_coverimage * p_coverimage_info, IJsonValue* pValue);
	bool coverimage_datalist_parser(coverimage_info_datalist_t * p_coverimage_datalist_item, IJsonValue* pValue);
	bool firstitem_parser(res_firstitem_t * firstitem, IJsonValue* pValue);
	bool purchase_status_parser(res_purchase_status_t * p_purchase_status, IJsonValue* pValue);
	bool item2_coverflow_parser(res_item2coverflow_t* p_item2coverflow, IJsonValue * pValue);
	bool item2coverflow_titlelist_parser(titlelist_t * titlelist, IJsonValue *pValue);
	bool item2nobuylist_parser(res_item2nobuylist_t * p_item2nobuylist, IJsonValue *pValue);
	bool item2itemname_parser(res_item2itemname_t * p_item2itemname, IJsonValue *pValue);
	bool download_complete_parser(bool * result, IJsonValue* pValue);
	bool download_bsurl_parser(res_download_bsurl_t * p_download_bsurl, IJsonValue *pValue);
	bool bookmark_delete_parser(res_bookmark_delete_t* p_bookmark_delete, IJsonValue *pValue);
	bool bookmark_sync_parser(res_bookmark_sync_t* p_bookmark_sync, IJsonValue *pValue);
	bool bookmark_sync_datalist_parser(bookmarkList_t* p_bookmarkList, IJsonValue *pValue);
	bool appstore2_url_parser(res_appstore2_url_t* p_appstore2_ur, IJsonValue *pValue);

};


#endif /* MYBOOKSHELFPARSER_H_ */
