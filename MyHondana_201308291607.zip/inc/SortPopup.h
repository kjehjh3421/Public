#ifndef _SORTPOPUP_H_
#define _SORTPOPUP_H_

#include <FBase.h>
#include <FUi.h>
#include <FMedia.h>
#include <FUi.h>
#include <FUiIme.h>
#include <FGraphics.h>
#include <gl.h>

using namespace Tizen::Graphics;

class ISortPopupListener
{
public:
	virtual ~ISortPopupListener() {}

	virtual void OnSortPopupSelected(int selectIdx) = 0;
};

class SortPopup
	: public Tizen::Ui::Controls::Popup
	, public Tizen::Ui::IPropagatedKeyEventListener
	, public Tizen::Ui::IActionEventListener
{
private:
	ISortPopupListener* __pListener;

public:
	bool chkFirst = true;

	const int sort_text_size = 34;
	const int sort_button_height = 96;
	const int sort_button_width = 450;

	SortPopup(void);
	SortPopup(ISortPopupListener * pListener);
	virtual ~SortPopup(void);
	virtual result OnInitializing(void);
	virtual result OnTerminating(void);

	void ShowPopup(void);
	void HidePopup(void);

	void FirstStart(void);
	virtual bool OnKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyPressed(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool OnPreviewKeyReleased(Tizen::Ui::Control& source, const Tizen::Ui::KeyEventInfo& keyEventInfo);
	virtual bool TranslateKeyEventInfo(Tizen::Ui::Control& source, Tizen::Ui::KeyEventInfo& keyEventInfo);

	virtual void OnActionPerformed(const Tizen::Ui::Control& source, int actionId);

	Bitmap* __pBitmapSortNormal[1];
	Bitmap* __pBitmapSortPopupbg[2];

	Tizen::Ui::Controls::Button* __pCheckList_Date;
	Tizen::Ui::Controls::Button* __pCheckList_Title;
	Tizen::Ui::Controls::Button* __pCheckList_Author;
	Tizen::Ui::Controls::Button* __pCheckList_Save;

	static const int ID_BUTTON_CLOSE_POPUP = 9000;
	static const int ID_SORT_DATE_SELECTED = ID_BUTTON_CLOSE_POPUP + 1;
	static const int ID_SORT_TITLE_SELECTED = ID_BUTTON_CLOSE_POPUP + 2;
	static const int ID_SORT_AUTHOR_SELECTED = ID_BUTTON_CLOSE_POPUP + 3;
	static const int ID_SORT_SAVE_SELECTED = ID_BUTTON_CLOSE_POPUP + 4;
};

#endif // _SORTPOPUP_H_
