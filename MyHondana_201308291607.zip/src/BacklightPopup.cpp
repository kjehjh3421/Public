#include "BacklightPopup.h"
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "SceneRegister.h"
#include "MyHondanaSettingForm.h"
#include "AppResourceId.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::System;

bool isFirstStart=true;

const String SETTING_INFO_KEY_PREFIX = L"http://tizen.org/setting/";

BacklightPopup::BacklightPopup(void)
{
}

BacklightPopup::BacklightPopup(IBacklightPopupListener * pListener)
{
	__pListener = pListener;
}

BacklightPopup::~BacklightPopup(void)
{
	SettingInfo::RemoveSettingEventListener(*this);
}

bool
BacklightPopup::Initialize(void)
{
	Construct(L"IDP_SETTING_BACKLIGHT_POPUP");
	return true;
}

result
BacklightPopup::OnInitializing(void)
{
	result r = E_SUCCESS;

	SettingInfo::AddSettingEventListener(*this);
	SetPropagatedKeyEventListener(this);

	if(isFirstStart==true)
	{
		SetControl();
		isFirstStart=false;
		InitializeValue();
	}
	ControlSetting();
	return r;
}

result
BacklightPopup::OnTerminating(void)
{
	result r = E_SUCCESS;

	return r;
}

void
BacklightPopup::InitializeValue(void)
{
	int a;

	String keyName = SETTING_INFO_KEY_PREFIX;
	keyName.Append("screen.backlight.time");
	if(SettingInfo::GetValue(keyName, a)==15)
		__pBacklight_CheckButton_15Sec ->SetSelected(true);
	else if(SettingInfo::GetValue(keyName, a)==30)
		__pBacklight_CheckButton_30Sec ->SetSelected(true);
	else if(SettingInfo::GetValue(keyName, a)==60)
		__pBacklight_CheckButton_60Sec ->SetSelected(true);
	else if(SettingInfo::GetValue(keyName, a)==120)
		__pBacklight_CheckButton_120Sec ->SetSelected(true);
	else if(SettingInfo::GetValue(keyName, a)==300)
		__pBacklight_CheckButton_300Sec ->SetSelected(true);
	else if(SettingInfo::GetValue(keyName, a)==600)
		__pBacklight_CheckButton_600Sec ->SetSelected(true);
}

void
BacklightPopup::SetControl(void)
{
	__pBacklight_CheckButton_15Sec	= static_cast <CheckButton *>	(GetControl(IDC_BACKLIGHT_CHECKBUTTON_15, true));
	__pBacklight_CheckButton_30Sec	= static_cast <CheckButton *>	(GetControl(IDC_BACKLIGHT_CHECKBUTTON_30, true));
	__pBacklight_CheckButton_60Sec 	= static_cast <CheckButton *>	(GetControl(IDC_BACKLIGHT_CHECKBUTTON_60, true));
	__pBacklight_CheckButton_120Sec = static_cast <CheckButton *>	(GetControl(IDC_BACKLIGHT_CHECKBUTTON_120, true));
	__pBacklight_CheckButton_300Sec = static_cast <CheckButton *>	(GetControl(IDC_BACKLIGHT_CHECKBUTTON_300, true));
	__pBacklight_CheckButton_600Sec = static_cast <CheckButton *>	(GetControl(IDC_BACKLIGHT_CHECKBUTTON_600, true));

	__pBacklight_Ok_Button     		= static_cast <Button *>		(GetControl(IDC_BACKLIGHT_BUTTON_OK, true));
	__pBacklight_Cancel_Button 		= static_cast <Button *>		(GetControl(IDC_BACKLIGHT_BUTTON_CANCEL, true));
}

void
BacklightPopup::ControlSetting(void)
{
	__pBacklight_CheckButton_15Sec->SetActionId(ID_SCREEN_BACKLIGHTTIME_VALUE_15, ID_SCREEN_BACKLIGHTTIME_VALUE_15, ID_SCREEN_BACKLIGHTTIME_VALUE_15);
	__pBacklight_CheckButton_15Sec->AddActionEventListener(*this);

	__pBacklight_CheckButton_30Sec->SetActionId(ID_SCREEN_BACKLIGHTTIME_VALUE_30, ID_SCREEN_BACKLIGHTTIME_VALUE_30, ID_SCREEN_BACKLIGHTTIME_VALUE_30);
	__pBacklight_CheckButton_30Sec->AddActionEventListener(*this);

	__pBacklight_CheckButton_60Sec->SetActionId(ID_SCREEN_BACKLIGHTTIME_VALUE_60, ID_SCREEN_BACKLIGHTTIME_VALUE_60, ID_SCREEN_BACKLIGHTTIME_VALUE_60);
	__pBacklight_CheckButton_60Sec->AddActionEventListener(*this);

	__pBacklight_CheckButton_120Sec->SetActionId(ID_SCREEN_BACKLIGHTTIME_VALUE_120, ID_SCREEN_BACKLIGHTTIME_VALUE_120, ID_SCREEN_BACKLIGHTTIME_VALUE_120);
	__pBacklight_CheckButton_120Sec->AddActionEventListener(*this);

	__pBacklight_CheckButton_300Sec->SetActionId(ID_SCREEN_BACKLIGHTTIME_VALUE_300, ID_SCREEN_BACKLIGHTTIME_VALUE_300, ID_SCREEN_BACKLIGHTTIME_VALUE_300);
	__pBacklight_CheckButton_300Sec->AddActionEventListener(*this);

	__pBacklight_CheckButton_600Sec->SetActionId(ID_SCREEN_BACKLIGHTTIME_VALUE_600, ID_SCREEN_BACKLIGHTTIME_VALUE_600, ID_SCREEN_BACKLIGHTTIME_VALUE_600);
	__pBacklight_CheckButton_600Sec->AddActionEventListener(*this);

	__pBacklight_Cancel_Button->SetActionId(ID_BACKLIGHT_CANCEL_BUTTON);
	__pBacklight_Cancel_Button->AddActionEventListener(*this);

	__pBacklight_Ok_Button->SetActionId(ID_BACKLIGHT_SET_BUTTON);
	__pBacklight_Ok_Button->AddActionEventListener(*this);
}

void
BacklightPopup::ShowPopup(void)
{
	SetShowState(true);
	Show();
}

void
BacklightPopup::HidePopup(void)
{
	SetShowState(false);
	Invalidate(true);
}

void
BacklightPopup::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	String keyName = SETTING_INFO_KEY_PREFIX;
	keyName.Append("screen.backlight.time");

	static int checkNum = 0;

	switch (actionId)
	{
		case ID_SCREEN_BACKLIGHTTIME_VALUE_15:
		case ID_SCREEN_BACKLIGHTTIME_VALUE_30:
		case ID_SCREEN_BACKLIGHTTIME_VALUE_60:
		case ID_SCREEN_BACKLIGHTTIME_VALUE_120:
		case ID_SCREEN_BACKLIGHTTIME_VALUE_300:
		case ID_SCREEN_BACKLIGHTTIME_VALUE_600:
			break;
		case ID_BACKLIGHT_CANCEL_BUTTON:
			{
				if(checkNum == 1)
				{
					__pBacklight_CheckButton_15Sec->SetSelected(true);
					__pBacklight_CheckButton_30Sec->SetSelected(false);
					__pBacklight_CheckButton_60Sec->SetSelected(false);
					__pBacklight_CheckButton_120Sec->SetSelected(false);
					__pBacklight_CheckButton_300Sec->SetSelected(false);
					__pBacklight_CheckButton_600Sec->SetSelected(false);
				}
				else if(checkNum == 2)
				{
					__pBacklight_CheckButton_15Sec->SetSelected(false);
					__pBacklight_CheckButton_30Sec->SetSelected(true);
					__pBacklight_CheckButton_60Sec->SetSelected(false);
					__pBacklight_CheckButton_120Sec->SetSelected(false);
					__pBacklight_CheckButton_300Sec->SetSelected(false);
					__pBacklight_CheckButton_600Sec->SetSelected(false);
				}
				else if(checkNum == 3)
				{
					__pBacklight_CheckButton_15Sec->SetSelected(false);
					__pBacklight_CheckButton_30Sec->SetSelected(false);
					__pBacklight_CheckButton_60Sec->SetSelected(true);
					__pBacklight_CheckButton_120Sec->SetSelected(false);
					__pBacklight_CheckButton_300Sec->SetSelected(false);
					__pBacklight_CheckButton_600Sec->SetSelected(false);
				}
				else if(checkNum == 4)
				{
					__pBacklight_CheckButton_15Sec->SetSelected(false);
					__pBacklight_CheckButton_30Sec->SetSelected(false);
					__pBacklight_CheckButton_60Sec->SetSelected(false);
					__pBacklight_CheckButton_120Sec->SetSelected(true);
					__pBacklight_CheckButton_300Sec->SetSelected(false);
					__pBacklight_CheckButton_600Sec->SetSelected(false);
				}
				else if(checkNum == 5)
				{
					__pBacklight_CheckButton_15Sec->SetSelected(false);
					__pBacklight_CheckButton_30Sec->SetSelected(false);
					__pBacklight_CheckButton_60Sec->SetSelected(false);
					__pBacklight_CheckButton_120Sec->SetSelected(false);
					__pBacklight_CheckButton_300Sec->SetSelected(true);
					__pBacklight_CheckButton_600Sec->SetSelected(false);
				}
				else if(checkNum == 6)
				{
					__pBacklight_CheckButton_15Sec->SetSelected(false);
					__pBacklight_CheckButton_30Sec->SetSelected(false);
					__pBacklight_CheckButton_60Sec->SetSelected(false);
					__pBacklight_CheckButton_120Sec->SetSelected(false);
					__pBacklight_CheckButton_300Sec->SetSelected(false);
					__pBacklight_CheckButton_600Sec->SetSelected(true);
				}
				HidePopup();
			}
			break;
		case ID_BACKLIGHT_SET_BUTTON:
			{
				if(__pBacklight_CheckButton_15Sec->IsSelected()==true)
				{
					SettingInfo::SetValue(keyName, 15);
					checkNum = 1;

//					__pListener->OnBacklightPopupSelected(1);
				}
				else if(__pBacklight_CheckButton_30Sec->IsSelected()==true)
				{
					SettingInfo::SetValue(keyName, 30);
					checkNum = 2;
//					__pListener->OnBacklightPopupSelected(2);
				}
				else if(__pBacklight_CheckButton_60Sec->IsSelected()==true)
				{
					SettingInfo::SetValue(keyName, 60);
					checkNum = 3;
//					__pListener->OnBacklightPopupSelected(3);
				}
				else if(__pBacklight_CheckButton_120Sec->IsSelected()==true)
				{
					SettingInfo::SetValue(keyName, 120);
					checkNum = 4;
//					__pListener->OnBacklightPopupSelected(4);
				}
				else if(__pBacklight_CheckButton_300Sec->IsSelected()==true)
				{
					SettingInfo::SetValue(keyName, 300);
					checkNum = 5;
//					__pListener->OnBacklightPopupSelected(5);
				}
				else if(__pBacklight_CheckButton_600Sec->IsSelected()==true)
				{
					SettingInfo::SetValue(keyName, 600);
					checkNum = 6;
//					__pListener->OnBacklightPopupSelected(6);
				}
				HidePopup();
			}
			break;
	}
}

bool
BacklightPopup::OnKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BacklightPopup::OnKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	if ((keyEventInfo.GetKeyCode() == KEY_ESC ||keyEventInfo.GetKeyCode() == KEY_BACK) && source.GetShowState() == true)
	{
		source.SetShowState(false);
	}
	return false;
}

bool
BacklightPopup::OnPreviewKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BacklightPopup::OnPreviewKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BacklightPopup::TranslateKeyEventInfo(Control& source, KeyEventInfo& keyEventInfo)
{
	return false;
}

// IScreenEventListener
void
BacklightPopup::OnScreenOn(void)
{

}
void
BacklightPopup::OnScreenOff(void)
{
}

void
BacklightPopup::OnScreenBacklightChanged(int brightness)
{
//	String brightText;

//	__pSliderBrightness->SetValue(brightness);
//	__pSliderBrightness->Draw();
//
//	brightText.Append(L"Brightness: ");
//	brightText.Append(brightness);
//	__pLabelBrightness->SetText(brightText);
//	__pLabelBrightness->Draw();
//
//	__pSliderBrightness->Show();
//	__pLabelBrightness->Show();
}

void
BacklightPopup::OnSettingChanged(String& key)
{
}

void
BacklightPopup::OnResultReceivedForSetValueAsync(const Tizen::Base::String& key, result r)
{
}
