
#include "BookmarkSharedPopup.h"
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "SceneRegister.h"
#include "MyHondanaSettingForm.h"
#include "AppResourceId.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::System;

const String SETTING_INFO_KEY_PREFIX = L"http://tizen.org/setting/";

BookmarkSharedPopup::BookmarkSharedPopup(void)
{
}

BookmarkSharedPopup::BookmarkSharedPopup(IBookmarkSharedPopupListener * pListener)
{
	__pListener = pListener;
}

BookmarkSharedPopup::~BookmarkSharedPopup(void)
{
}

bool
BookmarkSharedPopup::Initialize(void)
{
	Construct(L"IDP_SETTING_BOOKMARKSHARED_POPUP");
	return true;
}

result
BookmarkSharedPopup::OnInitializing(void)
{
	result r = E_SUCCESS;

	SetPropagatedKeyEventListener(this);

	SetControl();
	AddControl();

	return r;
}

result
BookmarkSharedPopup::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
BookmarkSharedPopup::SetControl(void)
{
	__pBookmarkShared_Button_Link = static_cast <Button *>(GetControl(IDC_BOOKMARKSHARED_BUTTON_LINK, true));
	__pBookmarkShared_Button_Send = static_cast <Button *>(GetControl(IDC_BOOKMARKSHARED_BUTTON_SEND, true));
	__pBookmarkShared_Button_Reception = static_cast <Button *>(GetControl(IDC_BOOKMARKSHARED_BUTTON_RECEPTION, true));
	__pBookmarkShared_Button_Delete = static_cast <Button *>(GetControl(IDC_BOOKMARKSHARED_BUTTON_DELETE, true));
	__pBookmarkShared_Cancel_Button = static_cast <Button *>(GetControl(IDC_BOOKMARKSHARED_BUTTON_CANCEL, true));
}

void
BookmarkSharedPopup::AddControl(void)
{
	__pBookmarkShared_Button_Link->SetActionId(ID_BOOKMARKSHARED_BUTTON_LINK);
	__pBookmarkShared_Button_Link->AddActionEventListener(*this);

	__pBookmarkShared_Button_Send->SetActionId(ID_BOOKMARKSHARED_BUTTON_SEND);
	__pBookmarkShared_Button_Send->AddActionEventListener(*this);

	__pBookmarkShared_Button_Reception->SetActionId(ID_BOOKMARKSHARED_BUTTON_RECEPTION);
	__pBookmarkShared_Button_Reception->AddActionEventListener(*this);

	__pBookmarkShared_Button_Delete->SetActionId(ID_BOOKMARKSHARED_BUTTON_DELETE);
	__pBookmarkShared_Button_Delete->AddActionEventListener(*this);

	__pBookmarkShared_Cancel_Button->SetActionId(ID_BOOKMARKSHARED_CANCEL_BUTTON);
	__pBookmarkShared_Cancel_Button->AddActionEventListener(*this);
}

void
BookmarkSharedPopup::ShowPopup(void)
{
	SetShowState(true);
	Show();
}

void
BookmarkSharedPopup::HidePopup(void)
{
	SetShowState(false);
	Invalidate(true);
}

void
BookmarkSharedPopup::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	switch (actionId)
	{
		case ID_BOOKMARKSHARED_CANCEL_BUTTON:
			{
				HidePopup();
			}
			break;
		case ID_BOOKMARKSHARED_BUTTON_LINK:
			{

			}
			break;
		case ID_BOOKMARKSHARED_BUTTON_SEND:
			{
			}
			break;
		case ID_BOOKMARKSHARED_BUTTON_RECEPTION:
			{
			}
			break;
		case ID_BOOKMARKSHARED_BUTTON_DELETE:
			{
			}
			break;
	}
}

bool
BookmarkSharedPopup::OnKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BookmarkSharedPopup::OnKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	if ((keyEventInfo.GetKeyCode() == KEY_ESC ||keyEventInfo.GetKeyCode() == KEY_BACK) && source.GetShowState() == true)
	{
		source.SetShowState(false);
	}
	return false;
}

bool
BookmarkSharedPopup::OnPreviewKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BookmarkSharedPopup::OnPreviewKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
BookmarkSharedPopup::TranslateKeyEventInfo(Control& source, KeyEventInfo& keyEventInfo)
{
	return false;
}
