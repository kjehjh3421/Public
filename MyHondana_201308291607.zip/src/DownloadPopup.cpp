
#include "DownloadPopup.h"
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "SceneRegister.h"
#include "MyHondanaSettingForm.h"
#include "AppResourceId.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::System;

const String SETTING_INFO_KEY_PREFIX = L"http://tizen.org/setting/";

DownloadPopup::DownloadPopup(void)
{
}

DownloadPopup::DownloadPopup(IDownloadPopupListener * pListener)
{
	__pListener = pListener;
}

DownloadPopup::~DownloadPopup(void)
{
}

bool
DownloadPopup::Initialize(void)
{
	Construct(L"IDP_DOWNLOAD_POPUP");
	return true;
}

result
DownloadPopup::OnInitializing(void)
{
	result r = E_SUCCESS;

	SetPropagatedKeyEventListener(this);

//	if(isFirstStart==true)
//	{
//		isFirstStart=false;
//	}
	SetControl();

//	InitializeValue();
	ControlSetting();
	return r;
}

result
DownloadPopup::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
DownloadPopup::SetControl(void)
{
	__pDownload_Label_Description = static_cast <Label *>(GetControl(IDC_DOWNLOAD_LABEL_DESCRIPTION, true));
	__pDownload_Label_Destination = static_cast <Label *>(GetControl(IDC_DOWNLOAD_LABEL_DESTINATION, true));

	__pDownload_Button_External = static_cast <Button *>(GetControl(IDC_DOWNLOAD_BUTTON_EXTERNAL, true));
	__pDownload_Button_Internal = static_cast <Button *>(GetControl(IDC_DOWNLOAD_BUTTON_INTERNAL, true));
	__pDownload_Button_Notsave = static_cast <Button *>(GetControl(IDC_DOWNLOAD_BUTTON_NOTSAVE, true));

	__pDownload_CheckButton_Nextshow = static_cast <CheckButton *>(GetControl(IDC_DOWNLOAD_CHECKBUTTON_NEXTSHOW, true));

	__pDownload_Button_Cancel = static_cast <Button *>(GetControl(IDC_DOWNLOAD_BUTTON_CANCEL, true));
	__pDownload_Button_Download = static_cast <Button *>(GetControl(IDC_DOWNLOAD_BUTTON_DOWNLOAD, true));
}

void
DownloadPopup::ControlSetting(void)
{
	__pDownload_Label_Description->SetText(L"");
	__pDownload_Label_Destination->SetText(L"");

	__pDownload_Button_External->SetActionId(ID_DOWNLOAD_BUTTON_EXTERNAL);
	__pDownload_Button_External->AddActionEventListener(*this);

	__pDownload_Button_Internal->SetActionId(ID_DOWNLOAD_BUTTON_INTERNAL);
	__pDownload_Button_Internal->AddActionEventListener(*this);

	__pDownload_Button_Notsave->SetActionId(ID_DOWNLOAD_BUTTON_NOTSAVE);
	__pDownload_Button_Notsave->AddActionEventListener(*this);

	__pDownload_CheckButton_Nextshow->SetActionId(ID_DOWNLOAD_CHECKBUTTON_NEXTSHOW, ID_DOWNLOAD_CHECKBUTTON_NEXTSHOW, ID_DOWNLOAD_CHECKBUTTON_NEXTSHOW);
	__pDownload_CheckButton_Nextshow->AddActionEventListener(*this);

	__pDownload_Button_Cancel->SetActionId(ID_DOWNLOAD_BUTTON_CANCEL);
	__pDownload_Button_Cancel->AddActionEventListener(*this);

	__pDownload_Button_Download->SetActionId(ID_DOWNLOAD_BUTTON_DOWNLOAD);
	__pDownload_Button_Download->AddActionEventListener(*this);
}

void
DownloadPopup::ShowPopup(void)
{
	SetShowState(true);
	Show();
}

void
DownloadPopup::HidePopup(void)
{
	SetShowState(false);
	Invalidate(true);
}

void
DownloadPopup::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	String keyName = SETTING_INFO_KEY_PREFIX;
	keyName.Append("screen.rotation.auto");

	static int checkId;
	static int checkNum = 0;

//	switch (actionId)
//	{
//		case ID_DOWNLOAD_CANCEL_BUTTON:
//			{
//				if(checkNum == 1)
//				{
//
//				}
//				else if(checkNum == 2)
//				{
//
//				}
//				HidePopup();
//			}
//			break;
//		case ID_DOWNLOAD_DOCOMODOWNLOAD_BUTTON:
//			{
//
//			}
//			break;
//	}
}

bool
DownloadPopup::OnKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
DownloadPopup::OnKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	if ((keyEventInfo.GetKeyCode() == KEY_ESC ||keyEventInfo.GetKeyCode() == KEY_BACK) && source.GetShowState() == true)
	{
		source.SetShowState(false);
	}
	return false;
}

bool
DownloadPopup::OnPreviewKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
DownloadPopup::OnPreviewKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
DownloadPopup::TranslateKeyEventInfo(Control& source, KeyEventInfo& keyEventInfo)
{
	return false;
}
