
#include "DownloadSettingPopup.h"
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "SceneRegister.h"
#include "MyHondanaSettingForm.h"
#include "AppResourceId.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::System;

const String SETTING_INFO_KEY_PREFIX = L"http://tizen.org/setting/";

DownloadSettingPopup::DownloadSettingPopup(void)
{
}

DownloadSettingPopup::DownloadSettingPopup(IDownloadSettingPopupListener * pListener)
{
	__pListener = pListener;
}

DownloadSettingPopup::~DownloadSettingPopup(void)
{
}

bool
DownloadSettingPopup::Initialize(void)
{
	Construct(L"IDP_SETTING_DOWNLOADSETTING_POPUP");
	return true;
}

result
DownloadSettingPopup::OnInitializing(void)
{
	result r = E_SUCCESS;

	SetPropagatedKeyEventListener(this);

	SetControl();
	AddControl();

	return r;
}

result
DownloadSettingPopup::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
DownloadSettingPopup::SetControl(void)
{
	__pDownloadSetting_Button_Link = static_cast <Button *>(GetControl(IDC_DOWNLOADSETTING_BUTTON_LINK, true));
	__pDownloadSetting_CheckButton_Select = static_cast <CheckButton *>(GetControl(IDC_DOWNLOADSETTING_CHECKBUTTON_SELECT, true));
	__pDownloadSetting_CheckButton_Inmemory = static_cast <CheckButton *>(GetControl(IDC_DOWNLOADSETTING_CHECKBUTTON_INMEMORY, true));
	__pDownloadSetting_CheckButton_Outmemory = static_cast <CheckButton *>(GetControl(IDC_DOWNLOADSETTING_CHECKBUTTON_OUTMEMORY, true));
	__pDownloadSetting_CheckButton_Notmemory = static_cast <CheckButton *>(GetControl(IDC_DOWNLOADSETTING_CHECKBUTTON_NOTMEMORY, true));
	__pDownloadSetting_Button_Ok = static_cast <Button *>(GetControl(IDC_DOWNLOADSETTING_BUTTON_OK, true));
	__pDownloadSetting_Button_Cancel = static_cast <Button *>(GetControl(IDC_DOWNLOADSETTING_BUTTON_CANCEL, true));
}

void
DownloadSettingPopup::AddControl(void)
{
	__pDownloadSetting_Button_Link->SetActionId(ID_DOWNLOADSETTING_BUTTON_LINK);
	__pDownloadSetting_Button_Link->AddActionEventListener(*this);

	__pDownloadSetting_CheckButton_Select->SetActionId(ID_DOWNLOADSETTING_BUTTON_SELECT, ID_DOWNLOADSETTING_BUTTON_SELECT, ID_DOWNLOADSETTING_BUTTON_SELECT);
	__pDownloadSetting_CheckButton_Select->AddActionEventListener(*this);

	__pDownloadSetting_CheckButton_Inmemory->SetActionId(ID_DOWNLOADSETTING_BUTTON_INMEMORY, ID_DOWNLOADSETTING_BUTTON_INMEMORY, ID_DOWNLOADSETTING_BUTTON_INMEMORY);
	__pDownloadSetting_CheckButton_Inmemory->AddActionEventListener(*this);

	__pDownloadSetting_CheckButton_Outmemory->SetActionId(ID_DOWNLOADSETTING_BUTTON_OUTMEMORY, ID_DOWNLOADSETTING_BUTTON_OUTMEMORY, ID_DOWNLOADSETTING_BUTTON_OUTMEMORY);
	__pDownloadSetting_CheckButton_Outmemory->AddActionEventListener(*this);

	__pDownloadSetting_CheckButton_Notmemory->SetActionId(ID_DOWNLOADSETTING_BUTTON_NOTMEMORY, ID_DOWNLOADSETTING_BUTTON_NOTMEMORY, ID_DOWNLOADSETTING_BUTTON_NOTMEMORY);
	__pDownloadSetting_CheckButton_Notmemory->AddActionEventListener(*this);

	__pDownloadSetting_Button_Ok->SetActionId(ID_DOWNLOADSETTING_BUTTON_OK);
	__pDownloadSetting_Button_Ok->AddActionEventListener(*this);

	__pDownloadSetting_Button_Cancel->SetActionId(ID_DOWNLOADSETTING_BUTTON_CANCEL);
	__pDownloadSetting_Button_Cancel->AddActionEventListener(*this);
}

void
DownloadSettingPopup::ShowPopup(void)
{
	SetShowState(true);
	Show();
}

void
DownloadSettingPopup::HidePopup(void)
{
	SetShowState(false);
	Invalidate(true);
}

void
DownloadSettingPopup::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	static int checkNum = 0;

	switch (actionId)
	{
		case ID_DOWNLOADSETTING_BUTTON_OK:
			{
				if(__pDownloadSetting_CheckButton_Select->IsSelected()==true)
				{

					checkNum = 1;
//					__pListener->OnBacklightPopupSelected(1);
				}
				else if(__pDownloadSetting_CheckButton_Inmemory->IsSelected()==true)
				{

					checkNum = 2;
//					__pListener->OnBacklightPopupSelected(2);
				}
				else if(__pDownloadSetting_CheckButton_Outmemory->IsSelected()==true)
				{

					checkNum = 3;
//					__pListener->OnBacklightPopupSelected(3);
				}
				else if(__pDownloadSetting_CheckButton_Notmemory->IsSelected()==true)
				{

					checkNum = 4;
//					__pListener->OnBacklightPopupSelected(4);
				}
				HidePopup();
			}
			break;
		case ID_DOWNLOADSETTING_BUTTON_CANCEL:
			{
				if(checkNum == 1)
				{
					__pDownloadSetting_CheckButton_Select->SetSelected(true);
					__pDownloadSetting_CheckButton_Inmemory->SetSelected(false);
					__pDownloadSetting_CheckButton_Outmemory->SetSelected(false);
					__pDownloadSetting_CheckButton_Notmemory->SetSelected(false);
				}
				else if(checkNum == 2)
				{
					__pDownloadSetting_CheckButton_Select->SetSelected(false);
					__pDownloadSetting_CheckButton_Inmemory->SetSelected(true);
					__pDownloadSetting_CheckButton_Outmemory->SetSelected(false);
					__pDownloadSetting_CheckButton_Notmemory->SetSelected(false);
				}
				else if(checkNum == 3)
				{
					__pDownloadSetting_CheckButton_Select->SetSelected(false);
					__pDownloadSetting_CheckButton_Inmemory->SetSelected(false);
					__pDownloadSetting_CheckButton_Outmemory->SetSelected(true);
					__pDownloadSetting_CheckButton_Notmemory->SetSelected(false);
				}
				else if(checkNum == 4)
				{
					__pDownloadSetting_CheckButton_Select->SetSelected(false);
					__pDownloadSetting_CheckButton_Inmemory->SetSelected(false);
					__pDownloadSetting_CheckButton_Outmemory->SetSelected(false);
					__pDownloadSetting_CheckButton_Notmemory->SetSelected(true);
				}
				HidePopup();
			}
			break;
		case ID_DOWNLOADSETTING_BUTTON_LINK:
			{
			}
			break;
		case ID_DOWNLOADSETTING_BUTTON_SELECT:
			{
			}
			break;
		case ID_DOWNLOADSETTING_BUTTON_INMEMORY:
			{
			}
			break;
		case ID_DOWNLOADSETTING_BUTTON_OUTMEMORY:
			{
			}
			break;
		case ID_DOWNLOADSETTING_BUTTON_NOTMEMORY:
			{
			}
			break;
	}
}

bool
DownloadSettingPopup::OnKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
DownloadSettingPopup::OnKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	if ((keyEventInfo.GetKeyCode() == KEY_ESC ||keyEventInfo.GetKeyCode() == KEY_BACK) && source.GetShowState() == true)
	{
		source.SetShowState(false);
	}
	return false;
}

bool
DownloadSettingPopup::OnPreviewKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
DownloadSettingPopup::OnPreviewKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
DownloadSettingPopup::TranslateKeyEventInfo(Control& source, KeyEventInfo& keyEventInfo)
{
	return false;
}
