
#include "LoginPopup.h"
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "SceneRegister.h"
#include "MyHondanaSettingForm.h"
#include "AppResourceId.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::System;

const String SETTING_INFO_KEY_PREFIX = L"http://tizen.org/setting/";

LoginPopup::LoginPopup(void)
{
}

LoginPopup::LoginPopup(ILoginPopupListener * pListener)
{
	__pListener = pListener;
}

LoginPopup::~LoginPopup(void)
{
}

bool
LoginPopup::Initialize(void)
{
	Construct(L"IDP_SETTING_LOGIN_POPUP");
	return true;
}

result
LoginPopup::OnInitializing(void)
{
	result r = E_SUCCESS;

	SetPropagatedKeyEventListener(this);

//	if(isFirstStart==true)
//	{
//		isFirstStart=false;
//	}
	SetControl();

//	InitializeValue();
	ControlSetting();
	return r;
}

result
LoginPopup::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
LoginPopup::SetControl(void)
{

	__pLogin_DocomoLogin_Button = static_cast <Button *>(GetControl(IDC_LOGIN_BUTTON_DOCOMOLOGIN, true));
	__pLogin_Cancel_Button = static_cast <Button *>(GetControl(IDC_LOGIN_BUTTON_CANCEL, true));
}

void
LoginPopup::ControlSetting(void)
{
	__pLogin_Cancel_Button->SetActionId(ID_LOGIN_CANCEL_BUTTON);
	__pLogin_Cancel_Button->AddActionEventListener(*this);

	__pLogin_DocomoLogin_Button->SetActionId(ID_LOGIN_DOCOMOLOGIN_BUTTON);
	__pLogin_DocomoLogin_Button->AddActionEventListener(*this);
}

void
LoginPopup::ShowPopup(void)
{
	SetShowState(true);
	Show();
}

void
LoginPopup::HidePopup(void)
{
	SetShowState(false);
	Invalidate(true);
}

void
LoginPopup::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	String keyName = SETTING_INFO_KEY_PREFIX;
	keyName.Append("screen.rotation.auto");

	static int checkId;
	static int checkNum = 0;

	switch (actionId)
	{
		case ID_LOGIN_CANCEL_BUTTON:
			{
				if(checkNum == 1)
				{

				}
				else if(checkNum == 2)
				{

				}
				HidePopup();
			}
			break;
		case ID_LOGIN_DOCOMOLOGIN_BUTTON:
			{

			}
			break;
	}
}

bool
LoginPopup::OnKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
LoginPopup::OnKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	if ((keyEventInfo.GetKeyCode() == KEY_ESC ||keyEventInfo.GetKeyCode() == KEY_BACK) && source.GetShowState() == true)
	{
		source.SetShowState(false);
	}
	return false;
}

bool
LoginPopup::OnPreviewKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
LoginPopup::OnPreviewKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
LoginPopup::TranslateKeyEventInfo(Control& source, KeyEventInfo& keyEventInfo)
{
	return false;
}
