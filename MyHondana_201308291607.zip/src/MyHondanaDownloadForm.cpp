#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "MyHondanaMainForm.h"
#include "MyHondanaDownloadForm.h"
#include "SceneRegister.h"
#include "AppResourceId.h"
#include "FUiLayout.h"
#include "FUiRelativeLayout.h"
#include "FUiVerticalBoxLayout.h"
#include "FUiHorizontalBoxLayout.h"
#include "FUiGridLayout.h"
#include "FMedia.h"
#include <FSystem.h>

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Graphics;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Media;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::Ui::Animations;
using namespace Tizen::Base::Collection;
using namespace Tizen::System;

const wchar_t LIST_IMAGE_PATH1[] = L"book02.png";
const wchar_t LIST_IMAGE_PATH2[] = L"book02.png";
const wchar_t LIST_IMAGE_PATH3[] = L"list_new_book_icon.png";
const wchar_t LIST_IMAGE_PATH4[] = L"grid_new_book_icon.png";
const wchar_t LIST_IMAGE_PATH5[] = L"list_bottom_text.png";
const wchar_t LIST_IMAGE_PATH6[] = L"grid_bottom_text.png";

const wchar_t HEADER_BACKGROUND[] = L"header_background.png";

namespace
{
static const int SIZE_OF_LABEL_Y = 40;

bool isPortrait = true;
bool isFirstStart = true;

static int isChecked[20];
static int __status[20];
	enum
	{
		BOOK_STATUS_TOTAL_OPEN = 100,
		BOOK_STATUS_TOTAL_CLOSE = BOOK_STATUS_TOTAL_OPEN + 0x01,

		ID_BUTTON_BASE     = 110,
		ID_BUTTON_CANCEL = ID_BUTTON_BASE + 0x00,
		ID_BUTTON_DOWNLOAD = ID_BUTTON_BASE + 0x01,
		ID_BUTTON_ACTIONBAR = ID_BUTTON_BASE + 0x02,
		ID_BUTTON_OPTION = ID_BUTTON_BASE + 0x03,
	};

int mBookDownloadMode = BOOK_STATUS_TOTAL_OPEN;
//int mBookOrientationMode = PORTRAIT;
}

struct BOOK_LIST_INFO {
	const Tizen::Base::String  		itemTitleText;
	const Tizen::Base::String		itemAuthorText;
	bool recommend;
	bool readbook;
	int filesize;
	bool topbook;
} BOOK_LIST_INFO[]= {
	 { L"0", L"いわさきなつみ", false, true, null, true }
	,{ L"1", L"わさきみ", false, false, 16, false }
	,{ L"2", L"わさきみ", false, false, 20, false }
	,{ L"3", L"わさきみ", false, false, 21, false }
	,{ L"4", L"わきみ", false, true, null, true }
	,{ L"5", L"わきみ", false, false, 11, false }
	,{ L"6", L"わさみ", false, false, 12, false }
	,{ L"7", L"さきみ", false, true, null, true }
	,{ L"8", L"わさみ", false, false, 10, false }
	,{ L"9", L"わさ", false, false, 22, false }
	,{ L"10", L"わみ", false, true, null, true}
	,{ L"11", L"わさきみ", false, false, 5, false }
	,{ L"12", L"わさ", false, true, null, true }
	,{ L"13", L"わ", false, false, 10, false }
	,{ L"14", L"わさきみ", false, false, 9, false }
	,{ L"15", L"み", false, true, null, true }
	,{ L"16", L"わさきみ", false, false, 3, false }
	,{ L"17", L"わさみ", true, true, null, true }
	,{ L"18", L"み", true, false, 7, false }
	,{ L"19", L"わさきみ", true, false, 7, false }
};

MyHondanaDownloadForm::MyHondanaDownloadForm(void)
	: __pCover(null)
	, __pBook(null)
	, __pListNewBook(null)
	, __pGridNewBook(null)
	, __pListBottomText(null)
	, __pGridBottomText(null)
	, __pHeaderBackground(null)
	, __pDownloadCheckPopup(null)
//	, checkImageRect(20, 60-31, 62, 62)
{
}

MyHondanaDownloadForm::~MyHondanaDownloadForm(void)
{
}

bool
MyHondanaDownloadForm::Initialize(void)
{
	RelativeLayout relativeLayout;
	relativeLayout.Construct();

	this->Construct(relativeLayout, FORM_STYLE_NORMAL | FORM_STYLE_INDICATOR | FORM_STYLE_HEADER);

	return true;
}

result
MyHondanaDownloadForm::OnInitializing(void)
{
	result r = E_SUCCESS;
	Control::OnInitializing();

//	SetOrientation(ORIENTATION_AUTOMATIC);
	AddOrientationEventListener(*this);
	SetFormBackEventListener(this);
	SetFormMenuEventListener(this);
	PowerManager::AddScreenEventListener(*((IScreenEventListener*) this));
	PowerManager::TurnScreenOn();
	this->SetBackgroundColor(Color::GetColor(COLOR_ID_BLACK));

	InitHeader();
	SetSplitPanel();
	ShowListView();
	SetButton();
	LoadBitmapFiles();
	DownloadPopupShow();

	for(int i=0; i<LIST_VIEW_MAIN_MENU_COUNT; i++)
	{
		// Button On/Off
		__status[i] = 3;

		// List Check/Uncheck
		isChecked[i] = 0;
	}
	__pListView->UpdateList();
	return r;
}

result
MyHondanaDownloadForm::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
MyHondanaDownloadForm::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);

	switch(actionId)
	{
	//***************************OPTION MENU*******************************
	case ID_BUTTON_CANCEL:
	{
		pSceneManager->GoBackward(BackwardSceneTransition());
	}
		break;
	case ID_BUTTON_DOWNLOAD:
	{
//		int itemDelCount = 0;
//
//		for(int i=0; i<LIST_VIEW_MAIN_MENU_COUNT; i++)
//		{
//			if(__status[i]==2)
//			{
//				__pListView->RefreshList(i-itemDelCount, LIST_REFRESH_TYPE_ITEM_REMOVE);
//				itemDelCount++;
//				__status[i]=3;
//				__pDownloadButton->SetEnabled(false);
//			}
//			AppLogDebug("a2tec: %d", i);
//		}
//
////		__pListView->UpdateList();
//		__pListView->RequestRedraw(true);
		__pDownloadPopup->ShowPopup();

	}
		break;
	default:
		break;
	}
	Invalidate(true);
}

void
MyHondanaDownloadForm::OnOrientationChanged(const Control &source, OrientationStatus orientationStatus)
{
//	SetSplitPanel();
//	ShowListView();
//	SetButton();
//
//	switch(GetOrientationStatus())
//	{
//		case ORIENTATION_PORTRAIT:
//		{
//			__pDownloadBackgroundPanel->SetShowState(true);
//			__pDownloadBackgroundPanel_Bottom->SetShowState(true);
//		}
//			break;
//		default:
//			break;
//	}
//	this->RequestRedraw();
}

void
MyHondanaDownloadForm::OnFormBackRequested(Tizen::Ui::Controls::Form& source)
{

	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);

	pSceneManager->GoBackward(BackwardSceneTransition());
}

void
MyHondanaDownloadForm::OnFormMenuRequested(Tizen::Ui::Controls::Form& source)
{
}

void
MyHondanaDownloadForm::LoadBitmapFiles(void)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	__pCover = pAppResource->GetBitmapN(LIST_IMAGE_PATH1);
	__pBook = pAppResource->GetBitmapN(LIST_IMAGE_PATH2);
	__pListNewBook = pAppResource->GetBitmapN(LIST_IMAGE_PATH3);
	__pGridNewBook = pAppResource->GetBitmapN(LIST_IMAGE_PATH4);
	__pListBottomText = pAppResource->GetBitmapN(LIST_IMAGE_PATH5);
	__pGridBottomText = pAppResource->GetBitmapN(LIST_IMAGE_PATH6);
	__pHeaderBackground = pAppResource->GetBitmapN(HEADER_BACKGROUND);

	__pUncheckImage[0] = pAppResource->GetBitmapN(L"checkbox_unchecked_normal.png");
	__pUncheckImage[1] = pAppResource->GetBitmapN(L"checkbox_unchecked_pressed.png");
	__pCheckImage[0] = pAppResource->GetBitmapN(L"checkbox_checked_download_normal.png");
	__pCheckImage[1] = pAppResource->GetBitmapN(L"checkbox_checked_download_pressed.png");
}

int
MyHondanaDownloadForm::GetItemCount(void)
{
//	AppLogDebug("a2tec : GetItemCount");
	return LIST_VIEW_MAIN_MENU_COUNT;
}


Tizen::Ui::Controls::ListItemBase*
MyHondanaDownloadForm::CreateItem(int index, int itemWidth)
{
	struct BOOK_LIST {
		const Tizen::Graphics::Bitmap* bookbitmap;
	} BOOK_LIST_ITEM[]= {
		 { Application::GetInstance()->GetAppResource()->GetBitmapN(L"book01.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book02.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book03.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book04.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book05.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book06.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book07.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book08.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book09.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book10.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book11.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book12.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book13.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book14.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book15.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book16.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book17.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book18.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book19.png") }
		,{ Application::GetInstance()->GetAppResource()->GetBitmapN(L"book20.png") }
	};

	ListAnnexStyle style = LIST_ANNEX_STYLE_MARK;

	CustomItem* pItem = new (std::nothrow) CustomItem();

	Rectangle checkImageRect(20, 60-31, 62, 62);
	Rectangle coverImageRect(20+80, 10, 70, 100);//96, 150);
	Rectangle titlekanaRect(105+80, 15, this->GetWidth()-200, 40);
	Rectangle authornamekanaRect(105+80, 55, this->GetWidth()-170, 40);
	Rectangle fileSelectRect(105+80, 95, 100, 30);
	Rectangle fileSizeRect(this->GetWidth()-150, 120/2-30, 150, 60);
	Dimension itemDimension(100, 120);//160

	pItem->Construct(itemDimension, style);

	static int nSelectNum = 0;
	String strSelectNum;

	if(BOOK_LIST_INFO[index].topbook==false)
	{
		pItem->SetBackgroundColor(LIST_ITEM_DRAWING_STATUS_NORMAL, 0xff111111);
		pItem->SetBackgroundColor(LIST_ITEM_DRAWING_STATUS_PRESSED, 0xff010101);
		String strFilesize;
		strFilesize = Tizen::Base::Integer::ToString(BOOK_LIST_INFO[index].filesize);

		checkImageRect.SetBounds(20+80, 60-31, 62, 62);
		coverImageRect.SetBounds(20+80+80, 10, 70, 100);//96, 150);
		titlekanaRect.SetBounds(105+80+80, 15, this->GetWidth()-200, 40);
		authornamekanaRect.SetBounds(105+80+80, 55, this->GetWidth()-170, 40);
		fileSelectRect.SetBounds(105+80+80, 80, 100, 30);

		if(isChecked[index]==0)
			pItem->AddElement(checkImageRect, ID_FORMAT_CHECKIMAGE, *__pUncheckImage[0], __pUncheckImage[1], null);
		else if(isChecked[index]==1)
			pItem->AddElement(checkImageRect, ID_FORMAT_CHECKIMAGE, *__pCheckImage[0], __pCheckImage[1], null);
		pItem->AddElement(coverImageRect, ID_FORMAT_BITMAP, *BOOK_LIST_ITEM[index].bookbitmap, null, null);
		pItem->AddElement(titlekanaRect, ID_FORMAT_STRING, BOOK_LIST_INFO[index].itemTitleText, 34, Color::GetColor(COLOR_ID_WHITE), Color::GetColor(COLOR_ID_WHITE), Color::GetColor(COLOR_ID_WHITE), true);
		pItem->AddElement(authornamekanaRect, ID_FORMAT_STRING2, BOOK_LIST_INFO[index].itemAuthorText, 28, Color::GetColor(COLOR_ID_GREY), Color::GetColor(COLOR_ID_GREY), Color::GetColor(COLOR_ID_GREY), true);
		pItem->AddElement(fileSizeRect, ID_FORMAT_STRING3, strFilesize+" MB", 26, Color::GetColor(COLOR_ID_GREY), Color::GetColor(COLOR_ID_GREY), Color::GetColor(COLOR_ID_GREY), true);
	}
	else if(BOOK_LIST_INFO[index].topbook==true)
	{
		pItem->SetBackgroundColor(LIST_ITEM_DRAWING_STATUS_NORMAL, 0xff222222);
		pItem->SetBackgroundColor(LIST_ITEM_DRAWING_STATUS_PRESSED, 0xff121212);
		if(isChecked[index]==0)
			pItem->AddElement(checkImageRect, ID_FORMAT_CHECKIMAGE, *__pUncheckImage[0], __pUncheckImage[1], null);
		else if(isChecked[index]==1)
		{
			for(int i=index+1; i<1000; i++)
			{
				if(BOOK_LIST_INFO[i].topbook==false)
					nSelectNum = nSelectNum + 1;
				else if(BOOK_LIST_INFO[i].topbook==true)
					break;
			}
			authornamekanaRect.SetBounds(105+80, 45, this->GetWidth()-170, 40);
			fileSelectRect.SetBounds(105+80, 75, 100, 30);

			strSelectNum = Tizen::Base::Integer::ToString(nSelectNum);
			pItem->AddElement(fileSelectRect, ID_FORMAT_STRING5, strSelectNum+"冊選択", 24, Color::GetColor(COLOR_ID_GREEN), Color::GetColor(COLOR_ID_GREEN), Color::GetColor(COLOR_ID_GREEN), true);
			pItem->AddElement(checkImageRect, ID_FORMAT_CHECKIMAGE, *__pCheckImage[0], __pCheckImage[1], null);
		}
		pItem->AddElement(coverImageRect, ID_FORMAT_BITMAP, *BOOK_LIST_ITEM[index].bookbitmap, null, null);
		pItem->AddElement(titlekanaRect, ID_FORMAT_STRING, BOOK_LIST_INFO[index].itemTitleText, 34, Color::GetColor(COLOR_ID_WHITE), Color::GetColor(COLOR_ID_WHITE), Color::GetColor(COLOR_ID_WHITE), true);
		pItem->AddElement(authornamekanaRect, ID_FORMAT_STRING2, BOOK_LIST_INFO[index].itemAuthorText, 28, Color::GetColor(COLOR_ID_GREY), Color::GetColor(COLOR_ID_GREY), Color::GetColor(COLOR_ID_GREY), true);

		nSelectNum = 0;
	}

//	AppLogDebug("a2tec : CreateItem");
	return pItem;
}

bool
MyHondanaDownloadForm::DeleteItem(int index, Tizen::Ui::Controls::ListItemBase* pItem, int itemWidth)
{
//	AppLogDebug("a2tec:DeleteItem %d", index);

	delete pItem;
	pItem = null;

	Invalidate(true);
	return true;
}

void
MyHondanaDownloadForm::OnListViewItemStateChanged(ListView& listView, int index, int elementId, ListItemStatus status)
{
	__status[index] = status;

//	AppLogDebug("a2tec:status - %d", status);

	//Unchecked -> Checked
	if(isChecked[index]==0)
	{
		if( BOOK_LIST_INFO[index].topbook==true )
		{
			for(int i=index+1; i<1000; i++) // 1000 : book count
			{
				if(BOOK_LIST_INFO[i].topbook==false)
					isChecked[i] = 1;
				else if(BOOK_LIST_INFO[i].topbook==true)
					break;
			}
		}
		else
		{
			static int pCount, mCount, endIndex, startIndex = 0;
			int flag, indexNum, countSum = 0;

			for(int i=index; i>0; i--)
			{
				if(BOOK_LIST_INFO[i].topbook==true)
				{
					startIndex=i;
					AppLogDebug("a2tec : startIndex = %d", i);
					flag = 1;
					if(flag==1)
					{
						break;
					}
				}
				if(isChecked[i] == 1)
				{
					mCount = mCount+1;
					AppLogDebug("a2tec : mCount = %d", mCount);
				}
			}

			for(int i=index+1; i<1000; i++)
			{
				if(BOOK_LIST_INFO[i].topbook==true)
				{
					endIndex=i;
					AppLogDebug("a2tec : endIndex = %d", endIndex);
					flag = 1;
					if(flag==1)
					{
						break;
					}
				}
				if(isChecked[i] == 1)
				{
					pCount = pCount+1;
					AppLogDebug("a2tec : pCount = %d", pCount);
				}
			}

			indexNum = endIndex - startIndex - 1;
			AppLogDebug("a2tec : %d(indexNum) = %d(endIndex) - %d(startIndex) - 1", indexNum, endIndex, startIndex);
			countSum = pCount + mCount + 1;
			AppLogDebug("a2tec : %d(countSum) = %d(pCount) + %d(mCount) + 1", countSum, pCount, mCount);

			if(indexNum==countSum)
			{
				isChecked[startIndex]=1;
				AppLogDebug("a2tec : startIndex = %d", startIndex);
			}

			pCount = 0;
			mCount = 0;
			startIndex = 0;
			endIndex = 0;
		}

		isChecked[index] = 1;
		__pListView->UpdateList();
	}//Checked->Unchecked
	else if(isChecked[index]==1)
	{
		if( BOOK_LIST_INFO[index].topbook==true )
		{
			for(int i=index+1; i<1000; i++)
			{
				if(BOOK_LIST_INFO[i].topbook==false)
					isChecked[i] = 0;
				else if(BOOK_LIST_INFO[i].topbook==true)
					break;
			}
		}
		else
		{
			static int pCount, mCount, endIndex, startIndex = 0;
			int flag, indexNum, countSum = 0;

			for(int i=index; i>0; i--)
			{
				if(BOOK_LIST_INFO[i].topbook==true)
				{
					startIndex=i;
					AppLogDebug("a2tec : startIndex = %d", i);
					flag = 1;
					if(flag==1)
					{
						break;
					}
				}
				if(isChecked[i] == 0)
				{
					mCount = mCount+1;
					AppLogDebug("a2tec : mCount = %d", mCount);
				}
			}

			for(int i=index+1; i<1000; i++)
			{
				if(BOOK_LIST_INFO[i].topbook==true)
				{
					endIndex=i;
					AppLogDebug("a2tec : endIndex = %d", endIndex);
					flag = 1;
					if(flag==1)
					{
						break;
					}
				}
				if(isChecked[i] == 0)
				{
					pCount = pCount+1;
					AppLogDebug("a2tec : pCount = %d", pCount);
				}
			}

			indexNum = endIndex - startIndex - 1;
			AppLogDebug("a2tec : %d(indexNum) = %d(endIndex) - %d(startIndex) - 1", indexNum, endIndex, startIndex);
			countSum = pCount + mCount + 1;
			AppLogDebug("a2tec : %d(countSum) = %d(pCount) + %d(mCount) + 1", countSum, pCount, mCount);

			if(indexNum != countSum)
			{
				isChecked[startIndex]=0;
				AppLogDebug("a2tec : startIndex = %d", startIndex);
			}

			pCount = 0;
			mCount = 0;
			startIndex = 0;
			endIndex = 0;
		}
		isChecked[index] = 0;
		__pListView->UpdateList();
	}

	//File size
	static int nFilesize;
	String strFilesize;
	static int nFileSizeSum =0;
	for(int i=0; i<LIST_VIEW_MAIN_MENU_COUNT; i++)
	{
		if(isChecked[i]==1 && BOOK_LIST_INFO[i].topbook==false)
		{
			nFilesize = BOOK_LIST_INFO[i].filesize;
			nFileSizeSum = nFileSizeSum + nFilesize;
		}
	}
	strFilesize = Tizen::Base::Integer::ToString(nFileSizeSum);
	__pFileSizeLabel -> SetText(strFilesize+" MB");

	nFileSizeSum=0;

	//Button On/Off
	for(int i=0; i<LIST_VIEW_MAIN_MENU_COUNT; i++)
	{
		if(isChecked[i]==1)
		{
			__pDownloadButton->SetEnabled(true);
			return;
		}
	}
	__pDownloadButton->SetEnabled(false);
}

void
MyHondanaDownloadForm::OnListViewItemSwept(ListView& listView, int index, SweepDirection direction)
{
}

void
MyHondanaDownloadForm::OnListViewContextItemStateChanged(ListView& listView, int index, int elementId, ListContextItemStatus state)
{
}

void
MyHondanaDownloadForm::OnListViewItemLongPressed(ListView& listView, int index, int elementId, bool& invokeListViewItemCallback)
{
}

void
MyHondanaDownloadForm::InitHeader(void)
{
	AppResource *pAppResource = App::GetInstance()->GetAppResource();

	// Create header
	Header * pHeader = GetHeader();

//	ButtonItem  buttonRightItem;
//	buttonRightItem.Construct(BUTTON_ITEM_STYLE_ICON, ID_BUTTON_ACTIONBAR);
//	if(mBookDownloadMode==BOOK_STATUS_TOTAL_OPEN)
//	{
//		buttonRightItem.SetIcon(BUTTON_ITEM_STATUS_NORMAL, pAppResource->GetBitmapN(L"total_close.png"));
//		buttonRightItem.SetIcon(BUTTON_ITEM_STATUS_PRESSED, pAppResource->GetBitmapN(L"total_close.png"));
//	}
//	else if(mBookDownloadMode==BOOK_STATUS_TOTAL_CLOSE)
//	{
//		buttonRightItem.SetIcon(BUTTON_ITEM_STATUS_NORMAL, pAppResource->GetBitmapN(L"total_open.png"));
//		buttonRightItem.SetIcon(BUTTON_ITEM_STATUS_PRESSED, pAppResource->GetBitmapN(L"total_open.png"));
//	}

	String download;
	pAppResource->GetString("IDS_OPTIONMENU_DOWNLOAD", download);

	pHeader->SetStyle(HEADER_STYLE_TITLE);
	pHeader->SetBackgroundBitmap(pAppResource->GetBitmapN(L"header_background.png"));
	pHeader->SetTitleText(download);
	pHeader->SetTitleTextColor(Color::GetColor(COLOR_ID_WHITE));
	pHeader->AddActionEventListener(*this);
}

void
MyHondanaDownloadForm::SetSplitPanel(void)
{
	RelativeLayout* pRelativeLayout = dynamic_cast<RelativeLayout*>(this->GetLayoutN());
	int list_height = LIST_VIEW_MAIN_MENU_COUNT*120;
	//****************************************************Portrait****************************************************************
	Panel* pPanel;
	__pDownloadBackgroundPanel_Bottom = new (std::nothrow) Panel();
	__pDownloadBackgroundPanel_Bottom->Construct(Rectangle(0, 0, this->GetWidth(), this->GetHeight()));

	pPanel = __pDownloadBackgroundPanel_Bottom;
	this->AddControl(pPanel);

	pRelativeLayout->SetRelation(*pPanel, this, RECT_EDGE_RELATION_LEFT_TO_LEFT);
	pRelativeLayout->SetRelation(*pPanel, this, RECT_EDGE_RELATION_RIGHT_TO_RIGHT);
	pRelativeLayout->SetRelation(*pPanel, this, RECT_EDGE_RELATION_TOP_TO_TOP);
	pRelativeLayout->SetRelation(*pPanel, this, RECT_EDGE_RELATION_BOTTOM_TO_BOTTOM);

	ScrollPanel* pScrollPanel;
	__pDownloadBackgroundPanel = new (std::nothrow) ScrollPanel();
	__pDownloadBackgroundPanel->Construct(Rectangle(0, 0, this->GetWidth(), list_height));
	pScrollPanel = __pDownloadBackgroundPanel;
	pPanel->AddControl(pScrollPanel);

	pRelativeLayout->SetRelation(*pScrollPanel, pPanel, RECT_EDGE_RELATION_LEFT_TO_LEFT);
	pRelativeLayout->SetRelation(*pScrollPanel, pPanel, RECT_EDGE_RELATION_RIGHT_TO_RIGHT);
	pRelativeLayout->SetRelation(*pScrollPanel, pPanel, RECT_EDGE_RELATION_TOP_TO_TOP);

	delete pRelativeLayout;
}

void
MyHondanaDownloadForm::ShowListView(void)
{
	//****************************************************Portrait****************************************************************
	Panel&          pList  = *__pDownloadBackgroundPanel;
	__pListView = new (std::nothrow) ListView();
	__pListView->Construct(Rectangle(-90, 0, this->GetWidth()+90, this->GetHeight()-320), true, SCROLL_STYLE_FADE_OUT);
	__pListView->SetBackgroundColor(0xff232323);
	__pListView->SetItemProvider(*this);
	__pListView->AddListViewItemEventListener(*this);
	pList.AddControl(*__pListView);
}

void
MyHondanaDownloadForm::SetButton(void)
{
	//****************************************************Portrait****************************************************************
	Panel&          pLabel  = *__pDownloadBackgroundPanel_Bottom;
	pLabel.SetBackgroundColor(0xff292929);
	__pFileSizeLabel = new (std::nothrow) Label;
	__pFileSizeLabel->Construct(Rectangle(0,  this->GetHeight()-320, this->GetWidth(), SIZE_OF_LABEL_Y+10), L"");
	__pFileSizeLabel->SetText(L"0 MB");
	__pFileSizeLabel->SetTextConfig(25, LABEL_TEXT_STYLE_NORMAL);
	__pFileSizeLabel->SetTextColor(0xffffffff);
	__pFileSizeLabel->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
	__pFileSizeLabel->SetTextVerticalAlignment(ALIGNMENT_BOTTOM);
	__pFileSizeLabel->SetBackgroundColor(0xff292929);
	pLabel.AddControl(__pFileSizeLabel);

	__pCancelButton = new (std::nothrow) Button;
	__pCancelButton->Construct(Rectangle(this->GetWidth()/2+10, this->GetHeight()-260, this->GetWidth()/2-30, 84), "");
	__pCancelButton->SetColor(BUTTON_STATUS_NORMAL, 0xff545454);
	__pCancelButton->SetColor(BUTTON_STATUS_PRESSED, 0xff343434);
	__pCancelButton->SetText(L"キャンセル");
	__pCancelButton->SetTextColor(0xffffffff);
	__pCancelButton->SetTextSize(30);
	__pCancelButton->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
	__pCancelButton->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pCancelButton->SetActionId(ID_BUTTON_CANCEL);
	__pCancelButton->AddActionEventListener(*this);
	pLabel.AddControl(__pCancelButton);

	__pDownloadButton = new (std::nothrow) Button;
	__pDownloadButton->Construct(Rectangle(20, this->GetHeight()-260, this->GetWidth()/2-30, 84), "");
	__pDownloadButton->SetColor(BUTTON_STATUS_NORMAL, 0xff31ff31);
	__pDownloadButton->SetColor(BUTTON_STATUS_PRESSED, 0xff11ff11);
	__pDownloadButton->SetColor(BUTTON_STATUS_DISABLED, 0xff318f31);
	__pDownloadButton->SetText(L"ダウンロード");
	__pDownloadButton->SetTextColor(0xffffffff);
	__pDownloadButton->SetTextSize(30);
	__pDownloadButton->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
	__pDownloadButton->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pDownloadButton->SetEnabled(false);
	__pDownloadButton->SetActionId(ID_BUTTON_DOWNLOAD);
	__pDownloadButton->AddActionEventListener(*this);
	pLabel.AddControl(__pDownloadButton);
}

void
MyHondanaDownloadForm::OnSceneDeactivated(const Tizen::Ui::Scenes::SceneId& currentSceneId, const Tizen::Ui::Scenes::SceneId& nextSceneId)
{
}

void
MyHondanaDownloadForm::OnSceneActivatedN(const Tizen::Ui::Scenes::SceneId& previousSceneId, const Tizen::Ui::Scenes::SceneId& currentSceneId, Tizen::Base::Collection::IList* pArgs)
{
}

//************************************************** Download Popup ******************************************************
void
MyHondanaDownloadForm::DownloadPopupShow(void)
{
	__pDownloadPopup = new (std::nothrow) DownloadPopup();
	__pDownloadPopup->Initialize();
	__pDownloadPopup->SetTitleText("ダウンロード");
}

void
MyHondanaDownloadForm::OnDownloadPopupSelected(int selectIdx)
{
	switch (selectIdx) {
	case 0:
		__pDownloadPopup->SetShowState(false);
		break;
	case 1:
		__pDownloadPopup->SetShowState(false);
		break;
	default:
		break;
	}
	Invalidate(true);
}
