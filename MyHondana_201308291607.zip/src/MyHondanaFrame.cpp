#include "MyHondanaFrame.h"
#include "SceneRegister.h"
#include <FNet.h>
#include <FIo.h>
#include <FApp.h>


using namespace Tizen::Base;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::Net::Http;
using namespace Tizen::Io;
using namespace Tizen::App;

namespace
{
	enum
	{
		STATUS_LOGIN = 100,
		STATUS_LOGOUT = 101
	};

int mLoginMode = STATUS_LOGOUT;
}

MyHondanaFrame::MyHondanaFrame(void)
{
}

MyHondanaFrame::~MyHondanaFrame(void)
{
}

result
MyHondanaFrame::OnInitializing(void)
{
	CheckLogin();

	// Prepare Scene management.
	SceneRegister::RegisterAllScenes();
	SceneManager* pSceneManager = SceneManager::GetInstance();
	result r;
	AppAssert(pSceneManager);

	// Go to the scene.
	if(mLoginMode==STATUS_LOGOUT)
	{
		r = pSceneManager->GoForward(ForwardSceneTransition(SCENE_LOGIN));
	}
	else if(mLoginMode==STATUS_LOGIN)
	{
		r = pSceneManager->GoForward(ForwardSceneTransition(SCENE_MAIN));
	}
	TryReturn(!IsFailed(r), r, "%s", GetErrorMessage(r));

	// TODO: Add your initialization code here
	return r;
}

result
MyHondanaFrame::OnTerminating(void)
{
	result r = E_SUCCESS;

	// TODO:
	// Add your termination code here
	return r;
}

void
MyHondanaFrame::CheckLogin(void)
{
	AppRegistry* pAppRegistry = Application::GetInstance()->GetAppRegistry();

	String sessionId;
	String mUSER_NO;
	pAppRegistry->Get(L"SessionID", sessionId);
	pAppRegistry->Get(L"UserID", mUSER_NO);

	if((mUSER_NO == null) || (sessionId == null))
		mLoginMode = STATUS_LOGOUT;
	else
		mLoginMode = STATUS_LOGIN;
}

