

#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include <FSystem.h>

#include "MyHondanaMainForm.h"
#include "MyHondanaDetailForm.h"
#include "SceneRegister.h"
#include "AppResourceId.h"

#include "GlobalDefine.h"
#include "ResMetaInfo.h"
#include "ResParser.h"
#include "MyHondana.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Graphics;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Media;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::Ui::Animations;
using namespace Tizen::Base::Collection;
using namespace Tizen::System;
using namespace Tizen::Io;


MyHondanaMainForm::MyHondanaMainForm(void)
{
	list_item_count = 0;
}

MyHondanaMainForm::~MyHondanaMainForm(void)
{
}

bool
MyHondanaMainForm::Initialize(void)
{
	Construct(L"IDF_MY_HONDANA_MAIN_FORM");
	//get bitmap files from resource

	MyHondanaApp * app = static_cast<MyHondanaApp *>(Tizen::App::UiApp::GetInstance());
	p_meta_info  = static_cast<cres_meta_info *>(&app->meta_info);
	p_store_intf = static_cast<CMyBookShelfStoreIF  *>(app->p_store_intf);

	// request meta data sync
	p_store_intf->set_caller_for_response( this);
	//	p_store_intf->bookshelf_sync_req(new String(L"0"),new String(L"0"));
	p_store_intf->imei2_check_req();

	
	LoadBitmapFiles();
	Control::OnInitializing();
	SetOrientation(ORIENTATION_AUTOMATIC);

	//set Event handler;
	AddOrientationEventListener(*this);
	SetFormBackEventListener(this);
	SetFormMenuEventListener(this);

	PowerManager::AddScreenEventListener(*((IScreenEventListener*) this));
//	PowerManager::TurnScreenOn();

	return true;
}

void MyHondanaMainForm::SetCurrentUIStatus(int newStatus)
{
	currentUiStatus = newStatus;
}

result
MyHondanaMainForm::OnInitializing(void)
{
	result r = E_SUCCESS;

	//__pHttpService = new HttpCommunicationService(this);
	InitControlPointer();
	InitHeader();
	InitMenuBar();
	CreateOptionMenu();
	SetFullScreenMode();
	SetThumbnailMode();
	if(GetOrientationStatus()==ORIENTATION_STATUS_PORTRAIT)
		SetPortraitMode();
	else
		SetLandscapeMode();
		
	DrawForm();
	
	chkNewBook = false;
	return r;
}

result
MyHondanaMainForm::OnTerminating(void)
{
	result r = E_SUCCESS;
	UnLoadBitmapFiles();
	RemoveAllControls();

	return r;
}

void 
MyHondanaMainForm::ShowListView( bool isFull, bool isPort)
{
	int x = 0;
	int y = 0;
	int h = list_item_count*LIST_ITEM_HEIGHT;
	int w = GetClientAreaBounds().width;	
	if(isFull)
	{
		int coverFlowHeight = __pCoverflowCotainerPanel->GetHeight();
		int MenuBarHeight   = __pMenuBarContainerLabel->GetHeight();
		y = MenuBarHeight + coverFlowHeight;
		AppLog("list - coverflowOn->Off!");
	}
	else
	{
		y = __pMenuBarContainerLabel->GetHeight();
		AppLog("list - coverflowOff->On!");
	}
//	__pThumbnailView->SetBounds(Rectangle(0, start_y, GetClientAreaBounds().width, 0));
	__pThumbnailView->SetShowState(false);
	__pListView->SetBounds(Rectangle(x, y, w, h));
	__pListView->SetShowState(true);
	
	__pListView->UpdateList();
}
void 
MyHondanaMainForm::ShowThumbnailView( bool isFull, bool isPort)
{
	int thumbnail_row_count;
	int x,y,w,h;
	int t,l,r,b;
	int s_h, s_v;
	int item_total_count = list_item_count;
	int item_row_count;
	x = 0;
	y = __pMenuBarContainerLabel->GetHeight();
	w = GetClientAreaBounds().width;
	
	if(isPort)
	{
		t = THUMB_PORT_MARGIN_TYPE_TOP;
		l = THUMB_PORT_MARGIN_TYPE_LEFT;
		r = THUMB_PORT_MARGIN_TYPE_RIGHT;
		b = THUMB_PORT_MARGIN_TYPE_BOTTOM;
		s_h = THUMB_PORT_ITEM_SPACING_H;
		s_v = THUMB_PORT_ITEM_SPACING_V;
		item_row_count = THUMB_PORT_ROW_ITEM_COUNT;

	}
	else
	{
		t = THUMB_LAND_MARGIN_TYPE_TOP;
		l = THUMB_LAND_MARGIN_TYPE_LEFT;
		r = THUMB_LAND_MARGIN_TYPE_RIGHT;
		b = THUMB_LAND_MARGIN_TYPE_BOTTOM;
		s_h = THUMB_LAND_ITEM_SPACING_H;
		s_v = THUMB_LAND_ITEM_SPACING_V;
		item_row_count = THUMB_LAND_ROW_ITEM_COUNT;
	}

	thumbnail_row_count = item_total_count/item_row_count + (item_total_count%item_row_count!=0);
	h = thumbnail_row_count*THUMB_ITEM_HEIGHT + THUMB_PORT_MARGIN_TYPE_TOP ;

	if(isFull)
	{
		y += __pCoverflowCotainerPanel->GetHeight();
	}

	__pThumbnailView->SetBounds(Rectangle(x, y, w, h));
	__pThumbnailView->SetShowState(true);
	//__pListView->SetBounds(Rectangle(x, y, w, 0));
	__pListView->SetShowState(false);

	__pThumbnailView->SetMargin(MARGIN_TYPE_TOP,	t);
	__pThumbnailView->SetMargin(MARGIN_TYPE_LEFT,	l);
	__pThumbnailView->SetMargin(MARGIN_TYPE_RIGHT,	r);
	__pThumbnailView->SetMargin(MARGIN_TYPE_BOTTOM, b);
	__pThumbnailView->SetItemSpacing(s_h, s_v);

	__pThumbnailView->UpdateList();

}

void 
MyHondanaMainForm::DrawForm(void)
{
	bool isFull = IsFullScreenMode();
	bool isThum = IsThumbnailMode();
	bool isPort = IsPortraitMode();

	if(isFull)
		ShowCoverFlow();
	else
		HideCoverFlow();
	ResizeMainContainerPanel();
	ResizeMenuBar(isFull);

	if(isThum)
		ShowThumbnailView(isFull,isPort);
	else
		ShowListView(isFull,isPort);
}


//************************************************** Image ******************************************************
void
MyHondanaMainForm::UnLoadBitmapFiles(void)
{
	for(int i=0; i<2; i++)
	{
		delete __pThumbnail_background[i];
		delete __pDivider_newbookbutton[i];
		delete __pDivider_coverflow_on_button[i];
		delete __pDivider_coverflow_off_button[i];

		delete __pOptionmenu_thumbnail[i];
		delete __pOptionmenu_list[i];
		delete __pOptionmenu_update[i];
		delete __pOptionmenu_delete[i];
		delete __pOptionmenu_download[i];
		delete __pOptionmenu_setting[i];
		delete __pOptionmenu_help[i];
	}
}

//************************************************** Image ******************************************************
void
MyHondanaMainForm::LoadBitmapFiles(void)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	//**Thumbnail View / List View
	__pListNewBook = pAppResource->GetBitmapN(L"list_new_book_icon.png");
	__pGridNewBook = pAppResource->GetBitmapN(L"thumbnail_new_btn_1.png");
	__pListBottomText = pAppResource->GetBitmapN(L"list_bottom_text.png");
	__pGridBottomText = pAppResource->GetBitmapN(L"recently_thumbnail.png");

	//**Option Menu / Context Menu
	__pOptionmenu_thumbnail[0] = pAppResource->GetBitmapN("optionmenu_icon_gridview.png");
	__pOptionmenu_thumbnail[1] = pAppResource->GetBitmapN("optionmenu_icon_gridview.png");
	__pOptionmenu_list[0] = pAppResource->GetBitmapN("optionmenu_icon_listview.png");
	__pOptionmenu_list[1] = pAppResource->GetBitmapN("optionmenu_icon_listview.png");
	__pOptionmenu_update[0] = pAppResource->GetBitmapN("optionmenu_icon_refresh.png");
	__pOptionmenu_update[1] = pAppResource->GetBitmapN("optionmenu_icon_refresh.png");
	__pOptionmenu_delete[0] = pAppResource->GetBitmapN("optionmenu_icon_delete.png");
	__pOptionmenu_delete[1] = pAppResource->GetBitmapN("optionmenu_icon_delete.png");
	__pOptionmenu_download[0] = pAppResource->GetBitmapN("optionmenu_icon_download.png");
	__pOptionmenu_download[1] = pAppResource->GetBitmapN("optionmenu_icon_download.png");
	__pOptionmenu_setting[0] = pAppResource->GetBitmapN("optionmenu_icon_setting.png");
	__pOptionmenu_setting[1] = pAppResource->GetBitmapN("optionmenu_icon_setting.png");
	__pOptionmenu_help[0] = pAppResource->GetBitmapN("optionmenu_icon_help.png");
	__pOptionmenu_help[1] = pAppResource->GetBitmapN("optionmenu_icon_help.png");

	//**Book List
	__pNoImage = pAppResource->GetBitmapN(L"thumbnail_thumbnail_default.png");
	__pBookCover[0] = pAppResource->GetBitmapN(L"book20.png");
	__pBookCover[1] = pAppResource->GetBitmapN(L"book19.png");
	__pBookCover[2] = pAppResource->GetBitmapN(L"book18.png");
	__pBookCover[3] = pAppResource->GetBitmapN(L"book17.png");
	__pBookCover[4] = pAppResource->GetBitmapN(L"book16.png");
	__pBookCover[5] = pAppResource->GetBitmapN(L"book15.png");
	__pBookCover[6] = pAppResource->GetBitmapN(L"book14.png");
	__pBookCover[7] = pAppResource->GetBitmapN(L"book13.png");
	__pBookCover[8] = pAppResource->GetBitmapN(L"book12.png");
	__pBookCover[9] = pAppResource->GetBitmapN(L"book11.png");
	__pBookCover[10] = pAppResource->GetBitmapN(L"book10.png");
	__pBookCover[11] = pAppResource->GetBitmapN(L"book09.png");
	__pBookCover[12] = pAppResource->GetBitmapN(L"book08.png");
	__pBookCover[13] = pAppResource->GetBitmapN(L"book07.png");
	__pBookCover[14] = pAppResource->GetBitmapN(L"book06.png");
	__pBookCover[15] = pAppResource->GetBitmapN(L"book05.png");
	__pBookCover[16] = pAppResource->GetBitmapN(L"book04.png");
	__pBookCover[17] = pAppResource->GetBitmapN(L"book03.png");
	__pBookCover[18] = pAppResource->GetBitmapN(L"book02.png");
	__pBookCover[19] = pAppResource->GetBitmapN(L"book01.png");

	//**Divider Bar
	__pThumbnail_background[0] = pAppResource->GetBitmapN(L"thumbnail_background_grey.png");
	__pDivider_newbookbutton[0] = pAppResource->GetBitmapN(L"new_btn_normal.png");
	__pDivider_newbookbutton[1] = pAppResource->GetBitmapN(L"new_btn_pressed.png");
	__pDivider_coverflow_on_button[0] = pAppResource->GetBitmapN(L"coverflow_on_normal.png");
	__pDivider_coverflow_on_button[1] = pAppResource->GetBitmapN(L"coverflow_on_pressed.png");
	__pDivider_coverflow_off_button[0] = pAppResource->GetBitmapN(L"coverflow_off_normal.png");
	__pDivider_coverflow_off_button[1] = pAppResource->GetBitmapN(L"coverflow_off_pressed.png");
}

//************************************************** Button Action / Orientation ******************************************************
void
MyHondanaMainForm::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	String toggle;
	pAppResource->GetString("IDS_OPTIONMENU_TOGGLE", toggle);

	switch(actionId)
	{
	case ID_BUTTON_COVERFLOW:
		if(IsFullScreenMode())
		{
			SetHalfScreenMode();
		}
		else
		{
			SetFullScreenMode();
		}
		DrawForm();
		break;
	case ID_BUTTON_MARKET:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_MARKET));
		break;
	case ID_BUTTON_SORT:
		__pSortPopup->ShowPopup();
		break;
	case ID_BUTTON_NEWBOOK:
		if(chkNewBook==true)
		{
			__pNewBookButton->SetNormalBackgroundBitmap(*__pDivider_newbookbutton[0]);
			chkNewBook = false;
		}
		else
		{
			__pNewBookButton->SetNormalBackgroundBitmap(*__pDivider_newbookbutton[1]);
			chkNewBook = true;
		}
		break;
	case ID_OPTIONMENU_TOGGLE:
		if(IsThumbnailMode())
		{
			SetListMode();
			__pOptionMenu->SetItemAt(null, toggle, ID_OPTIONMENU_TOGGLE, *__pOptionmenu_thumbnail[0], __pOptionmenu_thumbnail[1]);

		}
		else
		{
			SetThumbnailMode();
			__pOptionMenu->SetItemAt(null, toggle, ID_OPTIONMENU_TOGGLE, *__pOptionmenu_list[0], __pOptionmenu_list[1]);
		}
		DrawForm();
		break;
	case ID_OPTIONMENU_UPDATE:
		__pUpdatePopup->SetShowState(true);
		__pUpdatePopup->Show();
		break;
	case ID_OPTIONMENU_DELETE:
		__pDeletePopup->SetShowState(true);
		__pDeletePopup->Show();
		break;
	case ID_OPTIONMENU_DOWNLOAD:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_DOWNLOAD));
		break;
	case ID_OPTIONMENU_SETTING:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_SETTING));
		break;
	case ID_OPTIONMENU_HELP:
//		pSceneManager->GoForward(ForwardSceneTransition(SCENE_HELP));
		break;
	default:
		break;
	}
}

void
MyHondanaMainForm::OnOrientationChanged(const Control &source, OrientationStatus orientationStatus)
{
	if(orientationStatus == ORIENTATION_STATUS_PORTRAIT)
		SetPortraitMode();
	else
		SetLandscapeMode();
	DrawForm();
}

//************************************************** Form Base ******************************************************
void
MyHondanaMainForm::InitHeader(void)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	// Create header
	Header  * __pHeader= GetHeader();

	String title;
	pAppResource->GetString("IDS_HEADER_TITLE", title);
	__pHeader->SetTitleText(title);
	__pHeader->AddActionEventListener(*this);
}

void
MyHondanaMainForm::InitMenuBar(void)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	String date;
	pAppResource->GetString("IDS_SORT_DATE", date);

	__pSortButton->SetText(date);
	__pSortButton->SetActionId(ID_BUTTON_SORT);
	__pSortButton->AddActionEventListener(*this);

	__pNewBookButtonEmpty->SetActionId(ID_BUTTON_NEWBOOK);
	__pNewBookButtonEmpty->AddActionEventListener(*this);

//	__pNewBookButton->SetText("新刊あり");
//	__pNewBookButton->SetTextSize(NEWBUTTON_TEXT_SIZE);
	__pNewBookButton->SetActionId(ID_BUTTON_NEWBOOK);
	__pNewBookButton->AddActionEventListener(*this);

	__pCoverflowOnOffButton->SetActionId(ID_BUTTON_COVERFLOW);
	__pCoverflowOnOffButton->AddActionEventListener(*this);

}

void
MyHondanaMainForm::OnFormMenuRequested(Tizen::Ui::Controls::Form& source)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	String toggle, update, del, download, setting, help;
	pAppResource->GetString("IDS_OPTIONMENU_TOGGLE", toggle);
	pAppResource->GetString("IDS_OPTIONMENU_UPDATE", update);
	pAppResource->GetString("IDS_OPTIONMENU_DELETE", del);
	pAppResource->GetString("IDS_OPTIONMENU_DOWNLOAD", download);
	pAppResource->GetString("IDS_OPTIONMENU_SETTING", setting);
	pAppResource->GetString("IDS_OPTIONMENU_HELP", help);

	__pOptionMenu->AddItem(toggle, ID_OPTIONMENU_TOGGLE, *__pOptionmenu_list[0], __pOptionmenu_list[1]);
	__pOptionMenu->AddItem(update, ID_OPTIONMENU_UPDATE, *__pOptionmenu_update[0], __pOptionmenu_update[1]);
	__pOptionMenu->AddItem(del, ID_OPTIONMENU_DELETE, *__pOptionmenu_delete[0], __pOptionmenu_delete[1]);
	__pOptionMenu->AddItem(download, ID_OPTIONMENU_DOWNLOAD, *__pOptionmenu_download[0], __pOptionmenu_download[1]);
	__pOptionMenu->AddItem(setting, ID_OPTIONMENU_SETTING, *__pOptionmenu_setting[0], __pOptionmenu_setting[1]);
	__pOptionMenu->AddItem(help, ID_OPTIONMENU_HELP, *__pOptionmenu_help[0], __pOptionmenu_help[1]);
	__pOptionMenu->SetMaxVisibleItemsCount(OPTIONMENU_MAX_VISIBLE_ITEM_COUNT);
	__pOptionMenu->SetColor(OPTIONMENU_COLOR);
	__pOptionMenu->AddActionEventListener(*this);

	__pOptionMenu->SetShowState(true);
	__pOptionMenu->Show();
}

void
MyHondanaMainForm::OnFormBackRequested(Tizen::Ui::Controls::Form& source)
{
	UiApp* pApp = UiApp::GetInstance();
	AppAssert(pApp);
	pApp->Terminate();
}

void
MyHondanaMainForm::InitControlPointer(void)
{
	__pMainContainerPanel     = static_cast <ScrollPanel *>(GetControl(IDC_COVERFLOW_ON_SCROLLPANEL, true));
	__pCoverflowCotainerPanel = static_cast <Panel *>      (GetControl(IDC_COVERFLOW_PANEL, true));

	__pCoverflowPanel = new (std::nothrow) CoverFlowPanel();
	__pCoverflowPanel->Construct(Rectangle(0, 0, this->GetWidth(), COVERFLOW_HEIGHT));
	__pCoverflowCotainerPanel->AddControl(__pCoverflowPanel);

	__pMenuBarContainerLabel = static_cast <Label *> (GetControl(IDC_LABEL_GREENBAR, true));
	__pSortButton            = static_cast <Button*> (GetControl(IDC_BUTTON_SORT, true));
	__pNewBookButtonEmpty    = static_cast <Button*> (GetControl(IDC_BUTTON_NEWBOOK_EMPTY, true));
	__pNewBookButton         = static_cast <Button*> (GetControl(IDC_BUTTON_NEWBOOK, true));

	Play();	 // animation newbook button.
	
	__pCoverflowOnOffButton  = static_cast <Button*> (GetControl(IDC_BUTTON_COVERFLOW_OFF, true));

	__pThumbnailView         = static_cast <IconListView*> (GetControl(IDC_THUMBNAILVIEW, true));
	__pListView              = static_cast <ListView*>     (GetControl(IDC_LISTVIEW, true));

	
	__pListView->SetItemProvider(*this);
	__pListView->AddListViewItemEventListener(*this);
	__pMainContainerPanel->AddControl(__pListView);

	__pThumbnailView->SetItemProvider(*this);
	__pThumbnailView->AddIconListViewItemEventListener(*this);
	__pMainContainerPanel->AddControl(__pThumbnailView);
}

void
MyHondanaMainForm::ResizeMainContainerPanel()
{
	int w = this->GetWidth();
	Header * __pHeader = GetHeader();
	int h = WINDOW_HEIGHT - INDICATOR_HEIGHT - __pHeader->GetHeight();
		__pMainContainerPanel->SetBounds(0, 0, w, h);
}

//************************************************** Greenbar Button ******************************************************
void
MyHondanaMainForm::ResizeMenuBar(bool isFull)
{
	Rectangle menubarRect;
	Rectangle sortButtonRect;
	Rectangle newButtonRect;
	Rectangle coverOnButtonRect;


	menubarRect.width  = MENUBAR_WIDTH;
	menubarRect.height = MENUBAR_HEIGHT;
	
	sortButtonRect.width = SORTBUTTON_WIDTH;
	sortButtonRect.height= SORTBUTTON_HEIGHT;
	
	newButtonRect.width = NEWBUTTON_WIDTH;
	newButtonRect.height= NEWBUTTON_HEIGHT;
	
	coverOnButtonRect.width = COVERON_BUTTON_WIDTH;
	coverOnButtonRect.height= COVERON_BUTTON_HEIGHT;
	
	if(isFull)
	{
		menubarRect.x = 0;
		menubarRect.y = COVERFLOW_HEIGHT;

		sortButtonRect.x = 19;
		sortButtonRect.y = 265;

		newButtonRect.x = 250;
		newButtonRect.y = 265;

		coverOnButtonRect.x = WINDOW_WIDTH-182; 
		coverOnButtonRect.y = 257;

		__pCoverflowOnOffButton->SetNormalBackgroundBitmap(*__pDivider_coverflow_off_button[0]);
		__pCoverflowOnOffButton->SetPressedBackgroundBitmap(*__pDivider_coverflow_off_button[1]);
	}
	else
	{
		menubarRect.x = 0;
		menubarRect.y = 0;

		sortButtonRect.x = 19;
		sortButtonRect.y = 8;

		newButtonRect.x = 250;
		newButtonRect.y = 8;

		coverOnButtonRect.x = WINDOW_WIDTH-182; 
		coverOnButtonRect.y = 0;

		__pCoverflowOnOffButton->SetNormalBackgroundBitmap(*__pDivider_coverflow_on_button[0]);
		__pCoverflowOnOffButton->SetPressedBackgroundBitmap(*__pDivider_coverflow_on_button[1]);
	}


	__pMenuBarContainerLabel->SetBounds(menubarRect);
	__pSortButton->SetBounds(sortButtonRect);
	__pNewBookButtonEmpty->SetBounds(newButtonRect);
	__pNewBookButton->SetBounds(newButtonRect);
	__pCoverflowOnOffButton->SetBounds(coverOnButtonRect);

}

//************************************************** Thumbnail View ******************************************************
int
MyHondanaMainForm::GetItemCount(void)
{
    list_item_count = p_meta_info->datalist.size();
	return p_meta_info->datalist.size();
}

IconListViewItem*
MyHondanaMainForm::CreateItem(int index)
{

	pIconListview = new (std::nothrow) IconListViewItem();
	String itemText(L"");
	AppLog("[sihong] CreateItem() title_id = %S", p_meta_info->datalist[index]->title_id.GetPointer());

	//if(LoadBitmap(arTitleList[index].mTitleId) == null)
	if(!LoadBitmap(p_meta_info->datalist[index]->title_id))
		pIconListview->Construct(*__pNoImage, &itemText);
	else
		pIconListview->Construct(*LoadBitmap(p_meta_info->datalist[index]->title_id), &itemText);

	if(index==0)
		pIconListview->SetOverlayBitmap(ID_BITMAP_RECENTLY, 
		                                __pGridBottomText, 
		                                ALIGNMENT_CENTER, 
		                                ALIGNMENT_BOTTOM);
//	if(Temp_BOOK_LIST_ITEM[index].readbook==false)
//		pIconListview->SetOverlayBitmap(ID_BITMAP_NEWBOOK, __pGridNewBook, ALIGNMENT_CENTER, ALIGNMENT_TOP);
	return pIconListview;
/*
	for(int i=0; i<20; i++)
		delete __pBookCover[i];
	delete __pGridBottomText;
	delete __pGridNewBook;
	delete Temp_BOOK_LIST_ITEM[index].bookbitmap;
*/	
}

void
MyHondanaMainForm::OnIconListViewOverlayBitmapSelected(IconListView& iconListView, int index, int overlayBitmapId)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);

	switch(overlayBitmapId)
	{
	case ID_BITMAP_NEWBOOK:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_MARKET));
		break;
	}
	Invalidate(true);
}

void
MyHondanaMainForm::OnIconListViewItemStateChanged(IconListView& view, int index, IconListViewItemStatus status)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);

	ArrayList* pList = new (std::nothrow) ArrayList();
	pList->Add(*(new (std::nothrow) Integer(index)));

	MyHondanaDetailForm* pDetailForm = new (std::nothrow) MyHondanaDetailForm;
	pDetailForm->__dIndex = index;
	pDetailForm->Initialize();
	pDetailForm->AddControl(*pDetailForm);
	pDetailForm->SendUserEvent(MyHondanaMainForm::REQUEST_ID_SEND, pList);

	pSceneManager->GoForward(ForwardSceneTransition(SCENE_DETAIL));
	Invalidate(true);
}

bool
MyHondanaMainForm::DeleteItem(int index, IconListViewItem* pItem)
{
	delete pItem;
	return true;
}

//************************************************** List View ******************************************************
ListItemBase*
MyHondanaMainForm::CreateItem(int index, int itemWidth)
{
	ListAnnexStyle style = LIST_ANNEX_STYLE_NORMAL;


	CustomItem* pItem = new (std::nothrow) CustomItem();
	Rectangle coverImageRect(LIST_ITEM_COVERIMAGE_X, 
	                         LIST_ITEM_COVERIMAGE_Y, 
	                         LIST_ITEM_COVERIMAGE_W, 
	                         LIST_ITEM_COVERIMAGE_H);//96, 150);
	Rectangle bookImageRect (LIST_ITEM_COVER_BELOW_IMAGE_X, 
	                         LIST_ITEM_COVER_BELOW_IMAGE_Y, 
	                         LIST_ITEM_COVER_BELOW_IMAGE_W, 
	                         LIST_ITEM_COVER_BELOW_IMAGE_H);
	Rectangle titlekanaRect (LIST_ITEM_TITLE_KANA_X,
	                         LIST_ITEM_TITLE_KANA_Y, 
	                         LIST_ITEM_TITLE_KANA_W, 
	                         LIST_ITEM_TITLE_KANA_H);
	Rectangle authornamekanaRect(LIST_ITEM_AUTH_NAME_KANA_X,
	                         LIST_ITEM_AUTH_NAME_KANA_Y, 
	                         LIST_ITEM_AUTH_NAME_KANA_W, 
	                         LIST_ITEM_AUTH_NAME_KANA_H);
	Rectangle releasedateRect(LIST_ITEM_RELEASE_DATE_X, 
							 LIST_ITEM_RELEASE_DATE_Y, 
							 LIST_ITEM_RELEASE_DATE_W, 
							 LIST_ITEM_RELEASE_DATE_H);
	Rectangle gotonewbookImageRect(LIST_ITEM_NEWBOOK_IMAGE_X, 
	                         LIST_ITEM_NEWBOOK_IMAGE_Y, 
	                         LIST_ITEM_NEWBOOK_IMAGE_W, 
	                         LIST_ITEM_NEWBOOK_IMAGE_H);//70, 153, 50
	Dimension itemDimension(itemWidth, LIST_ITEM_HEIGHT);//160

	pItem->Construct(itemDimension, style);
	
	if(!LoadBitmap(p_meta_info->datalist[index]->title_id))
		pItem->AddElement(coverImageRect, ID_BITMAP_BOOKCOVER, *__pNoImage, null, null);
	else
		pItem->AddElement(coverImageRect, ID_BITMAP_BOOKCOVER, *LoadBitmap(p_meta_info->datalist[index]->title_id), null, null);
	//pItem->SetBackgroundColor(LIST_ITEM_DRAWING_STATUS_NORMAL, 0xffffffff);
	pItem->AddElement(titlekanaRect,  ID_STRING_TITLE, 
	                                 p_meta_info->datalist[index]->title_nm,
	                                 LIST_ITEM_TITLE_KANA_TEXT_SIZE, 
	                                 Color::GetColor(COLOR_ID_WHITE), 
	                                 Color::GetColor(COLOR_ID_WHITE), 
	                                 Color::GetColor(COLOR_ID_WHITE), true);
	pItem->AddElement(authornamekanaRect, ID_STRING_AUTHOR, 
	                                 p_meta_info->datalist[index]->author_nm,
	                                 LIST_ITEM_AUTH_NAME_KANA_TEXT_SIZE, 
	                                 Color::GetColor(COLOR_ID_GREY), 
	                                 Color::GetColor(COLOR_ID_GREY), 
	                                 Color::GetColor(COLOR_ID_GREY), true);
	if(index==0)
		pItem->AddElement(bookImageRect, ID_BITMAP_RECENTLY, *__pListBottomText, null, null);
	//if(Temp_BOOK_LIST_ITEM[index].readbook==false)
	//	pItem->AddElement(gotonewbookImageRect, ID_BITMAP_NEWBOOK, *__pListNewBook, null, null);

	return pItem;
/*
	for(int i=0; i<index; i++)
	{
		delete __pBookCover[i];
		delete BOOK_LIST_ITEM[i].bookbitmap;
	}
	delete __pListBottomText;
	delete __pListNewBook;
*/
}

void
MyHondanaMainForm::OnListViewItemStateChanged(ListView& listView, int index, int elementId, ListItemStatus status)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);

	ArrayList* pList = new (std::nothrow) ArrayList();
	pList->Add(*(new (std::nothrow) Integer(index)));

	MyHondanaDetailForm* pDetailForm = new (std::nothrow) MyHondanaDetailForm;
	
	pDetailForm->__dIndex = index;
	pDetailForm->Initialize();
	pDetailForm->AddControl(*pDetailForm);
	pDetailForm->SendUserEvent(MyHondanaMainForm::REQUEST_ID_SEND, pList);

	switch(elementId)
	{
	case ID_BITMAP_NEWBOOK:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_MARKET));
		break;
	default:
		pSceneManager->GoForward(ForwardSceneTransition(SCENE_DETAIL));
		break;
	}
}

bool
MyHondanaMainForm::DeleteItem(int index, Tizen::Ui::Controls::ListItemBase* pItem, int itemWidth)
{
	delete pItem;
	pItem = null;
	return true;
}

void
MyHondanaMainForm::OnListViewItemSwept(ListView& listView, int index, SweepDirection direction)
{
}

void
MyHondanaMainForm::OnListViewContextItemStateChanged(ListView& listView, int index, int elementId, ListContextItemStatus state)
{
}

void
MyHondanaMainForm::OnListViewItemLongPressed(ListView& listView, int index, int elementId, bool& invokeListViewItemCallback)
{
}

//************************************************** Newbook Button Animation ******************************************************
result
MyHondanaMainForm::Play(void)
{
	result r = E_SUCCESS;

	int start = 0;
	int end = 1;

	IntegerAnimation animRightBottom(start, end, AnimationPropertyInfo::DEFAULT_DURATION, ANIMATION_INTERPOLATOR_LINEAR);
	_animationPropertyInfo.ApplyGlobalSettings(animRightBottom);
	(__pNewBookButton->GetControlAnimator())->StartUserAnimation(ANIMATION_TARGET_ALPHA, animRightBottom);

	return r;
}

void
MyHondanaMainForm::OnAnimationStopped(const Tizen::Ui::Control& source)
{
}

//************************************************** Sort Popup ******************************************************
void MyHondanaMainForm::CreateOptionMenu()
{
	__pOptionMenu = new (std::nothrow) OptionMenu();
	__pOptionMenu->Construct();

	CreateSortPopup();
	CreateDeletePopup();
	CreateUpdatePopup();
}

void
MyHondanaMainForm::CreateSortPopup(void)
{
	__pSortPopup = new (std::nothrow) SortPopup(this);
	__pSortPopup->Construct(false, Dimension(SORTPOPUP_WIDTH, SORTPOPUP_HEIGHT));
	__pSortPopup->SetColor(SORTPOPUP_COLOR);
}

void
MyHondanaMainForm::OnSortPopupSelected(int selectIdx)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	String date, title, author, saved;
	pAppResource->GetString("IDS_SORT_DATE", date);
	pAppResource->GetString("IDS_SORT_TITLE", title);
	pAppResource->GetString("IDS_SORT_AUTHOR", author);
	pAppResource->GetString("IDS_SORT_SAVED", saved);

	switch (selectIdx) {
	case ID_SORTMENU_DATE:
		__pSortButton->SetText(date);
		__pSortButton->SetTextSize(SORTBUTTON_TEXT_SIZE);
		__pSortButton->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
		break;
	case ID_SORTMENU_TITLE:
		__pSortButton->SetText(title);
		__pSortButton->SetTextSize(SORTBUTTON_TEXT_SIZE);
		__pSortButton->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
		break;
	case ID_SORTMENU_AUTHOR:
		__pSortButton->SetText(author);
		__pSortButton->SetTextSize(SORTBUTTON_TEXT_SIZE);
		__pSortButton->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
		break;
	case ID_SORTMENU_SAVED:
		__pSortButton->SetText(saved);
		__pSortButton->SetTextSize(SORTBUTTON_TEXT_SIZE);
		__pSortButton->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
		break;
	default:
		break;
	}
	Invalidate(true);
}
//************************************************** Option Menu : Delete Popup ******************************************************
void
MyHondanaMainForm::CreateDeletePopup(void)
{
	Rectangle clientRect= GetClientAreaBounds();
	Rectangle rect(0, 0, clientRect.width, clientRect.height);
	__pDeletePopup = new (std::nothrow) Popup();
	__pDeletePopup->Construct(true, Dimension(DELETEPOPUP_WIDTH, DELETEPOPUP_HEIGHT));

	__pDeletePopup->SetTitleText(L"削除");
	__pDeletePopup->SetTitleTextColor(Color::GetColor(COLOR_ID_WHITE));
	__pDeletePopup->SetColor(DELETEPOPUP_COLOR);

	__pDeletePopupPanel = new (std::nothrow) DeletePopupPanel(this);
	__pDeletePopupPanel->Construct(Rectangle(0, 0, clientRect.width, clientRect.height));
	__pDeletePopup->AddControl(__pDeletePopupPanel);
}

void
MyHondanaMainForm::OnDeletePanelItemSelected(int selectIdx)
{
	switch (selectIdx) {
	case 1:
		break;
	default:
		break;
	}
	HideDeletePopup();
}

void
MyHondanaMainForm::HideDeletePopup(void)
{
	__pDeletePopup->SetShowState(false);
}

//************************************************** Option Menu : Update Popup ******************************************************
void
MyHondanaMainForm::CreateUpdatePopup(void)
{
	__pUpdatePopup = new (std::nothrow) ProgressPopup();
	__pUpdatePopup->Construct(true,false);
	__pUpdatePopup->SetTitleText(L"更新中");
	switch(GetOrientationStatus())
	{
		case ORIENTATION_STATUS_PORTRAIT:
			__pUpdatePopup->SetText(L"更新しています");
			break;
		case ORIENTATION_STATUS_LANDSCAPE:
			__pUpdatePopup->SetText(L"更新しています");
			break;
		case ORIENTATION_STATUS_LANDSCAPE_REVERSE:
			__pUpdatePopup->SetText(L"更新しています");
			break;
	}
	__pUpdatePopup->AddProgressPopupEventListener(*this);
}

void
MyHondanaMainForm::OnProgressPopupCanceled(void)
{
	__pUpdatePopup->SetShowState(false);
	Invalidate(true);
}

//************************************************** Screen Backlight ******************************************************
void
MyHondanaMainForm::OnScreenOn(void)
{
//	PowerManager::KeepScreenOnState(true, false);
}

void
MyHondanaMainForm::OnScreenOff(void)
{
}

Tizen::Graphics::Bitmap*
MyHondanaMainForm::LoadBitmap(const String& fullname)
{
	result r = E_SUCCESS;
	Bitmap* pBitmap = null;
	Image* pImage = new (std::nothrow) Image();

	String mFullPath = App::GetInstance()->GetAppDataPath();
	String mFilesPath = L"files/files/thumbnail/";

	/* remove prefix 0 series */
	int i_file_name;
	Integer::Parse(fullname, i_file_name);
	String str_file_name;
	str_file_name.Append(i_file_name);
	
	mFullPath.Append(mFilesPath);
	mFullPath.Append(str_file_name);
	mFullPath.Append(L".jpg");

	TryReturn((pImage != null), null, "Failed instantiate Image object");

	r = pImage->Construct();

	if (mFullPath.EndsWith(L"jpg"))
	{
		pBitmap = pImage->DecodeN(mFullPath, BITMAP_PIXEL_FORMAT_RGB565);
	}
	else if (mFullPath.EndsWith(L"bmp"))
	{
		pBitmap = pImage->DecodeN(mFullPath, BITMAP_PIXEL_FORMAT_RGB565);
	}
	else if (mFullPath.EndsWith(L"png"))
	{
		pBitmap = pImage->DecodeN(mFullPath, BITMAP_PIXEL_FORMAT_ARGB8888);
	}
	else if (mFullPath.EndsWith(L"gif"))
	{
		pBitmap = pImage->DecodeN(mFullPath, BITMAP_PIXEL_FORMAT_RGB565);
	}
	delete pImage;

	return pBitmap;
}

void
MyHondanaMainForm::OnUserEventReceivedN(RequestId requestId, IList *pArgs)
{
	File file;

	AppLog ("OnUserEventReceivedN");
	String *pMessage;
	AppLog("2");


	//	r = file.Construct(App::GetInstance()->GetAppRootPath() + L"data/jsonSample.json", "w+");
	//Read File Content into buffer
	result r = E_SUCCESS;
	//r = file.Construct(App::GetInstance()->GetAppDataPath() + L"data/jsonSample.json", "w+");

//	TryReturnVoid(r == E_SUCCESS, "file construction failure with [%s]", GetErrorMessage(r));


	switch(requestId)
	{
		case 100:
//			pMessage = static_cast<String *>(pArgs->GetAt(0));
			AppLog("3");

//			__pEditArea->SetText(*pMessage);
//			int iMsgSize = pMessage->GetLength();
//			r = file.Write(pMessage, iMsgSize);

			Invalidate(true);
			AppLog("4");
//			ParseAndDisplay();
		case IMEI_CHECK_OK:
			AppLog("IMEI_CHECK_OK response ");
			break;
		case IMEI_CHECK_FAIL:
			AppLog("IMEI_CHECK_FAIL response ");
			break;
		break;
			
		case RES_RECEIVE_OK:
			Invalidate(true);
			DrawForm();
			AppLog("ok to receive the meta sync response ");
			break;
		case RES_RECEIVE_FAIL:
			AppLog("Fail to receive the meta sync response ");
			break;
	}
}

void
MyHondanaMainForm::OnResponseReceived(const String &responseStr)
{
	AppLog("OnResponseReceived[%d] : %ls", responseStr.GetLength(), responseStr.GetPointer());

//	__pEditArea->SetText(responseStr);
//	Invalidate(true);
}

void
MyHondanaMainForm::StartConect(const String& pUri)
{

}
