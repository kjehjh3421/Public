#include <new>
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "MyHondanaSettingForm.h"
#include "SceneRegister.h"
#include "AppResourceId.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Graphics;;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Media;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::Ui::Animations;
using namespace Tizen::Base::Collection;
using namespace Tizen::System;

const String SETTING_INFO_KEY_PREFIX = L"http://tizen.org/setting/";

MyHondanaSettingForm::MyHondanaSettingForm(void)
 	: __pSectionTableView(null)
{
}

MyHondanaSettingForm::~MyHondanaSettingForm(void)
{
	SettingInfo::RemoveSettingEventListener(*this);
}

bool
MyHondanaSettingForm::Initialize(void)
{
	Construct(L"IDF_MY_HONDANA_SETTING_FORM");
	Control::OnInitializing();

	SetOrientation(ORIENTATION_AUTOMATIC);

	//	set Event handler;
	SettingInfo::AddSettingEventListener(*this);
	AddOrientationEventListener(*this);
	SetFormBackEventListener(this);

	return true;
}

result
MyHondanaSettingForm::OnInitializing(void)
{
	result r = E_SUCCESS;
	
	InitHeader();
	InitControlPointer();
	ResizeControl();

	RotationMenu();
	BacklightMenu();
	BrightnessMenu();
	LoginMenu();
	BookmarkSharedMenu();
	DownloadSettingMenu();

	return r;
}

result
MyHondanaSettingForm::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
MyHondanaSettingForm::OnFormBackRequested(Tizen::Ui::Controls::Form& source)
{
	SceneManager* pSceneManager = SceneManager::GetInstance();
	AppAssert(pSceneManager);
	pSceneManager->GoBackward(BackwardSceneTransition());
}
//************************************************** Orientation ******************************************************
void
MyHondanaSettingForm::OnOrientationChanged(const Control &source, OrientationStatus orientationStatus)
{
	ResizeControl();
}
//************************************************** Form Base ******************************************************
void
MyHondanaSettingForm::InitHeader(void)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	// Create header
	Header  * __pHeader= GetHeader();

	String setting;
	pAppResource->GetString("IDS_HEADER_SETTING", setting);
	__pHeader->SetTitleText(setting);
}

void
MyHondanaSettingForm::InitControlPointer(void)
{
	__pSectionTableView = static_cast <SectionTableView*> (GetControl("IDC_SECTIONTABLEVIEW", true));
	__pSectionTableView->SetItemProviderF(this);
	__pSectionTableView->AddSectionTableViewItemEventListener(*this);
}

void
MyHondanaSettingForm::ResizeControl(void)
{
	Header * __pHeader = GetHeader();
	int l	= STV_LEFT_MARGIN;
	int r 	= STV_RIGHT_MARGIN;
	int w 	= WINDOW_WIDTH;
	int P_h = WINDOW_HEIGHT - INDICATOR_HEIGHT - __pHeader->GetHeight();
	int L_h = WINDOW_HEIGHT - __pHeader->GetHeight();

	if(GetOrientationStatus()==ORIENTATION_STATUS_PORTRAIT)
		__pSectionTableView->SetBounds(l, 0, w-r, P_h);
	else
		__pSectionTableView->SetBounds(l, 0, w-r, L_h);
}
//************************************************** Section Table View ******************************************************
int
MyHondanaSettingForm::GetSectionCount(void)
{
	return STV_SECTION_COUNT;
}

int
MyHondanaSettingForm::GetItemCount(int sectionIndex)
{
	int itemCount = 0;

	switch (sectionIndex)
	{
	case STV_SECTION1:
		itemCount = STV_SECTION1_ITEM_COUNT;
		break;
	case STV_SECTION2:
		itemCount = STV_SECTION2_ITEM_COUNT;
		break;
	case STV_SECTION3:
		itemCount = STV_SECTION3_ITEM_COUNT;
		break;
	case STV_SECTION4:
		itemCount = STV_SECTION4_ITEM_COUNT;
		break;
	case STV_SECTION5:
		itemCount = STV_SECTION5_ITEM_COUNT;
		break;
	default :
		break;
	}

	return itemCount;
}

float
MyHondanaSettingForm::GetDefaultItemHeight(void)
{
	return STV_SECTION_ITEM_DEFAULT_HEIGHT;
}

TableViewItem*
MyHondanaSettingForm::CreateItem(int sectionIndex, int itemIndex, float itemWidth)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();

    TableViewAnnexStyle style = TABLE_VIEW_ANNEX_STYLE_NORMAL;
    TableViewItem* pItem = new TableViewItem();

    String titleText = L"";
    String descriptionText = L"";
    String currentSetText = L"";
    String currentValueText = L"";
    String currentStatusText = L"";

    pTitleLabel = new Label();
    pDescriptionLabel = new Label();
    pCurrentSetTextLabel = new Label();
    pCurrentValueLabel = new Label();
    pCurrentStatusLabel = new Label();

    pTitleLabel->Construct(Rectangle(0, 0, 0, 0), titleText);
    pDescriptionLabel->Construct(Rectangle(0, 0, 0, 0), descriptionText);
    pCurrentSetTextLabel->Construct(Rectangle(0, 0, 0, 0), currentSetText);
    pCurrentValueLabel->Construct(Rectangle(0, 0, 0, 0), currentValueText);
    pCurrentStatusLabel->Construct(Rectangle(0, 0, 0, 0), currentStatusText);

	if (sectionIndex % STV_SECTION_COUNT == 0)
	{
	    switch (itemIndex % STV_SECTION1_ITEM_COUNT)
	    {
	    case 0:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_DETAILED;

	    	bool t = true;
	    	bool f = false;
	    	String keyName = SETTING_INFO_KEY_PREFIX;
	    	keyName.Append("screen.rotation.auto");

	    	String rotate, currentSet, currentStatus;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_ROTATE", rotate);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_CURRENT", currentSet);
	    	if(SettingInfo::GetValue(keyName, t))
	    		pAppResource->GetString("IDS_SETTING_SCREEN_ROTATE_ENABLE", currentStatus);
	    	else if(SettingInfo::GetValue(keyName, f))
	    		pAppResource->GetString("IDS_SETTING_SCREEN_ROTATE_DISABLE", currentStatus);

	    	const wchar_t* rotate_t = rotate.GetPointer();
	    	const wchar_t* currentSet_t = currentSet.GetPointer();
	    	const wchar_t* currentStatus_t = currentStatus.GetPointer();

	    	titleText.Format(STV_FONT_LENGTH, rotate_t, itemIndex);
	        currentSetText.Format(STV_FONT_LENGTH, currentSet_t, itemIndex);
	        currentStatusText.Format(STV_FONT_LENGTH, currentStatus_t, itemIndex);

	        int stringLength = currentSet.GetLength();

	        pItem->Construct(Dimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION1_ITEM1_TITLE_X,
	        								 SECTION1_ITEM1_TITLE_Y,
	        								 SECTION1_ITEM1_TITLE_W,
	        								 SECTION1_ITEM1_TITLE_H));
	        pCurrentSetTextLabel->SetBounds(Rectangle(SECTION1_ITEM1_CURRENTSET_X,
	        										  SECTION1_ITEM1_CURRENTSET_Y,
	        										  LABEL_LEFT_MARGIN+CURRENTSET_STRING_LENGTH*stringLength,
	        										  SECTION1_ITEM1_CURRENTSET_H));
	        pCurrentStatusLabel->SetBounds(Rectangle(CURRENTSET_STRING_LENGTH*stringLength-LABEL_LEFT_MARGIN,
	        	        							 SECTION1_ITEM1_CURRENTSTATUS_Y,
	        	        							 SECTION1_ITEM1_CURRENTSTATUS_W,
	        	        							 SECTION1_ITEM1_CURRENTSTATUS_H));
	    }
	        break;
	    case 1:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_DETAILED;

	    	String backlight, backlightDesc, currentSet, currentStatus;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_BACKLIGHT", backlight);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_BACKLIGHT_DESC", backlightDesc);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_CURRENT", currentSet);
//	    	if(SettingInfo::GetValue(keyName, t))
//	    		pAppResource->GetString("IDS_SETTING_SCREEN_ROTATE_ENABLE", currentStatus);
//	    	else if(SettingInfo::GetValue(keyName, f))
	    		pAppResource->GetString("IDS_SETTING_SCREEN_BACKLIGHT_10MIN", currentStatus);

	    	const wchar_t* backlight_t = backlight.GetPointer();
	    	const wchar_t* backlightDesc_t = backlightDesc.GetPointer();
	    	const wchar_t* currentSet_t = currentSet.GetPointer();
	    	const wchar_t* currentStatus_t = currentStatus.GetPointer();

	        titleText.Format(STV_FONT_LENGTH, backlight_t, itemIndex);
	        descriptionText.Format(STV_FONT_LENGTH, backlightDesc_t, itemIndex);
	        currentSetText.Format(STV_FONT_LENGTH, currentSet_t, itemIndex);
	        currentStatusText.Format(STV_FONT_LENGTH, currentStatus_t, itemIndex);

	        int stringLength = currentSet.GetLength();

	        pItem->Construct(FloatDimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION1_ITEM2_TITLE_X,
	        								 SECTION1_ITEM2_TITLE_Y,
	        								 SECTION1_ITEM2_TITLE_W,
	        								 SECTION1_ITEM2_TITLE_H));
	        pDescriptionLabel->SetBounds(Rectangle(SECTION1_ITEM2_DESCRIPTION_X,
	        									   SECTION1_ITEM2_DESCRIPTION_Y,
	        									   SECTION1_ITEM2_DESCRIPTION_W,
	        									   SECTION1_ITEM2_DESCRIPTION_H));
	        pCurrentSetTextLabel->SetBounds(Rectangle(SECTION1_ITEM2_CURRENTSET_X,
	        										  SECTION1_ITEM2_CURRENTSET_Y,
	        										  LABEL_LEFT_MARGIN+CURRENTSET_STRING_LENGTH*stringLength,
	        										  SECTION1_ITEM2_CURRENTSET_H));
	        pCurrentStatusLabel->SetBounds(Rectangle(CURRENTSET_STRING_LENGTH*stringLength-LABEL_LEFT_MARGIN,
	        	        							 SECTION1_ITEM2_CURRENTSTATUS_Y,
	        	        							 SECTION1_ITEM2_CURRENTSTATUS_W,
	        	        							 SECTION1_ITEM2_CURRENTSTATUS_H));
	    }
	        break;
	    case 2:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_DETAILED;

	    	String brightness, currentSet, currentValue, currentStatus;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_BRIGHTNESS", brightness);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_CURRENT", currentSet);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_BRIGHTNESS_AUTO", currentValue);
//	    	if(SettingInfo::GetValue(keyName, t))
//	    		pAppResource->GetString("IDS_SETTING_SCREEN_ROTATE_ENABLE", currentStatus);
//	    	else if(SettingInfo::GetValue(keyName, f))
	    		pAppResource->GetString("IDS_SETTING_SCREEN_BRIGHTNESS_AUTO_ON", currentStatus);

			const wchar_t* brightness_t = brightness.GetPointer();
			const wchar_t* currentSet_t = currentSet.GetPointer();
			const wchar_t* currentValue_t = currentValue.GetPointer();
			const wchar_t* currentStatus_t = currentStatus.GetPointer();

			titleText.Format(STV_FONT_LENGTH, brightness_t, itemIndex);
			currentSetText.Format(STV_FONT_LENGTH, currentSet_t, itemIndex);
			currentValueText.Format(STV_FONT_LENGTH, currentValue_t, itemIndex);
			currentStatusText.Format(STV_FONT_LENGTH, currentStatus_t, itemIndex);

			int stringLength = currentSet.GetLength();

	        pItem->Construct(FloatDimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION1_ITEM3_TITLE_X,
	        								 SECTION1_ITEM3_TITLE_Y,
	        								 SECTION1_ITEM3_TITLE_W,
	        								 SECTION1_ITEM3_TITLE_H));
	        pCurrentSetTextLabel->SetBounds(Rectangle(SECTION1_ITEM3_CURRENTSET_X,
	        										  SECTION1_ITEM3_CURRENTSET_Y,
	        										  LABEL_LEFT_MARGIN+CURRENTSET_STRING_LENGTH*stringLength,
	        										  SECTION1_ITEM3_CURRENTSET_H));
	        pCurrentValueLabel->SetBounds(Rectangle(CURRENTSET_STRING_LENGTH*stringLength-LABEL_LEFT_MARGIN,
	        	        							 SECTION1_ITEM3_CURRENTVALUE_Y,
	        	        							 SECTION1_ITEM3_CURRENTVALUE_W,
	        	        							 SECTION1_ITEM3_CURRENTVALUE_H));
	        pCurrentStatusLabel->SetBounds(Rectangle(CURRENTSET_STRING_LENGTH*stringLength-LABEL_LEFT_MARGIN+SECTION1_ITEM3_CURRENTVALUE_W,
	        	        							 SECTION1_ITEM3_CURRENTSTATUS_Y,
	        	        							 SECTION1_ITEM3_CURRENTSTATUS_W,
	        	        							 SECTION1_ITEM3_CURRENTSTATUS_H));
	    }
	        break;
	    default:
	        break;
	    }
	}
	else if (sectionIndex % STV_SECTION_COUNT == 1)
	{
	    switch (itemIndex % STV_SECTION2_ITEM_COUNT)
	    {
	    case 0:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_ONOFF_SLIDING;
	    	String recent;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_RECENTLY_READBOOK", recent);

			const wchar_t* recent_t = recent.GetPointer();

			titleText.Format(STV_FONT_LENGTH, recent_t, itemIndex);

	        pItem->Construct(FloatDimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION2_ITEM1_TITLE_X,
	        								 SECTION2_ITEM1_TITLE_Y,
	        								 SECTION2_ITEM1_TITLE_W,
	        								 SECTION2_ITEM1_TITLE_H));
	    }
	        break;
	    default:
	        break;
	    }
	}
	else if (sectionIndex % STV_SECTION_COUNT == 2)
	{
	    switch (itemIndex % STV_SECTION3_ITEM_COUNT)
	    {
	    case 0:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_DETAILED;

	    	String login, loginDesc;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_LOGIN", login);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_LOGIN_DESC", loginDesc);

	    	const wchar_t* login_t = login.GetPointer();
	    	const wchar_t* loginDesc_t = loginDesc.GetPointer();

	        titleText.Format(STV_FONT_LENGTH, login_t, itemIndex);
	        descriptionText.Format(STV_FONT_LENGTH, loginDesc_t, itemIndex);

	        pItem->Construct(FloatDimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION3_ITEM1_TITLE_X,
	        								 SECTION3_ITEM1_TITLE_Y,
	        								 SECTION3_ITEM1_TITLE_W,
	        								 SECTION3_ITEM1_TITLE_H));
	        pDescriptionLabel->SetBounds(Rectangle(SECTION3_ITEM1_DESCRIPTION_X,
	        									   SECTION3_ITEM1_DESCRIPTION_Y,
	        									   SECTION3_ITEM1_DESCRIPTION_W,
	        									   SECTION3_ITEM1_DESCRIPTION_H));
	    }
	        break;
	    case 1:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_DETAILED;

	    	String bookmark, bookmarkDesc;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_BOOKMARK_SHARED", bookmark);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_BOOKMARK_SHARED_DESC", bookmarkDesc);

	    	const wchar_t* bookmark_t = bookmark.GetPointer();
	    	const wchar_t* bookmarkDesc_t = bookmarkDesc.GetPointer();

	        titleText.Format(STV_FONT_LENGTH, bookmark_t, itemIndex);
	        descriptionText.Format(STV_FONT_LENGTH, bookmarkDesc_t, itemIndex);

	        pItem->Construct(FloatDimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION3_ITEM2_TITLE_X,
	        								 SECTION3_ITEM2_TITLE_Y,
	        								 SECTION3_ITEM2_TITLE_W,
	        								 SECTION3_ITEM2_TITLE_H));
	        pDescriptionLabel->SetBounds(Rectangle(SECTION3_ITEM2_DESCRIPTION_X,
	        									   SECTION3_ITEM2_DESCRIPTION_Y,
	        									   SECTION3_ITEM2_DESCRIPTION_W,
	        									   SECTION3_ITEM2_DESCRIPTION_H));
	    }
	        break;
	    default:
	        break;
	    }
	}
	else if (sectionIndex % STV_SECTION_COUNT == 3)
	{
	    switch (itemIndex % STV_SECTION4_ITEM_COUNT)
	    {
	    case 0:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_DETAILED;

	    	String storage, storageDesc;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_STORAGE", storage);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_STORAGE_DESC", storageDesc);

	    	const wchar_t* storage_t = storage.GetPointer();
	    	const wchar_t* storageDesc_t = storageDesc.GetPointer();

	        titleText.Format(STV_FONT_LENGTH, storage_t, itemIndex);
	        descriptionText.Format(STV_FONT_LENGTH, storageDesc_t, itemIndex);

	        pItem->Construct(FloatDimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION3_ITEM2_TITLE_X,
	        								 SECTION3_ITEM2_TITLE_Y,
	        								 SECTION3_ITEM2_TITLE_W,
	        								 SECTION3_ITEM2_TITLE_H));
	        pDescriptionLabel->SetBounds(Rectangle(SECTION3_ITEM2_DESCRIPTION_X,
	        									   SECTION3_ITEM2_DESCRIPTION_Y,
	        									   SECTION3_ITEM2_DESCRIPTION_W,
	        									   SECTION3_ITEM2_DESCRIPTION_H));
	    }
	        break;
	    case 1:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_ONOFF_SLIDING;

	    	String downloadVibe, downloadVibeDesc;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_DOWNLOAD_VIBE", downloadVibe);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_DOWNLOAD_VIBE_DESC", downloadVibeDesc);

	    	const wchar_t* downloadVibe_t = downloadVibe.GetPointer();
	    	const wchar_t* downloadVibeDesc_t = downloadVibeDesc.GetPointer();

	        titleText.Format(STV_FONT_LENGTH, downloadVibe_t, itemIndex);
	        descriptionText.Format(STV_FONT_LENGTH, downloadVibeDesc_t, itemIndex);

	        pItem->Construct(FloatDimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION3_ITEM2_TITLE_X,
	        								 SECTION3_ITEM2_TITLE_Y,
	        								 SECTION3_ITEM2_TITLE_W,
	        								 SECTION3_ITEM2_TITLE_H));
	        pDescriptionLabel->SetBounds(Rectangle(SECTION3_ITEM2_DESCRIPTION_X,
	        									   SECTION3_ITEM2_DESCRIPTION_Y,
	        									   SECTION3_ITEM2_DESCRIPTION_W,
	        									   SECTION3_ITEM2_DESCRIPTION_H));
	    }
	    default:
	        break;
	    }
	}
	else if (sectionIndex % STV_SECTION_COUNT == 4)
	{
	    switch (itemIndex % STV_SECTION5_ITEM_COUNT)
	    {
	    case 0:
	    {
	        style = TABLE_VIEW_ANNEX_STYLE_DETAILED;

	    	String appInfo, appInfoDesc;
	    	pAppResource->GetString("IDS_SETTING_SCREEN_APP_INFO", appInfo);
	    	pAppResource->GetString("IDS_SETTING_SCREEN_APP_INFO_DESC", appInfoDesc);

	    	const wchar_t* appInfo_t = appInfo.GetPointer();
	    	const wchar_t* appInfoDesc_t = appInfoDesc.GetPointer();

	        titleText.Format(STV_FONT_LENGTH, appInfo_t, itemIndex);
	        descriptionText.Format(STV_FONT_LENGTH, appInfoDesc_t, itemIndex);

	        pItem->Construct(FloatDimension(itemWidth, STV_SECTION_ITEM_DEFAULT_HEIGHT), style);
	        pTitleLabel->SetBounds(Rectangle(SECTION3_ITEM2_TITLE_X,
	        								 SECTION3_ITEM2_TITLE_Y,
	        								 SECTION3_ITEM2_TITLE_W,
	        								 SECTION3_ITEM2_TITLE_H));
	        pDescriptionLabel->SetBounds(Rectangle(SECTION3_ITEM2_DESCRIPTION_X,
	        									   SECTION3_ITEM2_DESCRIPTION_Y,
	        									   SECTION3_ITEM2_DESCRIPTION_W,
	        									   SECTION3_ITEM2_DESCRIPTION_H));
	    }
	        break;
	    default:
	        break;
	    }
	}

    pTitleLabel->SetText(titleText);
    pTitleLabel->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
    pTitleLabel->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
    pTitleLabel->SetTextConfig(35, LABEL_TEXT_STYLE_NORMAL);

    pDescriptionLabel->SetText(descriptionText);
    pDescriptionLabel->SetTextColor(0xff696969);
    pDescriptionLabel->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
    pDescriptionLabel->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
    pDescriptionLabel->SetTextConfig(20, LABEL_TEXT_STYLE_NORMAL);

    pCurrentSetTextLabel->SetText(currentSetText);
    pCurrentSetTextLabel->SetTextColor(0xff696969);
    pCurrentSetTextLabel->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
    pCurrentSetTextLabel->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
    pCurrentSetTextLabel->SetTextConfig(20, LABEL_TEXT_STYLE_NORMAL);

    pCurrentValueLabel->SetText(currentValueText);
    pCurrentValueLabel->SetTextColor(0xff5555ff);
    pCurrentValueLabel->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
    pCurrentValueLabel->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
    pCurrentValueLabel->SetTextConfig(20, LABEL_TEXT_STYLE_NORMAL);

    pCurrentStatusLabel->SetText(currentStatusText);
    pCurrentStatusLabel->SetTextColor(0xff5555ff);
    pCurrentStatusLabel->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
    pCurrentStatusLabel->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
    pCurrentStatusLabel->SetTextConfig(20, LABEL_TEXT_STYLE_NORMAL);

    pItem->AddControl(pTitleLabel);
    pItem->AddControl(pDescriptionLabel);
    pItem->AddControl(pCurrentSetTextLabel);
    pItem->AddControl(pCurrentValueLabel);
    pItem->AddControl(pCurrentStatusLabel);


    return pItem;
}

void
MyHondanaSettingForm::UpdateItem(int sectionIndex, int itemIndex, TableViewItem* pItem)
{

}

bool
MyHondanaSettingForm::DeleteItem(int sectionIndex, int itemIndex, TableViewItem* pItem)
{
	delete pItem;

	return true;
}

Tizen::Base::String
MyHondanaSettingForm::GetSectionHeader(int sectionIndex)
{
	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	String headerText, screen, display, sharing, download, information;
	pAppResource->GetString("IDS_SETTING_SECTION_SCREEN", screen);
	pAppResource->GetString("IDS_SETTING_SECTION_DISPLAY", display);
	pAppResource->GetString("IDS_SETTING_SECTION_SHARING", sharing);
	pAppResource->GetString("IDS_SETTING_SECTION_DOWNLOAD", download);
	pAppResource->GetString("IDS_SETTING_SECTION_INFORMATION", information);

	switch (sectionIndex)
	{
	case 0:
		headerText = screen;
		break;
	case 1:
		headerText = display;
		break;
	case 2:
		headerText = sharing;
		break;
	case 3:
		headerText = download;
		break;
	case 4:
		headerText = information;
		break;
	default :
		break;
	}

	return headerText;
}

bool
MyHondanaSettingForm::HasSectionHeader(int sectionIndex)
{
	return true;
}

Tizen::Base::String
MyHondanaSettingForm::GetSectionFooter(int sectionIndex)
{
	return null;
}

bool
MyHondanaSettingForm::HasSectionFooter(int sectionIndex)
{
	if(sectionIndex==4)
		return true;
	else
		return false;
}

void
MyHondanaSettingForm::OnSectionTableViewItemStateChanged(Tizen::Ui::Controls::SectionTableView& tableView, int sectionIndex, int itemIndex, Tizen::Ui::Controls::TableViewItem* pItem, Tizen::Ui::Controls::TableViewItemStatus status)
{
	switch(sectionIndex)
	{
	case 0 :
		if(itemIndex==0)
			__pRotationMenu->ShowPopup();
		else if(itemIndex==1)
			__pBacklightMenu->ShowPopup();
		else if(itemIndex==2)
			__pBrightnessMenu->ShowPopup();
		break;
	case 1 :
		if(itemIndex==0)
			if(status==TABLE_VIEW_ITEM_STATUS_CHECKED)
				pTitleLabel->SetTextColor(0xff00ff00);
			else if(status==TABLE_VIEW_ITEM_STATUS_UNCHECKED)
				pTitleLabel->SetTextColor(0xffffffff);
		break;
	case 2 :
		if(itemIndex==0)
			__pLoginMenu->ShowPopup();
		else if(itemIndex==1)
			__pBookmarkSharedMenu->ShowPopup();
		break;
	case 3 :
		if(itemIndex==0)
			__pDownloadSettingMenu->ShowPopup();
		else if(itemIndex==1)
			if(status==TABLE_VIEW_ITEM_STATUS_CHECKED)
			{

			}
			else if(status==TABLE_VIEW_ITEM_STATUS_UNCHECKED)
			{

			}
		break;
	case 4 :
		if(itemIndex==0)
		{

		}
		break;
	default:
		break;
	}
}

void
MyHondanaSettingForm::OnSectionTableViewContextItemActivationStateChanged(Tizen::Ui::Controls::SectionTableView& tableView, int sectionIndex, int itemIndex, Tizen::Ui::Controls::TableViewContextItem* pContextItem, bool activated)
{
}

void
MyHondanaSettingForm::OnUserEventReceivedN(RequestId requestId, Tizen::Base::Collection::IList* pArgs)
{
//	AppLogDebug("Detail_OnUserEventReceivedN = %d", __dIndex);
//	__Indexlist = new Tizen::Base::Collection::ArrayList;
//	Integer* pInt = static_cast< Integer* >(pArgs->GetAt(0));
//	__dIndex = pInt->ToInt();
//	delete pInt;
//	AppLogDebug("Received = %d", __dIndex);
}


void
MyHondanaSettingForm::OnSceneDeactivated(const Tizen::Ui::Scenes::SceneId& currentSceneId, const Tizen::Ui::Scenes::SceneId& nextSceneId)
{
}

void
MyHondanaSettingForm::OnSceneActivatedN(const Tizen::Ui::Scenes::SceneId& previousSceneId, const Tizen::Ui::Scenes::SceneId& currentSceneId, Tizen::Base::Collection::IList* pArgs)
{
}

void
MyHondanaSettingForm::OnSettingChanged(String& key)
{
}

//************************************************** Rotation Menu ******************************************************
void
MyHondanaSettingForm::RotationMenu(void)
{
	__pRotationMenu = new (std::nothrow) RotationPopup();
	__pRotationMenu->Initialize();
}

void
MyHondanaSettingForm::OnRotationPopupSelected(int selectIdx)
{
	switch (selectIdx) {
	case 1:

		break;
	case 2:
		__pRotationMenu->SetShowState(false);
		break;
	default:
		break;
	}
	Invalidate(true);
}

//************************************************** Backlight Menu ******************************************************
void
MyHondanaSettingForm::BacklightMenu(void)
{
	__pBacklightMenu = new (std::nothrow) BacklightPopup(this);
	__pBacklightMenu->Initialize();
}

void
MyHondanaSettingForm::OnBacklightPopupSelected(int selectIdx)
{
	switch (selectIdx) {
	case 1:
		pCurrentStatusLabel->SetText("15sec");
		break;

	default:
		break;
	}
	Invalidate(true);
}

//************************************************** Brightness Menu ******************************************************
void
MyHondanaSettingForm::BrightnessMenu(void)
{
	__pBrightnessMenu = new (std::nothrow) BrightnessPopup();
	__pBrightnessMenu->Initialize();
}

void
MyHondanaSettingForm::OnBrightnessPopupSelected(int selectIdx)
{
	switch (selectIdx) {
	case 0:
		__pBrightnessMenu->SetShowState(false);
		break;
	case 1:
		__pBrightnessMenu->SetShowState(false);
		break;
	default:
		break;
	}
	Invalidate(true);
}

//************************************************** Login Menu ******************************************************
void
MyHondanaSettingForm::LoginMenu(void)
{
	__pLoginMenu = new (std::nothrow) LoginPopup();
	__pLoginMenu->Initialize();
}

void
MyHondanaSettingForm::OnLoginPopupSelected(int selectIdx)
{
	switch (selectIdx) {
	case 0:
		__pLoginMenu->SetShowState(false);
		break;
	case 1:
		__pLoginMenu->SetShowState(false);
		break;
	default:
		break;
	}
	Invalidate(true);
}

//************************************************** Bookmark Shared Menu ******************************************************
void
MyHondanaSettingForm::BookmarkSharedMenu(void)
{
	__pBookmarkSharedMenu = new (std::nothrow) BookmarkSharedPopup();
	__pBookmarkSharedMenu->Initialize();
}

void
MyHondanaSettingForm::OnBookmarkSharedPopupSelected(int selectIdx)
{
	switch (selectIdx) {
	case 0:
		__pBookmarkSharedMenu->SetShowState(false);
		break;
	case 1:
		__pBookmarkSharedMenu->SetShowState(false);
		break;
	default:
		break;
	}
	Invalidate(true);
}
//************************************************** Download Setting Menu ******************************************************
void
MyHondanaSettingForm::DownloadSettingMenu(void)
{
	__pDownloadSettingMenu = new (std::nothrow) DownloadSettingPopup();
	__pDownloadSettingMenu->Initialize();
}

void
MyHondanaSettingForm::OnDownloadSettingPopupSelected(int selectIdx)
{
	switch (selectIdx) {
	case 0:
		__pDownloadSettingMenu->SetShowState(false);
		break;
	case 1:
		__pDownloadSettingMenu->SetShowState(false);
		break;
	default:
		break;
	}
	Invalidate(true);
}
