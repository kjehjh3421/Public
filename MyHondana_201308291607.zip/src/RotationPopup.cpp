
#include "RotationPopup.h"
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "SceneRegister.h"
#include "MyHondanaSettingForm.h"
#include "AppResourceId.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Ui::Scenes;
using namespace Tizen::System;

//bool isFirstStart=true;

const String SETTING_INFO_KEY_PREFIX = L"http://tizen.org/setting/";
const String _ENABLED = L"enabled";
const String _DISABLED = L"disabled";

RotationPopup::RotationPopup(void)
{
}

RotationPopup::RotationPopup(IRotationPopupListener * pListener)
{
	__pListener = pListener;
}

RotationPopup::~RotationPopup(void)
{
	SettingInfo::RemoveSettingEventListener(*this);
}

bool
RotationPopup::Initialize(void)
{
	Construct(L"IDP_SETTING_ROTATION_POPUP");
	return true;
}

result
RotationPopup::OnInitializing(void)
{
	result r = E_SUCCESS;

	SettingInfo::AddSettingEventListener(*this);
	SetPropagatedKeyEventListener(this);

//	if(isFirstStart==true)
//	{
//		isFirstStart=false;
//	}
	SetControl();

//	InitializeValue();
	ControlSetting();
	return r;
}

result
RotationPopup::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}

void
RotationPopup::InitializeValue(void)
{
	int a;

	String keyName = SETTING_INFO_KEY_PREFIX;
	keyName.Append("screen.rotation.auto");
	if(SettingInfo::GetValue(keyName, a)==15)
		__pRotation_CheckButton_Enabled ->SetSelected(true);
	else if(SettingInfo::GetValue(keyName, a)==30)
		__pRotation_CheckButton_Disabled ->SetSelected(true);
}

void
RotationPopup::SetControl(void)
{
	__pRotation_CheckButton_Enabled = static_cast <CheckButton *>(GetControl(IDC_ROTATION_CHECKBUTTON_ENABLED, true));
	__pRotation_CheckButton_Disabled = static_cast <CheckButton *>(GetControl(IDC_ROTATION_CHECKBUTTON_DISABLED, true));
	__pRotation_Ok_Button = static_cast <Button *>(GetControl(IDC_ROTATION_BUTTON_OK, true));
	__pRotation_Cancel_Button = static_cast <Button *>(GetControl(IDC_ROTATION_BUTTON_CANCEL, true));
}

void
RotationPopup::ControlSetting(void)
{
	__pRotation_CheckButton_Enabled->SetActionId(ID_SCREEN_ROTATION_AUTO_ENABLED,
												 ID_SCREEN_ROTATION_AUTO_ENABLED,
												 ID_SCREEN_ROTATION_AUTO_ENABLED);
	__pRotation_CheckButton_Enabled->AddActionEventListener(*this);

	__pRotation_CheckButton_Disabled->SetActionId(ID_SCREEN_ROTATION_AUTO_DISABLED,
												  ID_SCREEN_ROTATION_AUTO_DISABLED,
												  ID_SCREEN_ROTATION_AUTO_DISABLED);
	__pRotation_CheckButton_Disabled->AddActionEventListener(*this);

	__pRotation_Cancel_Button->SetActionId(ID_ROTATION_CANCEL_BUTTON);
	__pRotation_Cancel_Button->AddActionEventListener(*this);

	__pRotation_Ok_Button->SetActionId(ID_ROTATION_SET_BUTTON);
	__pRotation_Ok_Button->AddActionEventListener(*this);
}

void
RotationPopup::ShowPopup(void)
{
	SetShowState(true);
	Show();
}

void
RotationPopup::HidePopup(void)
{
	SetShowState(false);
	Invalidate(true);
}

void
RotationPopup::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	String keyName = SETTING_INFO_KEY_PREFIX;
	keyName.Append("screen.rotation.auto");

	static int checkId;
	static int checkNum = 0;

	switch (actionId)
	{
		case ID_SCREEN_ROTATION_AUTO_ENABLED:
			{
				checkId = actionId;
			}
			break;
		case ID_SCREEN_ROTATION_AUTO_DISABLED:
			{
				checkId = actionId;
			}
			break;
		case ID_ROTATION_CANCEL_BUTTON:
			{
				if(checkNum == 1)
				{
					__pRotation_CheckButton_Enabled->SetSelected(true);
					__pRotation_CheckButton_Disabled->SetSelected(false);
				}
				else if(checkNum == 2)
				{
					__pRotation_CheckButton_Enabled->SetSelected(false);
					__pRotation_CheckButton_Disabled->SetSelected(true);
				}
				HidePopup();
			}
			break;
		case ID_ROTATION_SET_BUTTON:
			{
				if(__pRotation_CheckButton_Enabled->IsSelected()==true)
				{
					SettingInfo::SetValue(keyName, (checkId == ID_SCREEN_ROTATION_AUTO_ENABLED));
					checkNum = 1;
//					__pListener->OnRotationPopupSelected(1);
				}
				else if(__pRotation_CheckButton_Disabled->IsSelected()==true)
				{
					SettingInfo::SetValue(keyName, (checkId == ID_SCREEN_ROTATION_AUTO_ENABLED));
					checkNum = 2;
//					__pListener->OnRotationPopupSelected(2);
				}
				HidePopup();
			}
			break;
	}
//	RequestRedraw();
}

bool
RotationPopup::OnKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
RotationPopup::OnKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	if ((keyEventInfo.GetKeyCode() == KEY_ESC ||keyEventInfo.GetKeyCode() == KEY_BACK) && source.GetShowState() == true)
	{
		source.SetShowState(false);
	}
	return false;
}

bool
RotationPopup::OnPreviewKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
RotationPopup::OnPreviewKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
RotationPopup::TranslateKeyEventInfo(Control& source, KeyEventInfo& keyEventInfo)
{
	return false;
}

// IScreenEventListener
void
RotationPopup::OnScreenOn(void)
{

}
void
RotationPopup::OnScreenOff(void)
{
}

void
RotationPopup::OnScreenBacklightChanged(int brightness)
{
//	String brightText;

//	__pSliderBrightness->SetValue(brightness);
//	__pSliderBrightness->Draw();
//
//	brightText.Append(L"Brightness: ");
//	brightText.Append(brightness);
//	__pLabelBrightness->SetText(brightText);
//	__pLabelBrightness->Draw();
//
//	__pSliderBrightness->Show();
//	__pLabelBrightness->Show();
}

void
RotationPopup::OnSettingChanged(String& key)
{
}

void
RotationPopup::OnResultReceivedForSetValueAsync(const Tizen::Base::String& key, result r)
{
}
