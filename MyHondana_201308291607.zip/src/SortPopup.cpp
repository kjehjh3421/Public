
#include "SortPopup.h"
#include <FApp.h>
#include <FGraphics.h>
#include <FAppUiApp.h>
#include <FBase.h>
#include "SceneRegister.h"
#include "MyHondanaMainForm.h"

using namespace Tizen::App;
using namespace Tizen::Base;
using namespace Tizen::Base::Collection;
using namespace Tizen::Media;
using namespace Tizen::Ui;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;
using namespace Tizen::Ui::Scenes;

SortPopup::SortPopup(void)
{
}

SortPopup::SortPopup(ISortPopupListener * pListener)
{
	__pListener = pListener;
}

SortPopup::~SortPopup(void)
{
}

result
SortPopup::OnInitializing(void)
{
	result r = E_SUCCESS;

//	SetTitleText(L"Title");
	SetPropagatedKeyEventListener(this);

//	Rectangle rect;
//	rect = GetClientAreaBounds();

	AppResource* pAppResource = Application::GetInstance()->GetAppResource();
	String date, title, author, saved;
	pAppResource->GetString("IDS_SORT_DATE", date);
	pAppResource->GetString("IDS_SORT_TITLE", title);
	pAppResource->GetString("IDS_SORT_AUTHOR", author);
	pAppResource->GetString("IDS_SORT_SAVED", saved);


	__pBitmapSortNormal[0] = pAppResource->GetBitmapN(L"main_popup_selected_bg_normal.#.png");
	__pBitmapSortNormal[1] = pAppResource->GetBitmapN(L"main_popup_selected_bg_pressed.#.png");
	__pBitmapSortPopupbg[0] = pAppResource->GetBitmapN(L"main_popup_bg.#.png");
	__pBitmapSortPopupbg[1] = pAppResource->GetBitmapN(L"main_popup_bg_pressed.#.png");

	if(chkFirst)
	{
		__pCheckList_Date = new (std::nothrow) Button();
		__pCheckList_Date->Construct(Rectangle(0, 0, sort_button_width, sort_button_height), date);
		__pCheckList_Date->SetActionId(ID_SORT_DATE_SELECTED);
		__pCheckList_Date->SetTextSize(sort_text_size);
		__pCheckList_Date->SetPressedTextColor(0xff959595);
		__pCheckList_Date->SetTextColor(0xff323232);
		__pCheckList_Date->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
		__pCheckList_Date->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
		__pCheckList_Date->SetNormalBackgroundBitmap(*__pBitmapSortNormal[0]);
		__pCheckList_Date->SetPressedBackgroundBitmap(*__pBitmapSortPopupbg[1]);
		__pCheckList_Date->AddActionEventListener(*this);
		AddControl(*__pCheckList_Date);

		__pCheckList_Title = new (std::nothrow) Button();
		__pCheckList_Title->Construct(Rectangle(0, sort_button_height+1, sort_button_width, sort_button_height), title);
		__pCheckList_Title->SetActionId(ID_SORT_TITLE_SELECTED);
		__pCheckList_Title->SetTextSize(sort_text_size);
		__pCheckList_Title->SetTextColor(0xffbebebe);
		__pCheckList_Title->SetPressedTextColor(0xff959595);
		__pCheckList_Title->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
		__pCheckList_Title->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
		__pCheckList_Title->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);
		__pCheckList_Title->SetPressedBackgroundBitmap(*__pBitmapSortPopupbg[1]);
		__pCheckList_Title->AddActionEventListener(*this);
		AddControl(*__pCheckList_Title);

		__pCheckList_Author = new (std::nothrow) Button();
		__pCheckList_Author->Construct(Rectangle(0, (sort_button_height+1)*2, sort_button_width, sort_button_height), author);
		__pCheckList_Author->SetActionId(ID_SORT_AUTHOR_SELECTED);
		__pCheckList_Author->SetTextSize(sort_text_size);
		__pCheckList_Author->SetTextColor(0xffbebebe);
		__pCheckList_Author->SetPressedTextColor(0xff959595);
		__pCheckList_Author->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
		__pCheckList_Author->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
		__pCheckList_Author->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);
		__pCheckList_Author->SetPressedBackgroundBitmap(*__pBitmapSortPopupbg[1]);
		__pCheckList_Author->AddActionEventListener(*this);
		AddControl(*__pCheckList_Author);

		__pCheckList_Save = new (std::nothrow) Button();
		__pCheckList_Save->Construct(Rectangle(0, (sort_button_height+1)*3, sort_button_width, sort_button_height), saved);
		__pCheckList_Save->SetActionId(ID_SORT_SAVE_SELECTED);
		__pCheckList_Save->SetTextSize(34);
		__pCheckList_Save->SetTextColor(0xffbebebe);
		__pCheckList_Save->SetPressedTextColor(0xff959595);
		__pCheckList_Save->SetTextHorizontalAlignment(ALIGNMENT_CENTER);
		__pCheckList_Save->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
		__pCheckList_Save->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);
		__pCheckList_Save->SetPressedBackgroundBitmap(*__pBitmapSortPopupbg[1]);
		__pCheckList_Save->AddActionEventListener(*this);
		AddControl(*__pCheckList_Save);

		chkFirst = false;
	}
	Invalidate(true);

	return r;
}

result
SortPopup::OnTerminating(void)
{
	result r = E_SUCCESS;
	return r;
}


void
SortPopup::ShowPopup(void)
{
	SetShowState(true);
	Show();
}

void
SortPopup::HidePopup(void)
{
	SetShowState(false);
	Invalidate(true);
}

void
SortPopup::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	switch (actionId)
	{
		case ID_SORT_DATE_SELECTED:
			{
				__pCheckList_Date->SetTextColor(0xff323232);
				__pCheckList_Date->SetNormalBackgroundBitmap(*__pBitmapSortNormal[0]);

				__pCheckList_Title->SetTextColor(0xffbebebe);
				__pCheckList_Title->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Author->SetTextColor(0xffbebebe);
				__pCheckList_Author->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Save->SetTextColor(0xffbebebe);
				__pCheckList_Save->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);
				__pListener->OnSortPopupSelected(1);
			}
			break;
		case ID_SORT_TITLE_SELECTED:
			{
				__pCheckList_Date->SetTextColor(0xffbebebe);
				__pCheckList_Date->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Title->SetTextColor(0xff323232);
				__pCheckList_Title->SetNormalBackgroundBitmap(*__pBitmapSortNormal[0]);

				__pCheckList_Author->SetTextColor(0xffbebebe);
				__pCheckList_Author->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Save->SetTextColor(0xffbebebe);
				__pCheckList_Save->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);
				__pListener->OnSortPopupSelected(2);
			}
			break;
		case ID_SORT_AUTHOR_SELECTED:
			{
				__pCheckList_Date->SetTextColor(0xffbebebe);
				__pCheckList_Date->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Title->SetTextColor(0xffbebebe);
				__pCheckList_Title->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Author->SetTextColor(0xff323232);
				__pCheckList_Author->SetNormalBackgroundBitmap(*__pBitmapSortNormal[0]);

				__pCheckList_Save->SetTextColor(0xffbebebe);
				__pCheckList_Save->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);
				__pListener->OnSortPopupSelected(3);
			}
			break;
		case ID_SORT_SAVE_SELECTED:
			{
				__pCheckList_Date->SetTextColor(0xffbebebe);
				__pCheckList_Date->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Title->SetTextColor(0xffbebebe);
				__pCheckList_Title->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Author->SetTextColor(0xffbebebe);
				__pCheckList_Author->SetNormalBackgroundBitmap(*__pBitmapSortPopupbg[0]);

				__pCheckList_Save->SetTextColor(0xff323232);
				__pCheckList_Save->SetNormalBackgroundBitmap(*__pBitmapSortNormal[0]);
				__pListener->OnSortPopupSelected(4);
			}
			break;

		case ID_BUTTON_CLOSE_POPUP:
			HidePopup();
			break;

		default:
			break;
	}
	HidePopup();
}

bool
SortPopup::OnKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
SortPopup::OnKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	if ((keyEventInfo.GetKeyCode() == KEY_ESC ||keyEventInfo.GetKeyCode() == KEY_BACK) && source.GetShowState() == true)
	{
		source.SetShowState(false);
	}
	return false;
}

bool
SortPopup::OnPreviewKeyPressed(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
SortPopup::OnPreviewKeyReleased(Control& source, const KeyEventInfo& keyEventInfo)
{
	return false;
}

bool
SortPopup::TranslateKeyEventInfo(Control& source, KeyEventInfo& keyEventInfo)
{
	return false;
}
