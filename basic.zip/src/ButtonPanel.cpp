//
// Copyright (c) 2012 Samsung Electronics Co., Ltd.
//
// Licensed under the Flora License, Version 1.1 (the License);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://floralicense.org/license/
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an AS IS BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//

#include <new>
#include <FBase.h>

#include "ButtonPanel.h"

using namespace Tizen::Base;
using namespace Tizen::Ui::Controls;
using namespace Tizen::Graphics;

ButtonPanel::ButtonPanel(void)
	: __pLabel(null)
{
}

ButtonPanel::~ButtonPanel(void)
{
}

result
ButtonPanel::Initialize(const Tizen::Graphics::Rectangle& rect)
{
	return Panel::Construct(rect);
}

result
ButtonPanel::OnInitializing(void)
{
	// Create a Label
	__pLabel = new (std::nothrow) Label();
	__pLabel->Construct(Rectangle(45, 190, 600, 80), L"Button");
	__pLabel->SetName(L"Label1");
	__pLabel->SetTextVerticalAlignment(ALIGNMENT_MIDDLE);
	__pLabel->SetTextHorizontalAlignment(ALIGNMENT_LEFT);
	result r = AddControl(__pLabel);

	// Create a Button
	Button *pButton = new (std::nothrow) Button();
	pButton->Construct(Rectangle(20, 290, this->GetWidth()-40, 160));
	pButton->SetText(L"Change Text");
	pButton->SetActionId(ID_BUTTON);
	pButton->AddActionEventListener(*this);
	r = AddControl(pButton);

	return r;
}

void
ButtonPanel::OnActionPerformed(const Tizen::Ui::Control& source, int actionId)
{
	switch(actionId)
	{
	case ID_BUTTON:
		{
			__pLabel->SetText(L"Button is clicked!");
			AppLog("Button is pressed! \n");
		}
		break;
	}
	Invalidate(true);
}

